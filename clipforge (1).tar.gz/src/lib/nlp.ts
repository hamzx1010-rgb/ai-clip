export const CATEGORIES = [
  { id: 'hot', label: 'Hot takes', emoji: '🔥' },
  { id: 'funny', label: 'Funny moments', emoji: '😂' },
  { id: 'emotional', label: 'Emotional', emoji: '😢' },
  { id: 'educational', label: 'Educational', emoji: '🧠' },
  { id: 'shocking', label: 'Shocking', emoji: '😱' },
  { id: 'story', label: 'Storytelling', emoji: '🗣️' },
  { id: 'motivational', label: 'Motivational', emoji: '💪' },
  { id: 'hype', label: 'Action / Hype', emoji: '🎮' },
  { id: 'drama', label: 'Drama / Arguments', emoji: '🤬' },
] as const;

const LEX: Record<string, string[]> = {
  hot: ['honestly', 'hot take', 'unpopular', 'overrated', 'underrated', 'worst', 'best', 'never', 'always', 'nobody', 'everyone', 'wrong', 'lie', 'myth', 'truth', 'actually', 'stop', 'the problem', 'disagree', 'controversial', 'scam', 'fake', 'advice'],
  funny: ['haha', 'lol', 'funny', 'hilarious', 'joke', 'laugh', 'ridiculous', 'dumb', 'stupid', 'weird', 'no way', 'what?', 'bro', 'dude', 'literally'],
  emotional: ['cried', 'tears', 'love', 'lost', 'died', 'hurt', 'heart', 'devastated', 'miss', 'grateful', 'proud', 'alone', 'broke', 'scared', 'chills', 'family', 'mom', 'dad'],
  educational: ['how to', 'here\'s', 'the lesson', 'step', 'tip', 'secret', 'learn', 'because', 'reason', 'why', 'strategy', 'system', 'framework', 'data', 'percent', 'study', 'research', 'means', 'makes', 'hook'],
  shocking: ['crazy', 'insane', 'shocking', 'unbelievable', 'can\'t believe', 'million', 'billion', 'zero', 'wild', 'craziest', 'no way', 'what', 'exposed', 'banned', 'wait'],
  story: ['when i', 'i was', 'one day', 'the next day', 'years ago', 'story', 'then', 'suddenly', 'first', 'happened', 'remember', 'changed my life', 'emailed', 'called me'],
  motivational: ['you can', 'never give up', 'build', 'grind', 'discipline', 'dream', 'success', 'fail', 'believe', 'change', 'work', 'owned', 'future', 'win', 'goal', 'lesson', 'everything'],
  hype: ['let\'s go', 'lets go', 'clutch', 'insane', 'pog', 'no way', 'oh my god', 'omg', 'win', 'victory', 'ace', 'kill', 'destroyed', 'huge', 'massive'],
  drama: ['fight', 'beef', 'argue', 'disrespect', 'shut up', 'liar', 'fake', 'blocked', 'called out', 'exposed', 'betray', 'hate', 'drama', 'angry', 'mad'],
};

export const FILLERS = ['um', 'uh', 'uhm', 'umm', 'uhh', 'erm', 'er', 'ah', 'hmm', 'mm'];
export const SOFT_FILLERS = ['like', 'you know', 'i mean', 'sort of', 'kind of', 'basically'];
export const PROFANITY = ['fuck', 'fucking', 'shit', 'bitch', 'damn', 'ass', 'asshole', 'bastard', 'crap', 'dick', 'piss', 'hell'];

export const EMOJI_MAP: Record<string, string> = {
  money: '💰', dollars: '💵', dollar: '💵', rich: '🤑', cash: '💸', views: '👀', view: '👀', viral: '🚀', fire: '🔥', hot: '🔥',
  secret: '🤫', wrong: '❌', right: '✅', chills: '🥶', crazy: '🤯', craziest: '🤯', insane: '🤯', love: '❤️', heart: '❤️',
  laugh: '😂', funny: '😂', hook: '🪝', audience: '👥', brands: '🤝', emailed: '📧', email: '📧', question: '❓', devastated: '😭',
  cried: '😭', life: '🌱', build: '🏗️', time: '⏰', year: '📅', idea: '💡', think: '🤔', win: '🏆', winner: '🏆', lesson: '📚',
  million: '💯', zero: '0️⃣', worst: '👎', best: '👑', stop: '🛑', warning: '⚠️', podcast: '🎙️', video: '🎬', phone: '📱', eyes: '👀',
  agree: '🤝', comment: '💬', follow: '➕', boring: '😴', internet: '🌐', secretly: '🤫', owned: '🔑', rented: '🏠', brain: '🧠',
};

export const STOP = new Set('the a an and or but if then so to of in on at for with by from is are was were be been am i you he she it we they this that these those my your our their me him her us them do does did not no yes just very really can could would should will shall have has had what which who whom whose when where why how all any both each few more most other some such only own same than too s t don now here there about into over after before up down out off again further once because as until while its it\'s i\'m you\'re we\'re that\'s let\'s'.split(' '));

export function norm(w: string) {
  return w.toLowerCase().replace(/[^a-z0-9'$%]/g, '');
}

export type TextFeatures = {
  cats: Record<string, number>;
  question: boolean;
  exclaim: boolean;
  numbers: number;
  fillers: number;
  quotable: number; // short punchy sentence
  cta: boolean;
  firstPerson: boolean;
  keywordHits: string[];
  terms: string[];
};

export function textFeatures(text: string, customKeywords: string[] = []): TextFeatures {
  const t = ' ' + text.toLowerCase() + ' ';
  const cats: Record<string, number> = {};
  const terms: string[] = [];
  const tn = t.replace(/[.,!?;:"]/g, ' ');
  for (const [k, words] of Object.entries(LEX)) {
    let c = 0;
    for (const w of words) {
      const ww = w.replace(/[?]/g, '');
      if (tn.includes(' ' + ww + ' ')) { c++; if (!terms.includes(ww)) terms.push(ww); }
    }
    cats[k] = c;
  }
  const words = text.split(/\s+/).filter(Boolean);
  const fillers = words.filter((w) => FILLERS.includes(norm(w))).length;
  const numbers = (text.match(/\$?\d[\d,.]*|\b(one|two|three|five|ten|eleven|hundred|thousand|million|billion|zero)\b/gi) || []).length;
  const keywordHits = customKeywords.filter((k) => k && t.includes(k.toLowerCase()));
  return {
    cats,
    question: /\?/.test(text),
    exclaim: /!/.test(text),
    numbers,
    fillers,
    quotable: words.length >= 3 && words.length <= 12 ? 1 : 0,
    cta: /(comment|follow|subscribe|like and|share this|link in bio|part two|part 2)/i.test(text),
    firstPerson: /\b(i|my|me)\b/i.test(text),
    keywordHits,
    terms,
  };
}

export function isKeyword(word: string, custom: string[] = []): boolean {
  const n = norm(word);
  if (!n || STOP.has(n)) return false;
  if (custom.some((c) => c.toLowerCase() === n)) return true;
  if (/\d/.test(n) || n.startsWith('$')) return true;
  if (EMOJI_MAP[n]) return true;
  for (const words of Object.values(LEX)) if (words.includes(n)) return true;
  return n.length >= 8;
}

export function emojiFor(word: string): string | null {
  return EMOJI_MAP[norm(word)] ?? null;
}

export function censorWord(w: string): string | null {
  const n = norm(w);
  if (PROFANITY.includes(n)) return w[0] + '*'.repeat(Math.max(2, w.length - 2)) + (/[^a-z]$/i.test(w) ? w[w.length - 1] : '');
  return null;
}

export function makeHooks(text: string, cats: string[], seed: number): string[] {
  const pool: Record<string, string[]> = {
    hot: ['This take is going to make people mad 😬', 'Nobody wants to hear this… but it\'s true', 'Unpopular opinion incoming 🔥'],
    funny: ['I can\'t stop laughing at this 😂', 'Wait for the reaction…', 'He really said that 💀'],
    emotional: ['This one hit different 🥺', 'I wasn\'t ready for this', 'Watch till the end ❤️'],
    educational: ['Save this for later 📌', 'The one thing nobody tells you', 'This will change how you think 🧠'],
    shocking: ['You won\'t believe what happened next 😱', 'Wait… WHAT?!', 'This changes everything'],
    story: ['Storytime: this changed everything', 'The ending is crazy…', 'How it really happened 👇'],
    motivational: ['You needed to hear this today 💪', 'Read that again.', 'This is your sign'],
    hype: ['HE ACTUALLY DID IT 🤯', 'Clip of the year?', 'The chat went crazy 🔥'],
    drama: ['It got heated 😳', 'Things escalated fast…', 'Whose side are you on?'],
  };
  const out: string[] = [];
  const cs = cats.length ? cats : ['shocking', 'educational'];
  for (let i = 0; out.length < 3 && i < 12; i++) {
    const c = pool[cs[i % cs.length]] || pool.shocking;
    const h = c[(seed + i) % c.length];
    if (!out.includes(h)) out.push(h);
  }
  const q = text.split(/(?<=[.?!])\s+/).find((s) => s.includes('?') && s.length < 70);
  if (q) out[2] = q;
  return out;
}

export function makeTitle(text: string): string {
  const sentences = text.split(/(?<=[.?!])\s+/).map((s) => s.trim()).filter(Boolean);
  let best = sentences[0] || text;
  let bestScore = -1;
  for (const s of sentences) {
    const f = textFeatures(s);
    const sc = Object.values(f.cats).reduce((a, b) => a + b, 0) + (f.question ? 1 : 0) + f.numbers * 0.5 + f.quotable - f.fillers;
    if (sc > bestScore) { bestScore = sc; best = s; }
  }
  best = best.replace(/^(um|uh|so|and|but|okay)[, ]+/i, '');
  if (best.length > 64) best = best.slice(0, 61).replace(/\s\S*$/, '') + '…';
  return best.charAt(0).toUpperCase() + best.slice(1);
}

export function makeHashtags(text: string, cats: string[], platform = 'tiktok'): string[] {
  const words = text.toLowerCase().match(/[a-z]{5,}/g) || [];
  const freq: Record<string, number> = {};
  for (const w of words) if (!STOP.has(w)) freq[w] = (freq[w] || 0) + 1;
  const top = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([w]) => '#' + w);
  const catTags: Record<string, string> = { hot: '#hottake', funny: '#funny', emotional: '#emotional', educational: '#learnontiktok', shocking: '#mindblown', story: '#storytime', motivational: '#motivation', hype: '#gaming', drama: '#drama' };
  const plat: Record<string, string[]> = { tiktok: ['#fyp', '#viral'], shorts: ['#shorts'], reels: ['#reels', '#explore'], x: [], linkedin: ['#growth'], facebook: [] };
  return [...new Set([...(plat[platform] || []), ...cats.slice(0, 2).map((c) => catTags[c]).filter(Boolean), ...top])].slice(0, 8);
}

export function platformCaption(title: string, tags: string[], platform: string, handle: string): string {
  const h = handle ? (handle.startsWith('@') ? handle : '@' + handle) : '';
  switch (platform) {
    case 'x': return `${title}\n\n${tags.slice(0, 2).join(' ')}`;
    case 'linkedin': return `${title}\n\nHere's what most people miss 👇\n\nWhat's your take? ${h ? '\n\nFollow ' + h + ' for more.' : ''}\n\n${tags.slice(0, 3).join(' ')}`;
    case 'shorts': return `${title} ${tags.slice(0, 3).join(' ')}`;
    default: return `${title} 👀 ${h ? 'Follow ' + h + ' for part 2!' : ''}\n${tags.join(' ')}`;
  }
}

export function allCategoryScores(f: TextFeatures): Record<string, number> {
  return f.cats;
}

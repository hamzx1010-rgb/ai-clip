import type { AudioAnalysis } from './types';
import { percentile, smooth } from './util';

export const ANALYSIS_RATE = 16000;

/** Decode any browser-decodable media (mp4/mov/webm/mp3/wav...) to mono 16 kHz PCM */
export async function decodeToMono(file: Blob, rate = ANALYSIS_RATE): Promise<AudioBuffer> {
  const buf = await file.arrayBuffer();
  const ctx = new OfflineAudioContext(1, 1, rate);
  return await ctx.decodeAudioData(buf);
}

export function analyzeAudio(ab: AudioBuffer, onProgress?: (p: number) => void): AudioAnalysis {
  const sr = ab.sampleRate;
  const data = ab.getChannelData(0);
  const hop = 0.05;
  const hs = Math.round(sr * hop);
  const n = Math.floor(data.length / hs);
  const rmsRaw = new Float32Array(n);
  const zcr = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0, z = 0, prev = data[i * hs];
    const o = i * hs;
    for (let j = 0; j < hs; j++) {
      const x = data[o + j];
      s += x * x;
      if ((x >= 0) !== (prev >= 0)) z++;
      prev = x;
    }
    rmsRaw[i] = Math.sqrt(s / hs);
    zcr[i] = z / hs;
    if (onProgress && i % 4000 === 0) onProgress(i / n);
  }
  const p99 = percentile(rmsRaw, 0.995) || 1e-6;
  const rms = new Float32Array(n);
  for (let i = 0; i < n; i++) rms[i] = Math.min(1, rmsRaw[i] / p99);

  // onset strength (positive energy flux)
  const onset = new Float32Array(n);
  for (let i = 1; i < n; i++) onset[i] = Math.max(0, rms[i] - rms[i - 1]);

  const med = percentile(rms, 0.5);
  const p90 = percentile(rms, 0.9);
  const silenceThr = Math.max(0.035, Math.min(med * 0.45, p90 * 0.12));

  const zs = smooth(zcr, 3);
  const rs = smooth(rms, 3);
  const speech = new Uint8Array(n);
  const crowd = new Uint8Array(n);
  // broadband noise bursts (applause, laughter, cheers) have high & stable ZCR with high energy
  for (let i = 0; i < n; i++) {
    const loud = rs[i] > silenceThr;
    if (!loud) continue;
    if (zs[i] > 0.28 && rs[i] > med * 1.1) crowd[i] = 1;
    else speech[i] = 1;
  }
  // clean up crowd flags: need >= 0.5s continuous
  cleanRuns(crowd, 10);

  // silences: runs below threshold >= 0.6s
  const silences: { start: number; end: number }[] = [];
  let runStart = -1;
  for (let i = 0; i <= n; i++) {
    const quiet = i < n && rs[i] <= silenceThr;
    if (quiet && runStart < 0) runStart = i;
    if (!quiet && runStart >= 0) {
      if ((i - runStart) * hop >= 0.6) silences.push({ start: runStart * hop, end: i * hop });
      runStart = -1;
    }
  }

  // spikes: short-term energy vs local baseline
  const short = smooth(rms, 6); // ~0.6s
  const long = smooth(rms, 120); // ~12s
  const cand: { t: number; strength: number; kind: 'loud' | 'crowd' }[] = [];
  for (let i = 1; i < n - 1; i++) {
    const ratio = short[i] / (long[i] + 0.02);
    const isPeak = short[i] >= short[i - 1] && short[i] >= short[i + 1];
    if (isPeak && ratio > 1.45 && short[i] > med) {
      cand.push({ t: i * hop, strength: Math.min(1, (ratio - 1) / 1.5), kind: crowd[i] ? 'crowd' : 'loud' });
    }
  }
  // crowd runs are spikes as well
  for (let i = 0; i < n; i++) {
    if (crowd[i] && (i === 0 || !crowd[i - 1])) {
      let j = i; while (j < n && crowd[j]) j++;
      cand.push({ t: i * hop, strength: Math.min(1, 0.6 + (j - i) * hop * 0.12), kind: 'crowd' });
    }
  }
  cand.sort((a, b) => b.strength - a.strength);
  const spikes: typeof cand = [];
  for (const c of cand) if (!spikes.some((s) => Math.abs(s.t - c.t) < 3)) spikes.push(c);
  spikes.sort((a, b) => a.t - b.t);

  // waveform peaks for UI
  const P = 1200;
  const peaks = new Float32Array(P);
  const step = data.length / P;
  for (let i = 0; i < P; i++) {
    let m = 0;
    const a = Math.floor(i * step), b = Math.floor((i + 1) * step);
    for (let j = a; j < b; j += 8) { const v = Math.abs(data[j]); if (v > m) m = v; }
    peaks[i] = m;
  }
  const pk = Math.max(...peaks) || 1;
  for (let i = 0; i < P; i++) peaks[i] /= pk;

  let sum = 0;
  for (let i = 0; i < n; i++) sum += rmsRaw[i] * rmsRaw[i];
  const loudnessDb = 10 * Math.log10(sum / Math.max(1, n) + 1e-12);

  return { duration: ab.duration, hop, rms, zcr, onset, speech, crowd, spikes, silences, peaks, loudnessDb };
}

function cleanRuns(arr: Uint8Array, minLen: number) {
  let i = 0;
  while (i < arr.length) {
    if (!arr[i]) { i++; continue; }
    let j = i; while (j < arr.length && arr[j]) j++;
    if (j - i < minLen) for (let k = i; k < j; k++) arr[k] = 0;
    i = j;
  }
}

export function meanRange(arr: ArrayLike<number>, hop: number, a: number, b: number): number {
  const i0 = Math.max(0, Math.floor(a / hop)), i1 = Math.min(arr.length, Math.ceil(b / hop));
  if (i1 <= i0) return 0;
  let s = 0; for (let i = i0; i < i1; i++) s += arr[i];
  return s / (i1 - i0);
}

export function maxRange(arr: ArrayLike<number>, hop: number, a: number, b: number): number {
  const i0 = Math.max(0, Math.floor(a / hop)), i1 = Math.min(arr.length, Math.ceil(b / hop));
  let m = 0; for (let i = i0; i < i1; i++) if (arr[i] > m) m = arr[i];
  return m;
}

/** Encode AudioBuffer (or slice) to 16-bit PCM WAV */
export function encodeWav(ab: AudioBuffer, start = 0, end = ab.duration): Blob {
  const sr = ab.sampleRate;
  const ch = Math.min(2, ab.numberOfChannels);
  const s0 = Math.floor(start * sr), s1 = Math.min(ab.length, Math.floor(end * sr));
  const len = Math.max(0, s1 - s0);
  const buf = new ArrayBuffer(44 + len * ch * 2);
  const v = new DataView(buf);
  const w = (o: number, s: string) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + len * ch * 2, true); w(8, 'WAVE'); w(12, 'fmt ');
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, ch, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr * ch * 2, true); v.setUint16(32, ch * 2, true); v.setUint16(34, 16, true);
  w(36, 'data'); v.setUint32(40, len * ch * 2, true);
  const chans = Array.from({ length: ch }, (_, i) => ab.getChannelData(i));
  let o = 44;
  for (let i = s0; i < s1; i++) {
    for (let c = 0; c < ch; c++) {
      const x = Math.max(-1, Math.min(1, chans[c][i]));
      v.setInt16(o, x < 0 ? x * 0x8000 : x * 0x7fff, true);
      o += 2;
    }
  }
  return new Blob([buf], { type: 'audio/wav' });
}

/** Compute display peaks for any media blob */
export async function computePeaks(blob: Blob, count = 400): Promise<number[]> {
  try {
    const ab = await decodeToMono(blob, 8000);
    const d = ab.getChannelData(0);
    const out: number[] = [];
    const step = d.length / count;
    let mx = 1e-6;
    for (let i = 0; i < count; i++) {
      let m = 0;
      for (let j = Math.floor(i * step); j < Math.floor((i + 1) * step); j += 4) { const x = Math.abs(d[j]); if (x > m) m = x; }
      out.push(m); if (m > mx) mx = m;
    }
    return out.map((x) => x / mx);
  } catch {
    return [];
  }
}

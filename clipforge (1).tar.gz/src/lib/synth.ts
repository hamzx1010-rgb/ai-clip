// Procedural, 100% royalty-free music + SFX rendered with the Web Audio API.
import { encodeWav } from './audio';
import { seeded } from './util';

export type TrackDef = { id: string; name: string; mood: string; genre: string; bpm: number; bars: number; desc: string; color: string };

export const MUSIC: TrackDef[] = [
  { id: 'hype-trap', name: 'Night Drive Trap', mood: 'hype', genre: 'Trap', bpm: 140, bars: 8, desc: '808s, rolling hats', color: '#ff4d6d' },
  { id: 'lofi', name: 'Rainy Window Lo-Fi', mood: 'chill', genre: 'Lo-fi', bpm: 78, bars: 8, desc: 'Dusty keys, vinyl crackle', color: '#7cc6fe' },
  { id: 'emotional', name: 'Letters Home', mood: 'emotional', genre: 'Piano', bpm: 70, bars: 8, desc: 'Soft piano & strings', color: '#c3a6ff' },
  { id: 'epic', name: 'Titan Rising', mood: 'epic', genre: 'Cinematic', bpm: 90, bars: 8, desc: 'Taiko hits, big pads', color: '#ffb347' },
  { id: 'funny', name: 'Clumsy Cat', mood: 'funny', genre: 'Quirky', bpm: 120, bars: 8, desc: 'Pizzicato bounce', color: '#8affc1' },
  { id: 'horror', name: 'The Basement', mood: 'horror', genre: 'Dark Ambient', bpm: 60, bars: 4, desc: 'Drones & dissonance', color: '#9b9b9b' },
  { id: 'upbeat', name: 'Sunny Startup', mood: 'upbeat', genre: 'Corporate Pop', bpm: 115, bars: 8, desc: 'Plucks & claps', color: '#ffe066' },
  { id: 'synthwave', name: 'Neon 1986', mood: 'dramatic', genre: 'Synthwave', bpm: 100, bars: 8, desc: 'Arps & gated snare', color: '#ff5ec4' },
  { id: 'house', name: 'Rooftop House', mood: 'hype', genre: 'House', bpm: 124, bars: 8, desc: 'Four-on-the-floor', color: '#5eead4' },
  { id: 'suspense', name: 'Ticking Clock', mood: 'dramatic', genre: 'Tension', bpm: 96, bars: 4, desc: 'Pulses & ticks', color: '#f97316' },
];

export const SFX = [
  { id: 'whoosh', name: 'Whoosh', emoji: '💨' },
  { id: 'boom', name: 'Boom / Impact', emoji: '💥' },
  { id: 'riser', name: 'Riser', emoji: '📈' },
  { id: 'ding', name: 'Notification Ding', emoji: '🔔' },
  { id: 'pop', name: 'Pop', emoji: '🫧' },
  { id: 'cash', name: 'Cash Register', emoji: '💰' },
  { id: 'scratch', name: 'Vinyl Scratch', emoji: '💿' },
  { id: 'glitch', name: 'Glitch', emoji: '👾' },
  { id: 'sadtrombone', name: 'Sad Trombone', emoji: '🎺' },
  { id: 'applause', name: 'Crowd Applause', emoji: '👏' },
  { id: 'shutter', name: 'Camera Shutter', emoji: '📸' },
  { id: 'heartbeat', name: 'Heartbeat', emoji: '💓' },
  { id: 'drumroll', name: 'Drum Roll', emoji: '🥁' },
  { id: 'bruh', name: 'Bass Drop', emoji: '🔊' },
  { id: 'typing', name: 'Keyboard Typing', emoji: '⌨️' },
  { id: 'swipe', name: 'UI Swipe', emoji: '👆' },
] as const;

const cache = new Map<string, Promise<AudioBuffer>>();
const mtof = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

function noiseBuffer(ctx: BaseAudioContext, dur: number, seed = 7) {
  const b = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * dur), ctx.sampleRate);
  const d = b.getChannelData(0);
  const r = seeded(seed);
  for (let i = 0; i < d.length; i++) d[i] = r() * 2 - 1;
  return b;
}

type Ctx = OfflineAudioContext;
function env(ctx: Ctx, g: GainNode, t: number, a: number, peak: number, dcy: number, sus = 0.0001) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + a);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0001, sus), t + a + dcy);
}
function kick(ctx: Ctx, out: AudioNode, t: number, v = 1, low = 45) {
  const o = ctx.createOscillator(); const g = ctx.createGain();
  o.frequency.setValueAtTime(160, t); o.frequency.exponentialRampToValueAtTime(low, t + 0.12);
  env(ctx, g, t, 0.003, v, 0.45); o.connect(g).connect(out); o.start(t); o.stop(t + 0.6);
}
function snare(ctx: Ctx, out: AudioNode, t: number, nb: AudioBuffer, v = 0.6, dcy = 0.18) {
  const n = ctx.createBufferSource(); n.buffer = nb;
  const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 1900; f.Q.value = 0.7;
  const g = ctx.createGain(); env(ctx, g, t, 0.002, v, dcy);
  n.connect(f).connect(g).connect(out); n.start(t, Math.random() * 0.5); n.stop(t + dcy + 0.05);
  const o = ctx.createOscillator(); o.frequency.value = 190; const g2 = ctx.createGain(); env(ctx, g2, t, 0.002, v * 0.5, 0.08);
  o.connect(g2).connect(out); o.start(t); o.stop(t + 0.15);
}
function hat(ctx: Ctx, out: AudioNode, t: number, nb: AudioBuffer, v = 0.18, dcy = 0.04) {
  const n = ctx.createBufferSource(); n.buffer = nb;
  const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 7500;
  const g = ctx.createGain(); env(ctx, g, t, 0.001, v, dcy);
  n.connect(f).connect(g).connect(out); n.start(t, Math.random() * 0.5); n.stop(t + dcy + 0.03);
}
function tone(ctx: Ctx, out: AudioNode, t: number, midi: number, dur: number, type: OscillatorType, v: number, opts: { a?: number; cutoff?: number; detune?: number; glide?: number; vib?: number } = {}) {
  const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(mtof(midi), t);
  if (opts.glide) o.frequency.exponentialRampToValueAtTime(mtof(midi + opts.glide), t + dur);
  if (opts.detune) o.detune.value = opts.detune;
  if (opts.vib) { const l = ctx.createOscillator(); l.frequency.value = 5.5; const lg = ctx.createGain(); lg.gain.value = opts.vib; l.connect(lg).connect(o.frequency); l.start(t); l.stop(t + dur + 0.3); }
  const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = opts.cutoff ?? 4000;
  const g = ctx.createGain(); const a = opts.a ?? 0.005;
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + a);
  g.gain.setValueAtTime(v, t + Math.max(a, dur - 0.05)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.25);
  o.connect(f).connect(g).connect(out); o.start(t); o.stop(t + dur + 0.3);
}
function pluck(ctx: Ctx, out: AudioNode, t: number, midi: number, v: number, type: OscillatorType = 'triangle', dcy = 0.5) {
  const o = ctx.createOscillator(); o.type = type; o.frequency.value = mtof(midi);
  const g = ctx.createGain(); env(ctx, g, t, 0.004, v, dcy);
  const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.setValueAtTime(5000, t); f.frequency.exponentialRampToValueAtTime(600, t + dcy);
  o.connect(f).connect(g).connect(out); o.start(t); o.stop(t + dcy + 0.1);
}

const PROG: Record<string, number[][]> = {
  minor: [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]], // Am F C G
  sad: [[57, 60, 64], [52, 55, 59], [53, 57, 60], [48, 52, 55]], // Am Em F C
  major: [[48, 52, 55], [55, 59, 62], [57, 60, 64], [53, 57, 60]], // C G Am F
  lofi: [[50, 53, 57, 60], [55, 59, 62, 65], [48, 52, 55, 59], [45, 48, 52, 55]], // Dm7 G7 Cmaj7 Am7
  dark: [[45, 48, 51], [46, 49, 53], [45, 48, 51], [44, 47, 51]],
};

export async function renderMusic(id: string): Promise<AudioBuffer> {
  if (cache.has(id)) return cache.get(id)!;
  const p = (async () => {
    const def = MUSIC.find((m) => m.id === id) || MUSIC[0];
    const beat = 60 / def.bpm;
    const bar = beat * 4;
    const dur = bar * def.bars;
    const ctx = new OfflineAudioContext(2, Math.ceil(44100 * (dur + 0.01)), 44100);
    const master = ctx.createGain(); master.gain.value = 0.8;
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    master.connect(comp).connect(ctx.destination);
    const nb = noiseBuffer(ctx, 1);
    const drums = ctx.createGain(); drums.connect(master);
    const music = ctx.createGain(); music.connect(master);
    const rand = seeded(def.bpm * 13);
    const prog = def.mood === 'emotional' ? PROG.sad : def.mood === 'chill' ? PROG.lofi : def.mood === 'horror' ? PROG.dark : ['funny', 'upbeat'].includes(def.mood) || def.id === 'house' ? PROG.major : PROG.minor;
    for (let b = 0; b < def.bars; b++) {
      const t0 = b * bar;
      const chord = prog[b % prog.length];
      switch (def.id) {
        case 'hype-trap': {
          [0, 1.5, 2.75].forEach((x) => kick(ctx, drums, t0 + x * beat, 1, 38));
          snare(ctx, drums, t0 + 2 * beat, nb, 0.7, 0.2);
          for (let s = 0; s < 16; s++) { const roll = s >= 12 && b % 2 === 1; hat(ctx, drums, t0 + (s * beat) / 4, nb, 0.14); if (roll) hat(ctx, drums, t0 + (s * beat) / 4 + beat / 8, nb, 0.1); }
          tone(ctx, music, t0, chord[0] - 24, beat * 1.5, 'sine', 0.55, { glide: -2 });
          tone(ctx, music, t0 + beat * 2.75, chord[0] - 24, beat * 1.2, 'sine', 0.45);
          [0, 0.75, 1.5, 2.5, 3].forEach((x, k) => pluck(ctx, music, t0 + x * beat, chord[k % chord.length] + 12, 0.12, 'square', 0.25));
          break;
        }
        case 'lofi': {
          const sw = beat * 0.08;
          kick(ctx, drums, t0, 0.6); kick(ctx, drums, t0 + beat * 2.5, 0.5);
          snare(ctx, drums, t0 + beat, nb, 0.25, 0.25); snare(ctx, drums, t0 + beat * 3, nb, 0.25, 0.25);
          for (let s = 0; s < 8; s++) hat(ctx, drums, t0 + (s * beat) / 2 + (s % 2 ? sw : 0), nb, 0.06, 0.05);
          chord.forEach((m, k) => tone(ctx, music, t0 + k * 0.02, m, bar * 0.95, 'triangle', 0.08, { a: 0.08, cutoff: 1500, detune: rand() * 12 - 6 }));
          tone(ctx, music, t0, chord[0] - 12, bar * 0.9, 'sine', 0.22, { cutoff: 600 });
          [1, 2, 3, 2].forEach((k, i) => pluck(ctx, music, t0 + (i * beat) + beat * 0.5, chord[k % chord.length] + 12, 0.05, 'sine', 0.8));
          break;
        }
        case 'emotional': {
          chord.forEach((m) => tone(ctx, music, t0, m - 12, bar, 'sawtooth', 0.025, { a: 0.8, cutoff: 900, detune: 7 }));
          for (let s = 0; s < 8; s++) pluck(ctx, music, t0 + (s * beat) / 2, chord[[0, 1, 2, 1, 0, 2, 1, 2][s]] + (s > 3 ? 12 : 0), 0.12, 'sine', 1.4);
          tone(ctx, music, t0, chord[0] - 24, bar, 'sine', 0.15, { a: 0.3 });
          break;
        }
        case 'epic': {
          [0, 0.75, 1.5, 2, 3, 3.5].forEach((x, k) => kick(ctx, drums, t0 + x * beat, k === 0 ? 1 : 0.6, 60));
          snare(ctx, drums, t0 + 2 * beat, nb, 0.5, 0.4);
          chord.forEach((m) => { tone(ctx, music, t0, m, bar, 'sawtooth', 0.04, { a: 0.4, cutoff: 1800, detune: -8 }); tone(ctx, music, t0, m, bar, 'sawtooth', 0.04, { a: 0.4, cutoff: 1800, detune: 8 }); });
          tone(ctx, music, t0, chord[0] - 24, bar, 'sawtooth', 0.12, { cutoff: 300 });
          for (let s = 0; s < 8; s++) pluck(ctx, music, t0 + (s * beat) / 2, chord[s % 3] + 12, 0.05, 'sawtooth', 0.2);
          break;
        }
        case 'funny': {
          for (let s = 0; s < 4; s++) { kick(ctx, drums, t0 + s * beat, 0.35, 70); if (s % 2) snare(ctx, drums, t0 + s * beat, nb, 0.2, 0.08); }
          const mel = [0, 2, 1, 2, 0, 1, 2, 1];
          mel.forEach((k, i) => pluck(ctx, music, t0 + (i * beat) / 2, chord[k] + 12, 0.18, 'triangle', 0.15));
          [0, 2].forEach((x) => pluck(ctx, music, t0 + x * beat, chord[0] - 12, 0.3, 'triangle', 0.3));
          if (b % 4 === 3) tone(ctx, music, t0 + beat * 3.5, chord[2] + 12, beat * 0.4, 'sine', 0.12, { glide: 12 });
          break;
        }
        case 'horror': {
          tone(ctx, music, t0, 33, bar, 'sawtooth', 0.12, { a: 1.5, cutoff: 220, vib: 1 });
          tone(ctx, music, t0, 34, bar, 'sine', 0.08, { a: 2, vib: 3 });
          if (b % 2) pluck(ctx, music, t0 + beat * 2.3, 82 + Math.floor(rand() * 3), 0.05, 'sine', 3);
          kick(ctx, drums, t0, 0.5, 35); kick(ctx, drums, t0 + beat * 0.4, 0.35, 35);
          break;
        }
        case 'upbeat': {
          for (let s = 0; s < 4; s++) kick(ctx, drums, t0 + s * beat, 0.6);
          [1, 3].forEach((x) => snare(ctx, drums, t0 + x * beat, nb, 0.35, 0.12));
          for (let s = 0; s < 8; s++) hat(ctx, drums, t0 + (s * beat) / 2 + beat / 4, nb, 0.08);
          for (let s = 0; s < 8; s++) pluck(ctx, music, t0 + (s * beat) / 2, chord[s % 3] + 12, 0.09, 'square', 0.18);
          tone(ctx, music, t0, chord[0] - 12, bar * 0.95, 'triangle', 0.2);
          break;
        }
        case 'synthwave': {
          [0, 2].forEach((x) => kick(ctx, drums, t0 + x * beat, 0.8));
          [1, 3].forEach((x) => snare(ctx, drums, t0 + x * beat, nb, 0.5, 0.35));
          for (let s = 0; s < 16; s++) pluck(ctx, music, t0 + (s * beat) / 4, chord[s % 3] + (s % 8 > 3 ? 12 : 0), 0.06, 'sawtooth', 0.15);
          for (let s = 0; s < 8; s++) tone(ctx, music, t0 + (s * beat) / 2, chord[0] - 12, beat / 2 - 0.02, 'sawtooth', 0.12, { cutoff: 500 });
          chord.forEach((m) => tone(ctx, music, t0, m, bar, 'sawtooth', 0.025, { a: 0.3, cutoff: 1400, detune: 10 }));
          break;
        }
        case 'house': {
          for (let s = 0; s < 4; s++) { kick(ctx, drums, t0 + s * beat, 0.9); hat(ctx, drums, t0 + s * beat + beat / 2, nb, 0.16, 0.08); }
          [1, 3].forEach((x) => snare(ctx, drums, t0 + x * beat, nb, 0.3, 0.1));
          [0.5, 1.5, 2.5, 3.5].forEach((x) => chord.forEach((m) => pluck(ctx, music, t0 + x * beat, m + 12, 0.05, 'sawtooth', 0.22)));
          [0, 0.75, 1.5, 2.5, 3.25].forEach((x) => tone(ctx, music, t0 + x * beat, chord[0] - 12, beat * 0.3, 'square', 0.1, { cutoff: 400 }));
          break;
        }
        case 'suspense': {
          for (let s = 0; s < 8; s++) hat(ctx, drums, t0 + (s * beat) / 2, nb, s % 2 ? 0.08 : 0.16, 0.02);
          kick(ctx, drums, t0, 0.7, 40); kick(ctx, drums, t0 + beat * 2, 0.5, 40);
          for (let s = 0; s < 16; s++) tone(ctx, music, t0 + (s * beat) / 4, chord[0] - 12, beat / 4 - 0.03, 'sawtooth', 0.07, { cutoff: 700 });
          tone(ctx, music, t0, chord[1] + 12, bar, 'sine', 0.05, { a: 1, vib: 2 });
          break;
        }
      }
    }
    return await ctx.startRendering();
  })();
  cache.set(id, p);
  return p;
}

export async function renderSfx(id: string): Promise<AudioBuffer> {
  const k = 'sfx:' + id;
  if (cache.has(k)) return cache.get(k)!;
  const p = (async () => {
    const lens: Record<string, number> = { riser: 2.5, applause: 3, drumroll: 2.2, heartbeat: 1.8, sadtrombone: 2.4, typing: 1.5, bruh: 1.6, boom: 1.8 };
    const dur = lens[id] ?? 1;
    const ctx = new OfflineAudioContext(2, Math.ceil(44100 * dur), 44100);
    const out = ctx.createGain(); out.gain.value = 0.9; out.connect(ctx.destination);
    const nb = noiseBuffer(ctx, Math.max(3, dur), 11);
    const noise = (t: number, d: number, f: BiquadFilterType, freq: number, v: number, q = 1) => {
      const n = ctx.createBufferSource(); n.buffer = nb; const fl = ctx.createBiquadFilter(); fl.type = f; fl.frequency.value = freq; fl.Q.value = q;
      const g = ctx.createGain(); n.connect(fl).connect(g).connect(out); n.start(t); n.stop(t + d); return { fl, g };
    };
    switch (id) {
      case 'whoosh': { const { fl, g } = noise(0, 1, 'bandpass', 400, 1, 2); fl.frequency.setValueAtTime(300, 0); fl.frequency.exponentialRampToValueAtTime(3500, 0.35); fl.frequency.exponentialRampToValueAtTime(500, 0.9); g.gain.setValueAtTime(0.0001, 0); g.gain.exponentialRampToValueAtTime(1.2, 0.3); g.gain.exponentialRampToValueAtTime(0.0001, 0.95); break; }
      case 'swipe': { const { fl, g } = noise(0, 0.4, 'bandpass', 2000, 1, 3); fl.frequency.setValueAtTime(1200, 0); fl.frequency.exponentialRampToValueAtTime(6000, 0.2); env(ctx, g, 0, 0.05, 0.8, 0.3); break; }
      case 'boom': { kick(ctx, out, 0, 1.4, 30); const { g } = noise(0, 1.8, 'lowpass', 300, 1); env(ctx, g, 0, 0.005, 1, 1.6); break; }
      case 'riser': { const { fl, g } = noise(0, 2.5, 'bandpass', 300, 1, 4); fl.frequency.setValueAtTime(200, 0); fl.frequency.exponentialRampToValueAtTime(8000, 2.4); g.gain.setValueAtTime(0.01, 0); g.gain.exponentialRampToValueAtTime(1, 2.4); g.gain.linearRampToValueAtTime(0, 2.5); tone(ctx, out, 0, 48, 2.3, 'sawtooth', 0.12, { glide: 24, cutoff: 3000 }); break; }
      case 'ding': { pluck(ctx, out, 0, 88, 0.4, 'sine', 0.9); pluck(ctx, out, 0.12, 93, 0.35, 'sine', 0.9); break; }
      case 'pop': { const o = ctx.createOscillator(); o.frequency.setValueAtTime(900, 0); o.frequency.exponentialRampToValueAtTime(200, 0.08); const g = ctx.createGain(); env(ctx, g, 0, 0.002, 0.9, 0.1); o.connect(g).connect(out); o.start(); o.stop(0.2); break; }
      case 'cash': { pluck(ctx, out, 0, 96, 0.5, 'sine', 0.8); pluck(ctx, out, 0.02, 100, 0.3, 'sine', 0.8); const { g } = noise(0, 0.25, 'highpass', 3000, 1); env(ctx, g, 0, 0.001, 0.5, 0.2); break; }
      case 'scratch': { const { fl, g } = noise(0, 0.6, 'bandpass', 1000, 1, 5); fl.frequency.setValueAtTime(600, 0); fl.frequency.linearRampToValueAtTime(2500, 0.15); fl.frequency.linearRampToValueAtTime(500, 0.3); fl.frequency.linearRampToValueAtTime(2200, 0.45); g.gain.setValueAtTime(1, 0); g.gain.linearRampToValueAtTime(0, 0.58); break; }
      case 'glitch': { for (let i = 0; i < 10; i++) { const t = i * 0.07; tone(ctx, out, t, 40 + Math.floor(Math.random() * 50), 0.04, 'square', 0.18); } break; }
      case 'sadtrombone': { [58, 57, 56].forEach((m, i) => tone(ctx, out, i * 0.45, m, 0.4, 'sawtooth', 0.2, { cutoff: 1200 })); tone(ctx, out, 1.35, 55, 0.9, 'sawtooth', 0.2, { cutoff: 1200, vib: 6 }); break; }
      case 'applause': { for (let i = 0; i < 90; i++) { const t = Math.random() * 2.6; const { g } = noise(t, 0.05, 'bandpass', 1500 + Math.random() * 2500, 1, 1.5); env(ctx, g, t, 0.002, 0.25 + Math.random() * 0.3, 0.04); } break; }
      case 'shutter': { const a = noise(0, 0.06, 'highpass', 2000, 1); env(ctx, a.g, 0, 0.001, 0.9, 0.05); const b = noise(0.09, 0.06, 'highpass', 1500, 1); env(ctx, b.g, 0.09, 0.001, 0.7, 0.05); break; }
      case 'heartbeat': { [0, 0.25, 0.9, 1.15].forEach((t, i) => kick(ctx, out, t, i % 2 ? 0.6 : 0.9, 40)); break; }
      case 'drumroll': { for (let t = 0; t < 1.9; t += 0.045) snare(ctx, out, t, nb, 0.12 + t * 0.2, 0.06); snare(ctx, out, 1.95, nb, 0.9, 0.25); kick(ctx, out, 1.95, 1); break; }
      case 'bruh': { tone(ctx, out, 0, 40, 1.4, 'sawtooth', 0.4, { glide: -12, cutoff: 400 }); kick(ctx, out, 0, 1.2, 30); break; }
      case 'typing': { for (let t = 0; t < 1.4; t += 0.08 + Math.random() * 0.08) { const { g } = noise(t, 0.03, 'bandpass', 3000 + Math.random() * 2000, 1, 2); env(ctx, g, t, 0.001, 0.4, 0.025); } break; }
      default: pluck(ctx, out, 0, 72, 0.4, 'sine', 0.6);
    }
    return await ctx.startRendering();
  })();
  cache.set(k, p);
  return p;
}

export async function musicWavBlob(id: string, loops = 2): Promise<Blob> {
  const ab = await renderMusic(id);
  if (loops <= 1) return encodeWav(ab);
  const ctx = new OfflineAudioContext(2, ab.length * loops, ab.sampleRate);
  for (let i = 0; i < loops; i++) { const s = ctx.createBufferSource(); s.buffer = ab; s.connect(ctx.destination); s.start(i * ab.duration); }
  return encodeWav(await ctx.startRendering());
}
export async function sfxWavBlob(id: string): Promise<Blob> { return encodeWav(await renderSfx(id)); }

let previewCtx: AudioContext | null = null;
let previewSrc: AudioBufferSourceNode | null = null;
export async function previewBuffer(ab: AudioBuffer, loop = false) {
  previewCtx = previewCtx || new AudioContext();
  await previewCtx.resume();
  stopPreview();
  const s = previewCtx.createBufferSource(); s.buffer = ab; s.loop = loop; s.connect(previewCtx.destination); s.start();
  previewSrc = s;
  if (loop) setTimeout(() => { if (previewSrc === s) stopPreview(); }, 12000);
}
export function stopPreview() { try { previewSrc?.stop(); } catch { /* */ } previewSrc = null; }

export function beatTimes(id: string, duration: number): number[] {
  const def = MUSIC.find((m) => m.id === id);
  if (!def) return [];
  const b = 60 / def.bpm; const out: number[] = [];
  for (let t = 0; t < duration; t += b) out.push(t);
  return out;
}

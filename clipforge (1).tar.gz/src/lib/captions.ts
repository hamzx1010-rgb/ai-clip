import type { Word } from './types';
import { censorWord, emojiFor, isKeyword } from './nlp';
import { clamp, easing, roundRect } from './util';

export type CaptionStyle = {
  id: string;
  name: string;
  font: string;
  weight: number;
  size: number; // relative to min(W,H)
  upper: boolean;
  color: string;
  hi: string; // active word color
  kw: string; // keyword color
  stroke: string;
  strokeW: number; // relative to size
  shadow?: string;
  box?: string; // background box behind chunk
  boxActive?: string; // box behind active word
  anim: 'pop' | 'bounce' | 'none' | 'type' | 'karaoke' | 'glitch' | 'neon' | 'slide' | 'wave' | '3d';
  words: number;
  italic?: boolean;
};

export const CAPTION_STYLES: CaptionStyle[] = [
  { id: 'hormozi', name: 'Hormozi', font: 'Montserrat', weight: 900, size: 0.085, upper: true, color: '#ffffff', hi: '#ffe135', kw: '#3dff7a', stroke: '#000', strokeW: 0.16, shadow: 'rgba(0,0,0,.6)', anim: 'pop', words: 3 },
  { id: 'mrbeast', name: 'MrBeast', font: 'Luckiest Guy', weight: 400, size: 0.12, upper: true, color: '#ffffff', hi: '#ffd400', kw: '#ff3b3b', stroke: '#000', strokeW: 0.2, shadow: 'rgba(0,0,0,.8)', anim: 'bounce', words: 1 },
  { id: 'minimal', name: 'Minimal', font: 'Inter', weight: 500, size: 0.052, upper: false, color: '#ffffff', hi: '#ffffff', kw: '#ffffff', stroke: 'rgba(0,0,0,0)', strokeW: 0, shadow: 'rgba(0,0,0,.7)', anim: 'none', words: 7 },
  { id: 'karaoke', name: 'Karaoke', font: 'Poppins', weight: 800, size: 0.065, upper: false, color: 'rgba(255,255,255,.55)', hi: '#ffffff', kw: '#ffffff', stroke: '#000', strokeW: 0.1, anim: 'karaoke', words: 6 },
  { id: 'boxed', name: 'TikTok Box', font: 'Poppins', weight: 700, size: 0.06, upper: false, color: '#111111', hi: '#111111', kw: '#fe2c55', stroke: 'rgba(0,0,0,0)', strokeW: 0, box: '#ffffff', anim: 'slide', words: 5 },
  { id: 'highlight', name: 'Highlighter', font: 'Montserrat', weight: 800, size: 0.07, upper: true, color: '#ffffff', hi: '#000000', kw: '#ffffff', stroke: '#000', strokeW: 0.08, boxActive: '#7c5cff', anim: 'pop', words: 3 },
  { id: 'typewriter', name: 'Typewriter', font: 'Roboto Mono', weight: 700, size: 0.058, upper: false, color: '#f5f5f5', hi: '#00e5ff', kw: '#00e5ff', stroke: '#000', strokeW: 0.12, anim: 'type', words: 6 },
  { id: 'neon', name: 'Neon Glow', font: 'Bebas Neue', weight: 400, size: 0.1, upper: true, color: '#ffffff', hi: '#ff3df2', kw: '#3df8ff', stroke: 'rgba(0,0,0,0)', strokeW: 0, shadow: '#ff3df2', anim: 'neon', words: 3 },
  { id: 'glitch', name: 'Glitch', font: 'Anton', weight: 400, size: 0.09, upper: true, color: '#ffffff', hi: '#ffffff', kw: '#00ffd0', stroke: '#000', strokeW: 0.1, anim: 'glitch', words: 2 },
  { id: '3d', name: '3D Text', font: 'Bangers', weight: 400, size: 0.1, upper: true, color: '#ffe135', hi: '#ffffff', kw: '#ff7a00', stroke: '#1a1a1a', strokeW: 0.1, anim: '3d', words: 2 },
  { id: 'handwritten', name: 'Handwritten', font: 'Permanent Marker', weight: 400, size: 0.075, upper: false, color: '#ffffff', hi: '#ffd23f', kw: '#ff6b6b', stroke: '#000', strokeW: 0.12, anim: 'wave', words: 4 },
  { id: 'podcast', name: 'Podcast Clean', font: 'Montserrat', weight: 700, size: 0.058, upper: false, color: '#ffffff', hi: '#7cf2ff', kw: '#7cf2ff', stroke: '#000', strokeW: 0.12, anim: 'none', words: 8 },
  { id: 'iman', name: 'Yellow Punch', font: 'Anton', weight: 400, size: 0.13, upper: true, color: '#ffe600', hi: '#ffe600', kw: '#ffffff', stroke: '#000', strokeW: 0.18, anim: 'pop', words: 1 },
  { id: 'comic', name: 'Comic', font: 'Bangers', weight: 400, size: 0.09, upper: true, color: '#ffffff', hi: '#ff4d4d', kw: '#4dd2ff', stroke: '#000', strokeW: 0.22, anim: 'bounce', words: 2 },
  { id: 'cinema', name: 'Cinema Subtitle', font: 'Inter', weight: 400, size: 0.045, upper: false, color: '#fff8d6', hi: '#fff8d6', kw: '#fff8d6', stroke: 'rgba(0,0,0,0)', strokeW: 0, box: 'rgba(0,0,0,.55)', anim: 'none', words: 9, italic: true },
  { id: 'retro', name: 'Retro Arcade', font: 'Press Start 2P', weight: 400, size: 0.05, upper: true, color: '#39ff14', hi: '#ff00ff', kw: '#ffff00', stroke: '#000', strokeW: 0.25, anim: 'type', words: 3 },
  { id: 'aesthetic', name: 'lowercase aesthetic', font: 'Playfair Display', weight: 600, size: 0.065, upper: false, color: '#fff3f8', hi: '#ffb3d9', kw: '#ffb3d9', stroke: 'rgba(0,0,0,0)', strokeW: 0, shadow: 'rgba(0,0,0,.6)', anim: 'slide', words: 4, italic: true },
  { id: 'bold-red', name: 'Bold Red', font: 'Oswald', weight: 700, size: 0.085, upper: true, color: '#ffffff', hi: '#ff2d2d', kw: '#ff2d2d', stroke: '#000', strokeW: 0.14, anim: 'pop', words: 3 },
  { id: 'news', name: 'Breaking News', font: 'Oswald', weight: 600, size: 0.055, upper: true, color: '#ffffff', hi: '#ffffff', kw: '#ffde00', stroke: 'rgba(0,0,0,0)', strokeW: 0, box: '#c4001a', anim: 'slide', words: 6 },
  { id: 'bubble', name: 'Bubble Pop', font: 'Luckiest Guy', weight: 400, size: 0.08, upper: false, color: '#ffffff', hi: '#111', kw: '#ff5ea8', stroke: '#ff5ea8', strokeW: 0.14, boxActive: '#ffffff', anim: 'bounce', words: 2 },
  { id: 'wave', name: 'Wave', font: 'Poppins', weight: 900, size: 0.075, upper: true, color: '#ffffff', hi: '#8affc1', kw: '#8affc1', stroke: '#000', strokeW: 0.14, anim: 'wave', words: 3 },
  { id: 'gamer', name: 'Gamer', font: 'Bebas Neue', weight: 400, size: 0.11, upper: true, color: '#ffffff', hi: '#00ff88', kw: '#ff0055', stroke: '#000', strokeW: 0.16, shadow: '#00ff88', anim: 'glitch', words: 2 },
  { id: 'elegant', name: 'Elegant Serif', font: 'Playfair Display', weight: 800, size: 0.07, upper: false, color: '#ffffff', hi: '#e8c872', kw: '#e8c872', stroke: 'rgba(0,0,0,.6)', strokeW: 0.06, anim: 'slide', words: 4 },
  { id: 'outline', name: 'Outline Only', font: 'Anton', weight: 400, size: 0.1, upper: true, color: 'rgba(0,0,0,0)', hi: '#ffffff', kw: '#ffffff', stroke: '#ffffff', strokeW: 0.06, anim: 'karaoke', words: 3 },
];

export const FONT_LIST = ['Montserrat', 'Anton', 'Bebas Neue', 'Poppins', 'Bangers', 'Permanent Marker', 'Inter', 'Oswald', 'Playfair Display', 'Pacifico', 'Press Start 2P', 'Roboto Mono', 'Luckiest Guy', 'Caveat', 'Arial', 'Georgia', 'Impact'];

export function getStyle(id: string): CaptionStyle {
  return CAPTION_STYLES.find((s) => s.id === id) || CAPTION_STYLES[0];
}

export function ensureFonts() {
  if (!('fonts' in document)) return;
  for (const s of CAPTION_STYLES) document.fonts.load(`${s.weight} 32px "${s.font}"`).catch(() => {});
}

type Chunk = { words: Word[]; s: number; e: number };
const chunkCache = new WeakMap<Word[], Map<number, Chunk[]>>();
export function chunkWords(words: Word[], n: number): Chunk[] {
  let m = chunkCache.get(words);
  if (!m) { m = new Map(); chunkCache.set(words, m); }
  const hit = m.get(n);
  if (hit) return hit;
  const out: Chunk[] = [];
  let cur: Word[] = [];
  const flush = () => { if (cur.length) out.push({ words: cur, s: cur[0].s, e: cur[cur.length - 1].e }); cur = []; };
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    if (cur.length && w.s - cur[cur.length - 1].e > 0.7) flush();
    cur.push(w);
    if (cur.length >= n || /[.?!,]$/.test(w.w) && cur.length >= Math.min(2, n)) flush();
  }
  flush();
  m.set(n, out);
  return out;
}

export type CaptionOpts = {
  pos: 'top' | 'middle' | 'bottom';
  scale: number;
  emojis: boolean;
  keywords: boolean;
  censor: boolean;
  custom?: string[];
  maxWidth?: number;
};

export function drawCaptions(ctx: CanvasRenderingContext2D, W: number, H: number, words: Word[], t: number, st: CaptionStyle, o: CaptionOpts) {
  if (!words.length) return;
  const chunks = chunkWords(words, st.words);
  const ch = chunks.find((c) => t >= c.s - 0.05 && t <= c.e + 0.3);
  if (!ch) return;
  const base = Math.min(W, H) * st.size * o.scale * (H > W ? 1 : 0.8);
  const since = t - ch.s;
  ctx.save();
  ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  const maxW = (o.maxWidth ?? 0.86) * W;
  type Item = { text: string; w: number; size: number; active: boolean; past: boolean; kw: boolean; word: Word };
  const items: Item[] = ch.words.map((w) => {
    let text = st.upper ? w.w.toUpperCase() : w.w;
    if (st.id === 'aesthetic') text = text.toLowerCase();
    if (o.censor) { const c = censorWord(text); if (c) text = c; }
    const kw = o.keywords && isKeyword(w.w, o.custom);
    const active = t >= w.s && t < w.e + 0.02;
    const size = base * (kw && st.words > 1 ? 1.14 : 1);
    ctx.font = `${st.italic ? 'italic ' : ''}${st.weight} ${size}px "${st.font}", Impact, sans-serif`;
    return { text, w: ctx.measureText(text).width, size, active, past: t >= w.e, kw, word: w };
  });
  // typewriter: only words already started
  const visible = st.anim === 'type' ? items.filter((it) => it.word.s <= t) : items;
  if (!visible.length) { ctx.restore(); return; }
  const space = base * 0.28;
  const lines: Item[][] = [];
  let line: Item[] = [], lw = 0;
  for (const it of visible) {
    if (line.length && lw + space + it.w > maxW) { lines.push(line); line = []; lw = 0; }
    lw += (line.length ? space : 0) + it.w;
    line.push(it);
  }
  if (line.length) lines.push(line);
  const lh = base * 1.22;
  const cy = o.pos === 'top' ? H * 0.2 : o.pos === 'middle' ? H * 0.5 : H > W ? H * 0.7 : H * 0.8;
  let y0 = cy - ((lines.length - 1) * lh) / 2;

  // chunk entrance animations
  let chunkScale = 1, chunkAlpha = 1, chunkDy = 0;
  if (st.anim === 'pop') chunkScale = 0.75 + 0.25 * easing('back', since / 0.14);
  if (st.anim === 'slide') { chunkDy = (1 - easing('out', since / 0.2)) * base * 0.6; chunkAlpha = clamp(since / 0.15, 0, 1); }
  if (st.anim === 'bounce') chunkScale = 0.6 + 0.4 * easing('elastic', since / 0.35);
  ctx.globalAlpha = chunkAlpha;
  ctx.translate(W / 2, cy + chunkDy);
  ctx.scale(chunkScale, chunkScale);
  ctx.translate(-W / 2, -cy);

  // emoji above chunk
  if (o.emojis) {
    const em = ch.words.map((w) => emojiFor(w.w)).find(Boolean);
    if (em) {
      const es = base * 1.25 * (0.6 + 0.4 * easing('back', since / 0.25));
      ctx.font = `${es}px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText(em, W / 2, y0 - lh * 0.95);
    }
  }
  ctx.textAlign = 'left';
  for (const ln of lines) {
    const total = ln.reduce((a, it) => a + it.w, 0) + space * (ln.length - 1);
    let x = W / 2 - total / 2;
    if (st.box) {
      ctx.fillStyle = st.box;
      const pad = base * 0.3;
      roundRect(ctx, x - pad, y0 - lh / 2 - pad * 0.1, total + pad * 2, lh + pad * 0.2, base * 0.25);
      ctx.fill();
    }
    for (let k = 0; k < ln.length; k++) {
      const it = ln[k];
      ctx.font = `${st.italic ? 'italic ' : ''}${st.weight} ${it.size}px "${st.font}", Impact, sans-serif`;
      let dy = 0, sc = 1;
      const wSince = t - it.word.s;
      if (it.active) {
        if (st.anim === 'pop') sc = 1 + 0.12 * (1 - easing('out', wSince / 0.2)) + 0.04;
        if (st.anim === 'bounce') dy = -Math.sin(clamp(wSince / 0.25, 0, 1) * Math.PI) * base * 0.25;
      }
      if (st.anim === 'wave') dy = Math.sin(t * 6 + k * 0.9) * base * 0.08;
      let fill = st.color;
      if (st.anim === 'karaoke') fill = it.past || it.active ? st.hi : st.color;
      else if (it.active && st.words > 1) fill = st.hi;
      else if (it.kw) fill = st.kw;
      if (st.words === 1) fill = it.kw ? st.kw : st.hi;
      const cx = x + it.w / 2;
      ctx.save();
      ctx.translate(cx, y0 + dy);
      ctx.scale(sc, sc);
      if (st.boxActive && it.active) {
        ctx.fillStyle = st.boxActive;
        roundRect(ctx, -it.w / 2 - base * 0.15, -lh * 0.45, it.w + base * 0.3, lh * 0.9, base * 0.18);
        ctx.fill();
      }
      let txt = it.text;
      if (st.anim === 'type' && it.active) {
        const frac = clamp(wSince / Math.max(0.08, it.word.e - it.word.s), 0, 1);
        txt = txt.slice(0, Math.max(1, Math.ceil(txt.length * frac)));
      }
      const tx = -it.w / 2;
      if (st.anim === '3d') {
        ctx.fillStyle = '#1a1a1a';
        for (let d = Math.round(base * 0.12); d > 0; d -= 1) ctx.fillText(txt, tx + d, d);
      }
      if (st.shadow && st.anim !== 'neon') { ctx.shadowColor = st.shadow; ctx.shadowBlur = base * 0.25; ctx.shadowOffsetY = base * 0.05; }
      if (st.anim === 'neon') {
        ctx.shadowColor = it.active ? st.hi : st.kw;
        ctx.shadowBlur = base * (0.5 + 0.25 * Math.sin(t * 10));
      }
      if (st.strokeW > 0) {
        ctx.lineWidth = it.size * st.strokeW;
        ctx.strokeStyle = st.stroke;
        ctx.strokeText(txt, tx, 0);
      }
      if (st.anim === 'glitch' && (it.active || Math.random() < 0.05)) {
        const j = base * 0.05;
        ctx.shadowBlur = 0;
        ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = 'rgba(255,0,80,.8)'; ctx.fillText(txt, tx - j * (Math.random() * 2), 0);
        ctx.fillStyle = 'rgba(0,255,230,.8)'; ctx.fillText(txt, tx + j * (Math.random() * 2), 0);
        ctx.globalCompositeOperation = 'source-over';
      }
      ctx.fillStyle = fill;
      ctx.fillText(txt, tx, 0);
      if (st.id === 'outline' && (it.active || it.past)) { ctx.fillStyle = st.hi; ctx.fillText(txt, tx, 0); }
      ctx.restore();
      x += it.w + space;
    }
    y0 += lh;
  }
  ctx.restore();
}

/** Tiny preview for style picker cards */
export function drawStyleThumb(c: HTMLCanvasElement, st: CaptionStyle, t: number) {
  const ctx = c.getContext('2d')!;
  const W = c.width, H = c.height;
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, '#2b2540'); g.addColorStop(1, '#141220');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  const words: Word[] = ['this', 'changes', 'everything', 'forever'].map((w, i) => ({ w, s: i * 0.35, e: i * 0.35 + 0.33 }));
  const tt = (t % 1.8);
  drawCaptions(ctx, W, H, words, Math.min(tt, 1.39), st, { pos: 'middle', scale: 1.5, emojis: false, keywords: true, censor: false });
}

import type { FaceDetector as FD, ImageSegmenter as IS } from '@mediapipe/tasks-vision';
import type { FaceBox } from './types';

let fdPromise: Promise<FD | null> | null = null;
let segPromise: Promise<IS | null> | null = null;
const base = () => new URL(import.meta.env.BASE_URL + 'mediapipe/', location.href).href;

async function fileset() {
  const { FilesetResolver } = await import('@mediapipe/tasks-vision');
  return FilesetResolver.forVisionTasks(base() + 'wasm');
}

export function getFaceDetector(): Promise<FD | null> {
  if (!fdPromise) {
    fdPromise = (async () => {
      try {
        const { FaceDetector } = await import('@mediapipe/tasks-vision');
        const fs = await fileset();
        const make = (delegate: 'GPU' | 'CPU') => FaceDetector.createFromOptions(fs, {
          baseOptions: { modelAssetPath: base() + 'blaze_face_short_range.tflite', delegate },
          runningMode: 'IMAGE',
          minDetectionConfidence: 0.45,
        });
        try { return await make('GPU'); } catch { return await make('CPU'); }
      } catch (e) {
        console.warn('Face detector unavailable', e);
        return null;
      }
    })();
  }
  return fdPromise;
}

export async function detectFaces(src: HTMLCanvasElement | HTMLVideoElement, w: number, h: number): Promise<FaceBox[]> {
  const fd = await getFaceDetector();
  if (!fd) return [];
  try {
    const r = fd.detect(src);
    return r.detections
      .map((d) => {
        const b = d.boundingBox!;
        return { x: b.originX / w, y: b.originY / h, w: b.width / w, h: b.height / h, score: d.categories?.[0]?.score ?? 0.5 };
      })
      .filter((f) => f.w > 0.02);
  } catch {
    return [];
  }
}

export function getSegmenter(): Promise<IS | null> {
  if (!segPromise) {
    segPromise = (async () => {
      try {
        const { ImageSegmenter } = await import('@mediapipe/tasks-vision');
        const fs = await fileset();
        const make = (delegate: 'GPU' | 'CPU') => ImageSegmenter.createFromOptions(fs, {
          baseOptions: { modelAssetPath: base() + 'selfie_segmenter.tflite', delegate },
          runningMode: 'IMAGE',
          outputCategoryMask: false,
          outputConfidenceMasks: true,
        });
        try { return await make('CPU'); } catch { return await make('GPU'); }
      } catch (e) {
        console.warn('Segmenter unavailable', e);
        return null;
      }
    })();
  }
  return segPromise;
}

const maskCanvas = document.createElement('canvas');
const smallCanvas = document.createElement('canvas');
/** returns a canvas containing an alpha mask (white person / transparent bg) at 256x256 */
export function segmentToMask(seg: IS, src: CanvasImageSource, sw: number, sh: number): HTMLCanvasElement | null {
  const S = 256;
  smallCanvas.width = S; smallCanvas.height = Math.round((S * sh) / sw) || S;
  const sctx = smallCanvas.getContext('2d', { willReadFrequently: true })!;
  sctx.drawImage(src, 0, 0, smallCanvas.width, smallCanvas.height);
  let out: HTMLCanvasElement | null = null;
  try {
    const res = seg.segment(smallCanvas);
    const m = res.confidenceMasks?.[0];
    if (m) {
      const arr = m.getAsFloat32Array();
      maskCanvas.width = m.width; maskCanvas.height = m.height;
      const mctx = maskCanvas.getContext('2d')!;
      const img = mctx.createImageData(m.width, m.height);
      for (let i = 0; i < arr.length; i++) {
        const a = Math.max(0, Math.min(1, (arr[i] - 0.35) / 0.3));
        img.data[i * 4] = 255; img.data[i * 4 + 1] = 255; img.data[i * 4 + 2] = 255; img.data[i * 4 + 3] = a * 255;
      }
      mctx.putImageData(img, 0, 0);
      out = maskCanvas;
    }
    res.close?.();
  } catch (e) {
    console.warn(e);
  }
  return out;
}

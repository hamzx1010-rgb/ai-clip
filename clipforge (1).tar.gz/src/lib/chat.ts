import type { ChatAnalysis, ChatMsg } from './types';
import { seeded, smooth } from './util';

const HYPE = [/\bLUL\b/i, /\bKEKW\b/i, /\bOMEGALUL\b/i, /\bLMAO+\b/i, /\bLOL+\b/i, /😂|🤣|💀/, /\bW+\b/, /\bPOG(GERS|CHAMP)?\b/i, /\bNO WAY\b/i, /\?\?\?+/, /\bCLIP (IT|THAT)\b/i, /\bHOLY\b/i, /\bOMG\b/i, /\bSHEESH\b/i, /\bINSANE\b/i, /\bL+\b/, /🔥|😱|😭/, /\bMonkaS\b/i, /\bPogU\b/i, /\bEZ\b/];
const LABELS: [RegExp, string][] = [
  [/\bLUL\b|KEKW|OMEGALUL|LMAO|LOL|😂|🤣|💀/i, 'laughing spam (LMAO/KEKW)'],
  [/\bPOG|POGGERS|PogU|W\b|SHEESH|🔥/i, 'hype spam (POG / W)'],
  [/NO WAY|\?\?\?|HOLY|OMG|😱/i, 'shock spam (NO WAY / ???)'],
  [/CLIP (IT|THAT)/i, 'viewers asking to "clip it"'],
  [/\bL+\b|😭|monkaS/i, 'L / monkaS spam'],
];

export function parseChatLog(text: string): ChatMsg[] {
  const out: ChatMsg[] = [];
  const trimmed = text.trim();
  if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
    try {
      const j = JSON.parse(trimmed);
      const arr = Array.isArray(j) ? j : j.comments || j.messages || [];
      for (const m of arr) {
        const t = m.content_offset_seconds ?? m.time_in_seconds ?? m.t ?? m.offset ?? 0;
        const user = m.commenter?.display_name ?? m.author?.name ?? m.user ?? 'user';
        const txt = m.message?.body ?? m.message ?? m.text ?? '';
        out.push({ t: +t, user: String(user), text: String(txt), kind: classify(String(txt)) });
      }
      return out.sort((a, b) => a.t - b.t);
    } catch { /* fallthrough */ }
  }
  for (const line of text.split(/\r?\n/)) {
    // [0:12:34] user: message   |  00:12:34 user: message  | 754.2 user: message
    const m = line.match(/^\s*\[?(\d+:\d{1,2}(?::\d{1,2})?(?:\.\d+)?|\d+(?:\.\d+)?)\]?\s+<?([^:>]{1,30})>?:\s?(.*)$/);
    if (!m) continue;
    const parts = m[1].split(':').map(Number);
    const t = parts.length === 3 ? parts[0] * 3600 + parts[1] * 60 + parts[2] : parts.length === 2 ? parts[0] * 60 + parts[1] : parts[0];
    out.push({ t, user: m[2].trim(), text: m[3], kind: classify(m[3]) });
  }
  return out.sort((a, b) => a.t - b.t);
}

function classify(txt: string): ChatMsg['kind'] {
  if (/subscribed|gifted .* sub|resub/i.test(txt)) return 'sub';
  if (/donated|\$\d+|tipped/i.test(txt)) return 'donation';
  if (/raiding|raid/i.test(txt)) return 'raid';
  if (/cheer\d+|bits/i.test(txt)) return 'bits';
  return 'msg';
}

export function hypeScore(txt: string): number {
  let s = 0;
  for (const r of HYPE) if (r.test(txt)) s++;
  if (txt.length > 3 && txt === txt.toUpperCase() && /[A-Z]/.test(txt)) s += 0.5;
  return s;
}

export function analyzeChat(msgs: ChatMsg[], duration: number, bucket = 5): ChatAnalysis {
  const n = Math.max(1, Math.ceil(duration / bucket));
  const rate = new Array(n).fill(0);
  const hype = new Array(n).fill(0);
  const texts: string[][] = Array.from({ length: n }, () => []);
  for (const m of msgs) {
    const i = Math.min(n - 1, Math.floor(m.t / bucket));
    if (i < 0) continue;
    rate[i]++;
    hype[i] += hypeScore(m.text) + (m.kind && m.kind !== 'msg' ? 2 : 0);
    texts[i].push(m.text);
  }
  const base = smooth(rate, 12);
  const mean = rate.reduce((a, b) => a + b, 0) / n || 1;
  const spikes: ChatAnalysis['spikes'] = [];
  for (let i = 0; i < n; i++) {
    const ratio = rate[i] / (base[i] + mean * 0.3);
    const hr = hype[i] / Math.max(1, rate[i]);
    const strength = Math.min(1, Math.max(0, (ratio - 1.2) / 2) * 0.7 + hr * 0.25);
    if (rate[i] >= 3 && ratio > 1.5 && (i === 0 || rate[i] >= rate[i - 1]) && (i === n - 1 || rate[i] >= rate[i + 1])) {
      const joined = texts[i].join(' ');
      const label = LABELS.find(([r]) => r.test(joined))?.[1] ?? 'chat activity spike';
      const freq: Record<string, number> = {};
      for (const t of texts[i]) { const k = t.trim().slice(0, 24); freq[k] = (freq[k] || 0) + 1; }
      const top = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k]) => k);
      spikes.push({ t: i * bucket, strength: Math.max(0.3, strength), label: `${label} — ${ratio.toFixed(1)}× normal rate`, top });
    }
  }
  return { bucket, rate, hype, spikes, events: msgs.filter((m) => m.kind && m.kind !== 'msg') };
}

/** Synthetic chat that reacts to the sample VOD moments (for the demo) */
export function sampleChat(duration: number, moments: { t: number; kind: string }[]): ChatMsg[] {
  const r = seeded(42);
  const users = ['xQcFan99', 'pixelqueen', 'ttv_rico', 'NoScopeNate', 'luna_uwu', 'bigdawg', 'streamsniper', 'kappa_king', 'clipchimp', 'mod_mike', 'vibecheck', 'tacocat', 'zeroBrain', 'gg_ez', 'moonwalker'];
  const idle = ['hi chat', 'what game is next', 'first time here', 'this podcast is fire', 'facts', 'true', 'hmm', 'real', 'who is the guest?', 'lets gooo', 'audio is good today', 'agree', 'based', 'W podcast'];
  const funny = ['LMAO', 'KEKW', 'LUL LUL', '😂😂😂', 'OMEGALUL', 'LMAOOOO', '💀💀', 'bro 😂', 'I CANT 😂'];
  const shock = ['NO WAY', '???', 'NO WAYYY', 'HOLY', '😱', 'CLIP IT', 'CLIP THAT', 'W TAKE', 'POGGERS', 'W', 'WWWW', 'SHEESH', '🔥🔥'];
  const out: ChatMsg[] = [];
  for (let t = 0; t < duration; t += 0.6 + r() * 1.6) out.push({ t, user: users[Math.floor(r() * users.length)], text: idle[Math.floor(r() * idle.length)], kind: 'msg' });
  for (const m of moments) {
    const pool = m.kind === 'laugh' ? funny : shock;
    const count = 14 + Math.floor(r() * 10);
    for (let k = 0; k < count; k++) out.push({ t: m.t + 0.3 + r() * 5, user: users[Math.floor(r() * users.length)], text: pool[Math.floor(r() * pool.length)], kind: 'msg' });
  }
  out.push({ t: 38.5, user: 'bigdawg', text: 'bigdawg subscribed at Tier 1 for 6 months!', kind: 'sub' });
  out.push({ t: 71, user: 'pixelqueen', text: 'pixelqueen donated $10: that story was insane', kind: 'donation' });
  return out.sort((a, b) => a.t - b.t);
}

/** Anonymous read-only Twitch chat over IRC WebSocket */
export class TwitchChat {
  ws: WebSocket | null = null;
  channel: string;
  onMsg: (m: { user: string; text: string; kind: ChatMsg['kind'] }) => void;
  onStatus: (s: string) => void;
  constructor(channel: string, onMsg: (m: { user: string; text: string; kind: ChatMsg['kind'] }) => void, onStatus: (s: string) => void) {
    this.channel = channel; this.onMsg = onMsg; this.onStatus = onStatus;
  }
  connect() {
    const ch = this.channel.replace(/^.*twitch\.tv\//, '').replace(/[^a-z0-9_]/gi, '').toLowerCase();
    if (!ch) { this.onStatus('Invalid channel'); return; }
    const ws = new WebSocket('wss://irc-ws.chat.twitch.tv:443');
    this.ws = ws;
    ws.onopen = () => {
      ws.send('CAP REQ :twitch.tv/tags twitch.tv/commands');
      ws.send('PASS SCHMOOPIIE');
      ws.send('NICK justinfan' + Math.floor(10000 + Math.random() * 80000));
      ws.send('JOIN #' + ch);
      this.onStatus('Connected to #' + ch);
    };
    ws.onmessage = (e) => {
      for (const line of String(e.data).split('\r\n')) {
        if (!line) continue;
        if (line.startsWith('PING')) { ws.send('PONG :tmi.twitch.tv'); continue; }
        const pm = line.match(/(?:^@([^ ]*) )?:([^!]+)![^ ]+ PRIVMSG #[^ ]+ :(.*)$/);
        if (pm) {
          const tags = pm[1] || '';
          const dn = tags.match(/display-name=([^;]*)/)?.[1] || pm[2];
          const bits = /(^|;)bits=/.test(tags);
          this.onMsg({ user: dn, text: pm[3], kind: bits ? 'bits' : 'msg' });
          continue;
        }
        const un = line.match(/USERNOTICE #[^ ]+(?: :(.*))?$/);
        if (un) {
          const tags = line.split(' ')[0];
          const sys = (tags.match(/system-msg=([^;]*)/)?.[1] || 'event').replace(/\\s/g, ' ');
          const id = tags.match(/msg-id=([^;]*)/)?.[1] || '';
          this.onMsg({ user: 'system', text: sys, kind: id.includes('raid') ? 'raid' : 'sub' });
        }
      }
    };
    ws.onclose = () => this.onStatus('Disconnected');
    ws.onerror = () => this.onStatus('Connection error');
  }
  close() { this.ws?.close(); this.ws = null; }
}

export function detectStreamPlatform(url: string): { id: string; name: string; live: boolean } | null {
  const u = url.toLowerCase();
  const table: [RegExp, string, string][] = [
    [/twitch\.tv/, 'twitch', 'Twitch'], [/youtube\.com|youtu\.be/, 'youtube', 'YouTube Live'], [/kick\.com/, 'kick', 'Kick'],
    [/facebook\.com|fb\.watch/, 'facebook', 'Facebook Live'], [/instagram\.com/, 'instagram', 'Instagram Live'], [/tiktok\.com/, 'tiktok', 'TikTok Live'],
    [/(twitter|x)\.com\/i\/spaces/, 'spaces', 'X Spaces'], [/discord\.(gg|com)/, 'discord', 'Discord Stage'], [/rumble\.com/, 'rumble', 'Rumble'],
  ];
  for (const [r, id, name] of table) if (r.test(u)) return { id, name, live: !/videos\/|\/v\/|vod|watch\?v=/.test(u) };
  return null;
}

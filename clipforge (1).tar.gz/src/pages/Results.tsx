import { useEffect, useMemo, useRef, useState } from 'react';
import { zipSync } from 'fflate';
import { ArrowLeft, Copy, Download, Pause, Play, Scissors, Sparkles, Wand2, RotateCcw, Music2, Check, Volume2 } from 'lucide-react';
import { useApp, PLATFORMS, type ClipSession } from '../store';
import type { Clip, ClipRenderOptions } from '../lib/types';
import { ClipEngine, GRADES, clipThumb, optsFor, reframeFor } from '../lib/clipRender';
import { CaptionStylePicker, Empty, MiniBar, Modal, ScoreRing, Seg, Slider, Toggle, Waveform } from '../components/ui';
import { CATEGORIES, makeHashtags, platformCaption, isKeyword } from '../lib/nlp';
import { reasoningSentence, wordsInRange } from '../lib/engine';
import { MUSIC, renderMusic, previewBuffer, stopPreview } from '../lib/synth';
import { extFor } from '../lib/recorder';
import { chunkWords } from '../lib/captions';
import { download, fmtTime, slug, uid, clamp } from '../lib/util';

type Tab = 'why' | 'captions' | 'hook' | 'edit' | 'audio' | 'brand' | 'publish';
type Aspect = ClipRenderOptions['aspect'];

export default function Results({ sessionId }: { sessionId: string }) {
  const { sessions, go, updateSession, setPendingEditorImport } = useApp();
  const session = sessions.find((s) => s.id === sessionId);
  const [selId, setSelId] = useState<string | null>(session?.clips[0]?.id ?? null);
  const [tab, setTab] = useState<Tab>('why');
  const [thumbs, setThumbs] = useState<Record<string, string>>({});
  const [filterCat, setFilterCat] = useState('');
  const [minScore, setMinScore] = useState(0);
  const [exportOpen, setExportOpen] = useState(false);

  useEffect(() => {
    if (!session) return;
    let dead = false;
    (async () => {
      for (const c of session.clips.slice(0, 60)) {
        if (dead) return;
        const o = optsFor(session.options, c);
        const key = `${c.id}|${o.aspect}|${o.reframe}`;
        if (thumbs[key]) continue;
        try {
          const t = await clipThumb(session.url, c, session.visual, session.transcript, o.aspect, o.reframe);
          if (!dead) setThumbs((m) => ({ ...m, [key]: t }));
        } catch { /* */ }
      }
    })();
    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session?.id, session?.clips.map((c) => `${c.aspect}${c.reframe}`).join()]);

  if (!session) return <div className="page"><Empty icon="🤷" title="Session not found">Clip sessions live in memory — they reset when the page reloads. <button className="btn sm mt8" onClick={() => go({ name: 'clip-video' })}>Start a new one</button></Empty></div>;
  const clip = session.clips.find((c) => c.id === selId) || session.clips[0];
  const setOpts = (p: Partial<ClipRenderOptions>) => updateSession(session.id, { options: { ...session.options, ...p } });
  const setClip = (p: Partial<Clip>) => updateSession(session.id, { clips: session.clips.map((c) => (c.id === clip.id ? { ...c, ...p } : c)) });
  const layout = optsFor(session.options, clip);
  const setAspect = (a: Aspect, all = false) => updateSession(session.id, {
    clips: session.clips.map((c) => (all || c.id === clip.id ? { ...c, aspect: a, reframe: reframeFor(a, c, session.visual, session.width, session.height), layoutWhy: 'Set by you' } : c)),
  });
  const thumbOf = (c: Clip) => { const o = optsFor(session.options, c); return thumbs[`${c.id}|${o.aspect}|${o.reframe}`]; };
  const visible = session.clips.filter((c) => (!filterCat || c.categories.includes(filterCat)) && c.score >= minScore);
  const avg = Math.round(session.clips.reduce((a, c) => a + c.score, 0) / Math.max(1, session.clips.length));

  const openInEditor = (c: Clip) => {
    const words = wordsInRange(session.transcript, c.start, c.end);
    const chunks = chunkWords(words, 3).map((ch) => ({ text: ch.words.map((w) => w.w).join(' '), start: ch.s - c.start, end: ch.e - c.start }));
    setPendingEditorImport({ url: session.url, name: c.title, start: c.start, end: c.end, captions: chunks, aspect: optsFor(session.options, c).aspect, file: session.file });
    go({ name: 'editor' });
  };


  return (
    <div className="page" style={{ maxWidth: 1500 }}>
      <div className="page-head">
        <div>
          <button className="btn ghost sm" onClick={() => go({ name: session.mode === 'stream' ? 'clip-stream' : 'clip-video' })}><ArrowLeft size={14} /> New job</button>
          <h1 className="mt8">{session.name}</h1>
          <div className="row muted small wrap">
            <span>{fmtTime(session.duration)} source</span>·<span>{session.clips.length} clips</span>·<span>avg virality <b style={{ color: 'var(--text)' }}>{avg}</b></span>·
            <span>{session.transcript ? `transcript: ${session.transcript.source}` : 'no transcript'}</span>·<span>faces: {session.visual?.faceEngine ?? 'n/a'}</span>
            {session.chat && <>·<span>{session.chat.spikes.length} chat explosions</span></>}
          </div>
        </div>
        <div className="row">
          <button className="btn glow" onClick={() => setExportOpen(true)}><Download size={16} /> Export clips</button>
        </div>
      </div>

      {session.audio && (
        <div className="card tight mb8" style={{ marginBottom: 16 }}>
          <div className="row between small mb8"><span className="section-title" style={{ margin: 0 }}>Source overview — clips, audio spikes {session.chat ? '& chat explosions' : ''}</span><span className="dim tiny">click a highlighted range to open that clip</span></div>
          <Waveform peaks={session.audio.peaks} h={54}
            ranges={session.clips.map((c) => ({ a: c.start / session.duration, b: c.end / session.duration, color: c.id === clip?.id ? '#7c5cff66' : '#7c5cff22' }))}
            markers={[...session.audio.spikes.map((s) => ({ x: s.t / session.duration, color: s.kind === 'crowd' ? '#3ddc97' : '#ffd23f88' })), ...(session.chat?.spikes || []).map((s) => ({ x: s.t / session.duration, color: '#ff4fa3' }))]}
            onSeek={(x) => { const t = x * session.duration; const c = session.clips.find((k) => t >= k.start && t <= k.end); if (c) setSelId(c.id); }} />
          <div className="row gap16 tiny dim mt8"><span>■ <span style={{ color: '#7c5cff' }}>clips</span></span><span style={{ color: '#3ddc97' }}>| crowd reaction</span><span style={{ color: '#ffd23f' }}>| volume spike</span>{session.chat && <span style={{ color: '#ff4fa3' }}>| chat spike</span>}</div>
        </div>
      )}

      {!clip ? <Empty icon="🔍" title="No clips found">Try a lower minimum length or different content types.</Empty> : (
        <div className="grid" style={{ gridTemplateColumns: '320px minmax(300px, 400px) minmax(0, 1fr)', alignItems: 'start' }}>
          <div className="col gap6" style={{ maxHeight: 'calc(100vh - 150px)', overflow: 'auto', paddingRight: 4, position: 'sticky', top: 12 }}>
            <div className="row gap6 wrap">
              <select className="input sm" style={{ width: 'auto' }} value={filterCat} onChange={(e) => setFilterCat(e.target.value)}>
                <option value="">All types</option>{CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.emoji} {c.label}</option>)}
              </select>
              <select className="input sm" style={{ width: 'auto' }} value={minScore} onChange={(e) => setMinScore(+e.target.value)}>
                <option value={0}>Any score</option><option value={70}>70+</option><option value={80}>80+</option><option value={90}>90+</option>
              </select>
            </div>
            {visible.map((c, i) => (
              <div key={c.id} className={'clip-card' + (c.id === clip.id ? ' sel' : '')} onClick={() => setSelId(c.id)}>
                <div className="thumb" style={{ backgroundImage: thumbOf(c) ? `url(${thumbOf(c)})` : undefined, backgroundSize: 'contain', backgroundRepeat: 'no-repeat', backgroundColor: '#000' }}>
                  {!thumbOf(c) && <div className="spin" style={{ margin: '48px auto' }} />}
                  <span className="dur">{fmtTime(c.end - c.start)}</span>
                </div>
                <div className="col grow gap4" style={{ minWidth: 0 }}>
                  <div className="row between" style={{ alignItems: 'flex-start' }}>
                    <span className="dim tiny">#{i + 1} · {fmtTime(c.start)}–{fmtTime(c.end)}</span>
                    <ScoreRing score={c.score} size={40} stroke={4} />
                  </div>
                  <b style={{ fontSize: 13, lineHeight: 1.3 }}>{c.title}</b>
                  <div className="row wrap gap4">
                    {c.categories.slice(0, 2).map((k) => { const cat = CATEGORIES.find((x) => x.id === k); return cat ? <span key={k} className="badge">{cat.emoji} {cat.label}</span> : null; })}
                    <span className="badge" title={c.layoutWhy}>{optsFor(session.options, c).aspect === '16:9' ? '▭ 16:9 full' : optsFor(session.options, c).aspect === '9:16' ? '▯ 9:16' : optsFor(session.options, c).aspect}</span>
                    {c.part && <span className="badge brand">Part {c.part.n}/{c.part.of}</span>}
                    {c.keywordHits.length > 0 && <span className="badge ok">🔑 {c.keywordHits[0]}</span>}
                    {session.exported.includes(c.id) && <span className="badge ok"><Check size={10} /> exported</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ position: 'sticky', top: 12 }}>
            <ClipPreview session={session} clip={clip} />
            <div className="row center mt8 gap6">
              <Seg value={layout.aspect} options={[{ v: '16:9', l: '▭ 16:9' }, { v: '9:16', l: '▯ 9:16' }, { v: '1:1', l: '1:1' }, { v: '4:5', l: '4:5' }]} onChange={(v) => setAspect(v)} />
            </div>
            <div className="dim tiny mt8" style={{ textAlign: 'center' }}>
              {clip.layoutWhy && <>{clip.layoutWhy}<br /></>}
              <a href="#" onClick={(e) => { e.preventDefault(); setAspect(layout.aspect, true); }}>Use {layout.aspect} for all clips</a>
            </div>
            <div className="row center mt8 gap6">
              <button className="btn sm" onClick={() => openInEditor(clip)}><Wand2 size={14} /> Open in editor</button>
              <button className="btn sm" onClick={() => setExportOpen(true)}><Download size={14} /> Export</button>
            </div>
          </div>

          <div className="card" style={{ padding: 0, minWidth: 0 }}>
            <div style={{ padding: 10, borderBottom: '1px solid var(--line)', overflowX: 'auto' }}>
              <div className="tabs" style={{ width: 'max-content' }}>
                {([['why', '🧠 Why viral'], ['captions', '💬 Captions'], ['hook', '🪝 Hook'], ['edit', '✂️ Edit'], ['audio', '🎵 Audio'], ['brand', '🏷️ Overlays'], ['publish', '📋 Post text']] as [Tab, string][]).map(([k, l]) => (
                  <div key={k} className={'tab' + (tab === k ? ' on' : '')} onClick={() => setTab(k)}>{l}</div>
                ))}
              </div>
            </div>
            <div style={{ padding: 18 }}>
              {tab === 'why' && <WhyTab clip={clip} session={session} />}
              {tab === 'captions' && (
                <div className="col gap16">
                  <Toggle label="Show animated captions" value={session.options.captions} onChange={(v) => setOpts({ captions: v })} />
                  {!session.transcript && <div className="badge warn" style={{ whiteSpace: 'normal' }}>No transcript available — captions need Whisper (API key) or imported subtitles.</div>}
                  <CaptionStylePicker value={session.options.captionStyle} onChange={(id) => setOpts({ captionStyle: id })} />
                  <div className="row wrap gap16">
                    <label className="field">Position<Seg value={session.options.captionPos} options={[{ v: 'top', l: 'Top' }, { v: 'middle', l: 'Center' }, { v: 'bottom', l: 'Bottom' }]} onChange={(v) => setOpts({ captionPos: v })} /></label>
                    <div style={{ width: 200 }}><Slider label="Size" value={session.options.captionScale} min={0.6} max={1.6} step={0.05} onChange={(v) => setOpts({ captionScale: v })} fmt={(v) => Math.round(v * 100) + '%'} /></div>
                  </div>
                  <div className="grid g2">
                    <Toggle label="Keyword emphasis (color + size)" value={session.options.keywordEmphasis} onChange={(v) => setOpts({ keywordEmphasis: v })} />
                    <Toggle label="Auto emoji injection 🤯" value={session.options.emojis} onChange={(v) => setOpts({ emojis: v })} />
                    <Toggle label="Profanity: censor text + bleep audio" value={session.options.censor} onChange={(v) => setOpts({ censor: v })} />
                  </div>
                  <div className="dim small">Tip: the same caption style applies to every clip in this batch for brand consistency. Save it as your default in Brand Kit.</div>
                </div>
              )}
              {tab === 'hook' && (
                <div className="col gap16">
                  <Toggle label="Show text hook overlay (first 3 seconds)" value={session.options.hookOverlay} onChange={(v) => setOpts({ hookOverlay: v })} />
                  <div className="section-title">A/B hook variations</div>
                  {clip.hooks.map((h, i) => (
                    <div key={i} className={'chip' + ((session.options.hookText || clip.hooks[0]) === h ? ' on' : '')} style={{ borderRadius: 12, padding: '10px 14px', justifyContent: 'space-between' }} onClick={() => setOpts({ hookText: h })}>
                      <span><b className="dim">{'ABC'[i]}</b>&nbsp;&nbsp;{h}</span>
                    </div>
                  ))}
                  <label className="field">Custom hook<input className="input" placeholder="You won't believe what he said next…" value={session.options.hookText} onChange={(e) => setOpts({ hookText: e.target.value })} /></label>
                  <div className="divider" />
                  <Toggle label={<span>Teaser-first: open on the punchline, then ⏪ rewind to full context</span>} value={session.options.teaser} onChange={(v) => setOpts({ teaser: v })} />
                  {clip.hookLine ? <div className="card tight small"><span className="muted">Teaser line ({fmtTime(clip.hookLine.start - clip.start)}):</span> “{clip.hookLine.text}”</div> : <div className="dim small">No short standout line found for a teaser in this clip.</div>}
                </div>
              )}
              {tab === 'edit' && (
                <div className="col gap16">
                  <div className="section-title">Trim</div>
                  <div className="grid g2">
                    {(['start', 'end'] as const).map((k) => (
                      <div key={k} className="col gap6">
                        <span className="small muted" style={{ fontWeight: 600 }}>{k === 'start' ? 'In point' : 'Out point'} — <span className="mono">{fmtTime(clip[k], true)}</span></span>
                        <div className="row gap4">
                          {[-2, -0.5, 0.5, 2].map((d) => <button key={d} className="btn sm" onClick={() => setClip({ [k]: clamp(+(clip[k] + d).toFixed(2), k === 'start' ? 0 : clip.start + 3, k === 'end' ? session.duration : clip.end - 3) })}>{d > 0 ? '+' : ''}{d}s</button>)}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="section-title">Smart reframing</div>
                  <Seg value={layout.reframe} options={[{ v: 'fit', l: '▭ Full frame' }, { v: 'blur', l: '🌫️ Full frame + blur fill' }, { v: 'track', l: '🎯 Face track (crop)' }, { v: 'split', l: '◫ Split screen' }, { v: 'center', l: '⊡ Center crop' }]} onChange={(v) => setClip({ reframe: v, layoutWhy: 'Set by you' })} />
                  <div className="dim tiny">For gameplay use <b>Full frame</b> or <b>Full frame + blur fill</b> so nothing gets cut off. Face track crops in on the person.</div>
                  {layout.reframe === 'track' && (
                    <label className="field">Speaker focus (multi-speaker)<Seg value={session.options.speakerFocus} options={[{ v: 'auto', l: 'Auto-switch on speaker turns' }, { v: 'left', l: 'Left person' }, { v: 'right', l: 'Right person' }]} onChange={(v) => setOpts({ speakerFocus: v })} /></label>
                  )}
                  <div className="section-title">Pacing</div>
                  <div className="grid g2">
                    <Toggle label="Remove dead air (jump cuts)" value={session.options.removeSilence} onChange={(v) => setOpts({ removeSilence: v })} />
                    <Toggle label="Remove filler words (um, uh…)" value={session.options.removeFillers} onChange={(v) => setOpts({ removeFillers: v })} />
                  </div>
                  <Slider label="Playback speed" value={session.options.speed} min={0.75} max={1.5} step={0.05} onChange={(v) => setOpts({ speed: v })} fmt={(v) => v.toFixed(2) + '×'} />
                  <div className="section-title">Visual effects</div>
                  <div className="grid g2">
                    <Toggle label="Zoom pulses on key words & spikes" value={session.options.zoomPulses} onChange={(v) => setOpts({ zoomPulses: v })} />
                    <Toggle label="Shake on impact moments" value={session.options.shake} onChange={(v) => setOpts({ shake: v })} />
                    <Toggle label="Screen flash on dramatic moments" value={session.options.flash} onChange={(v) => setOpts({ flash: v })} />
                  </div>
                  <div className="section-title">Color grade</div>
                  <div className="row wrap gap6">
                    {Object.entries(GRADES).map(([k, g]) => <div key={k} className={'chip' + (session.options.grade === k ? ' on' : '')} onClick={() => setOpts({ grade: k })}>{g.name}</div>)}
                  </div>
                </div>
              )}
              {tab === 'audio' && <AudioTab session={session} setOpts={setOpts} />}
              {tab === 'brand' && (
                <div className="col gap16">
                  <div className="grid g2">
                    <Toggle label="End card: “Follow for more”" value={session.options.endCard} onChange={(v) => setOpts({ endCard: v })} />
                    <Toggle label="Progress bar (“watch till the end”)" value={session.options.progressBar} onChange={(v) => setOpts({ progressBar: v })} />
                    <Toggle label="Comment bait overlay 👇" value={session.options.commentBait} onChange={(v) => setOpts({ commentBait: v })} />
                    <Toggle label={<span>Chat overlay {!session.chatLog.length && <span className="dim tiny">(stream only)</span>}</span>} value={session.options.chatOverlay} onChange={(v) => setOpts({ chatOverlay: v })} />
                  </div>
                </div>
              )}
              {tab === 'publish' && <PublishTab clip={clip} session={session} />}
            </div>
          </div>
        </div>
      )}
      {exportOpen && <ExportModal session={session} current={clip} onClose={() => setExportOpen(false)} />}
    </div>
  );
}

function ClipPreview({ session, clip }: { session: ClipSession; clip: Clip }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const eng = useRef<ClipEngine | null>(null);
  const [playing, setPlaying] = useState(false);
  const [t, setT] = useState({ out: 0, total: 1 });
  const { settings } = useApp();
  useEffect(() => {
    if (!ref.current) return;
    const e = new ClipEngine({ url: session.url, clip, options: optsFor(session.options, clip), transcript: session.transcript, audio: session.audio, visual: session.visual, chatLog: session.chatLog, logo: settings.logo, brandColor: settings.brandColor }, ref.current);
    e.onTime = (out, total) => setT({ out, total });
    e.onEnd = () => setPlaying(false);
    eng.current = e;
    return () => { e.destroy(); eng.current = null; setPlaying(false); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clip.id, session.id]);
  useEffect(() => { eng.current?.configure(optsFor(session.options, clip), clip); }, [session.options, clip]);
  const toggle = async () => {
    const e = eng.current; if (!e) return;
    if (e.playing) { e.pause(); setPlaying(false); } else { await e.play(); setPlaying(true); }
  };
  const asp = optsFor(session.options, clip).aspect;
  const w = asp === '16:9' ? 400 : asp === '1:1' ? 360 : 300;
  return (
    <div className="col" style={{ alignItems: 'center' }}>
      <div className="phone" style={{ width: w, cursor: 'pointer' }} onClick={toggle}>
        <canvas ref={ref} />
        {!playing && <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none' }}><div style={{ width: 64, height: 64, borderRadius: 99, background: '#000a', display: 'grid', placeItems: 'center', backdropFilter: 'blur(4px)' }}><Play size={28} fill="#fff" /></div></div>}
      </div>
      <div className="row mt8" style={{ width: w }}>
        <button className="btn sm icon" onClick={toggle}>{playing ? <Pause size={14} /> : <Play size={14} />}</button>
        <input type="range" min={0} max={t.total} step={0.05} value={t.out} onChange={(e) => eng.current?.seekOut(+e.target.value)} style={{ flex: 1 }} />
        <span className="mono small dim">{fmtTime(t.out)}/{fmtTime(t.total)}</span>
        <button className="btn sm icon ghost" title="Restart" onClick={() => eng.current?.seekOut(0)}><RotateCcw size={13} /></button>
      </div>
      {clip.end - clip.start - t.total > 0.3 && <div className="tiny dim mt8"><Scissors size={11} /> {(clip.end - clip.start - t.total).toFixed(1)}s of dead air / fillers cut</div>}
    </div>
  );
}

function WhyTab({ clip, session }: { clip: Clip; session: ClipSession }) {
  const words = wordsInRange(session.transcript, clip.start, clip.end);
  const kws = session.options.keywordEmphasis;
  return (
    <div className="col gap16">
      <div className="row gap16" style={{ alignItems: 'center' }}>
        <ScoreRing score={clip.score} size={84} stroke={7} />
        <div className="grow">
          <div className="section-title" style={{ margin: 0 }}>Virality score</div>
          <b style={{ fontSize: 18 }}>{clip.title}</b>
          <div className="muted small mt8">{reasoningSentence(clip)}</div>
        </div>
      </div>
      <div className="grid g3">
        <MiniBar label="🪝 Hook strength" v={clip.breakdown.hook} />
        <MiniBar label="⏱️ Retention" v={clip.breakdown.retention} />
        <MiniBar label="💬 Comment potential" v={clip.breakdown.comments} />
        <MiniBar label="🔁 Share potential" v={clip.breakdown.shares} />
        <MiniBar label="🔖 Save potential" v={clip.breakdown.saves} />
        <MiniBar label="♻️ Replay value" v={clip.breakdown.replay} />
      </div>
      <div>
        <div className="section-title">Signals detected</div>
        <div className="col gap6">{clip.reasons.map((r, i) => <div key={i} className="row small" style={{ alignItems: 'flex-start' }}><span style={{ color: 'var(--ok)' }}>●</span><span>{r}</span></div>)}</div>
      </div>
      {words.length > 0 && (
        <div>
          <div className="section-title">Transcript</div>
          <div className="card tight" style={{ lineHeight: 1.8, maxHeight: 220, overflow: 'auto' }}>
            {words.map((w, i) => {
              const prev = words[i - 1];
              const newSpeaker = w.speaker && (!prev || prev.speaker !== w.speaker);
              return (
                <span key={i}>
                  {newSpeaker && <><br /><b className="badge brand" style={{ marginRight: 4 }}>{w.speaker}</b></>}
                  <span style={kws && isKeyword(w.w) ? { color: '#ffd23f', fontWeight: 700 } : /^(um|uh),?$/i.test(w.w) ? { textDecoration: 'line-through', opacity: 0.5 } : undefined}>{w.w}</span>{' '}
                </span>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function AudioTab({ session, setOpts }: { session: ClipSession; setOpts: (p: Partial<ClipRenderOptions>) => void }) {
  const [mood, setMood] = useState('');
  const [prev, setPrev] = useState('');
  useEffect(() => () => stopPreview(), []);
  const o = session.options;
  const tracks = MUSIC.filter((m) => !mood || m.mood === mood);
  return (
    <div className="col gap16">
      <div className="row wrap gap6">
        <div className={'chip' + (!mood ? ' on' : '')} onClick={() => setMood('')}>All moods</div>
        {[...new Set(MUSIC.map((m) => m.mood))].map((m) => <div key={m} className={'chip' + (mood === m ? ' on' : '')} onClick={() => setMood(m)}>{m}</div>)}
      </div>
      <div className="col gap6">
        <div className={'clip-card' + (!o.music ? ' sel' : '')} style={{ alignItems: 'center' }} onClick={() => setOpts({ music: '' })}><Volume2 size={16} /> <b>No music — original audio only</b></div>
        {tracks.map((m) => (
          <div key={m.id} className={'clip-card' + (o.music === m.id ? ' sel' : '')} style={{ alignItems: 'center' }} onClick={() => setOpts({ music: m.id })}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: m.color + '33', display: 'grid', placeItems: 'center' }}><Music2 size={18} color={m.color} /></div>
            <div className="grow"><b>{m.name}</b><div className="dim small">{m.genre} · {m.bpm} BPM · {m.desc}</div></div>
            <button className="btn sm icon" onClick={async (e) => { e.stopPropagation(); if (prev === m.id) { stopPreview(); setPrev(''); } else { previewBuffer(await renderMusic(m.id), true); setPrev(m.id); } }}>{prev === m.id ? <Pause size={13} /> : <Play size={13} />}</button>
          </div>
        ))}
      </div>
      <Slider label="Music volume" value={o.musicVolume} min={0} max={1} step={0.05} onChange={(v) => setOpts({ musicVolume: v })} fmt={(v) => Math.round(v * 100) + '%'} />
      <div className="grid g2">
        <Toggle label="Auto-ducking under speech" value={o.ducking} onChange={(v) => setOpts({ ducking: v })} />
        <Toggle label="Beat-synced zoom pulses" value={o.beatZoom} onChange={(v) => setOpts({ beatZoom: v })} />
        <Toggle label="Auto sound effects (whoosh, boom, pop)" value={o.sfx} onChange={(v) => setOpts({ sfx: v })} />
      </div>
      <div className="dim small">All tracks are generated procedurally in your browser — 100% royalty-free, no copyright claims.</div>
    </div>
  );
}

function PublishTab({ clip }: { clip: Clip; session: ClipSession }) {
  const { settings, toast } = useApp();
  const [plats, setPlats] = useState<string[]>(['tiktok', 'shorts', 'reels']);
  const list = PLATFORMS.filter((p) => p.id !== 'all');
  const copy = (t: string) => { navigator.clipboard.writeText(t).then(() => toast('Copied to clipboard', 'success')); };
  return (
    <div className="col gap16">
      <div className="row wrap gap6">
        {list.map((p) => <div key={p.id} className={'chip' + (plats.includes(p.id) ? ' on' : '')} onClick={() => setPlats(plats.includes(p.id) ? plats.filter((x) => x !== p.id) : [...plats, p.id])}><span style={{ width: 8, height: 8, borderRadius: 9, background: p.color }} />{p.name}</div>)}
      </div>
      {plats.map((pid) => {
        const p = list.find((x) => x.id === pid)!;
        const tags = makeHashtags(clip.text || clip.title, clip.categories, pid);
        const cap = platformCaption(clip.title, tags, pid, settings.handle);
        const tooLong = clip.end - clip.start > p.maxLen;
        return (
          <div key={pid} className="card tight">
            <div className="row between"><b>{p.name}</b><div className="row gap6">{tooLong && <span className="badge warn">over {p.maxLen}s limit</span>}<span className="badge">{p.aspect}</span><button className="btn sm" onClick={() => copy(cap)}><Copy size={12} /> Copy</button></div></div>
            <pre className="small" style={{ whiteSpace: 'pre-wrap', margin: '8px 0 0', fontFamily: 'inherit', color: 'var(--muted)' }}>{cap}</pre>
          </div>
        );
      })}
      <div className="card tight">
        <div className="section-title">Title ideas</div>
        {[clip.title, ...clip.hooks, `I can't believe ${clip.title.toLowerCase().replace(/[.?!…]+$/, '')}`, `${clip.title.replace(/[.?!…]+$/, '')} (watch till the end)`].slice(0, 6).map((t, i) => (
          <div key={i} className="row between small" style={{ padding: '5px 0' }}><span><b className="dim">{i + 1}.</b> {t}</span><button className="btn ghost sm icon" onClick={() => copy(t)}><Copy size={12} /></button></div>
        ))}
      </div>
    </div>
  );
}

function ExportModal({ session, current, onClose }: { session: ClipSession; current: Clip; onClose: () => void }) {
  const { settings, updateSession, toast, logHistory } = useApp();
  const [scope, setScope] = useState<'current' | 'top' | 'all'>('current');
  const [topN, setTopN] = useState(5);
  const [aspects, setAspects] = useState<string[]>(['auto']);
  const [res, setRes] = useState<number>(settings.exportRes);
  const [prog, setProg] = useState<{ i: number; n: number; p: number; label: string } | null>(null);
  const cancel = useRef(false);
  const list = scope === 'current' ? [current] : scope === 'top' ? session.clips.slice(0, topN) : session.clips;
  const jobs = useMemo(() => list.flatMap((c) => aspects.map((a) => ({ c, a }))), [list, aspects]);
  const run = async () => {
    cancel.current = false;
    const files: Record<string, Uint8Array> = {};
    const blobs: { name: string; blob: Blob }[] = [];
    for (let i = 0; i < jobs.length; i++) {
      if (cancel.current) break;
      const { c, a } = jobs[i];
      setProg({ i, n: jobs.length, p: 0, label: `${c.title} · ${a}` });
      const base = optsFor(session.options, c);
      const aa = (a === 'auto' ? base.aspect : a) as Aspect;
      const opts = a === 'auto' ? base : { ...base, aspect: aa, reframe: aa === base.aspect ? base.reframe : reframeFor(aa, c, session.visual, session.width, session.height) };
      const eng = new ClipEngine({ url: session.url, clip: c, options: opts, transcript: session.transcript, audio: session.audio, visual: session.visual, chatLog: session.chatLog, logo: settings.logo, brandColor: settings.brandColor });
      try {
        const blob = await eng.export(res, (p) => setProg((x) => (x ? { ...x, p } : x)));
        const name = `${String(i + 1).padStart(2, '0')}-${slug(c.title)}-${aa.replace(':', 'x')}-score${c.score}.${extFor(blob.type)}`;
        blobs.push({ name, blob });
        files[name] = new Uint8Array(await blob.arrayBuffer());
        logHistory({ title: c.title, score: c.score, kind: 'export' });
      } finally { eng.destroy(); }
    }
    if (blobs.length === 1) download(blobs[0].blob, blobs[0].name);
    else if (blobs.length > 1) download(new Blob([zipSync(files, { level: 0 }) as Uint8Array<ArrayBuffer>], { type: 'application/zip' }), `${slug(session.name)}-clips.zip`);
    updateSession(session.id, { exported: [...new Set([...session.exported, ...list.map((c) => c.id)])] });
    setProg(null);
    if (blobs.length) toast(`✅ Exported ${blobs.length} file${blobs.length > 1 ? 's' : ''}`, 'success');
    onClose();
  };
  return (
    <Modal open onClose={() => { if (!prog) onClose(); }} title="Export clips">
      {prog ? (
        <div className="col gap16">
          <div className="muted">Rendering {prog.i + 1} of {prog.n} — <b style={{ color: 'var(--text)' }}>{prog.label}</b></div>
          <div className="bar"><div style={{ width: `${((prog.i + prog.p) / prog.n) * 100}%` }} /></div>
          <div className="dim small">Rendering in real time with the browser's hardware encoder. Keep this tab visible for best results.</div>
          <button className="btn" onClick={() => (cancel.current = true)}>Stop after current clip</button>
        </div>
      ) : (
        <div className="col gap16">
          <label className="field">Which clips?<Seg value={scope} options={[{ v: 'current', l: 'Current clip' }, { v: 'top', l: 'Top N' }, { v: 'all', l: `All (${session.clips.length})` }]} onChange={setScope} /></label>
          {scope === 'top' && <Slider label="Top N by score" value={topN} min={1} max={Math.max(1, session.clips.length)} onChange={setTopN} />}
          <label className="field">Format
            <div className="row gap6 wrap">{['auto', '16:9', '9:16', '1:1', '4:5'].map((a) => <div key={a} className={'chip' + (aspects.includes(a) ? ' on' : '')} onClick={() => setAspects(aspects.includes(a) ? aspects.filter((x) => x !== a) : [...aspects, a])}>{a === 'auto' ? "Each clip's own layout" : 'Force ' + a}</div>)}</div>
          </label>
          <label className="field">Resolution<Seg value={res} options={[{ v: 480, l: '480p' }, { v: 720, l: '720p' }, { v: 1080, l: '1080p' }]} onChange={setRes} /></label>
          <div className="card tight small muted">
            <b style={{ color: 'var(--text)' }}>{jobs.length} file{jobs.length !== 1 && 's'}</b> · {MediaRecorder.isTypeSupported('video/mp4') ? 'MP4 (H.264 + AAC)' : 'WebM (VP9 + Opus)'} · 30 fps · {jobs.length > 1 ? 'ZIP download' : 'direct download'}.
          </div>
          <button className="btn glow lg" disabled={!jobs.length} onClick={run}><Sparkles size={16} /> Render {jobs.length} file{jobs.length !== 1 && 's'}</button>
        </div>
      )}
    </Modal>
  );
}

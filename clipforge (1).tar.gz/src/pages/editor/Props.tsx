import { Diamond, Trash2, Copy } from 'lucide-react';
import type { Item, KfProp, Project } from './model';
import { ANIMS_IN, LUTS, kfValue, setProp, DEFAULT_ADJ } from './model';
import { FONT_LIST } from '../../lib/captions';
import { Toggle } from '../../components/ui';

type P = { project: Project; item: Item | null; time: number; update: (fn: (p: Project) => void, record?: boolean) => void; onDelete: () => void; onDuplicate: () => void };

const BLENDS: GlobalCompositeOperation[] = ['source-over', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 'color-dodge', 'color-burn', 'hard-light', 'soft-light', 'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity'];

function Num({ label, value, min, max, step = 0.01, onChange, kf, onKf, fmt }: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; kf?: 'on' | 'has' | 'off'; onKf?: () => void; fmt?: (v: number) => string }) {
  return (
    <div className="prop-row">
      <span className="row gap4">{onKf && <button className={'kf' + (kf === 'on' ? ' on' : '')} style={{ opacity: kf === 'off' ? 0.5 : 1 }} title="Toggle keyframe at playhead" onClick={onKf}><Diamond size={11} fill={kf === 'on' ? '#ffd23f' : kf === 'has' ? '#ffd23f55' : 'none'} /></button>}{label}</span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(+e.target.value)} />
      <input className="input sm mono" style={{ padding: '0 4px', textAlign: 'right' }} value={fmt ? fmt(value) : Math.round(value * 100) / 100} onChange={(e) => { const v = parseFloat(e.target.value); if (!isNaN(v)) onChange(v); }} />
    </div>
  );
}

export default function Props({ project, item, time, update, onDelete, onDuplicate }: P) {
  if (!item) return <ProjectProps project={project} update={update} />;
  const it = item;
  const local = time - it.start;
  const mut = (fn: (x: Item) => void, rec = true) => update((p) => { const x = p.items.find((i) => i.id === it.id); if (x) fn(x); }, rec);
  const kfState = (prop: KfProp): 'on' | 'has' | 'off' => { const k = it.kf[prop]; if (!k?.length) return 'off'; return k.some((x) => Math.abs(x.t - local) < 0.04) ? 'on' : 'has'; };
  const toggleKf = (prop: KfProp) => mut((x) => {
    const ks = x.kf[prop];
    const cur = kfValue(x, prop, local);
    if (!ks?.length) x.kf[prop] = [{ t: Math.max(0, local), v: cur, ease: 'inout' }];
    else {
      const i = ks.findIndex((k) => Math.abs(k.t - local) < 0.04);
      if (i >= 0) { ks.splice(i, 1); if (!ks.length) { delete x.kf[prop]; (x as unknown as Record<string, number>)[prop] = cur; } }
      else { ks.push({ t: Math.max(0, local), v: cur, ease: 'inout' }); ks.sort((a, b) => a.t - b.t); }
    }
  });
  const tp = (prop: KfProp, label: string, min: number, max: number, step = 0.01, fmt?: (v: number) => string) => (
    <Num key={prop} label={label} value={kfValue(it, prop, local)} min={min} max={max} step={step} fmt={fmt} kf={kfState(prop)} onKf={() => toggleKf(prop)} onChange={(v) => mut((x) => setProp(x, prop, v, Math.max(0, local)), false)} />
  );
  const isMedia = it.type === 'video' || it.type === 'image';
  const hasAudio = it.type === 'video' || it.type === 'audio';
  return (
    <div className="col gap16">
      <div className="row between">
        <div><div className="section-title" style={{ margin: 0 }}>{it.type}</div><b className="ellipsis" style={{ maxWidth: 180, display: 'block' }}>{it.name}</b></div>
        <div className="row gap4"><button className="btn sm icon" title="Duplicate (Ctrl+D)" onClick={onDuplicate}><Copy size={13} /></button><button className="btn sm icon danger" title="Delete (Del)" onClick={onDelete}><Trash2 size={13} /></button></div>
      </div>

      <div>
        <div className="section-title">Timing</div>
        <Num label="Start" value={it.start} min={0} max={Math.max(60, it.start + 10)} step={0.05} onChange={(v) => mut((x) => { x.start = Math.max(0, v); }, false)} />
        <Num label="Duration" value={it.dur} min={0.1} max={Math.max(30, it.dur * 2)} step={0.05} onChange={(v) => mut((x) => { x.dur = Math.max(0.1, v); }, false)} />
        {hasAudio && <Num label="Speed" value={it.speed} min={0.25} max={4} step={0.05} fmt={(v) => v.toFixed(2) + '×'} onChange={(v) => mut((x) => { const endSrc = x.dur * x.speed; x.speed = v; x.dur = endSrc / v; }, false)} />}
      </div>

      {it.type !== 'audio' && (
        <div>
          <div className="section-title">Transform <span className="dim" style={{ textTransform: 'none', letterSpacing: 0 }}>· ◆ = keyframe</span></div>
          {tp('x', 'X', -0.5, 1.5)}{tp('y', 'Y', -0.5, 1.5)}{tp('scale', 'Scale', 0.05, 5)}{tp('rotation', 'Rotation', -180, 180, 1)}{tp('opacity', 'Opacity', 0, 1)}
          {Object.values(it.kf).some((k) => k?.length) && (
            <div className="row gap6 mt8 small">
              <span className="muted">Easing</span>
              <select className="input sm" style={{ width: 'auto' }} onChange={(e) => mut((x) => { for (const k of Object.values(x.kf)) k?.forEach((kk) => (kk.ease = e.target.value)); })} defaultValue="inout">
                {['linear', 'in', 'out', 'inout', 'back', 'elastic', 'bounce'].map((e) => <option key={e} value={e}>{e}</option>)}
              </select>
              <button className="btn sm ghost" onClick={() => mut((x) => { for (const [k, v] of Object.entries(x.kf)) { if (v?.length) (x as unknown as Record<string, number>)[k] = v[0].v; } x.kf = {}; })}>Clear all keys</button>
            </div>
          )}
        </div>
      )}

      {it.type === 'text' && it.text && <TextProps it={it} mut={mut} />}
      {it.type === 'shape' && it.shape && (
        <div>
          <div className="section-title">Shape</div>
          <div className="grid g2">
            <label className="field">Fill<input type="color" value={it.shape.fill.slice(0, 7)} onChange={(e) => mut((x) => { x.shape!.fill = e.target.value; }, false)} /></label>
            <label className="field">Stroke<input type="color" value={(it.shape.stroke || '#ffffff').slice(0, 7)} onChange={(e) => mut((x) => { x.shape!.stroke = e.target.value; x.shape!.strokeW = x.shape!.strokeW || 1; }, false)} /></label>
          </div>
          <Num label="Width" value={it.shape.w} min={0.02} max={1.2} onChange={(v) => mut((x) => { x.shape!.w = v; }, false)} />
          <Num label="Height" value={it.shape.h} min={0.005} max={1.2} onChange={(v) => mut((x) => { x.shape!.h = v; }, false)} />
          <Num label="Corner" value={it.shape.radius} min={0} max={1} onChange={(v) => mut((x) => { x.shape!.radius = v; }, false)} />
          <Num label="Stroke W" value={it.shape.strokeW} min={0} max={5} step={0.1} onChange={(v) => mut((x) => { x.shape!.strokeW = v; }, false)} />
          <label className="field">Label<input className="input sm" value={it.shape.label || ''} onChange={(e) => mut((x) => { x.shape!.label = e.target.value; }, false)} /></label>
        </div>
      )}
      {it.type === 'sticker' && <label className="field">Emoji<input className="input" value={it.sticker} onChange={(e) => mut((x) => { x.sticker = e.target.value; }, false)} /></label>}
      {it.type === 'bg' && it.bg && (
        <div>
          <div className="section-title">Gradient</div>
          <div className="row gap6">{it.bg.colors.map((c, i) => <input key={i} type="color" value={c.slice(0, 7)} onChange={(e) => mut((x) => { x.bg!.colors[i] = e.target.value; }, false)} />)}
            <button className="btn sm" onClick={() => mut((x) => { x.bg!.colors.push('#ffffff'); })}>+</button>{it.bg.colors.length > 1 && <button className="btn sm" onClick={() => mut((x) => { x.bg!.colors.pop(); })}>−</button>}</div>
          <Num label="Angle" value={it.bg.angle} min={0} max={360} step={1} onChange={(v) => mut((x) => { x.bg!.angle = v; }, false)} />
          <Toggle label="Animated" value={it.bg.animated} onChange={(v) => mut((x) => { x.bg!.animated = v; })} />
        </div>
      )}

      {it.type !== 'audio' && (
        <div>
          <div className="section-title">Animation & transitions</div>
          <div className="grid g2">
            <label className="field">In<select className="input sm" value={it.animIn} onChange={(e) => mut((x) => { x.animIn = e.target.value; })}>{ANIMS_IN.map((a) => <option key={a}>{a}</option>)}</select></label>
            <label className="field">Out<select className="input sm" value={it.animOut} onChange={(e) => mut((x) => { x.animOut = e.target.value; })}>{ANIMS_IN.map((a) => <option key={a}>{a}</option>)}</select></label>
          </div>
          <Num label="Anim length" value={it.animDur} min={0.05} max={3} step={0.05} onChange={(v) => mut((x) => { x.animDur = v; }, false)} />
          <label className="field">Loop<select className="input sm" value={it.loopAnim} onChange={(e) => mut((x) => { x.loopAnim = e.target.value as Item['loopAnim']; })}>{['none', 'wiggle', 'pulse', 'float', 'spin', 'kenburns'].map((a) => <option key={a}>{a}</option>)}</select></label>
          <div className="grid g2 mt8">
            <label className="field">Blend mode<select className="input sm" value={it.blend} onChange={(e) => mut((x) => { x.blend = e.target.value as GlobalCompositeOperation; })}>{BLENDS.map((b) => <option key={b} value={b}>{b === 'source-over' ? 'normal' : b}</option>)}</select></label>
            <label className="field">Mask<select className="input sm" value={it.mask} onChange={(e) => mut((x) => { x.mask = e.target.value as Item['mask']; })}>{['none', 'circle', 'rounded', 'heart'].map((b) => <option key={b}>{b}</option>)}</select></label>
          </div>
        </div>
      )}

      {isMedia && (
        <>
          <div>
            <div className="section-title">Fit</div>
            <div className="seg"><button className={it.fit === 'cover' ? 'on' : ''} onClick={() => mut((x) => { x.fit = 'cover'; })}>Fill / crop</button><button className={it.fit === 'contain' ? 'on' : ''} onClick={() => mut((x) => { x.fit = 'contain'; })}>Fit</button></div>
          </div>
          <div>
            <div className="section-title">Color — LUT presets</div>
            <div className="row wrap gap4">{Object.entries(LUTS).map(([k, l]) => <div key={k} className={'chip' + (it.lut === k ? ' on' : '')} style={{ padding: '4px 9px', fontSize: 11 }} onClick={() => mut((x) => { x.lut = k; })}>{l.name}</div>)}</div>
          </div>
          <div>
            <div className="row between"><div className="section-title">Color correction</div><button className="btn ghost sm" onClick={() => mut((x) => { x.adj = { ...DEFAULT_ADJ }; })}>Reset</button></div>
            <Num label="Exposure" value={it.adj.brightness} min={0} max={200} step={1} onChange={(v) => mut((x) => { x.adj.brightness = v; }, false)} />
            <Num label="Contrast" value={it.adj.contrast} min={0} max={200} step={1} onChange={(v) => mut((x) => { x.adj.contrast = v; }, false)} />
            <Num label="Saturation" value={it.adj.saturate} min={0} max={300} step={1} onChange={(v) => mut((x) => { x.adj.saturate = v; }, false)} />
            <Num label="Temperature" value={it.adj.temp} min={-50} max={50} step={1} onChange={(v) => mut((x) => { x.adj.temp = v; }, false)} />
            <Num label="Hue" value={it.adj.hue} min={-180} max={180} step={1} onChange={(v) => mut((x) => { x.adj.hue = v; }, false)} />
            <Num label="Blur" value={it.adj.blur} min={0} max={40} step={0.5} onChange={(v) => mut((x) => { x.adj.blur = v; }, false)} />
            <Num label="B&W" value={it.adj.grayscale} min={0} max={100} step={1} onChange={(v) => mut((x) => { x.adj.grayscale = v; }, false)} />
            <Num label="Sepia" value={it.adj.sepia} min={0} max={100} step={1} onChange={(v) => mut((x) => { x.adj.sepia = v; }, false)} />
            <Num label="Invert" value={it.adj.invert} min={0} max={100} step={1} onChange={(v) => mut((x) => { x.adj.invert = v; }, false)} />
          </div>
        </>
      )}
      {it.type !== 'audio' && (
        <div>
          <div className="section-title">Effects</div>
          <Num label="Vignette" value={it.fx.vignette} min={0} max={1} onChange={(v) => mut((x) => { x.fx.vignette = v; }, false)} />
          <Num label="Film grain" value={it.fx.grain} min={0} max={1} onChange={(v) => mut((x) => { x.fx.grain = v; }, false)} />
          <Num label="Glitch" value={it.fx.glitch} min={0} max={100} step={1} onChange={(v) => mut((x) => { x.fx.glitch = v; }, false)} />
          <Num label="Pixelate" value={it.fx.pixelate} min={0} max={100} step={1} onChange={(v) => mut((x) => { x.fx.pixelate = v; }, false)} />
          <Num label="RGB split" value={it.fx.rgbSplit} min={0} max={100} step={1} onChange={(v) => mut((x) => { x.fx.rgbSplit = v; }, false)} />
          <Toggle label="VHS / CRT" value={it.fx.vhs} onChange={(v) => mut((x) => { x.fx.vhs = v; })} />
          <Toggle label="Mirror (flip horizontal)" value={it.fx.flipH} onChange={(v) => mut((x) => { x.fx.flipH = v; })} />
        </div>
      )}
      {isMedia && (
        <div>
          <div className="section-title">Keying & AI</div>
          <Toggle label="Chroma key (green screen)" value={it.fx.chroma} onChange={(v) => mut((x) => { x.fx.chroma = v; })} />
          {it.fx.chroma && (<>
            <div className="row gap6 small"><span className="muted">Key color</span><input type="color" value={it.fx.chromaColor} onChange={(e) => mut((x) => { x.fx.chromaColor = e.target.value; }, false)} /></div>
            <Num label="Tolerance" value={it.fx.chromaTol} min={10} max={250} step={1} onChange={(v) => mut((x) => { x.fx.chromaTol = v; }, false)} />
          </>)}
          <Toggle label="AI background removal (no green screen)" value={it.fx.bgRemove} onChange={(v) => mut((x) => { x.fx.bgRemove = v; })} />
          {it.fx.bgRemove && <div className="row gap6 small"><span className="muted">Replace with color</span><input type="color" value={it.fx.bgColor || '#000000'} onChange={(e) => mut((x) => { x.fx.bgColor = e.target.value; }, false)} /><button className="btn sm ghost" onClick={() => mut((x) => { x.fx.bgColor = ''; })}>transparent</button></div>}
        </div>
      )}
      {hasAudio && (
        <div>
          <div className="section-title">Audio</div>
          <Num label="Volume" value={it.volume} min={0} max={2} onChange={(v) => mut((x) => { x.volume = v; }, false)} fmt={(v) => Math.round(v * 100) + '%'} />
          <Num label="Fade in" value={it.fadeIn} min={0} max={5} step={0.1} onChange={(v) => mut((x) => { x.fadeIn = v; }, false)} />
          <Num label="Fade out" value={it.fadeOut} min={0} max={5} step={0.1} onChange={(v) => mut((x) => { x.fadeOut = v; }, false)} />
          <Toggle label="Keep pitch when changing speed" value={it.keepPitch} onChange={(v) => mut((x) => { x.keepPitch = v; })} />
          <Toggle label="Voice enhance (EQ, de-ess, compressor)" value={it.voiceEnhance} onChange={(v) => mut((x) => { x.voiceEnhance = v; })} />
        </div>
      )}
    </div>
  );
}

function TextProps({ it, mut }: { it: Item; mut: (fn: (x: Item) => void, rec?: boolean) => void }) {
  const t = it.text!;
  const set = (p: Partial<typeof t>, rec = false) => mut((x) => { Object.assign(x.text!, p); if (p.content !== undefined) x.name = p.content.slice(0, 18); }, rec);
  return (
    <div>
      <div className="section-title">Text</div>
      <textarea className="input" rows={3} value={t.content} onChange={(e) => set({ content: e.target.value })} />
      <div className="grid g2 mt8">
        <label className="field">Font<select className="input sm" value={t.font} onChange={(e) => set({ font: e.target.value }, true)}>{FONT_LIST.map((f) => <option key={f} style={{ fontFamily: f }}>{f}</option>)}</select></label>
        <label className="field">Weight<select className="input sm" value={t.weight} onChange={(e) => set({ weight: +e.target.value }, true)}>{[400, 500, 600, 700, 800, 900].map((w) => <option key={w}>{w}</option>)}</select></label>
      </div>
      <div className="mt8" />
      <Num label="Size" value={t.size} min={0.01} max={0.4} step={0.002} onChange={(v) => set({ size: v })} />
      <Num label="Box width" value={t.width} min={0.2} max={1} onChange={(v) => set({ width: v })} />
      <Num label="Outline" value={t.strokeW} min={0} max={0.4} step={0.01} onChange={(v) => set({ strokeW: v })} />
      <div className="row wrap gap6 small">
        <label className="row gap4">Color<input type="color" value={t.color.slice(0, 7)} onChange={(e) => set({ color: e.target.value })} /></label>
        <label className="row gap4">Gradient<input type="color" value={(t.gradient || '#ffffff').slice(0, 7)} onChange={(e) => set({ gradient: e.target.value })} /></label>
        {t.gradient && <button className="btn sm ghost" onClick={() => set({ gradient: '' })}>×</button>}
        <label className="row gap4">Outline<input type="color" value={t.stroke.slice(0, 7)} onChange={(e) => set({ stroke: e.target.value, strokeW: t.strokeW || 0.1 })} /></label>
        <label className="row gap4">Box<input type="color" value={(t.bg || '#000000').slice(0, 7)} onChange={(e) => set({ bg: e.target.value })} /></label>
        {t.bg && <button className="btn sm ghost" onClick={() => set({ bg: '' })}>×</button>}
        <label className="row gap4">Glow<input type="color" value={(t.glow || '#7c5cff').slice(0, 7)} onChange={(e) => set({ glow: e.target.value })} /></label>
        {t.glow && <button className="btn sm ghost" onClick={() => set({ glow: '' })}>×</button>}
      </div>
      <div className="row gap6 mt8 wrap">
        <div className="seg">{(['left', 'center', 'right'] as CanvasTextAlign[]).map((a) => <button key={a} className={t.align === a ? 'on' : ''} onClick={() => set({ align: a }, true)}>{a}</button>)}</div>
        <button className={'btn sm' + (t.italic ? ' active' : '')} onClick={() => set({ italic: !t.italic }, true)}><i>I</i></button>
        <button className={'btn sm' + (t.upper ? ' active' : '')} onClick={() => set({ upper: !t.upper }, true)}>AA</button>
        <button className={'btn sm' + (t.shadow ? ' active' : '')} onClick={() => set({ shadow: !t.shadow }, true)}>Shadow</button>
      </div>
      <label className="field mt8">Text animation<select className="input sm" value={t.anim} onChange={(e) => set({ anim: e.target.value as typeof t.anim }, true)}>{['none', 'typewriter', 'word', 'wave', 'bounce', 'shake', 'glitch', 'neon', 'ticker'].map((a) => <option key={a}>{a}</option>)}</select></label>
    </div>
  );
}

function ProjectProps({ project, update }: { project: Project; update: P['update'] }) {
  const sizes: [string, number, number][] = [['9:16 TikTok/Reels/Shorts', 1080, 1920], ['16:9 YouTube', 1920, 1080], ['1:1 Square', 1080, 1080], ['4:5 Instagram feed', 1080, 1350], ['4:3 Classic', 1440, 1080], ['21:9 Cinematic', 2560, 1080]];
  return (
    <div className="col gap16">
      <div className="section-title" style={{ margin: 0 }}>Project</div>
      <label className="field">Name<input className="input" value={project.name} onChange={(e) => update((p) => { p.name = e.target.value; }, false)} /></label>
      <label className="field">Canvas size
        <select className="input" value={`${project.w}x${project.h}`} onChange={(e) => { const [w, h] = e.target.value.split('x').map(Number); update((p) => { p.w = w; p.h = h; }); }}>
          {sizes.map(([n, w, h]) => <option key={n} value={`${w}x${h}`}>{n} — {w}×{h}</option>)}
        </select>
      </label>
      <div className="grid g2">
        <label className="field">Frame rate<select className="input" value={project.fps} onChange={(e) => update((p) => { p.fps = +e.target.value; })}>{[24, 25, 30, 48, 50, 60].map((f) => <option key={f}>{f}</option>)}</select></label>
        <label className="field">Background<input type="color" value={project.bgColor} onChange={(e) => update((p) => { p.bgColor = e.target.value; }, false)} /></label>
      </div>
      <div className="card tight small">
        <div className="section-title">Keyboard shortcuts</div>
        {[['Space', 'Play / pause'], ['S', 'Split at playhead'], ['Del', 'Delete'], ['Shift+Del', 'Ripple delete'], ['Ctrl+Z / Ctrl+Shift+Z', 'Undo / redo'], ['Ctrl+D', 'Duplicate'], ['← / →', 'Step 1 frame (Shift = 1s)'], ['I / O', 'Mark in / out'], ['M', 'Add marker'], ['+ / −', 'Zoom timeline'], ['Ctrl+K', 'Command palette']].map(([k, v]) => (
          <div key={k} className="row between" style={{ padding: '3px 0' }}><span className="kbd">{k}</span><span className="muted">{v}</span></div>
        ))}
      </div>
      <div className="dim tiny">Select anything on the timeline or click it in the preview to edit its properties. Drag in the preview to move.</div>
    </div>
  );
}

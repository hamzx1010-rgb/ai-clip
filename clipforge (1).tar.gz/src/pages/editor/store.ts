import { get, set, del } from 'idb-keyval';
import type { Asset, Project } from './model';
import { computePeaks } from '../../lib/audio';
import { loadVideoMeta, uid } from '../../lib/util';

export type ProjectMeta = { id: string; name: string; updatedAt: number; w: number; h: number; thumb?: string; items: number };

export async function listProjects(): Promise<ProjectMeta[]> {
  return ((await get('cf:projects')) as ProjectMeta[] | undefined) || [];
}

export async function saveProject(p: Project, thumb?: string) {
  const clean: Project = { ...p, assets: p.assets.map((a) => ({ ...a, url: '' })) };
  await set('cf:proj:' + p.id, clean);
  const list = await listProjects();
  const meta: ProjectMeta = { id: p.id, name: p.name, updatedAt: Date.now(), w: p.w, h: p.h, thumb: thumb ?? list.find((x) => x.id === p.id)?.thumb, items: p.items.length };
  await set('cf:projects', [meta, ...list.filter((x) => x.id !== p.id)]);
}

export async function saveVersion(p: Project) {
  const key = 'cf:ver:' + p.id;
  const vs = ((await get(key)) as { at: number; project: Project }[] | undefined) || [];
  const clean: Project = { ...p, assets: p.assets.map((a) => ({ ...a, url: '' })) };
  vs.unshift({ at: Date.now(), project: clean });
  await set(key, vs.slice(0, 20));
}
export async function listVersions(id: string): Promise<{ at: number; project: Project }[]> {
  return ((await get('cf:ver:' + id)) as { at: number; project: Project }[] | undefined) || [];
}

export async function loadProject(id: string): Promise<Project | null> {
  const p = (await get('cf:proj:' + id)) as Project | undefined;
  if (!p) return null;
  return await hydrate(p);
}

export async function hydrate(p: Project): Promise<Project> {
  const assets: Asset[] = [];
  for (const a of p.assets) {
    const blob = (await get('cf:asset:' + a.id)) as Blob | undefined;
    if (blob) assets.push({ ...a, url: URL.createObjectURL(blob) });
  }
  return { ...p, assets };
}

export async function deleteProject(id: string) {
  const p = (await get('cf:proj:' + id)) as Project | undefined;
  const others = (await listProjects()).filter((x) => x.id !== id);
  const used = new Set<string>();
  for (const o of others) { const op = (await get('cf:proj:' + o.id)) as Project | undefined; op?.assets.forEach((a) => used.add(a.id)); }
  if (p) for (const a of p.assets) if (!used.has(a.id)) await del('cf:asset:' + a.id);
  await del('cf:proj:' + id);
  await del('cf:ver:' + id);
  const list = await listProjects();
  await set('cf:projects', list.filter((x) => x.id !== id));
}

export async function makeAsset(blob: Blob, name: string): Promise<Asset> {
  const id = uid('as_');
  await set('cf:asset:' + id, blob);
  const url = URL.createObjectURL(blob);
  const type = blob.type || '';
  let kind: Asset['kind'] = type.startsWith('image/') ? 'image' : type.startsWith('audio/') ? 'audio' : 'video';
  if (/\.(png|jpe?g|gif|webp|svg)$/i.test(name)) kind = 'image';
  if (/\.(mp3|wav|m4a|ogg|aac|flac)$/i.test(name)) kind = 'audio';
  let duration = 5, width = 0, height = 0;
  if (kind === 'image') {
    const img = new Image(); img.src = url;
    await new Promise((r) => { img.onload = r; img.onerror = r; });
    width = img.naturalWidth; height = img.naturalHeight;
  } else if (kind === 'video') {
    try { const m = await loadVideoMeta(url); duration = m.duration; width = m.width; height = m.height; if (!width) kind = 'audio'; } catch { /* */ }
  }
  if (kind === 'audio') {
    const a = document.createElement('audio'); a.src = url; a.preload = 'metadata';
    await new Promise((r) => { a.onloadedmetadata = r; a.onerror = r; setTimeout(r, 5000); });
    if (isFinite(a.duration)) duration = a.duration;
  }
  const peaks = kind !== 'image' && blob.size < 150e6 ? await computePeaks(blob, 600) : undefined;
  return { id, kind, name, url, duration: duration || 5, width, height, peaks };
}

import { useRef, type MouseEvent as RME } from 'react';
import { Eye, EyeOff, Lock, Unlock, Volume2, VolumeX, Plus, Trash2 } from 'lucide-react';
import type { Item, Project, Track } from './model';
import { projectDuration } from './model';
import { fmtTime, uid } from '../../lib/util';

const COLORS: Record<string, string> = { video: '#4c3fa8', image: '#2f6f8f', audio: '#1f7a5c', text: '#a8457a', shape: '#8a6a1f', sticker: '#a85a2f', bg: '#3a3a55' };
const ROW = 52;

export type TLProps = {
  project: Project;
  time: number;
  zoom: number;
  selected: string | null;
  snapping: boolean;
  onSelect: (id: string | null) => void;
  onSeek: (t: number) => void;
  update: (fn: (p: Project) => void, record?: boolean) => void;
};

export default function Timeline({ project, time, zoom, selected, snapping, onSelect, onSeek, update }: TLProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const headsRef = useRef<HTMLDivElement>(null);
  const dur = projectDuration(project) + 10;
  const width = dur * zoom;

  const snapPoints = (exclude: string) => {
    const pts = [0, time, ...project.markers];
    for (const it of project.items) if (it.id !== exclude) pts.push(it.start, it.start + it.dur);
    return pts;
  };
  const snap = (t: number, exclude: string) => {
    if (!snapping) return t;
    const thr = 8 / zoom;
    let best = t, bd = thr;
    for (const p of snapPoints(exclude)) { const d = Math.abs(p - t); if (d < bd) { bd = d; best = p; } }
    return best;
  };

  const startDrag = (e: RME, it: Item, mode: 'move' | 'l' | 'r') => {
    e.stopPropagation();
    e.preventDefault();
    onSelect(it.id);
    const tr = project.tracks.find((t) => t.id === it.track);
    if (tr?.locked) return;
    const x0 = e.clientX, y0 = e.clientY;
    const orig = { ...it };
    const asset = project.assets.find((a) => a.id === it.assetId);
    let recorded = false;
    const trackKind = tr?.kind;
    const move = (ev: MouseEvent) => {
      const dt = (ev.clientX - x0) / zoom;
      if (!recorded && Math.abs(ev.clientX - x0) + Math.abs(ev.clientY - y0) < 3) return;
      const rec = !recorded; recorded = true;
      update((p) => {
        const t = p.items.find((i) => i.id === it.id)!;
        if (mode === 'move') {
          let ns = Math.max(0, orig.start + dt);
          const s1 = snap(ns, it.id), s2 = snap(ns + orig.dur, it.id) - orig.dur;
          ns = Math.abs(s1 - ns) <= Math.abs(s2 - ns) ? s1 : s2;
          t.start = Math.max(0, ns);
          // vertical track change
          const rows = Math.round((ev.clientY - y0) / ROW);
          const idx = p.tracks.findIndex((x) => x.id === orig.track) + rows;
          const target = p.tracks[idx];
          if (target && target.kind === trackKind && !target.locked) t.track = target.id;
        } else if (mode === 'l') {
          const maxBack = it.type === 'video' || it.type === 'audio' ? orig.in / orig.speed : 1e9;
          let ns = snap(orig.start + dt, it.id);
          ns = Math.min(orig.start + orig.dur - 0.1, Math.max(orig.start - maxBack, ns, 0));
          const d = ns - orig.start;
          t.start = ns; t.dur = orig.dur - d;
          if (it.type === 'video' || it.type === 'audio') t.in = Math.max(0, orig.in + d * orig.speed);
        } else {
          let ne = snap(orig.start + orig.dur + dt, it.id);
          const maxEnd = asset && (it.type === 'video' || it.type === 'audio') ? orig.start + (asset.duration - orig.in) / orig.speed : 1e9;
          ne = Math.max(orig.start + 0.1, Math.min(maxEnd, ne));
          t.dur = ne - orig.start;
        }
      }, rec);
    };
    const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  const rulerDown = (e: RME) => {
    const el = scrollRef.current!;
    const seekAt = (cx: number) => { const r = el.getBoundingClientRect(); onSeek(Math.max(0, (cx - r.left + el.scrollLeft) / zoom)); };
    seekAt(e.clientX);
    const move = (ev: MouseEvent) => seekAt(ev.clientX);
    const up = () => { window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up); };
    window.addEventListener('mousemove', move); window.addEventListener('mouseup', up);
  };

  const step = zoom > 150 ? 0.5 : zoom > 60 ? 1 : zoom > 25 ? 5 : zoom > 8 ? 10 : 30;
  const ticks: number[] = [];
  for (let t = 0; t < dur; t += step) ticks.push(t);
  const setTrack = (id: string, p: Partial<Track>) => update((pr) => { const t = pr.tracks.find((x) => x.id === id)!; Object.assign(t, p); });

  return (
    <div className="tl-body">
      <div className="tl-heads" ref={headsRef}>
        <div style={{ height: 26, borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', padding: '0 6px', gap: 4 }}>
          <button className="btn ghost sm" title="Add visual track" onClick={() => update((p) => { p.tracks.unshift({ id: uid('tr_'), kind: 'visual', name: 'Layer ' + (p.tracks.length + 1), muted: false, locked: false, hidden: false }); })}><Plus size={12} />V</button>
          <button className="btn ghost sm" title="Add audio track" onClick={() => update((p) => { p.tracks.push({ id: uid('tr_'), kind: 'audio', name: 'Audio ' + (p.tracks.length + 1), muted: false, locked: false, hidden: false }); })}><Plus size={12} />A</button>
        </div>
        {project.tracks.map((tr) => (
          <div key={tr.id} className="tl-head" style={{ background: tr.kind === 'audio' ? '#0f1a1a40' : undefined }}>
            <span className="grow ellipsis" title={tr.name}>{tr.kind === 'audio' ? '♪' : '▦'} {tr.name}</span>
            {tr.kind === 'visual' ? <button className="btn ghost sm icon" title="Hide" onClick={() => setTrack(tr.id, { hidden: !tr.hidden })}>{tr.hidden ? <EyeOff size={12} /> : <Eye size={12} />}</button>
              : <button className="btn ghost sm icon" title="Mute" onClick={() => setTrack(tr.id, { muted: !tr.muted })}>{tr.muted ? <VolumeX size={12} color="#ff5470" /> : <Volume2 size={12} />}</button>}
            <button className="btn ghost sm icon" title="Lock" onClick={() => setTrack(tr.id, { locked: !tr.locked })}>{tr.locked ? <Lock size={12} color="#ffd23f" /> : <Unlock size={12} />}</button>
            {project.tracks.length > 1 && !project.items.some((i) => i.track === tr.id) && <button className="btn ghost sm icon" title="Delete empty track" onClick={() => update((p) => { p.tracks = p.tracks.filter((x) => x.id !== tr.id); })}><Trash2 size={11} /></button>}
          </div>
        ))}
      </div>
      <div className="tl-scroll" ref={scrollRef} onScroll={(e) => { if (headsRef.current) headsRef.current.scrollTop = e.currentTarget.scrollTop; }} onMouseDown={(e) => { if (e.target === e.currentTarget) onSelect(null); }}>
        <div style={{ width, position: 'relative', minHeight: '100%' }}>
          <div className="tl-ruler" onMouseDown={rulerDown}>
            {ticks.map((t) => (
              <div key={t} style={{ position: 'absolute', left: t * zoom, top: 0, height: '100%', borderLeft: '1px solid var(--line2)', paddingLeft: 4, fontSize: 10, color: 'var(--dim)' }}>{fmtTime(t)}</div>
            ))}
            {project.markers.map((m, i) => <div key={i} title="Marker (M)" style={{ position: 'absolute', left: m * zoom - 4, top: 14, width: 8, height: 8, background: '#ffd23f', transform: 'rotate(45deg)' }} />)}
            {project.markIn !== null && <div className="tl-inout" style={{ left: project.markIn * zoom, width: ((project.markOut ?? projectDuration(project)) - project.markIn) * zoom }} />}
          </div>
          {project.tracks.map((tr) => (
            <div key={tr.id} className={'tl-track' + (tr.kind === 'audio' ? ' audio' : '')} style={{ opacity: tr.hidden || tr.muted ? 0.45 : 1 }} onMouseDown={(e) => { if (e.target === e.currentTarget) onSelect(null); }}>
              {project.items.filter((i) => i.track === tr.id).map((it) => {
                const asset = project.assets.find((a) => a.id === it.assetId);
                return (
                  <div key={it.id} className={'tl-item' + (selected === it.id ? ' sel' : '')}
                    style={{ left: it.start * zoom, width: Math.max(6, it.dur * zoom), background: `linear-gradient(180deg, ${COLORS[it.type]}, ${COLORS[it.type]}cc)` }}
                    onMouseDown={(e) => startDrag(e, it, 'move')} title={`${it.name} · ${fmtTime(it.start, true)} → ${fmtTime(it.start + it.dur, true)}`}>
                    {asset?.peaks && asset.duration > 0 && <Wave peaks={asset.peaks} a={it.in / asset.duration} b={(it.in + it.dur * it.speed) / asset.duration} />}
                    <span className="ellipsis" style={{ position: 'relative', zIndex: 1 }}>
                      {it.type === 'text' ? '𝐓 ' + (it.text?.content || '') : it.type === 'sticker' ? it.sticker + ' sticker' : it.type === 'shape' ? '◆ ' + it.name : it.type === 'bg' ? '▨ Background' : it.name}
                      {it.speed !== 1 && ` · ${it.speed}×`}
                    </span>
                    {Object.values(it.kf).some((k) => k && k.length) && Object.values(it.kf).flatMap((k) => k || []).map((k, i) => <div key={i} style={{ position: 'absolute', left: k.t * zoom - 3, bottom: 2, width: 6, height: 6, background: '#ffd23f', transform: 'rotate(45deg)' }} />)}
                    <div className="h l" onMouseDown={(e) => startDrag(e, it, 'l')} />
                    <div className="h r" onMouseDown={(e) => startDrag(e, it, 'r')} />
                  </div>
                );
              })}
            </div>
          ))}
          <div className="tl-playhead" style={{ left: time * zoom }} />
        </div>
      </div>
    </div>
  );
}

function Wave({ peaks, a, b }: { peaks: number[]; a: number; b: number }) {
  const n = peaks.length;
  const i0 = Math.max(0, Math.floor(a * n)), i1 = Math.min(n, Math.ceil(b * n));
  const seg = peaks.slice(i0, i1);
  if (seg.length < 2) return null;
  const pts = seg.map((v, i) => `${(i / (seg.length - 1)) * 100},${50 - v * 48}`).join(' ');
  const pts2 = seg.map((v, i) => `${(i / (seg.length - 1)) * 100},${50 + v * 48}`).reverse().join(' ');
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0.45, pointerEvents: 'none' }}>
      <polygon points={pts + ' ' + pts2} fill="#fff" />
    </svg>
  );
}

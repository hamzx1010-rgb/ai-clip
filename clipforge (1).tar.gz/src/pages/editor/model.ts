import { easing, uid } from '../../lib/util';

export type AssetKind = 'video' | 'image' | 'audio';
export type Asset = { id: string; kind: AssetKind; name: string; url: string; duration: number; width: number; height: number; peaks?: number[] };

export type ItemType = 'video' | 'image' | 'audio' | 'text' | 'shape' | 'sticker' | 'bg';
export type KF = { t: number; v: number; ease: string };
export type KfProp = 'x' | 'y' | 'scale' | 'rotation' | 'opacity';

export type TextProps = {
  content: string; font: string; size: number; color: string; weight: number; align: CanvasTextAlign; stroke: string; strokeW: number;
  bg: string; shadow: boolean; glow: string; anim: 'none' | 'typewriter' | 'wave' | 'shake' | 'glitch' | 'neon' | 'bounce' | 'word' | 'ticker';
  gradient: string; italic: boolean; upper: boolean; width: number;
};
export type ShapeProps = { kind: 'rect' | 'circle' | 'triangle' | 'star' | 'arrow' | 'bubble' | 'progress' | 'line' | 'subscribe' | 'bars' | 'pie' | 'spectrum' | 'frame'; fill: string; stroke: string; strokeW: number; radius: number; w: number; h: number; label?: string };
export type Adj = { brightness: number; contrast: number; saturate: number; hue: number; blur: number; grayscale: number; sepia: number; invert: number; temp: number };
export type Fx = { vignette: number; grain: number; glitch: number; pixelate: number; rgbSplit: number; vhs: boolean; flipH: boolean; chroma: boolean; chromaColor: string; chromaTol: number; bgRemove: boolean; bgColor: string };

export type Item = {
  id: string; type: ItemType; track: string; name: string;
  start: number; dur: number; in: number; speed: number; volume: number; fadeIn: number; fadeOut: number; keepPitch: boolean; voiceEnhance: boolean;
  assetId?: string;
  x: number; y: number; scale: number; rotation: number; opacity: number; fit: 'cover' | 'contain';
  kf: Partial<Record<KfProp, KF[]>>;
  adj: Adj; lut: string; fx: Fx; blend: GlobalCompositeOperation; mask: 'none' | 'circle' | 'rounded' | 'heart';
  animIn: string; animOut: string; animDur: number; loopAnim: 'none' | 'wiggle' | 'pulse' | 'float' | 'spin' | 'kenburns';
  text?: TextProps; shape?: ShapeProps; sticker?: string; bg?: { colors: string[]; angle: number; animated: boolean };
};
export type Track = { id: string; kind: 'visual' | 'audio'; name: string; muted: boolean; locked: boolean; hidden: boolean };
export type Project = {
  id: string; name: string; w: number; h: number; fps: number; bgColor: string;
  tracks: Track[]; items: Item[]; assets: Asset[]; markers: number[]; markIn: number | null; markOut: number | null;
  createdAt: number; updatedAt: number;
};

export const DEFAULT_ADJ: Adj = { brightness: 100, contrast: 100, saturate: 100, hue: 0, blur: 0, grayscale: 0, sepia: 0, invert: 0, temp: 0 };
export const DEFAULT_FX: Fx = { vignette: 0, grain: 0, glitch: 0, pixelate: 0, rgbSplit: 0, vhs: false, flipH: false, chroma: false, chromaColor: '#00ff00', chromaTol: 90, bgRemove: false, bgColor: '' };

export const LUTS: Record<string, { name: string; adj: Partial<Adj>; tint?: string }> = {
  none: { name: 'None', adj: {} },
  cinematic: { name: 'Cinematic', adj: { contrast: 112, saturate: 88, brightness: 96 }, tint: 'rgba(0,70,90,.10)' },
  kodak: { name: 'Film Stock', adj: { contrast: 108, saturate: 110, sepia: 12 }, tint: 'rgba(255,170,90,.06)' },
  moody: { name: 'Moody', adj: { brightness: 86, contrast: 120, saturate: 72 } },
  bright: { name: 'Bright & Airy', adj: { brightness: 112, contrast: 92, saturate: 105 } },
  vintage: { name: 'Vintage', adj: { sepia: 45, contrast: 90, saturate: 85, brightness: 104 } },
  retro: { name: 'Retro 70s', adj: { sepia: 30, saturate: 130, hue: -10 }, tint: 'rgba(255,120,0,.08)' },
  noir: { name: 'Noir', adj: { grayscale: 100, contrast: 135 } },
  teal: { name: 'Teal & Orange', adj: { contrast: 110, saturate: 125, hue: -8 }, tint: 'rgba(0,128,128,.08)' },
  cyber: { name: 'Cyberpunk', adj: { saturate: 160, hue: 35, contrast: 110 }, tint: 'rgba(255,0,200,.08)' },
  faded: { name: 'Faded', adj: { contrast: 80, brightness: 110, saturate: 78 } },
  vivid: { name: 'Vivid', adj: { saturate: 155, contrast: 108 } },
  cold: { name: 'Nordic Cold', adj: { saturate: 80, hue: -15, brightness: 104 }, tint: 'rgba(80,140,255,.08)' },
  golden: { name: 'Golden Hour', adj: { saturate: 120, sepia: 20, brightness: 106 }, tint: 'rgba(255,190,80,.10)' },
};

export const ANIMS_IN = ['none', 'fade', 'slide-left', 'slide-right', 'slide-up', 'slide-down', 'zoom-in', 'zoom-out', 'pop', 'spin', 'blur', 'wipe-left', 'wipe-right', 'iris', 'glitch', 'whip', 'flip', 'drop'];

export function newItem(p: Partial<Item> & { type: ItemType; track: string }): Item {
  return {
    id: uid('it_'), name: p.type, start: 0, dur: 5, in: 0, speed: 1, volume: 1, fadeIn: 0, fadeOut: 0, keepPitch: true, voiceEnhance: false,
    x: 0.5, y: 0.5, scale: 1, rotation: 0, opacity: 1, fit: 'cover', kf: {}, adj: { ...DEFAULT_ADJ }, lut: 'none', fx: { ...DEFAULT_FX },
    blend: 'source-over', mask: 'none', animIn: 'none', animOut: 'none', animDur: 0.4, loopAnim: 'none',
    ...p,
  };
}

export function textProps(p: Partial<TextProps> = {}): TextProps {
  return { content: 'Your text', font: 'Montserrat', size: 0.06, color: '#ffffff', weight: 900, align: 'center', stroke: '#000000', strokeW: 0, bg: '', shadow: true, glow: '', anim: 'none', gradient: '', italic: false, upper: false, width: 0.86, ...p };
}
export function shapeProps(p: Partial<ShapeProps> = {}): ShapeProps {
  return { kind: 'rect', fill: '#7c5cff', stroke: '', strokeW: 0, radius: 0.1, w: 0.4, h: 0.2, ...p };
}

export function newProject(w = 1080, h = 1920, name = 'Untitled project'): Project {
  return {
    id: uid('proj_'), name, w, h, fps: 30, bgColor: '#000000',
    tracks: [
      { id: uid('tr_'), kind: 'visual', name: 'Text', muted: false, locked: false, hidden: false },
      { id: uid('tr_'), kind: 'visual', name: 'Overlay', muted: false, locked: false, hidden: false },
      { id: uid('tr_'), kind: 'visual', name: 'Main', muted: false, locked: false, hidden: false },
      { id: uid('tr_'), kind: 'audio', name: 'Voice', muted: false, locked: false, hidden: false },
      { id: uid('tr_'), kind: 'audio', name: 'Music', muted: false, locked: false, hidden: false },
    ],
    items: [], assets: [], markers: [], markIn: null, markOut: null, createdAt: Date.now(), updatedAt: Date.now(),
  };
}

export function projectDuration(p: Project): number {
  return Math.max(1, ...p.items.map((i) => i.start + i.dur));
}

export function kfValue(it: Item, prop: KfProp, localT: number): number {
  const ks = it.kf[prop];
  const base = it[prop] as number;
  if (!ks || !ks.length) return base;
  if (localT <= ks[0].t) return ks[0].v;
  for (let i = 1; i < ks.length; i++) {
    if (localT <= ks[i].t) {
      const a = ks[i - 1], b = ks[i];
      const k = easing(b.ease || 'inout', (localT - a.t) / (b.t - a.t || 1));
      return a.v + (b.v - a.v) * k;
    }
  }
  return ks[ks.length - 1].v;
}

export function setProp(it: Item, prop: KfProp, v: number, localT: number) {
  const ks = it.kf[prop];
  if (ks && ks.length) {
    const ex = ks.find((k) => Math.abs(k.t - localT) < 0.04);
    if (ex) ex.v = v; else { ks.push({ t: localT, v, ease: 'inout' }); ks.sort((a, b) => a.t - b.t); }
  } else (it as unknown as Record<string, number>)[prop] = v;
}

// ---------- Templates ----------
export type TemplateDef = { id: string; name: string; cat: string; emoji: string; aspect: '9:16' | '16:9' | '1:1'; music?: string; sfx?: { id: string; t: number }[]; build: (p: Project) => void };

const T = (p: Project, name: string) => p.tracks.find((t) => t.name === name)!.id;
const bgItem = (p: Project, colors: string[], dur: number, animated = true, angle = 135) => p.items.push(newItem({ type: 'bg', track: T(p, 'Main'), name: 'Background', start: 0, dur, bg: { colors, angle, animated } }));
const text = (p: Project, content: string, start: number, dur: number, tp: Partial<TextProps>, it: Partial<Item> = {}) => p.items.push(newItem({ type: 'text', track: T(p, 'Text'), name: content.slice(0, 18), start, dur, text: textProps({ content, ...tp }), animIn: 'pop', animOut: 'fade', ...it }));

export const TEMPLATES: TemplateDef[] = [
  {
    id: 'top5', name: 'Top 5 Listicle', cat: 'TikTok / Reels', emoji: '🏆', aspect: '9:16', music: 'hype-trap',
    build: (p) => {
      bgItem(p, ['#1a0b3b', '#6d28d9', '#db2777'], 16);
      text(p, 'TOP 5 HABITS\nOF RICH PEOPLE', 0, 3, { size: 0.085, font: 'Anton', stroke: '#000', strokeW: 0.12, anim: 'bounce' }, { y: 0.4 });
      ['5. Wake up early ⏰', '4. Read daily 📚', '3. Invest first 💸', '2. Guard your time 🛡️', '1. Think long-term 🧠'].forEach((s, i) => text(p, s, 3 + i * 2.5, 2.5, { size: 0.07, font: 'Montserrat', stroke: '#000', strokeW: 0.14, anim: 'word' }, { y: 0.5, animIn: i % 2 ? 'slide-left' : 'slide-right' }));
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'Progress', start: 0, dur: 15.5, y: 0.985, shape: shapeProps({ kind: 'progress', fill: '#ffd23f', w: 1, h: 0.012, radius: 0 }) }));
    },
  },
  {
    id: 'quote', name: 'Motivational Quote', cat: 'Motivational', emoji: '💪', aspect: '9:16', music: 'emotional',
    build: (p) => {
      bgItem(p, ['#0f172a', '#1e293b', '#334155'], 10);
      text(p, '“Discipline is choosing between what you want now and what you want most.”', 0.5, 8.5, { size: 0.055, font: 'Playfair Display', weight: 800, italic: true, anim: 'typewriter', shadow: true }, { y: 0.45, animIn: 'fade' });
      text(p, '— Abraham Lincoln', 4, 5, { size: 0.035, font: 'Inter', weight: 600, color: '#e8c872' }, { y: 0.62, animIn: 'slide-up' });
      p.items[0].fx = { ...DEFAULT_FX, vignette: 0.6, grain: 0.25 };
    },
  },
  {
    id: 'product', name: 'Product Ad', cat: 'Product ads', emoji: '👟', aspect: '9:16', music: 'upbeat', sfx: [{ id: 'whoosh', t: 0 }, { id: 'cash', t: 5 }],
    build: (p) => {
      bgItem(p, ['#fde047', '#fb923c', '#f43f5e'], 9);
      p.items.push(newItem({ type: 'sticker', track: T(p, 'Overlay'), name: 'Product', start: 0, dur: 9, sticker: '👟', scale: 2.2, y: 0.42, animIn: 'drop', loopAnim: 'float' }));
      text(p, 'NEW DROP', 0.3, 8.7, { size: 0.1, font: 'Anton', color: '#111', anim: 'none' }, { y: 0.14, animIn: 'slide-down' });
      text(p, 'AirStride 2', 1, 8, { size: 0.06, font: 'Montserrat', color: '#fff', stroke: '#111', strokeW: 0.12 }, { y: 0.68 });
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'Price tag', start: 2.5, dur: 6.5, x: 0.76, y: 0.28, rotation: 12, animIn: 'pop', loopAnim: 'pulse', shape: shapeProps({ kind: 'star', fill: '#111', w: 0.3, h: 0.3, label: '$89' }) }));
      p.items.push(newItem({ type: 'shape', track: T(p, 'Text'), name: 'CTA', start: 4.5, dur: 4.5, y: 0.82, animIn: 'zoom-in', loopAnim: 'pulse', shape: shapeProps({ kind: 'rect', fill: '#111', w: 0.6, h: 0.08, radius: 0.5, label: 'SHOP NOW →' }) }));
    },
  },
  {
    id: 'storytime', name: 'Storytime', cat: 'Storytime', emoji: '📖', aspect: '9:16', music: 'lofi',
    build: (p) => {
      bgItem(p, ['#312e81', '#0e7490'], 12);
      text(p, 'STORYTIME 📖', 0, 12, { size: 0.05, font: 'Poppins', bg: '#ffffff', color: '#111', shadow: false }, { y: 0.1, animIn: 'slide-down' });
      ['So I walked into my job interview…', 'and the CEO was the guy I cut off in traffic 😳', 'He looked at me and said…', '“Nice driving.” 💀'].forEach((s, i) => text(p, s, 0.5 + i * 2.8, 2.8, { size: 0.058, font: 'Montserrat', stroke: '#000', strokeW: 0.14, anim: 'word' }, { y: 0.5 }));
    },
  },
  {
    id: 'ytintro', name: 'YouTube Intro', cat: 'YouTube intros', emoji: '▶️', aspect: '16:9', music: 'synthwave', sfx: [{ id: 'riser', t: 0 }, { id: 'boom', t: 2.4 }],
    build: (p) => {
      bgItem(p, ['#0f0c29', '#302b63', '#ff00cc'], 6);
      text(p, 'YOUR CHANNEL', 2.4, 3.6, { size: 0.16, font: 'Bebas Neue', weight: 400, anim: 'glitch', glow: '#ff3df2' }, { y: 0.45, animIn: 'zoom-out' });
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'Subscribe', start: 3.2, dur: 2.8, y: 0.75, animIn: 'pop', shape: shapeProps({ kind: 'subscribe', fill: '#ff0000', w: 0.26, h: 0.1, radius: 0.2 }) }));
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'Spectrum', start: 0, dur: 6, y: 0.9, shape: shapeProps({ kind: 'spectrum', fill: '#ff3df2', w: 0.8, h: 0.12 }) }));
    },
  },
  {
    id: 'news', name: 'Breaking News', cat: 'News / commentary', emoji: '📰', aspect: '16:9', music: 'suspense',
    build: (p) => {
      bgItem(p, ['#111827', '#1f2937'], 10, false);
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'Lower third', start: 0.5, dur: 9.5, y: 0.8, animIn: 'wipe-right', shape: shapeProps({ kind: 'rect', fill: '#c4001a', w: 0.62, h: 0.1, radius: 0, label: 'BREAKING NEWS' }), x: 0.33 }));
      text(p, 'Creator makes $0 from 11M views — then this happened', 1, 9, { size: 0.04, font: 'Oswald', weight: 600, bg: '#ffffff', color: '#111', shadow: false, width: 0.9 }, { y: 0.9, animIn: 'slide-up' });
      text(p, 'LIVE • CLIPFORGE NEWS • TRENDING NOW • CREATOR ECONOMY • ', 0, 10, { size: 0.03, font: 'Roboto Mono', weight: 700, anim: 'ticker', bg: '#000000' }, { y: 0.975, animIn: 'none' });
    },
  },
  {
    id: 'countdown', name: 'Countdown 3-2-1', cat: 'Intros', emoji: '⏱️', aspect: '9:16', sfx: [{ id: 'ding', t: 0 }, { id: 'ding', t: 1 }, { id: 'ding', t: 2 }, { id: 'boom', t: 3 }],
    build: (p) => {
      bgItem(p, ['#000000', '#1f1147'], 4.5);
      ['3', '2', '1'].forEach((n, i) => text(p, n, i, 1, { size: 0.35, font: 'Anton', weight: 400, glow: '#7c5cff' }, { animIn: 'zoom-out', animOut: 'fade', animDur: 0.3 }));
      text(p, 'GO!', 3, 1.5, { size: 0.25, font: 'Anton', weight: 400, color: '#ffd23f', anim: 'shake' }, { animIn: 'pop' });
    },
  },
  {
    id: 'meme', name: 'Classic Meme', cat: 'Memes', emoji: '😂', aspect: '1:1', sfx: [{ id: 'bruh', t: 2 }],
    build: (p) => {
      bgItem(p, ['#475569', '#1e293b'], 5, false);
      p.items.push(newItem({ type: 'sticker', track: T(p, 'Overlay'), name: 'Face', start: 0, dur: 5, sticker: '🤨', scale: 2.4, loopAnim: 'kenburns' }));
      text(p, 'WHEN THE CODE WORKS', 0, 5, { size: 0.09, font: 'Impact', weight: 400, stroke: '#000', strokeW: 0.14, upper: true, shadow: false }, { y: 0.1, animIn: 'none' });
      text(p, 'ON THE FIRST TRY', 1.5, 3.5, { size: 0.09, font: 'Impact', weight: 400, stroke: '#000', strokeW: 0.14, upper: true, shadow: false }, { y: 0.9, animIn: 'none' });
    },
  },
  {
    id: 'beforeafter', name: 'Before / After', cat: 'Comparisons', emoji: '↔️', aspect: '9:16', music: 'house',
    build: (p) => {
      bgItem(p, ['#0b0a12', '#1e1c2e'], 8, false);
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'Before', start: 0, dur: 8, y: 0.27, shape: shapeProps({ kind: 'rect', fill: '#374151', w: 0.9, h: 0.24, radius: 0.08, label: 'drop BEFORE clip here' }) }));
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'After', start: 1.5, dur: 6.5, y: 0.73, animIn: 'wipe-right', shape: shapeProps({ kind: 'rect', fill: '#7c5cff', w: 0.9, h: 0.24, radius: 0.08, label: 'drop AFTER clip here' }) }));
      text(p, 'BEFORE', 0, 8, { size: 0.05, font: 'Anton', weight: 400 }, { y: 0.1 });
      text(p, 'AFTER ✨', 1.5, 6.5, { size: 0.05, font: 'Anton', weight: 400, color: '#ffd23f' }, { y: 0.56 });
    },
  },
  {
    id: 'stats', name: 'Data Story', cat: 'Educational', emoji: '📊', aspect: '9:16', music: 'upbeat',
    build: (p) => {
      bgItem(p, ['#042f2e', '#134e4a'], 9, false);
      text(p, 'Where creator income\nreally comes from', 0, 9, { size: 0.06, font: 'Poppins', weight: 800 }, { y: 0.14 });
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'Bar chart', start: 0.8, dur: 8.2, y: 0.45, shape: shapeProps({ kind: 'bars', fill: '#5eead4', w: 0.8, h: 0.3 }) }));
      p.items.push(newItem({ type: 'shape', track: T(p, 'Overlay'), name: 'Pie chart', start: 3.5, dur: 5.5, y: 0.76, animIn: 'pop', shape: shapeProps({ kind: 'pie', fill: '#fbbf24', w: 0.3, h: 0.3 }) }));
    },
  },
];

export const STICKERS = '😂 🤣 😭 😱 🤯 😳 🥶 🔥 💯 💀 👀 🙌 👏 💪 🧠 ❤️ 💔 ✨ ⚡ 🚀 💰 💸 🤑 🏆 🎉 🎯 📈 📉 ✅ ❌ ⚠️ ❓ ❗ 👉 👇 👆 🤔 😎 🥳 😡 🤬 🙏 👑 💎 🍿 🎬 🎮 🎧 🎤 📱 💻 ⏰ 📚 🌈 ☀️ 🌙 ⭐ 🍕 🍔 ☕ 🐐 🦄 🐶 🐱 👻 🤖 👽 💩 🫡 🫠 🤝 🫶 👍 👎 🤞 ✌️ 🎁 🛒 📦 🏠 🚗 ✈️ 🗣️ 💬 🔔 📌'.split(' ');

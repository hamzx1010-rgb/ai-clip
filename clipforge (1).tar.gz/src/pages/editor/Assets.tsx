import { useEffect, useRef, useState } from 'react';
import { Upload, Music2, Play, Pause, Mic, MonitorUp, Camera, Sparkles, Wand2, Search, Image as ImageIcon, Square } from 'lucide-react';
import type { Asset, Item, Project, TemplateDef } from './model';
import { STICKERS, TEMPLATES, newItem, shapeProps, textProps } from './model';
import { MUSIC, SFX, renderMusic, renderSfx, previewBuffer, stopPreview, musicWavBlob, sfxWavBlob, beatTimes } from '../../lib/synth';
import { hasAI, writeScript, ttsOpenAI, generateImageAI, transcribeWhisper, type ScriptScene } from '../../lib/llm';
import { useApp } from '../../store';
import { fmtTime, uid } from '../../lib/util';
import { pickAudioMime, pickMime } from '../../lib/recorder';
import { decodeToMono, analyzeAudio } from '../../lib/audio';
import { findClips } from '../../lib/engine';
import { chunkWords } from '../../lib/captions';
import { FONT_LIST } from '../../lib/captions';

export type AssetsProps = {
  tab: string;
  project: Project;
  time: number;
  selected: Item | null;
  addBlob: (b: Blob, name: string, place?: boolean) => Promise<Asset>;
  placeAsset: (a: Asset) => void;
  addItem: (it: Partial<Item> & { type: Item['type'] }, kind?: 'visual' | 'audio', trackName?: string) => void;
  update: (fn: (p: Project) => void, record?: boolean) => void;
  applyTemplate: (t: TemplateDef) => void;
  snapshot: () => string;
};

export default function Assets(props: AssetsProps) {
  switch (props.tab) {
    case 'media': return <MediaTab {...props} />;
    case 'text': return <TextTab {...props} />;
    case 'stickers': return <StickerTab {...props} />;
    case 'shapes': return <ShapesTab {...props} />;
    case 'bg': return <BgTab {...props} />;
    case 'audio': return <AudioTab {...props} />;
    case 'templates': return <TemplatesTab {...props} />;
    case 'ai': return <AiTab {...props} />;
    case 'record': return <RecordTab {...props} />;
    case 'stock': return <StockTab {...props} />;
    default: return null;
  }
}

function MediaTab({ project, addBlob, placeAsset }: AssetsProps) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const onFiles = async (fl: FileList | null) => {
    if (!fl) return;
    setBusy(true);
    for (const f of Array.from(fl)) await addBlob(f, f.name, false);
    setBusy(false);
  };
  return (
    <div className="col gap16">
      <div className="drop" style={{ padding: 20 }} onClick={() => ref.current?.click()} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); onFiles(e.dataTransfer.files); }}>
        <Upload size={22} color="#b8a6ff" />
        <div style={{ fontWeight: 700, marginTop: 6 }}>{busy ? 'Importing…' : 'Upload media'}</div>
        <div className="dim tiny">Video · images · GIF · audio — or drag files onto the preview</div>
        <input ref={ref} type="file" multiple hidden accept="video/*,image/*,audio/*" onChange={(e) => onFiles(e.target.files)} />
      </div>
      <button className="btn sm" onClick={async () => { const r = await fetch(import.meta.env.BASE_URL + 'sample/sample.mp4'); const b = await r.blob(); await addBlob(new File([b], 'sample-podcast.mp4', { type: 'video/mp4' }), 'sample-podcast.mp4', false); }}><Play size={12} /> Add sample podcast footage</button>
      <div className="section-title">Project media ({project.assets.length}) — click to add at playhead</div>
      <div className="asset-grid">
        {project.assets.map((a) => (
          <div key={a.id} className="asset" onClick={() => placeAsset(a)} draggable onDragStart={(e) => e.dataTransfer.setData('cf/asset', a.id)} title={a.name}>
            {a.kind === 'image' ? <img src={a.url} /> : a.kind === 'video' ? <video src={a.url + '#t=0.5'} muted preload="metadata" disableRemotePlayback /> : <Music2 size={22} color="#3ddc97" />}
            <div className="lbl ellipsis">{a.name} {a.kind !== 'image' && '· ' + fmtTime(a.duration)}</div>
          </div>
        ))}
      </div>
      {!project.assets.length && <div className="dim small">No media yet. Everything you import is stored locally in your browser (IndexedDB) and restored with the project.</div>}
    </div>
  );
}

const TEXT_PRESETS: { name: string; it: Partial<Item> }[] = [
  { name: 'Big Title', it: { text: textProps({ content: 'BIG TITLE', font: 'Anton', weight: 400, size: 0.1, stroke: '#000', strokeW: 0.1 }), animIn: 'pop', y: 0.3 } },
  { name: 'Subtitle', it: { text: textProps({ content: 'subtitle goes here', font: 'Inter', weight: 600, size: 0.04 }), animIn: 'fade', y: 0.4 } },
  { name: 'Hormozi Caption', it: { text: textProps({ content: 'THIS CHANGES EVERYTHING', font: 'Montserrat', weight: 900, size: 0.065, stroke: '#000', strokeW: 0.16, color: '#ffe135' }), animIn: 'pop', y: 0.7 } },
  { name: 'TikTok Box', it: { text: textProps({ content: 'wait for it…', font: 'Poppins', weight: 700, size: 0.045, bg: '#ffffff', color: '#111', shadow: false }), animIn: 'slide-up', y: 0.2 } },
  { name: 'Neon Sign', it: { text: textProps({ content: 'OPEN LATE', font: 'Bebas Neue', weight: 400, size: 0.11, color: '#fff', glow: '#ff3df2', anim: 'neon' }), animIn: 'fade' } },
  { name: 'Glitch', it: { text: textProps({ content: 'SYSTEM ERROR', font: 'Anton', weight: 400, size: 0.09, anim: 'glitch' }), animIn: 'glitch' } },
  { name: 'Typewriter', it: { text: textProps({ content: 'Once upon a time…', font: 'Roboto Mono', weight: 700, size: 0.045, anim: 'typewriter' }), animIn: 'none' } },
  { name: 'Wavy', it: { text: textProps({ content: 'good vibes', font: 'Pacifico', weight: 400, size: 0.08, anim: 'wave', color: '#ffd23f' }), animIn: 'pop' } },
  { name: 'Gradient', it: { text: textProps({ content: 'GRADIENT', font: 'Poppins', weight: 900, size: 0.1, color: '#7c5cff', gradient: '#ff4fa3' }), animIn: 'zoom-in' } },
  { name: 'Handwritten', it: { text: textProps({ content: 'note to self', font: 'Caveat', weight: 700, size: 0.08, shadow: false }), animIn: 'fade' } },
  { name: 'Lower Third', it: { text: textProps({ content: 'Maya Lopez · Host', font: 'Montserrat', weight: 800, size: 0.035, bg: '#7c5cff', align: 'left' }), animIn: 'slide-right', x: 0.32, y: 0.82 } },
  { name: 'News Ticker', it: { text: textProps({ content: 'BREAKING • LIVE UPDATES • TRENDING NOW • ', font: 'Roboto Mono', weight: 700, size: 0.03, anim: 'ticker', bg: '#c4001a' }), y: 0.96 } },
  { name: 'Quote', it: { text: textProps({ content: '“Stay hungry, stay foolish.”', font: 'Playfair Display', weight: 800, italic: true, size: 0.06 }), animIn: 'fade' } },
  { name: 'Meme Top', it: { text: textProps({ content: 'WHEN YOU', font: 'Impact', weight: 400, size: 0.09, stroke: '#000', strokeW: 0.14, shadow: false }), y: 0.1 } },
  { name: 'Word by Word', it: { text: textProps({ content: 'one word at a time builds suspense', font: 'Montserrat', weight: 900, size: 0.06, anim: 'word', stroke: '#000', strokeW: 0.12 }) } },
  { name: 'Shake!', it: { text: textProps({ content: 'BOOM!', font: 'Bangers', weight: 400, size: 0.14, color: '#ff4d4d', anim: 'shake', stroke: '#000', strokeW: 0.14 }), animIn: 'pop' } },
];

function TextTab({ addItem }: AssetsProps) {
  return (
    <div className="col gap16">
      <button className="btn primary" onClick={() => addItem({ type: 'text', name: 'Text', text: textProps(), animIn: 'pop' })}>+ Add text</button>
      <div className="section-title">Animated text presets</div>
      <div className="col gap6">
        {TEXT_PRESETS.map((p) => (
          <div key={p.name} className="clip-card" style={{ padding: '10px 12px' }} onClick={() => addItem({ type: 'text', name: p.name, dur: 4, ...p.it })}>
            <span style={{ fontFamily: `"${p.it.text!.font}"`, fontWeight: p.it.text!.weight, fontSize: 18, color: p.it.text!.color, fontStyle: p.it.text!.italic ? 'italic' : undefined, textShadow: p.it.text!.glow ? `0 0 10px ${p.it.text!.glow}` : undefined, background: p.it.text!.bg || undefined, padding: p.it.text!.bg ? '0 6px' : 0, borderRadius: 4 }} className="ellipsis">{p.it.text!.content}</span>
          </div>
        ))}
      </div>
      <div className="dim tiny">{FONT_LIST.length} fonts built-in · every property is keyframeable.</div>
    </div>
  );
}

function StickerTab({ addItem, addBlob }: AssetsProps) {
  const [q, setQ] = useState('');
  const list = STICKERS.filter((s) => !q || s.includes(q));
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div className="col gap16">
      <input className="input sm" placeholder="Paste any emoji to search…" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="emoji-grid">
        {list.map((s) => <button key={s} onClick={() => addItem({ type: 'sticker', name: s, sticker: s, dur: 3, animIn: 'pop', loopAnim: 'wiggle', y: 0.35 })}>{s}</button>)}
      </div>
      <div className="section-title">Animated social stickers</div>
      <div className="grid g2">
        <button className="btn sm" onClick={() => addItem({ type: 'shape', name: 'Subscribe', dur: 4, y: 0.8, animIn: 'pop', shape: shapeProps({ kind: 'subscribe', fill: '#ff0000', w: 0.5, h: 0.07, radius: 0.2 }) })}>🔔 Subscribe</button>
        <button className="btn sm" onClick={() => addItem({ type: 'sticker', name: 'Like', sticker: '👍', dur: 2.5, animIn: 'pop', loopAnim: 'pulse', x: 0.8, y: 0.75 })}>👍 Like</button>
        <button className="btn sm" onClick={() => addItem({ type: 'text', name: 'Follow', dur: 3, y: 0.85, animIn: 'slide-up', text: textProps({ content: 'FOLLOW FOR PART 2 ➕', size: 0.04, bg: '#fe2c55', shadow: false }) })}>➕ Follow</button>
        <button className="btn sm" onClick={() => addItem({ type: 'text', name: 'Comment bait', dur: 3, y: 0.5, animIn: 'pop', text: textProps({ content: 'Comment your answer 👇', size: 0.045, bg: '#7c5cff', shadow: false }) })}>💬 Comment bait</button>
      </div>
      <button className="btn sm" onClick={() => ref.current?.click()}><ImageIcon size={13} /> Upload custom sticker (PNG / GIF / SVG)</button>
      <input ref={ref} type="file" accept="image/*" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) await addBlob(f, f.name, true); }} />
    </div>
  );
}

function ShapesTab({ addItem }: AssetsProps) {
  const shapes: [string, Partial<Item>][] = [
    ['▭ Rectangle', { shape: shapeProps({ kind: 'rect' }) }], ['● Circle', { shape: shapeProps({ kind: 'circle', w: 0.3, fill: '#ff4fa3' }) }], ['▲ Triangle', { shape: shapeProps({ kind: 'triangle', fill: '#ffd23f', w: 0.3, h: 0.17 }) }],
    ['★ Star', { shape: shapeProps({ kind: 'star', fill: '#ffd23f', w: 0.3 }) }], ['➜ Arrow', { shape: shapeProps({ kind: 'arrow', fill: '#ff4d4d', w: 0.4, h: 0.1 }) }], ['💬 Speech bubble', { shape: shapeProps({ kind: 'bubble', fill: '#ffffff', w: 0.6, h: 0.14, label: 'Hello!' }) }],
    ['— Line', { shape: shapeProps({ kind: 'line', fill: '#ffffff', w: 0.6, h: 0.05 }) }], ['▢ Frame', { shape: shapeProps({ kind: 'frame', fill: '#ffffff', w: 0.9, h: 0.9, radius: 0.05, strokeW: 1 }) }], ['▬ Progress bar', { y: 0.985, shape: shapeProps({ kind: 'progress', fill: '#7c5cff', w: 1, h: 0.012, radius: 0 }) }],
    ['📊 Bar chart', { shape: shapeProps({ kind: 'bars', fill: '#5eead4', w: 0.7, h: 0.25 }) }], ['◔ Pie chart', { shape: shapeProps({ kind: 'pie', fill: '#fbbf24', w: 0.4 }) }], ['🎚️ Audio spectrum', { y: 0.85, shape: shapeProps({ kind: 'spectrum', fill: '#7c5cff', w: 0.8, h: 0.1 }) }],
    ['🏷️ Callout box', { shape: shapeProps({ kind: 'rect', fill: '#111111', w: 0.6, h: 0.08, radius: 0.5, label: 'Callout text' }) }],
  ];
  return (
    <div className="col gap6">
      {shapes.map(([n, p]) => <button key={n} className="btn" style={{ justifyContent: 'flex-start' }} onClick={() => addItem({ type: 'shape', name: n.slice(2), dur: 4, animIn: 'pop', ...p })}>{n}</button>)}
      <div className="dim tiny mt8">Tip: add a “Frame” + mask your video to a circle for picture-in-picture.</div>
    </div>
  );
}

const GRADS = [['#7c5cff', '#ff4fa3'], ['#0f2027', '#2c5364'], ['#ff9966', '#ff5e62'], ['#00c6ff', '#0072ff'], ['#f7971e', '#ffd200'], ['#1a2a6c', '#b21f1f', '#fdbb2d'], ['#11998e', '#38ef7d'], ['#232526', '#414345'], ['#fc466b', '#3f5efb'], ['#000000', '#1f1147'], ['#fdfcfb', '#e2d1c3'], ['#0f0c29', '#302b63', '#ff00cc'], ['#ee0979', '#ff6a00'], ['#4b6cb7', '#182848'], ['#ffffff', '#ffffff'], ['#000000', '#000000']];
function BgTab({ addItem }: AssetsProps) {
  const [anim, setAnim] = useState(true);
  return (
    <div className="col gap16">
      <label className="toggle" onClick={() => setAnim(!anim)}><span>Animated gradient</span><div className={'switch' + (anim ? ' on' : '')} /></label>
      <div className="asset-grid">
        {GRADS.map((g, i) => <div key={i} className="asset" style={{ background: `linear-gradient(135deg, ${g.join(',')})` }} onClick={() => addItem({ type: 'bg', name: 'Background', dur: 10, bg: { colors: g, angle: 135, animated: anim } }, 'visual', 'Main')} />)}
      </div>
    </div>
  );
}

function AudioTab({ addBlob, placeAsset, update, project }: AssetsProps) {
  const [prev, setPrev] = useState('');
  const [busy, setBusy] = useState('');
  useEffect(() => () => stopPreview(), []);
  const addMusic = async (id: string) => {
    setBusy(id);
    const blob = await musicWavBlob(id, 4);
    const m = MUSIC.find((x) => x.id === id)!;
    const a = await addBlob(blob, `♪ ${m.name}.wav`, false);
    placeAsset(a);
    update((p) => { p.markers = [...new Set([...p.markers, ...beatTimes(id, Math.min(a.duration, 60)).filter((_, i) => i % 4 === 0).map((t) => +t.toFixed(3))])]; }, false);
    setBusy('');
  };
  const addSfx = async (id: string, name: string) => { const a = await addBlob(await sfxWavBlob(id), `${name}.wav`, false); placeAsset(a); };
  return (
    <div className="col gap16">
      <div className="section-title">Royalty-free music (procedural)</div>
      <div className="col gap6">
        {MUSIC.map((m) => (
          <div key={m.id} className="clip-card" style={{ alignItems: 'center', padding: 8 }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: m.color + '33', display: 'grid', placeItems: 'center' }}><Music2 size={15} color={m.color} /></div>
            <div className="grow" style={{ minWidth: 0 }}><b className="small">{m.name}</b><div className="dim tiny">{m.mood} · {m.bpm} BPM</div></div>
            <button className="btn sm icon" onClick={async () => { if (prev === m.id) { stopPreview(); setPrev(''); } else { previewBuffer(await renderMusic(m.id), true); setPrev(m.id); } }}>{prev === m.id ? <Pause size={12} /> : <Play size={12} />}</button>
            <button className="btn sm" onClick={() => addMusic(m.id)} disabled={busy === m.id}>{busy === m.id ? '…' : '+ Add'}</button>
          </div>
        ))}
      </div>
      <div className="dim tiny">Adding a track also drops beat markers on the ruler for cut-to-the-beat editing.</div>
      <div className="section-title">Sound effects</div>
      <div className="grid g2">
        {SFX.map((s) => (
          <div key={s.id} className="row gap4">
            <button className="btn sm grow" style={{ justifyContent: 'flex-start' }} onClick={() => addSfx(s.id, s.name)}>{s.emoji} {s.name}</button>
            <button className="btn sm icon ghost" onClick={async () => previewBuffer(await renderSfx(s.id))}><Play size={11} /></button>
          </div>
        ))}
      </div>
      <div className="section-title">Beat detection</div>
      <button className="btn sm" onClick={async () => {
        const audioItems = project.items.filter((i) => i.type === 'audio' || i.type === 'video');
        if (!audioItems.length) { useApp.getState().toast('Add audio or video first', 'error'); return; }
        const it = audioItems[audioItems.length - 1];
        const a = project.assets.find((x) => x.id === it.assetId)!;
        const blob = await (await fetch(a.url)).blob();
        const an = analyzeAudio(await decodeToMono(blob));
        const beats = an.spikes.map((s) => it.start + (s.t - it.in) / it.speed).filter((t) => t >= it.start && t <= it.start + it.dur);
        update((p) => { p.markers = [...new Set([...p.markers, ...beats.map((t) => +t.toFixed(2))])].sort((x, y) => x - y); });
        useApp.getState().toast(`🥁 ${beats.length} beat / impact markers added`, 'success');
      }}>Detect beats in last audio clip → markers</button>
    </div>
  );
}

function TemplatesTab({ applyTemplate }: AssetsProps) {
  return (
    <div className="col gap6">
      <div className="dim small mb8">Fully editable. Applying a template replaces the current timeline (undo with Ctrl+Z).</div>
      {TEMPLATES.map((t) => (
        <div key={t.id} className="clip-card" style={{ alignItems: 'center' }} onClick={() => applyTemplate(t)}>
          <div style={{ width: t.aspect === '16:9' ? 64 : 36, height: t.aspect === '16:9' ? 36 : t.aspect === '1:1' ? 36 : 64, borderRadius: 6, background: 'var(--grad)', display: 'grid', placeItems: 'center', fontSize: 18, flexShrink: 0 }}>{t.emoji}</div>
          <div className="grow"><b>{t.name}</b><div className="dim tiny">{t.cat} · {t.aspect}{t.music ? ' · music' : ''}</div></div>
        </div>
      ))}
      <div className="dim tiny mt8">Save any project as your own template by duplicating it from the dashboard.</div>
    </div>
  );
}

function AiTab({ project, selected, update, addItem, addBlob, placeAsset, snapshot }: AssetsProps) {
  const toast = useApp((s) => s.toast);
  const [topic, setTopic] = useState('');
  const [script, setScript] = useState<{ title: string; hook: string; scenes: ScriptScene[]; cta: string; hashtags: string[] } | null>(null);
  const [busy, setBusy] = useState('');
  const [tts, setTts] = useState('');
  const [imgPrompt, setImgPrompt] = useState('');
  const sel = selected;
  const selAsset = project.assets.find((a) => a.id === sel?.assetId);
  const run = async (k: string, fn: () => Promise<void>) => { setBusy(k); try { await fn(); } catch (e) { toast((e as Error).message, 'error'); } setBusy(''); };

  const buildFromScript = () => {
    if (!script) return;
    update((p) => {
      const vt = p.tracks.find((t) => t.name === 'Text')?.id || p.tracks[0].id;
      const ot = p.tracks.find((t) => t.name === 'Overlay')?.id || vt;
      const mt = p.tracks.find((t) => t.name === 'Main')?.id || p.tracks[0].id;
      const keepTracks = new Set(p.tracks.filter((t) => t.kind === 'audio').map((t) => t.id));
      p.items = p.items.filter((i) => keepTracks.has(i.track));
      let t = 0;
      const pal = [['#7c5cff', '#ff4fa3'], ['#0f2027', '#2c5364'], ['#ff9966', '#ff5e62'], ['#11998e', '#38ef7d'], ['#1a2a6c', '#b21f1f'], ['#fc466b', '#3f5efb']];
      p.items.push(newItem({ type: 'text', track: vt, name: 'Hook', start: 0, dur: 2.5, text: textProps({ content: script.hook, size: 0.06, stroke: '#000', strokeW: 0.12 }), animIn: 'pop', y: 0.45 }));
      p.items.push(newItem({ type: 'bg', track: mt, name: 'Background', start: 0, dur: 2.5, bg: { colors: pal[0], angle: 135, animated: true } }));
      t = 2.5;
      script.scenes.forEach((s, i) => {
        const d = Math.max(2.5, s.seconds || 4);
        p.items.push(newItem({ type: 'bg', track: mt, name: s.heading, start: t, dur: d, bg: { colors: pal[(i + 1) % pal.length], angle: 135, animated: true }, animIn: 'fade' }));
        p.items.push(newItem({ type: 'text', track: vt, name: s.onScreen, start: t, dur: d, text: textProps({ content: s.onScreen, size: 0.07, font: 'Anton', weight: 400, stroke: '#000', strokeW: 0.1 }), animIn: i % 2 ? 'slide-left' : 'slide-right', y: 0.3 }));
        p.items.push(newItem({ type: 'text', track: ot, name: 'VO', start: t + 0.3, dur: d - 0.3, text: textProps({ content: s.voiceover, size: 0.04, font: 'Inter', weight: 700, anim: 'word' }), y: 0.62 }));
        t += d;
      });
      p.items.push(newItem({ type: 'text', track: vt, name: 'CTA', start: t, dur: 3, text: textProps({ content: script.cta, size: 0.045, bg: '#fe2c55', shadow: false }), animIn: 'pop', y: 0.5 }));
      p.items.push(newItem({ type: 'bg', track: mt, name: 'Background', start: t, dur: 3, bg: { colors: ['#000', '#1f1147'], angle: 135, animated: true } }));
    });
    toast('🎬 Storyboard built — visual tracks replaced (Ctrl+Z to undo)', 'success');
  };

  return (
    <div className="col gap16">
      {!hasAI() && <div className="card tight small"><span className="badge warn">offline mode</span> <span className="muted">Script writer & highlight tools work offline. Add an OpenAI key in Settings for GPT scripts, Whisper captions, TTS voices and DALL·E images.</span></div>}
      <div className="card tight">
        <b className="small">✍️ AI Script Writer + Storyboard</b>
        <input className="input sm mt8" placeholder="Topic, e.g. how to grow on TikTok in 2026" value={topic} onChange={(e) => setTopic(e.target.value)} />
        <button className="btn sm primary mt8" disabled={!!busy} onClick={() => run('script', async () => setScript(await writeScript(topic, 'TikTok', 'energetic', 30)))}>{busy === 'script' ? 'Writing…' : 'Write script'}</button>
        {script && (
          <div className="small mt8 col gap4">
            <b>{script.title}</b>
            <div><span className="badge brand">HOOK</span> {script.hook}</div>
            {script.scenes.map((s, i) => <div key={i} className="muted"><b style={{ color: 'var(--text)' }}>{i + 1}. {s.heading}</b> — {s.voiceover} <i className="dim">[{s.visual}]</i></div>)}
            <div><span className="badge ok">CTA</span> {script.cta}</div>
            <div className="dim">{script.hashtags.join(' ')}</div>
            <button className="btn sm mt8" onClick={buildFromScript}><Wand2 size={12} /> Build video from script</button>
          </div>
        )}
      </div>
      <div className="card tight">
        <b className="small">⚡ AI Auto-Edit highlight reel</b>
        <div className="dim tiny mt8">Select a video clip on the timeline → we find its best moments (energy, spikes, pacing) and assemble a 30s highlight reel.</div>
        <button className="btn sm mt8" disabled={!selAsset || selAsset.kind !== 'video' || !!busy} onClick={() => run('reel', async () => {
          const blob = await (await fetch(selAsset!.url)).blob();
          const an = analyzeAudio(await decodeToMono(blob));
          const clips = findClips({ duration: selAsset!.duration, audio: an, visual: null, transcript: null }, { count: 5, minLen: 4, maxLen: 9, categories: [], keywords: [], platform: 'tiktok', speakerPriority: 'all' }).sort((a, b) => a.start - b.start);
          update((p) => {
            const tr = sel!.track; let t = sel!.start + sel!.dur + 0.5;
            clips.forEach((c, i) => { p.items.push(newItem({ ...sel!, id: uid('it_'), kf: {}, track: tr, start: t, in: c.start, dur: c.end - c.start, name: `Highlight ${i + 1} (${c.score})`, animIn: i ? 'zoom-out' : 'fade', animDur: 0.3 })); t += c.end - c.start; });
          });
          toast(`⚡ ${clips.length} highlights appended after the clip`, 'success');
        })}>{busy === 'reel' ? 'Analysing…' : 'Make highlight reel'}</button>
      </div>
      <div className="card tight">
        <b className="small">💬 AI Auto-Subtitles</b>
        <button className="btn sm mt8" disabled={!selAsset || selAsset.kind === 'image' || !hasAI() || !!busy} onClick={() => run('subs', async () => {
          const blob = await (await fetch(selAsset!.url)).blob();
          const tr = await transcribeWhisper(blob, 'auto');
          const words = tr.segments.flatMap((s) => s.words).filter((w) => w.e > sel!.in && w.s < sel!.in + sel!.dur * sel!.speed);
          const chunks = chunkWords(words, 3);
          update((p) => {
            let track = p.tracks.find((t) => t.name === 'Captions');
            if (!track) { track = { id: 'tr_capt' + Date.now(), kind: 'visual', name: 'Captions', muted: false, locked: false, hidden: false }; p.tracks.unshift(track); }
            for (const c of chunks) p.items.push(newItem({ type: 'text', track: track.id, name: 'Caption', start: sel!.start + (c.s - sel!.in) / sel!.speed, dur: Math.max(0.2, (c.e - c.s) / sel!.speed), y: 0.72, animIn: 'pop', animDur: 0.12, text: textProps({ content: c.words.map((w) => w.w).join(' '), upper: true, size: 0.06, stroke: '#000', strokeW: 0.16 }) }));
          });
          toast(`💬 ${chunks.length} captions added`, 'success');
        })}>{busy === 'subs' ? 'Transcribing…' : 'Generate captions for selected clip'}</button>
      </div>
      <div className="card tight">
        <b className="small">🧍 AI Background Remover · 🎨 Auto-Color</b>
        <div className="row mt8 gap6">
          <button className="btn sm" disabled={!sel || (sel.type !== 'video' && sel.type !== 'image')} onClick={() => update((p) => { const it = p.items.find((i) => i.id === sel!.id)!; it.fx.bgRemove = !it.fx.bgRemove; })}>{sel?.fx.bgRemove ? 'Restore background' : 'Remove background'}</button>
          <button className="btn sm" disabled={!sel || (sel.type !== 'video' && sel.type !== 'image')} onClick={() => {
            const c = document.createElement('canvas'); c.width = 64; c.height = 64;
            const img = new Image(); img.src = snapshot();
            img.onload = () => {
              const x = c.getContext('2d')!; x.drawImage(img, 0, 0, 64, 64);
              const d = x.getImageData(0, 0, 64, 64).data; let l = 0, s = 0, r = 0, b = 0;
              for (let i = 0; i < d.length; i += 4) { const mx = Math.max(d[i], d[i + 1], d[i + 2]), mn = Math.min(d[i], d[i + 1], d[i + 2]); l += (mx + mn) / 2; s += mx - mn; r += d[i]; b += d[i + 2]; }
              const n = d.length / 4; l /= n; s /= n; r /= n; b /= n;
              update((p) => { const it = p.items.find((i) => i.id === sel!.id)!; it.adj.brightness = Math.round(Math.min(140, Math.max(80, (128 / (l || 1)) * 100))); it.adj.saturate = Math.round(Math.min(150, Math.max(90, (60 / (s || 1)) * 100))); it.adj.contrast = 108; it.adj.temp = Math.round(Math.max(-30, Math.min(30, (b - r) / 3))); });
              toast('🎨 Auto-color applied (exposure, saturation, white balance)', 'success');
            };
          }}>Auto-color</button>
        </div>
      </div>
      <div className="card tight">
        <b className="small">🗣️ Text-to-Speech voice-over</b>
        <textarea className="input mt8 small" rows={3} placeholder="Type narration…" value={tts} onChange={(e) => setTts(e.target.value)} />
        <div className="row mt8 gap6">
          <button className="btn sm" disabled={!tts} onClick={() => { const u = new SpeechSynthesisUtterance(tts); speechSynthesis.cancel(); speechSynthesis.speak(u); }}>Preview (browser voice)</button>
          <button className="btn sm primary" disabled={!tts || !hasAI() || !!busy} onClick={() => run('tts', async () => { const a = await addBlob(await ttsOpenAI(tts, 'nova'), 'Voice-over.mp3', false); placeAsset(a); })}>{busy === 'tts' ? '…' : 'Generate & add (OpenAI)'}</button>
        </div>
      </div>
      <div className="card tight">
        <b className="small">🖼️ AI Image / Scene generator</b>
        <input className="input sm mt8" placeholder="A neon city at night, cinematic" value={imgPrompt} onChange={(e) => setImgPrompt(e.target.value)} />
        <button className="btn sm primary mt8" disabled={!imgPrompt || !hasAI() || !!busy} onClick={() => run('img', async () => { const a = await addBlob(await generateImageAI(imgPrompt, project.h > project.w ? '1024x1792' : project.w > project.h ? '1792x1024' : '1024x1024'), imgPrompt.slice(0, 20) + '.png', false); placeAsset(a); })}>{busy === 'img' ? 'Generating…' : 'Generate image'}</button>
      </div>
      <div className="card tight">
        <b className="small">🖼️ Thumbnail generator</b>
        <button className="btn sm mt8" onClick={() => { const url = snapshot(); const a = document.createElement('a'); a.href = url; a.download = `${project.name}-thumbnail.png`; a.click(); }}><Sparkles size={12} /> Export current frame as thumbnail PNG</button>
      </div>
    </div>
  );
}

function RecordTab({ addBlob, placeAsset }: AssetsProps) {
  const toast = useApp((s) => s.toast);
  const [rec, setRec] = useState<{ r: MediaRecorder; kind: string; stream: MediaStream; t0: number } | null>(null);
  const [el, setEl] = useState(0);
  const vref = useRef<HTMLVideoElement>(null);
  useEffect(() => { if (!rec) return; const id = setInterval(() => setEl((performance.now() - rec.t0) / 1000), 250); return () => clearInterval(id); }, [rec]);
  const start = async (kind: 'screen' | 'cam' | 'mic') => {
    try {
      const stream = kind === 'screen' ? await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true }) : kind === 'cam' ? await navigator.mediaDevices.getUserMedia({ video: { width: 1280, height: 720 }, audio: true }) : await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      const mime = kind === 'mic' ? pickAudioMime() : pickMime();
      const r = new MediaRecorder(stream, { mimeType: mime });
      const chunks: Blob[] = [];
      r.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      r.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunks, { type: mime.split(';')[0] });
        const a = await addBlob(blob, `${kind === 'screen' ? 'Screen recording' : kind === 'cam' ? 'Webcam' : 'Voice-over'} ${new Date().toLocaleTimeString()}.${mime.includes('mp4') ? (kind === 'mic' ? 'm4a' : 'mp4') : 'webm'}`, false);
        placeAsset(a);
        toast('Recording added to timeline', 'success');
      };
      r.start(500);
      if (kind !== 'mic' && vref.current) { vref.current.srcObject = stream; vref.current.muted = true; vref.current.play(); }
      stream.getTracks()[0].addEventListener('ended', () => r.state !== 'inactive' && r.stop());
      setRec({ r, kind, stream, t0: performance.now() });
    } catch (e) { toast('Recording failed: ' + (e as Error).message, 'error'); }
  };
  return (
    <div className="col gap16">
      <video ref={vref} style={{ width: '100%', borderRadius: 10, background: '#000', display: rec && rec.kind !== 'mic' ? 'block' : 'none' }} />
      {rec ? (
        <div className="col gap6">
          <div className="row"><span className="badge live pulse">● REC</span><b className="mono">{fmtTime(el)}</b></div>
          <button className="btn danger" onClick={() => { rec.r.stop(); setRec(null); }}><Square size={14} /> Stop & add to timeline</button>
        </div>
      ) : (
        <div className="col gap6">
          <button className="btn" onClick={() => start('screen')}><MonitorUp size={16} /> Record screen / tab</button>
          <button className="btn" onClick={() => start('cam')}><Camera size={16} /> Record webcam</button>
          <button className="btn" onClick={() => start('mic')}><Mic size={16} /> Record voice-over</button>
        </div>
      )}
      <div className="dim tiny">Mic recordings use browser noise suppression + echo cancellation. Enable “Voice enhance” on the clip for EQ, de-ess & compression.</div>
    </div>
  );
}

function StockTab({ addBlob, placeAsset }: AssetsProps) {
  const { settings, setSettings, toast } = useApp();
  const [q, setQ] = useState('city night');
  const [kind, setKind] = useState<'videos' | 'photos'>('videos');
  const [res, setRes] = useState<{ id: number; thumb: string; url: string; name: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const key = settings.pexelsKey || '';
  const search = async () => {
    if (!key) { toast('Add a free Pexels API key below', 'error'); return; }
    setBusy(true);
    try {
      const r = await fetch(kind === 'videos' ? `https://api.pexels.com/videos/search?per_page=20&query=${encodeURIComponent(q)}` : `https://api.pexels.com/v1/search?per_page=20&query=${encodeURIComponent(q)}`, { headers: { Authorization: key } });
      const j = await r.json();
      if (kind === 'videos') setRes((j.videos || []).map((v: { id: number; image: string; video_files: { link: string; width: number; quality: string }[] }) => { const f = v.video_files.filter((x) => x.width <= 1920).sort((a, b) => b.width - a.width)[0] || v.video_files[0]; return { id: v.id, thumb: v.image, url: f.link, name: `pexels-${v.id}.mp4` }; }));
      else setRes((j.photos || []).map((p: { id: number; src: { medium: string; large2x: string } }) => ({ id: p.id, thumb: p.src.medium, url: p.src.large2x, name: `pexels-${p.id}.jpg` })));
    } catch (e) { toast('Search failed: ' + (e as Error).message, 'error'); }
    setBusy(false);
  };
  return (
    <div className="col gap16">
      <div className="row gap6"><input className="input sm" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && search()} /><button className="btn sm" onClick={search}><Search size={12} /></button></div>
      <div className="seg"><button className={kind === 'videos' ? 'on' : ''} onClick={() => setKind('videos')}>Stock video</button><button className={kind === 'photos' ? 'on' : ''} onClick={() => setKind('photos')}>Stock photos</button></div>
      {!key && (
        <label className="field">Pexels API key (free at pexels.com/api)
          <input className="input sm" placeholder="paste key" onChange={(e) => setSettings({ pexelsKey: e.target.value })} />
        </label>
      )}
      {busy && <div className="spin" />}
      <div className="asset-grid">
        {res.map((r) => (
          <div key={r.id} className="asset" onClick={async () => {
            try { toast('Downloading…'); const b = await (await fetch(r.url)).blob(); const a = await addBlob(b, r.name, false); placeAsset(a); } catch { toast('Download blocked by CORS for this file', 'error'); }
          }}><img src={r.thumb} /><div className="lbl">{kind === 'videos' ? '▶ video' : 'photo'}</div></div>
        ))}
      </div>
      <div className="dim tiny">Millions of free clips via Pexels. Storyblocks, Pixabay & GIPHY connect the same way in the hosted build.</div>
    </div>
  );
}

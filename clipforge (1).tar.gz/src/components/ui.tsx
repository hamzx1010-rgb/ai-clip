import { useEffect, useRef, useState, type ReactNode } from 'react';
import { X } from 'lucide-react';
import { CAPTION_STYLES, drawStyleThumb } from '../lib/captions';

export function Toggle({ label, value, onChange, hint }: { label: ReactNode; value: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <div className="toggle" onClick={() => onChange(!value)} title={hint}>
      <span>{label}</span>
      <div className={'switch' + (value ? ' on' : '')} />
    </div>
  );
}

export function Seg<T extends string | number>({ value, options, onChange }: { value: T; options: { v: T; l: ReactNode }[]; onChange: (v: T) => void }) {
  return (
    <div className="seg">
      {options.map((o) => (
        <button key={String(o.v)} className={o.v === value ? 'on' : ''} onClick={() => onChange(o.v)}>{o.l}</button>
      ))}
    </div>
  );
}

export function Slider({ label, value, min, max, step = 1, onChange, fmt }: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; fmt?: (v: number) => string }) {
  return (
    <label className="field">
      <div className="row between"><span>{label}</span><span className="mono" style={{ color: 'var(--text)' }}>{fmt ? fmt(value) : value}</span></div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(+e.target.value)} />
    </label>
  );
}

export function Modal({ open, onClose, title, children, width }: { open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode; width?: number }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-back" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={width ? { width: `min(${width}px, 94vw)` } : undefined}>
        {title && (
          <div className="row between mb8">
            <h2 style={{ margin: 0, fontSize: 19 }}>{title}</h2>
            <button className="btn ghost icon" onClick={onClose}><X size={18} /></button>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

export function ScoreRing({ score, size = 54, stroke = 5 }: { score: number; size?: number; stroke?: number }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const color = score >= 85 ? '#3ddc97' : score >= 70 ? '#ffd23f' : score >= 55 ? '#ff9f43' : '#ff5470';
  return (
    <div className="ring" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#ffffff14" strokeWidth={stroke} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none" strokeDasharray={c} strokeDashoffset={c * (1 - score / 100)} strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      </svg>
      <span style={{ fontSize: size * 0.32, color }}>{score}</span>
    </div>
  );
}

export function MiniBar({ label, v, color }: { label: string; v: number; color?: string }) {
  return (
    <div className="col gap4">
      <div className="row between tiny"><span className="muted">{label}</span><b>{v}</b></div>
      <div className="bar" style={{ height: 6 }}><div style={{ width: v + '%', background: color }} /></div>
    </div>
  );
}

export function Sparkline({ data, w = 300, h = 60, color = '#7c5cff', fill = true, markers = [] }: { data: number[]; w?: number; h?: number; color?: string; fill?: boolean; markers?: number[] }) {
  if (!data.length) return <svg width={w} height={h} />;
  const mx = Math.max(...data, 1e-6);
  const pts = data.map((d, i) => [(i / Math.max(1, data.length - 1)) * w, h - (d / mx) * (h - 4) - 2]);
  const path = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
  const id = 'g' + Math.random().toString(36).slice(2, 7);
  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ display: 'block' }}>
      <defs><linearGradient id={id} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor={color} stopOpacity=".45" /><stop offset="1" stopColor={color} stopOpacity="0" /></linearGradient></defs>
      {fill && <path d={path + ` L${w},${h} L0,${h} Z`} fill={`url(#${id})`} />}
      <path d={path} stroke={color} strokeWidth="1.8" fill="none" vectorEffect="non-scaling-stroke" />
      {markers.map((m, i) => <line key={i} x1={m * w} x2={m * w} y1={0} y2={h} stroke="#ffd23f" strokeWidth="1.5" strokeDasharray="3 3" vectorEffect="non-scaling-stroke" />)}
    </svg>
  );
}

export function Waveform({ peaks, h = 56, markers = [], ranges = [], onSeek, color = '#7c5cff', playhead }: { peaks: ArrayLike<number>; h?: number; markers?: { x: number; color: string }[]; ranges?: { a: number; b: number; color: string }[]; onSeek?: (x: number) => void; color?: string; playhead?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const W = (c.width = c.clientWidth * devicePixelRatio), H = (c.height = h * devicePixelRatio);
    const ctx = c.getContext('2d')!;
    ctx.clearRect(0, 0, W, H);
    for (const r of ranges) { ctx.fillStyle = r.color; ctx.fillRect(r.a * W, 0, (r.b - r.a) * W, H); }
    ctx.fillStyle = color;
    const n = peaks.length;
    for (let i = 0; i < W; i += 2) {
      const v = peaks[Math.floor((i / W) * n)] || 0;
      const bh = Math.max(1, v * H * 0.9);
      ctx.fillRect(i, (H - bh) / 2, 1.4, bh);
    }
    for (const m of markers) { ctx.fillStyle = m.color; ctx.fillRect(m.x * W - 1, 0, 2, H); }
    if (playhead !== undefined) { ctx.fillStyle = '#fff'; ctx.fillRect(playhead * W - 1, 0, 2, H); }
  }, [peaks, h, markers, ranges, color, playhead]);
  return <canvas ref={ref} style={{ width: '100%', height: h, display: 'block', cursor: onSeek ? 'pointer' : 'default', borderRadius: 8 }} onClick={(e) => { if (!onSeek) return; const r = e.currentTarget.getBoundingClientRect(); onSeek((e.clientX - r.left) / r.width); }} />;
}

export function CaptionStylePicker({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  const refs = useRef<(HTMLCanvasElement | null)[]>([]);
  const [hover, setHover] = useState<number>(-1);
  useEffect(() => {
    let raf = 0; const t0 = performance.now();
    const draw = () => {
      const t = (performance.now() - t0) / 1000;
      refs.current.forEach((c, i) => { if (c && (i === hover || t < 0.05 || CAPTION_STYLES[i].id === value)) drawStyleThumb(c, CAPTION_STYLES[i], i === hover || CAPTION_STYLES[i].id === value ? t : 0.4); });
      raf = requestAnimationFrame(draw);
    };
    refs.current.forEach((c, i) => c && drawStyleThumb(c, CAPTION_STYLES[i], 0.4));
    draw();
    const again = setTimeout(() => refs.current.forEach((c, i) => c && drawStyleThumb(c, CAPTION_STYLES[i], 0.4)), 800);
    return () => { cancelAnimationFrame(raf); clearTimeout(again); };
  }, [hover, value]);
  return (
    <div className="style-grid">
      {CAPTION_STYLES.map((s, i) => (
        <div key={s.id} className={'style-card' + (s.id === value ? ' on' : '')} onClick={() => onChange(s.id)} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(-1)}>
          <canvas ref={(el) => { refs.current[i] = el; }} width={180} height={110} />
          <div>{s.name}</div>
        </div>
      ))}
    </div>
  );
}

export function Empty({ icon, title, children }: { icon: ReactNode; title: string; children?: ReactNode }) {
  return (
    <div className="col" style={{ alignItems: 'center', textAlign: 'center', padding: '48px 20px', gap: 8 }}>
      <div style={{ fontSize: 36, opacity: 0.8 }}>{icon}</div>
      <b style={{ fontSize: 16 }}>{title}</b>
      <div className="muted" style={{ maxWidth: 420 }}>{children}</div>
    </div>
  );
}

export function useInterval(fn: () => void, ms: number | null) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    if (ms === null) return;
    const id = setInterval(() => ref.current(), ms);
    return () => clearInterval(id);
  }, [ms]);
}

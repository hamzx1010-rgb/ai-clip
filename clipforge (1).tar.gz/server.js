// ClipForge production server (Render / any Node 20+ host)
// - serves the built SPA from ./dist
// - /api/proxy?url=…  streams any public video URL (GitHub releases, S3, CDN…) with Range support,
//                     so the browser can read files from hosts that don't send CORS headers
// - /api/audio?url=…  (optional, needs ffmpeg) extracts a small 16 kHz mono MP3 for very large videos
// - /api/health       health check
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import dns from 'node:dns/promises';
import net from 'node:net';
import { spawn, spawnSync } from 'node:child_process';
import { Readable } from 'node:stream';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(__dirname, 'dist');
const PORT = Number(process.env.PORT) || 3000;
const require = createRequire(import.meta.url);

// ---------- ffmpeg discovery (optional) ----------
let FFMPEG = null;
try { const p = require('ffmpeg-static'); if (p && fs.existsSync(p)) FFMPEG = p; } catch { /* optional */ }
if (!FFMPEG) { try { if (spawnSync('ffmpeg', ['-version']).status === 0) FFMPEG = 'ffmpeg'; } catch { /* none */ } }

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.wasm': 'application/wasm', '.tflite': 'application/octet-stream', '.task': 'application/octet-stream', '.binarypb': 'application/octet-stream',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
};
const VIDEO_EXT = { mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', mkv: 'video/x-matroska', mp3: 'audio/mpeg', m4a: 'audio/mp4', wav: 'audio/wav', ogg: 'audio/ogg' };

// ---------- SSRF guard: only public http(s) hosts ----------
function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
  }
  const v = ip.toLowerCase();
  return v === '::1' || v === '::' || v.startsWith('fc') || v.startsWith('fd') || v.startsWith('fe80') || v.startsWith('::ffff:127.') || v.startsWith('::ffff:10.') || v.startsWith('::ffff:192.168.');
}
const ALLOW_PRIVATE = process.env.ALLOW_PRIVATE_URLS === '1'; // testing only
async function checkUrl(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new Error('Invalid URL'); }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('Only http(s) links are supported');
  if (ALLOW_PRIVATE) return u;
  const host = u.hostname.replace(/^\[|\]$/g, '');
  if (host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) throw new Error('Host not allowed');
  const addrs = net.isIP(host) ? [host] : (await dns.lookup(host, { all: true })).map((a) => a.address);
  if (!addrs.length || addrs.some(isPrivateIp)) throw new Error('Host not allowed');
  return u;
}

function json(res, code, obj) {
  res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(JSON.stringify(obj));
}

function guessType(u, upstreamType) {
  const ext = (u.pathname.split('.').pop() || '').toLowerCase();
  if (upstreamType && /^(video|audio)\//.test(upstreamType)) return upstreamType;
  return VIDEO_EXT[ext] || (upstreamType && !upstreamType.startsWith('text/html') ? upstreamType : 'video/mp4');
}

// ---------- /api/proxy ----------
async function handleProxy(req, res, q) {
  let u;
  try { u = await checkUrl(q.get('url') || ''); } catch (e) { return json(res, 400, { error: e.message }); }
  const headers = { 'user-agent': 'Mozilla/5.0 (ClipForge ingest)', accept: '*/*' };
  if (req.headers.range) headers.range = req.headers.range;
  const ac = new AbortController();
  res.on('close', () => ac.abort());
  let up;
  try {
    up = await fetch(u, { headers, redirect: 'follow', signal: ac.signal, method: req.method === 'HEAD' ? 'HEAD' : 'GET' });
  } catch (e) {
    if (!res.headersSent) json(res, 502, { error: 'Could not reach the video host: ' + (e.cause?.code || e.message) });
    return;
  }
  if (!up.ok && up.status !== 206) {
    json(res, up.status === 404 ? 404 : 502, { error: `Video host answered ${up.status} ${up.statusText}` });
    up.body?.cancel().catch(() => {});
    return;
  }
  const ct = up.headers.get('content-type') || '';
  if (ct.startsWith('text/html')) {
    json(res, 415, { error: 'That link returns a web page, not a video file. Use a direct download link (…/file.mp4).' });
    up.body?.cancel().catch(() => {});
    return;
  }
  const out = {
    'content-type': guessType(u, ct),
    'accept-ranges': 'bytes',
    'cache-control': 'private, max-age=3600',
    'access-control-allow-origin': '*',
    'access-control-expose-headers': 'content-length, content-range, x-filename',
    'x-filename': encodeURIComponent(decodeURIComponent(u.pathname.split('/').pop() || 'video.mp4')),
  };
  for (const h of ['content-length', 'content-range', 'last-modified', 'etag']) { const v = up.headers.get(h); if (v) out[h] = v; }
  res.writeHead(up.status, out);
  if (req.method === 'HEAD' || !up.body) return res.end();
  const stream = Readable.fromWeb(up.body);
  stream.on('error', () => res.destroy());
  stream.pipe(res);
}

// ---------- /api/audio (ffmpeg → 16 kHz mono mp3) ----------
async function handleAudio(req, res, q) {
  if (!FFMPEG) return json(res, 501, { error: 'ffmpeg not available on this server' });
  let u;
  try { u = await checkUrl(q.get('url') || ''); } catch (e) { return json(res, 400, { error: e.message }); }
  // ffmpeg reads through our own proxy on 127.0.0.1 (static ffmpeg builds can crash on DNS/TLS; this also reuses the Range logic)
  const src = `http://127.0.0.1:${PORT}/api/proxy?url=${encodeURIComponent(u.href)}`;
  const ff = spawn(FFMPEG, ['-hide_banner', '-loglevel', 'error', '-i', src, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'libmp3lame', '-b:a', '48k', '-f', 'mp3', 'pipe:1'], { stdio: ['ignore', 'pipe', 'pipe'] });
  let err = '';
  ff.stderr.on('data', (d) => { err += d; });
  let started = false;
  ff.stdout.once('data', () => { started = true; });
  res.writeHead(200, { 'content-type': 'audio/mpeg', 'cache-control': 'no-store', 'access-control-allow-origin': '*' });
  ff.stdout.pipe(res);
  ff.on('close', (code) => { if (code !== 0 && !started) console.error('[audio] ffmpeg failed:', err.slice(0, 500)); res.end(); });
  res.on('close', () => { if (ff.exitCode === null) ff.kill('SIGKILL'); });
}

// ---------- static ----------
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel.includes('\0')) return json(res, 400, { error: 'bad path' });
  let file = path.join(DIST, path.normalize(rel).replace(/^([/\\])+/, ''));
  if (!file.startsWith(DIST)) return json(res, 403, { error: 'forbidden' });
  fs.stat(file, (err, st) => {
    if (err || st.isDirectory()) {
      if (path.extname(rel) && !rel.endsWith('.html')) { res.writeHead(404); return res.end('Not found'); }
      file = path.join(DIST, 'index.html'); // SPA fallback
      return fs.stat(file, (e2, st2) => (e2 ? (res.writeHead(500), res.end('Build missing — run `npm run build`')) : send(file, st2)));
    }
    send(file, st);
  });
  function send(f, st) {
    const ext = path.extname(f).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    const immutable = f.includes(`${path.sep}assets${path.sep}`);
    const headers = { 'content-type': type, 'cache-control': ext === '.html' ? 'no-cache' : immutable ? 'public, max-age=31536000, immutable' : 'public, max-age=86400', 'accept-ranges': 'bytes' };
    const range = req.headers.range && /bytes=(\d*)-(\d*)/.exec(req.headers.range);
    if (range && (ext === '.mp4' || ext === '.webm')) {
      const start = range[1] ? +range[1] : 0, end = range[2] ? Math.min(+range[2], st.size - 1) : st.size - 1;
      res.writeHead(206, { ...headers, 'content-range': `bytes ${start}-${end}/${st.size}`, 'content-length': end - start + 1 });
      return fs.createReadStream(f, { start, end }).pipe(res);
    }
    res.writeHead(200, { ...headers, 'content-length': st.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(f).pipe(res);
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const { pathname, searchParams } = new URL(req.url || '/', 'http://x');
    if (req.method === 'OPTIONS') { res.writeHead(204, { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'range', 'access-control-allow-methods': 'GET, HEAD' }); return res.end(); }
    if (pathname === '/api/health') return json(res, 200, { ok: true, ffmpeg: !!FFMPEG });
    if (pathname === '/api/proxy') return await handleProxy(req, res, searchParams);
    if (pathname === '/api/audio') return await handleAudio(req, res, searchParams);
    if (pathname.startsWith('/api/')) return json(res, 404, { error: 'Unknown endpoint' });
    serveStatic(req, res, pathname);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) json(res, 500, { error: 'Server error' }); else res.destroy();
  }
});
server.requestTimeout = 0; // allow long video streams
server.headersTimeout = 65_000;
server.keepAliveTimeout = 61_000;
server.listen(PORT, '0.0.0.0', () => console.log(`ClipForge listening on :${PORT} · ffmpeg: ${FFMPEG || 'not found (optional)'}`));

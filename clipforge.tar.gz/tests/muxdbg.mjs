import { build } from 'esbuild';
const r = await build({ entryPoints:['src/lib/mp4mux.ts'], bundle:true, write:false, format:'esm', platform:'neutral' });
const src = r.outputFiles[0].text + `
;export function __dbg(cfg){
  const e = avc1Entry(cfg);
  return { entryLen: e.length, esdsLen: buildEsds(cfg.audioSampleRate,cfg.audioChannels).length,
           avcCLen: cfg.avcC.length, spreadLen: [...cfg.avcC].length };
}
export { leaf as __leaf, u16 as __u16, u32 as __u32, ascii as __ascii };
`;
const mod = await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'));
const avcC = new Uint8Array(Buffer.from('0164001fffe1001a6764001facd9405005bb0110000003001000000303c0f183196001000468efbcb0fdf8f800','hex'));
console.log(mod.__dbg({width:720,height:1280,videoTimescale:600,avcC,audioSampleRate:48000,audioChannels:2,audioFrameDuration:1024/48000}));
console.log('leaf avcC:', mod.__leaf('avcC',[...avcC]).length);
console.log('u16(1):', mod.__u16(1), 'u32(0x00480000):', mod.__u32(0x00480000));

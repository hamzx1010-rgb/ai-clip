import MP4Box from 'mp4box';
console.log('default keys:', Object.keys(MP4Box));
console.log('has DataStream:', typeof MP4Box.DataStream, 'MP4BoxStream:', typeof MP4Box.MP4BoxStream, 'BoxParser:', typeof MP4Box.BoxParser);
console.log('BoxParser.esdsBox:', typeof MP4Box.BoxParser?.esdsBox, 'avcCBox:', typeof MP4Box.BoxParser?.avcCBox);
console.log('MP4BoxStream:', typeof MP4Box.MP4BoxStream);
// try building an esds box from the real bytes
import { readFileSync } from 'node:fs';
const buf = readFileSync('/tmp/cf-test/source-180s.mp4');
const idx = buf.indexOf('esds');
const size = buf.readUInt32BE(idx - 4);
console.log('found esds box at', idx - 4, 'size', size);
const esdsBytes = buf.subarray(idx - 4, idx - 4 + size);
try {
  const box = new MP4Box.BoxParser.esdsBox();
  box.parse(new MP4Box.MP4BoxStream(esdsBytes.buffer.slice(esdsBytes.byteOffset, esdsBytes.byteOffset + esdsBytes.byteLength)));
  console.log('esds parse OK, has esd:', !!box.esd, 'type:', box.type, 'size:', box.size);
} catch (e) { console.log('esds parse FAILED:', e.message); }

// parseOneBox handles the header itself
try {
  const stream = new MP4Box.MP4BoxStream(esdsBytes.buffer.slice(esdsBytes.byteOffset, esdsBytes.byteOffset + esdsBytes.byteLength));
  const res = MP4Box.BoxParser.parseOneBox(stream, false);
  console.log('parseOneBox code:', res.code, 'type:', res.box?.type, 'has esd:', !!res.box?.esd, 'size:', res.box?.size);
  console.log('BoxParser.OK =', MP4Box.BoxParser.OK, 'codes:', Object.keys(MP4Box.BoxParser).filter(k=>/^(OK|ERR|MORE)/.test(k)).map(k=>k+'='+MP4Box.BoxParser[k]).join(' '));
} catch (e) { console.log('parseOneBox FAILED:', e.message); }

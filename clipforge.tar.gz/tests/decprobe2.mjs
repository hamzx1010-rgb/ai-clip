import { readFileSync } from 'node:fs';
import MP4Box from 'mp4box';
import puppeteer from 'puppeteer-core';

// ---- extract first key sample + avcC in Node ----
const buf = readFileSync('/tmp/cf-test/source-180s.mp4');
const f = MP4Box.createFile();
let info=null, started=false, firstSample=null, avcCBytes=null;
f.onReady=(i)=>{info=i;};
f.onSamples=(id,u,samples)=>{
  for(const s of samples){
    if(id===info.videoTracks[0].id && s.is_sync && !firstSample){ firstSample=Buffer.from(s.data); }
    f.releaseUsedSamples(id,s.number);
  }
};
let off=0; const CH=4<<20;
while(off<buf.length){
  const sl=buf.subarray(off,Math.min(off+CH,buf.length));
  const ab=sl.buffer.slice(sl.byteOffset,sl.byteOffset+sl.byteLength); ab.fileStart=off;
  const next=f.appendBuffer(ab);
  if(!started&&info){started=true;f.setExtractionOptions(info.videoTracks[0].id,null,{nbSamples:5});f.start();}
  off=(typeof next==='number'&&next>off)?next:off+sl.byteLength;
  if(off>=buf.length)f.flush();
  if(firstSample)break;
}
const vt=f.getTrackById(info.videoTracks[0].id);
const avcC=vt.mdia.minf.stbl.stsd.entries[0].avcC;
const DS=MP4Box.DataStream; const saved=avcC.size;
const st=new DS(new ArrayBuffer(4096),0,DS.BIG_ENDIAN); st.endianness=DS.BIG_ENDIAN; avcC.write(st);
avcCBytes=Buffer.from(st.buffer.slice(0,st.getPosition())); avcC.size=saved;
const codec = info.videoTracks[0].codec;
const W=info.videoTracks[0].video.width, H=info.videoTracks[0].video.height;

// ---- convert to Annex-B in Node ----
let o=13; const numSPS=avcCBytes[o]&0x1f; o++;
const sps=[]; for(let i=0;i<numSPS;i++){const L=avcCBytes.readUInt16BE(o);o+=2;sps.push(avcCBytes.subarray(o,o+L));o+=L;}
const numPPS=avcCBytes[o]; o++;
const pps=[]; for(let i=0;i<numPPS;i++){const L=avcCBytes.readUInt16BE(o);o+=2;pps.push(avcCBytes.subarray(o,o+L));o+=L;}
const nalLen=(avcCBytes[13]&3)+1;
const nalus=[]; let q=0;
while(q+nalLen<=firstSample.length){
  const L=nalLen===4?firstSample.readUInt32BE(q):firstSample.readUIntBE(q,nalLen); q+=nalLen;
  if(L<=0||q+L>firstSample.length)break;
  nalus.push(firstSample.subarray(q,q+L)); q+=L;
}
const sc=Buffer.from([0,0,0,1]);
const annexB=Buffer.concat([...sps,...pps,...nalus].flatMap(n=>[sc,n]));
const sc3=Buffer.from([0,0,1]);
const annexB3=Buffer.concat([...sps,...pps,...nalus].flatMap(n=>[sc3,n]));
console.log(JSON.stringify({codec,W,H,avcCLen:avcCBytes.length,sampleLen:firstSample.length,annexBLen:annexB.length,annexB3Len:annexB3.length,nalus:nalus.map(n=>n[0]&0x1f),nalLen},null,1));

const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,protocolTimeout:120000,
  args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('pageerror',e=>console.log('[pageerror]',String(e.message).slice(0,200)));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async (codec,W,H,b64avcC,b64mp4,b64ab,b64ab3) => {
  const toU8=(b64)=>{const bin=atob(b64);const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u;};
  const avcC=toU8(b64avcC), mp4s=toU8(b64mp4), ab=toU8(b64ab);
  const out={};
  const cfgs={
    withDesc:{codec,codedWidth:W,codedHeight:H,description:avcC},
    noDesc:{codec,codedWidth:W,codedHeight:H},
    noDims:{codec},
    noDescLatency:{codec,codedWidth:W,codedHeight:H,optimizeForLatency:true},
  };
  for(const [k,c] of Object.entries(cfgs)){
    try{ out['isConfig_'+k]=await VideoDecoder.isConfigSupported(c); }catch(e){ out['isConfig_'+k]='ERR '+e.message.slice(0,100); }
  }
  const tryDecode=async(name,cfg,data,type)=> new Promise((resolve)=>{
    let got=null, timer=setTimeout(()=>resolve({timeout:true,got}),20000);
    const dec=new VideoDecoder({output:(fr)=>{got={w:fr.codedWidth,h:fr.codedHeight,ts:fr.timestamp,fmt:fr.format};fr.close();},
      error:(e)=>{clearTimeout(timer);resolve({error:String(e.message).slice(0,140)});}});
    try{
      dec.configure(cfg);
      dec.decode(new EncodedVideoChunk({type,timestamp:0,duration:33333,data}));
      dec.flush().then(()=>{clearTimeout(timer);resolve(got?{ok:true,...got}:{ok:false,noFrame:true});})
        .catch(e=>{clearTimeout(timer);resolve({flushErr:String(e.message).slice(0,140),got});});
    }catch(e){clearTimeout(timer);resolve({cfgErr:String(e.message).slice(0,140)});}
  });
  const descPayload = avcC.slice(8);           // AVCDecoderConfigurationRecord only
  const variants = {
    annexB_noDesc:      [{codec,codedWidth:W,codedHeight:H}, ab],
    annexB_descPayload: [{codec,codedWidth:W,codedHeight:H,description:descPayload}, ab],
    annexB_descBox:     [{codec,codedWidth:W,codedHeight:H,description:avcC}, ab],
    lenpref_noDesc:     [{codec,codedWidth:W,codedHeight:H}, mp4s],
    lenpref_descPayload:[{codec,codedWidth:W,codedHeight:H,description:descPayload}, mp4s],
    lenpref_descBox:    [{codec,codedWidth:W,codedHeight:H,description:avcC}, mp4s],
    annexB3_noDesc:     [{codec,codedWidth:W,codedHeight:H}, toU8(b64ab3)],
  };
  for (const [k,[cfg,data]] of Object.entries(variants)) {
    try { out['decode_'+k] = await tryDecode(k,cfg,data,'key'); }
    catch(e){ out['decode_'+k]='THREW '+String(e.message).slice(0,120); }
  }
  out.isConfig_descPayload = await VideoDecoder.isConfigSupported({codec,codedWidth:W,codedHeight:H,description:descPayload}).then(r=>({supported:!!r.supported})).catch(e=>'ERR '+e.message.slice(0,120));
  return out;
}, codec,W,H, avcCBytes.toString('base64'), firstSample.toString('base64'), annexB.toString('base64'), annexB3.toString('base64'));
console.log(JSON.stringify(r,null,1));
await b.close();

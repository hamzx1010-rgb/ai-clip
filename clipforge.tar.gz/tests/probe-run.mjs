#!/usr/bin/env node
/**
 * Run the export probe in real Chrome and check the produced file with ffmpeg.
 *
 * Usage: node tests/probe-run.mjs [--engine=fast|realtime] [--start=40] [--end=68]
 */
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync, rmSync, writeFileSync, copyFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import puppeteer from 'puppeteer-core';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');
const arg = (k, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${k}=`));
  return hit ? hit.slice(k.length + 3) : d;
};

const engine = arg('engine', 'fast');
const start = Number(arg('start', 40));
const end = Number(arg('end', 68));
const fps = Number(arg('fps', 30));
const url = arg('url', 'http://127.0.0.1:8099/source-180s.mp4');
const dl = resolve(arg('dl', '/tmp/cf-probe'));
const timeout = Number(arg('timeout', 900)) * 1000;

rmSync(dl, { recursive: true, force: true });
mkdirSync(dl, { recursive: true });

const browser = await puppeteer.launch({
  executablePath: '/usr/bin/google-chrome-stable',
  headless: true,
  protocolTimeout: timeout,
  args: [
    '--no-sandbox',
    '--disable-dev-shm-usage',
    '--disable-gpu',
    '--mute-audio',
    '--autoplay-policy=no-user-gesture-required',
    '--enable-features=SharedArrayBuffer',
    '--window-size=412,915',
  ],
});

const page = await browser.newPage();
await page.setViewport({ width: 412, height: 915 });
const cdp = await page.createCDPSession();
await cdp.send('Page.setDownloadBehavior', { behavior: 'allow', downloadPath: dl, eventsEnabled: true });
page.on('pageerror', (e) => console.log('[pageerror]', String(e.message).slice(0, 400)));
page.on('console', (m) => {
  if (m.type() === 'error') console.log('[console.error]', m.text().slice(0, 300));
});

await page.goto('http://127.0.0.1:5173/tests/probe.html', { waitUntil: 'domcontentloaded' });
await page.waitForFunction('typeof window.__PROBE === "function"', { timeout: 60000 });

console.log('caps:', JSON.stringify(await page.evaluate('window.__CAPS()'), null, 1));

const t0 = Date.now();
const promise = page.evaluate(
  (u, s, e, f, eng) => window.__PROBE({ url: u, start: s, end: e, fps: f, engine: eng }),
  url,
  start,
  end,
  fps,
  engine,
);

// progress ticker
const tick = setInterval(async () => {
  try {
    const p = await page.evaluate('window.__PROGRESS');
    if (p) process.stdout.write(`\r  probe: ${p}   (${((Date.now() - t0) / 1000).toFixed(0)}s)   `);
  } catch {
    /* page may be busy */
  }
}, 2000);

const result = await promise;
clearInterval(tick);
console.log('\n\nPROBE RESULT:', JSON.stringify(result, null, 2));

// Pull the finished bytes straight out of the page. A browser download can be
// cancelled when the tab closes, which made this harness flaky.
let inline = null;
try {
  const b64 = await page.evaluate('window.__FILE_B64 || null');
  if (b64) {
    mkdirSync(dl, { recursive: true });
    const name = `probe-${engine}-${start}-${end}.mp4`;
    writeFileSync(join(dl, name), Buffer.from(b64, 'base64'));
    inline = join(dl, name);
    console.log('\nINLINE FILE:', inline);
  }
} catch (e) {
  console.log('inline file read failed:', String(e.message).slice(0, 120));
}

const demuxInfo = await page.evaluate('window.__DEMUX').catch(() => null);
console.log('SOURCE DEMUX:', JSON.stringify(demuxInfo, null, 1));

await browser.close();

if (!result.ok) {
  console.error('\nPROBE FAILED:', result.error);
  process.exit(1);
}

// wait for the download
const t1 = Date.now();
let files = [];
while (Date.now() - t1 < 30000) {
  files = readdirSync(dl).filter((f) => !f.endsWith('.crdownload'));
  if (files.length) break;
  await new Promise((r) => setTimeout(r, 500));
}
if (!files.length) {
  console.error('no file was downloaded by the probe');
  process.exit(1);
}
const file = join(dl, files[0]);
console.log('\nFILE:', file, existsSync(file) ? '' : '(missing)');

const ffprobe = spawnSync(
  'ffprobe',
  ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', file],
  { encoding: 'utf8' },
);
if (ffprobe.status !== 0) {
  console.error('ffprobe could not read the file:\n' + ffprobe.stderr);
  // Dump the head of the file so we can see what mp4box produced.
  const hex = spawnSync('xxd', ['-l', '128', file], { encoding: 'utf8' });
  console.log(hex.stdout);
  process.exit(1);
}
const probe = JSON.parse(ffprobe.stdout);
const v = probe.streams.find((s) => s.codec_type === 'video');
const a = probe.streams.find((s) => s.codec_type === 'audio');
console.log(
  `ffmpeg says: duration=${probe.format.duration}s format=${probe.format.format_name}\n` +
    `  video: ${v ? `${v.codec_name} ${v.width}x${v.height} nb_frames=${v.nb_frames} dur=${v.duration}` : 'NONE'}\n` +
    `  audio: ${a ? `${a.codec_name} ${a.sample_rate}Hz ${a.channels}ch dur=${a.duration}` : 'NONE'}`,
);

const fz = spawnSync(
  'ffmpeg',
  ['-hide_banner', '-i', file, '-vf', 'freezedetect=n=-55dB:d=1.0', '-map', '0:v:0', '-f', 'null', '-'],
  { encoding: 'utf8' },
);
const freezes = [...String(fz.stderr).matchAll(/freeze_duration:\s*([\d.]+)/g)].map((m) => Number(m[1]));
console.log('freezes >=1.0s:', freezes.length ? freezes.join(', ') : 'none');

const tail = Number(probe.format.duration) - 1.0;
const ft = spawnSync(
  'ffmpeg',
  ['-hide_banner', '-ss', String(Math.max(0, tail)), '-i', file, '-map', '0:v:0', '-f', 'null', '-'],
  { encoding: 'utf8' },
);
const frameLine = [...String(ft.stderr).matchAll(/frame=\s*(\d+)/g)].pop();
console.log('frames in the last 1s:', frameLine ? frameLine[1] : '0');

const ok =
  v &&
  Number(probe.format.duration) >= end - start - 1 &&
  freezes.length === 0 &&
  frameLine &&
  Number(frameLine[1]) >= 5;
// keep a copy for later manual inspection
try {
  const keep = '/tmp/cf-keep';
  mkdirSync(keep, { recursive: true });
  copyFileSync(file, join(keep, `probe-${engine}-${start}-${end}.mp4`));
} catch { /* ignore */ }
console.log('\nVERDICT:', ok ? 'PROBE PASSED' : 'PROBE FAILED');
process.exit(ok ? 0 : 1);

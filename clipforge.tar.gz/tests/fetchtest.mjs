import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('console',m=>console.log('['+m.type()+']',m.text().slice(0,200)));
p.on('requestfailed',r=>console.log('[reqfail]',r.url(),r.failure()?.errorText));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  try {
    const res = await fetch('http://127.0.0.1:8099/source-180s.mp4');
    const blob = await res.blob();
    return {ok:res.ok, status:res.status, type:blob.type, size:blob.size};
  } catch(e) { return {error:String(e), name:e.name}; }
});
console.log('FETCH:',JSON.stringify(r));
await b.close();

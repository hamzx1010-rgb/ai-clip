import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,protocolTimeout:120000,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('pageerror',e=>console.log('[pageerror]',String(e.message).slice(0,300)));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const out = {};
  const MP4Box = (await import('/node_modules/.vite/deps/mp4box.js?v=ac962f6c')).default;
  const {SourceReader} = await import('/src/lib/mp4demux.ts');
  // get real tracks from a tiny slice? use full file but video only header
  const res = await fetch('http://127.0.0.1:8099/source-180s.mp4',{cache:'no-store'});
  const ab = await res.arrayBuffer();
  const blob = new Blob([ab],{type:'video/mp4'});
  const rd = new SourceReader({blob, wantVideo:false, wantAudio:false});
  const lp = rd.start(); const t = await rd.ready(); rd.destroy(); await lp.catch(()=>{});
  out.avcCBytes_is = {ctor: t.avcCBytes?.constructor?.name, isU8: t.avcCBytes instanceof Uint8Array, isAB: t.avcCBytes instanceof ArrayBuffer, len: t.avcCBytes?.length, bufIsAB: t.avcCBytes?.buffer instanceof ArrayBuffer};
  // A: addTrack with Uint8Array
  try {
    const f1 = MP4Box.createFile();
    f1.init({timescale:600, brands:['isom','iso2','avc1','mp41']});
    const id = f1.addTrack({timescale:18000, media_duration:0, width:720, height:1280, avcDecoderConfigRecord:t.avcCBytes, avc_inband:false, type:'avc1', hdlr:'vide', name:'v', default_sample_description_index:1});
    out.A_uint8 = 'ok id='+id;
  } catch(e){ out.A_uint8 = 'THREW '+String(e); }
  // B: addTrack with a plain ArrayBuffer copy
  try {
    const f2 = MP4Box.createFile();
    f2.init({timescale:600, brands:['isom','iso2','avc1','mp41']});
    const copy = t.avcCBytes.slice().buffer;
    const id = f2.addTrack({timescale:18000, media_duration:0, width:720, height:1280, avcDecoderConfigRecord:copy, avc_inband:false, type:'avc1', hdlr:'vide', name:'v', default_sample_description_index:1});
    out.B_arraybuffer = 'ok id='+id;
  } catch(e){ out.B_arraybuffer = 'THREW '+String(e); }
  // C: audio track with esds box object
  try {
    const f3 = MP4Box.createFile();
    f3.init({timescale:600, brands:['isom','iso2','avc1','mp41']});
    const id = f3.addTrack({timescale:48000, media_duration:0, samplerate:48000, channel_count:2, samplesize:16, hdlr:'soun', name:'a', type:'mp4a', description:t.esds, default_sample_description_index:1});
    out.C_audio_esds = 'ok id='+id+' esdsType='+(t.esds&&t.esds.type);
  } catch(e){ out.C_audio_esds = 'THREW '+String(e); }
  // D: does the writer class work end-to-end for track creation?
  try {
    const {Mp4Writer} = await import('/src/lib/mp4demux.ts');
    const w = new Mp4Writer({width:720,height:1280,fps:30,avcCBytes:t.avcCBytes,audioSampleRate:48000,audioChannels:2,esds:t.esds});
    out.D_writer = 'ok video='+w.videoTrackId+' audio='+w.audioTrackId;
  } catch(e){ out.D_writer = 'THREW '+String(e); }
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--autoplay-policy=no-user-gesture-required','--enable-features=SharedArrayBuffer']});
const p = await b.newPage();
await p.goto('http://127.0.0.1:4173/', {waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const out = {};
  out.secure = window.isSecureContext;
  out.webcodecs = typeof VideoDecoder !== 'undefined' && typeof VideoEncoder !== 'undefined';
  out.audioEncoder = typeof AudioEncoder !== 'undefined';
  out.audioData = typeof AudioData !== 'undefined';
  out.faceDetector = typeof FaceDetector !== 'undefined';
  out.wakeLock = 'wakeLock' in navigator;
  out.mediaRecorder = typeof MediaRecorder !== 'undefined';
  out.recorderMimes = ['video/mp4;codecs="avc1.42E01E,mp4a.40.2"','video/mp4','video/webm;codecs="vp9,opus"','video/webm;codecs="vp8,opus"','video/webm'].filter(m=>{try{return MediaRecorder.isTypeSupported(m)}catch{return false}});
  out.rvfc = 'requestVideoFrameCallback' in HTMLVideoElement.prototype;
  const dec = await VideoDecoder.isConfigSupported({codec:'avc1.64001f',codedWidth:1280,codedHeight:720});
  out.h264Decode = dec.supported;
  for (const c of ['avc1.42001f','avc1.4d001f','avc1.64001f','avc1.420028','avc1.4d0034','avc1.640034']) {
    const s = await VideoEncoder.isConfigSupported({codec:c,width:720,height:1280,bitrate:2000000,framerate:30});
    out['enc_'+c] = s.supported;
  }
  out.aacEnc = (await AudioEncoder.isConfigSupported({codec:'mp4a.40.2',sampleRate:48000,numberOfChannels:2,bitrate:128000})).supported;
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

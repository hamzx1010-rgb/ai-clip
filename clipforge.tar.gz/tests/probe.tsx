/**
 * Export probe — TEST HARNESS ONLY (served by `vite` from tests/probe.html,
 * never part of the shipped dist bundle).
 *
 * It runs one engine directly against a real source file and exposes the
 * result on window.__PROBE so the Puppeteer harness can measure exactly what
 * came out: how many frames were decoded, how many were written, how long the
 * file is, and whether the picture is still moving at the end.
 */

import { exportWebcodecs, webcodecsSupported, canEncodeH264, canDemux } from '../src/lib/export-webcodecs';
import { exportRealtime, pickRecorderMime, recorderSupported } from '../src/lib/export-realtime';
import { verifyExport } from '../src/lib/verify';
import { SourceReader } from '../src/lib/mp4demux';
import type { ExportJob } from '../src/lib/export-types';
import type { LayoutMode } from '../src/lib/types';

interface ProbeInput {
  url: string;
  start: number;
  end: number;
  width?: number;
  height?: number;
  fps?: number;
  engine?: 'fast' | 'realtime';
  layout?: LayoutMode;
  verify?: boolean;
}

interface ProbeOutcome {
  ok: boolean;
  error?: string;
  errorName?: string;
  stage?: string;
  stack?: string;
  engine?: string;
  mime?: string;
  size?: number;
  framesDecoded?: number;
  framesWritten?: number;
  framesExpected?: number;
  duration?: number;
  audioWritten?: boolean;
  elapsedMs?: number;
  notes?: string[];
  verification?: unknown;
  caps?: Record<string, unknown>;
}

declare global {
  interface Window {
    __PROBE?: (input: ProbeInput) => Promise<ProbeOutcome>;
    __CAPS?: () => Promise<Record<string, unknown>>;
  }
}

window.__CAPS = async () => {
  const caps: Record<string, unknown> = {
    webcodecs: webcodecsSupported(),
    h264Encode: await canEncodeH264(),
    recorder: recorderSupported(),
    recorderMime: pickRecorderMime(),
    faceDetector: typeof (window as unknown as { FaceDetector?: unknown }).FaceDetector !== 'undefined',
    secure: window.isSecureContext,
    ua: navigator.userAgent,
  };
  return caps;
};

window.__PROBE = async (input: ProbeInput): Promise<ProbeOutcome> => {
  const t0 = performance.now();
  const stage = (name: string) => {
    (window as unknown as { __STAGE?: string }).__STAGE = name;
  };
  stage('start');
  try {
    const res = await fetch(input.url, { cache: 'no-store' });
    if (!res.ok) return { ok: false, error: `fetch ${res.status}` };
    // Read as a stream: res.blob() is unreliable for big cross-origin videos
    // on some Chrome builds.
    const parts: Uint8Array[] = [];
    if (res.body) {
      const rd = res.body.getReader();
      for (;;) {
        const { done, value } = await rd.read();
        if (done) break;
        if (value) parts.push(value);
      }
    } else {
      parts.push(new Uint8Array(await res.arrayBuffer()));
    }
    const blob = new Blob(parts as BlobPart[], { type: res.headers.get('content-type') || 'video/mp4' });

    // Report what the streaming reader sees, so a codec problem is obvious.
    try {
      const r = new SourceReader({ blob, wantVideo: false, wantAudio: false });
      const p = r.start();
      const t = await r.ready();
      r.destroy();
      await p.catch(() => undefined);
      (window as unknown as { __DEMUX?: unknown }).__DEMUX = {
        canDemux: await canDemux(blob),
        durationSeconds: t.durationSeconds,
        videoCodec: t.videoCodec,
        size: [t.width, t.height],
        audioCodec: t.audioCodec,
        audioSampleRate: t.audioSampleRate,
        audioChannels: t.audioChannels,
        hasAvcC: !!t.avcC,
        hasEsds: !!t.esds,
        avcCBytes: t.avcCBytes ? [...t.avcCBytes].map((x) => x.toString(16).padStart(2, '0')).join('') : null,
        esdsBytes: t.esdsBytes ? [...t.esdsBytes].map((x) => x.toString(16).padStart(2, '0')).join('') : null,
        decSupport: await VideoDecoder.isConfigSupported({
          codec: t.videoCodec,
          codedWidth: t.width,
          codedHeight: t.height,
          description: t.avcCBytes ?? undefined,
        }).then((r) => ({ supported: !!r.supported })).catch((e) => ({ err: String(e.message).slice(0, 160) })),
        decSupportNoDesc: await VideoDecoder.isConfigSupported({ codec: t.videoCodec, codedWidth: t.width, codedHeight: t.height }).then((r) => !!r.supported),
      };
    } catch (e) {
      (window as unknown as { __DEMUX?: unknown }).__DEMUX = { error: (e as Error).message };
    }

    stage('build-job');
    const job: ExportJob = {
      srcUrl: URL.createObjectURL(blob),
      srcBlob: blob,
      start: input.start,
      end: input.end,
      width: input.width ?? 720,
      height: input.height ?? 1280,
      fps: input.fps ?? 30,
      layout: input.layout ?? 'full',
      faceCenter: null,
      mode: input.engine ?? 'fast',
      onProgress: (f, m) => {
        (window as unknown as { __PROGRESS?: string }).__PROGRESS = `${(f * 100).toFixed(0)}% ${m}`;
      },
    };

    stage(job.mode === 'fast' ? 'exportWebcodecs' : 'exportRealtime');
    const result =
      job.mode === 'fast' ? await exportWebcodecs(job) : await exportRealtime(job);
    stage('exported');

    const out: ProbeOutcome = {
      ok: true,
      engine: result.engine,
      mime: result.mime,
      size: result.blob.size,
      framesDecoded: result.framesDecoded,
      framesWritten: result.framesWritten,
      framesExpected: result.framesExpected,
      duration: result.duration,
      audioWritten: result.audioWritten,
      elapsedMs: Math.round(performance.now() - t0),
      notes: result.notes,
    };

    if (input.verify !== false) {
      stage('verify');
      out.verification = await verifyExport(result.blob, result, {
        expectedDuration: input.end - input.start,
        fps: job.fps,
        sourceHasAudio: result.audioWritten,
      });
    }

    // Hand the file to the harness so ffmpeg can check it independently.
    // Kept in memory as base64 AND offered as a download: the download can be
    // cancelled when the harness closes the tab, so the runner reads the base64
    // copy first and only falls back to the download.
    const bin = new Uint8Array(await result.blob.arrayBuffer());
    let b64 = '';
    const CH = 0x8000;
    for (let i = 0; i < bin.length; i += CH) {
      b64 += String.fromCharCode(...bin.subarray(i, i + CH));
    }
    (window as unknown as { __FILE_B64?: string }).__FILE_B64 = btoa(b64);

    const a = document.createElement('a');
    a.href = URL.createObjectURL(result.blob);
    a.download = `probe-${job.mode}-${input.start}-${input.end}.mp4`;
    document.body.appendChild(a);
    a.click();

    URL.revokeObjectURL(job.srcUrl);
    return out;
  } catch (e) {
    const err = e as { message?: string; name?: string; stack?: string };
    return {
      ok: false,
      error: String(err?.message ?? err ?? 'unknown'),
      errorName: err?.name,
      stage: (window as unknown as { __STAGE?: string }).__STAGE,
      stack: String(err?.stack ?? '').split('\n').slice(0, 6).join(' | '),
      elapsedMs: Math.round(performance.now() - t0),
    };
  }
};

document.getElementById('root')!.textContent = 'ClipForge probe ready';

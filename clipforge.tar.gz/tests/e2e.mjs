#!/usr/bin/env node
/**
 * ClipForge end-to-end verification.
 *
 * What it does, in the order the brief asks for:
 *   1. real Google Chrome (full H.264/AAC), Pixel 7 emulation, new headless;
 *   2. an H.264/AAC MP4 source fetched over http from a separate origin;
 *   3. analyse -> export all -> then check EVERY file with ffmpeg:
 *        full length, video frames all the way to the end, audio present;
 *   4. the same again in forced real-time mode;
 *   5. screenshots of every page at phone size + horizontal-overflow checks;
 *   6. writes tests/results.json and exits non-zero if anything failed.
 *
 * Usage:
 *   node tests/e2e.mjs [--media=http://127.0.0.1:8099/source-180s.mp4]
 *                      [--app=http://127.0.0.1:4173]
 *                      [--only=fast|realtime|pages]
 *                      [--shots=dir] [--downloads=dir]
 */
import { spawn, spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import puppeteer from 'puppeteer-core';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');

const arg = (k, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${k}=`));
  return hit ? hit.slice(k.length + 3) : d;
};
const has = (k) => process.argv.includes(`--${k}`);

const APP = arg('app', 'http://127.0.0.1:4173');
const MEDIA = arg('media', 'http://127.0.0.1:8099/source-180s.mp4');
const ONLY = arg('only', '');
const SHOTS = resolve(arg('shots', join(root, 'tests', 'screenshots')));
const DL = resolve(arg('downloads', join(root, 'tests', 'downloads')));
const RESULTS = resolve(arg('results', join(root, 'tests', 'results.json')));
const CHROME = arg('chrome', '/usr/bin/google-chrome-stable');
const TIMEOUT = Number(arg('timeout', 1800)) * 1000;

const PIXEL7 = {
  name: 'Pixel 7',
  userAgent:
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36',
  viewport: { width: 412, height: 915, deviceScaleFactor: 2, isMobile: true, hasTouch: true, isLandscape: false },
};

const report = { startedAt: new Date().toISOString(), app: APP, media: MEDIA, runs: [], pages: [], failures: [] };
const fail = (msg) => {
  report.failures.push(msg);
  console.log('  FAIL: ' + msg);
};
const pass = (msg) => console.log('  ok:   ' + msg);
const info = (msg) => console.log('        ' + msg);

/* ------------------------------------------------------------------ */
/* ffmpeg helpers                                                       */
/* ------------------------------------------------------------------ */

function ffprobeJson(file) {
  const r = spawnSync(
    'ffprobe',
    ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', file],
    { encoding: 'utf8', maxBuffer: 1 << 26 },
  );
  if (r.status !== 0) throw new Error('ffprobe failed: ' + String(r.stderr).slice(0, 400));
  return JSON.parse(r.stdout);
}

function ff(args) {
  const r = spawnSync('ffmpeg', ['-hide_banner', '-nostdin', ...args], {
    encoding: 'utf8',
    maxBuffer: 1 << 26,
  });
  return { status: r.status, out: String(r.stdout || '') + String(r.stderr || '') };
}

/** Frame timestamps (seconds) for a window of the file. */
function frameTimes(file, from, to) {
  const r = ff([
    '-ss', String(from),
    ...(to ? ['-to', String(to)] : []),
    '-i', file,
    '-map', '0:v:0',
    '-f', 'null', '-',
  ]);
  const times = [];
  const re = /time=(\d+):(\d+):(\d+(?:\.\d+)?)/g;
  let m;
  while ((m = re.exec(r.out))) {
    times.push(Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]));
  }
  const frames = (r.out.match(/frame=\s*(\d+)/g) || []).pop();
  return { count: frames ? Number(frames.replace(/\D/g, '')) : 0, lastTime: times.length ? times[times.length - 1] : 0, raw: r.out };
}

/** freezedetect over the whole file. */
function freezeScan(file, noiseDb = -55, minSeconds = 1.5) {
  const r = ff(['-i', file, '-vf', `freezedetect=n=${noiseDb}dB:d=${minSeconds}`, '-map', '0:v:0', '-f', 'null', '-']);
  const starts = [...r.out.matchAll(/freeze_start:\s*([\d.]+)/g)].map((m) => Number(m[1]));
  const durations = [...r.out.matchAll(/freeze_duration:\s*([\d.]+)/g)].map((m) => Number(m[1]));
  return { starts, durations, longest: durations.length ? Math.max(...durations) : 0 };
}

/** Is the picture actually changing near the end of the file? */
function motionNearEnd(file, duration) {
  const from = Math.max(0, duration - Math.min(2.5, duration * 0.25));
  const r = ff([
    '-ss', String(from),
    '-i', file,
    '-map', '0:v:0',
    '-vf', 'fps=8,signalstats,metadata=print:key=lavfi.signalstats.YDIF',
    '-f', 'null', '-',
  ]);
  const vals = [...r.out.matchAll(/YDIF=([\d.]+)/g)].map((m) => Number(m[1]));
  const moving = vals.filter((v) => v > 0.35).length;
  return { samples: vals.length, moving, ratio: vals.length ? moving / vals.length : 0, windowStart: from };
}

function audioCheck(file) {
  const r = ff(['-i', file, '-map', '0:a:0?', '-af', 'volumedetect', '-f', 'null', '-']);
  const mean = /mean_volume:\s*(-?[\d.]+)\s*dB/.exec(r.out);
  const max = /max_volume:\s*(-?[\d.]+)\s*dB/.exec(r.out);
  return {
    hasStream: !/Stream map '0:a:0' matches no streams/.test(r.out),
    meanDb: mean ? Number(mean[1]) : null,
    maxDb: max ? Number(max[1]) : null,
  };
}

/** The full per-file verdict the brief asks for. */
function verifyFile(file, expectedDuration, opts = {}) {
  const checks = [];
  const ok = (name, cond, detail) => {
    checks.push({ name, ok: !!cond, detail });
    if (!cond) fail(`${opts.label || 'file'} ${name}: ${detail}`);
    else pass(`${opts.label || 'file'} ${name} — ${detail}`);
    return !!cond;
  };

  if (!existsSync(file)) {
    ok('exists', false, 'file missing');
    return { ok: false, checks };
  }
  const size = statSync(file).size;
  ok('not-empty', size > 4096, `${(size / 1048576).toFixed(2)} MB`);

  let probe;
  try {
    probe = ffprobeJson(file);
  } catch (e) {
    ok('readable-by-ffmpeg', false, e.message);
    return { ok: false, checks };
  }
  ok('readable-by-ffmpeg', true, probe.format.format_name);

  const v = probe.streams.find((s) => s.codec_type === 'video');
  const a = probe.streams.find((s) => s.codec_type === 'audio');
  const dur = Number(probe.format.duration || v?.duration || 0);

  ok('has-video', !!v, v ? `${v.codec_name} ${v.width}x${v.height}` : 'none');
  ok('vertical-9x16', !!v && v.width === 720 && v.height === 1280, v ? `${v.width}x${v.height}` : 'n/a');
  ok(
    'full-length',
    dur > 0 && dur >= expectedDuration * 0.9 - 0.35 && dur <= expectedDuration + 1.6,
    `${dur.toFixed(2)}s (expected about ${expectedDuration.toFixed(2)}s)`,
  );
  ok('audio-present', !!a, a ? `${a.codec_name} ${a.sample_rate}Hz ${a.channels}ch` : 'NO AUDIO TRACK');

  if (v && a) {
    const vd = Number(v.duration || dur);
    const ad = Number(a.duration || dur);
    ok('video-length-matches-audio', Math.abs(vd - ad) <= 0.6, `video ${vd.toFixed(2)}s vs audio ${ad.toFixed(2)}s`);
  }

  // The headline check: frames all the way to the end, not just at the start.
  const tailFrom = Math.max(0, dur - 1.0);
  const tail = frameTimes(file, tailFrom, 0);
  ok('frames-at-the-end', tail.count >= 5, `${tail.count} frames decoded in the last ${(dur - tailFrom).toFixed(1)}s`);

  const total = frameTimes(file, 0, 0);
  const fps = v ? Number(evalRate(v)) : 30;
  const expectedFrames = Math.max(1, Math.round(dur * fps));
  ok(
    'frame-count',
    total.count >= expectedFrames * 0.85,
    `${total.count} frames in file vs about ${expectedFrames} expected at ${fps}fps`,
  );

  const fz = freezeScan(file, -55, 1.5);
  ok('no-freeze-over-1.5s', fz.longest < 1.5, fz.longest ? `longest freeze ${fz.longest.toFixed(2)}s at ${fz.starts[0]}s` : 'no freeze detected');

  const endMotion = motionNearEnd(file, dur);
  ok(
    'picture-moving-at-the-end',
    endMotion.ratio > 0.25,
    `${endMotion.moving}/${endMotion.samples} changing frames in the last ${(dur - endMotion.windowStart).toFixed(1)}s`,
  );

  const aud = audioCheck(file);
  ok(
    'audio-is-audible',
    aud.hasStream && aud.maxDb !== null && aud.maxDb > -45,
    aud.hasStream ? `mean ${aud.meanDb}dB max ${aud.maxDb}dB` : 'no audio stream',
  );

  return {
    ok: checks.every((c) => c.ok),
    checks,
    duration: dur,
    sizeBytes: size,
    frames: total.count,
    expectedFrames,
    fps,
    longestFreeze: fz.longest,
    endMotionRatio: endMotion.ratio,
    audio: aud,
  };
}

function evalRate(v) {
  const r = v.avg_frame_rate || v.r_frame_rate || '30/1';
  if (!r.includes('/')) return r;
  const [n, d] = r.split('/').map(Number);
  return d ? (n / d).toFixed(3) : '30';
}

/* ------------------------------------------------------------------ */
/* browser helpers                                                      */
/* ------------------------------------------------------------------ */

let saveStream;

async function launch() {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: true,
    dumpio: false,
    protocolTimeout: TIMEOUT,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--hide-scrollbars',
      '--mute-audio',
      '--autoplay-policy=no-user-gesture-required',
      '--use-fake-ui-for-media-stream',
      '--use-fake-device-for-media-stream',
      '--enable-features=SharedArrayBuffer,PlatformHEVCDecoderSupport,MediaRecorderHEVCOppo',
      '--disable-features=Translate',
      '--allow-file-access-from-files',
      '--window-size=412,915',
      `--user-agent=${PIXEL7.userAgent}`,
    ],
  });
  return browser;
}

async function newPhonePage(browser, tag) {
  const page = await browser.newPage();
  await page.emulate(PIXEL7);
  const dlDir = join(DL, tag);
  mkdirSync(dlDir, { recursive: true });
  const cdp = await page.createCDPSession();
  await cdp.send('Page.setDownloadBehavior', { behavior: 'allow', downloadPath: dlDir, eventsEnabled: true });
  page.on('console', (m) => {
    const t = m.text();
    if (/error|fail|uncaught/i.test(t)) console.log(`      [console:${m.type()}] ${t.slice(0, 300)}`);
  });
  page.on('pageerror', (e) => console.log(`      [pageerror] ${String(e.message).slice(0, 300)}`));
  saveStream = (line) => console.log(`      [log] ${line}`);
  return { page, dlDir };
}

/** Type into a React-controlled input the way a real user would. */
async function setInput(page, selector, value) {
  await page.waitForSelector(selector, { visible: true, timeout: 30000 });
  await page.evaluate(
    (sel, val) => {
      const el = document.querySelector(sel);
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      setter.call(el, val);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    },
    selector,
    value,
  );
}

async function setCheckbox(page, id, checked) {
  await page.evaluate(
    (elId, want) => {
      const el = document.getElementById(elId);
      if (!el || el.checked === want) return;
      el.click();
    },
    id,
    checked,
  );
}

async function readClipState(page) {
  return page.evaluate(() => {
    const out = [];
    document.querySelectorAll('[data-clip-id]').forEach((el) => {
      const title = el.querySelector('.clip-title')?.textContent?.trim() || '';
      const badges = [...el.querySelectorAll('.badge')].map((b) => b.textContent.trim());
      const err = el.querySelector('.err')?.textContent?.trim() || null;
      const notes = [...el.querySelectorAll('.tiny')].map((n) => n.textContent.trim());
      const layoutPressed = [...el.querySelectorAll('.seg button')]
        .filter((b) => b.getAttribute('aria-pressed') === 'true')
        .map((b) => b.textContent.trim());
      const meter = el.querySelector('.meter > i')?.style.width || null;
      out.push({
        id: el.getAttribute('data-clip-id'),
        status: el.getAttribute('data-status'),
        title,
        badges,
        error: err,
        notes,
        layout: layoutPressed[0] || null,
        meter,
      });
    });
    return out;
  });
}

async function waitForRun(page, timeoutMs) {
  const t0 = Date.now();
  let last = '';
  let lastChange = Date.now();
  for (;;) {
    const state = await readClipState(page);
    const summary = await page.evaluate(() => {
      const logs = document.getElementById('logbox');
      return {
        status: document.querySelector('main .strong')?.textContent || '',
        logTail: logs ? logs.textContent.split('\n').slice(-3).join(' | ') : '',
        err: document.querySelector('main > .err')?.textContent?.trim() || null,
      };
    });
    const line = `${state.length} clips: ${state.map((c) => c.status).join(',')}`;
    if (line !== last) {
      last = line;
      lastChange = Date.now();
      const secs = ((Date.now() - t0) / 1000).toFixed(0);
      console.log(`      [+${secs}s] ${line}`);
      if (summary.logTail) saveStream(summary.logTail.slice(0, 220));
    }
    const done = state.length > 0 && state.every((c) => c.status === 'done' || c.status === 'error');
    if (done) return state;
    if (summary.err && !state.length) throw new Error('Run failed: ' + summary.err);
    if (Date.now() - t0 > timeoutMs) throw new Error('Timed out. Last state: ' + line + ' | ' + summary.logTail);
    if (Date.now() - lastChange > timeoutMs * 0.75) throw new Error('Stalled. Last state: ' + line);
    await new Promise((r) => setTimeout(r, 2000));
  }
}

function waitForDownloads(dir, settleMs = 4000, timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    const t0 = Date.now();
    let lastCount = -1;
    let lastChange = Date.now();
    const tick = () => {
      if (!existsSync(dir)) return reject(new Error('no download dir'));
      const files = readdirSync(dir).filter((f) => !f.endsWith('.crdownload') && !f.endsWith('.tmp'));
      const pending = readdirSync(dir).filter((f) => f.endsWith('.crdownload'));
      if (files.length !== lastCount || pending.length) lastChange = Date.now();
      lastCount = files.length;
      if (files.length > 0 && !pending.length && Date.now() - lastChange > settleMs) return resolve(files);
      if (Date.now() - t0 > timeoutMs) return resolve(files);
      setTimeout(tick, 700);
    };
    tick();
  });
}

/* ------------------------------------------------------------------ */
/* the runs                                                             */
/* ------------------------------------------------------------------ */

async function fullRun(browser, tag, { realtime }) {
  console.log(`\n=== RUN: ${tag} (${realtime ? 'forced real-time mode' : 'fast/WebCodecs mode'}) ===`);
  const { page, dlDir } = await newPhonePage(browser, tag);
  rmSync(dlDir, { recursive: true, force: true });
  mkdirSync(dlDir, { recursive: true, force: true });

  const runReport = { tag, realtime, steps: [], clips: [], files: [], ok: false };

  try {
    await page.goto(APP, { waitUntil: 'networkidle0', timeout: 60000 });
    await page.waitForSelector('#src', { visible: true, timeout: 30000 });
    runReport.steps.push('app loaded');

    // Turn the log on so we can see what the app itself measured.
    await page.goto(APP + '#/settings', { waitUntil: 'domcontentloaded' });
    await setCheckbox(page, 'showLog', true);
    if (realtime) await setCheckbox(page, 'forceRealtime', true);
    await page.screenshot({ path: join(SHOTS, `${tag}-01-settings.png`), fullPage: true });

    await page.goto(APP + '#/clips', { waitUntil: 'domcontentloaded' });
    await setInput(page, '#src', MEDIA);
    await page.screenshot({ path: join(SHOTS, `${tag}-02-home-filled.png`) });

    await page.click('button.btn-primary');
    runReport.steps.push('Make clips pressed');

    const state = await waitForRun(page, TIMEOUT);
    runReport.clips = state;
    await page.screenshot({ path: join(SHOTS, `${tag}-03-results.png`), fullPage: true });

    const done = state.filter((c) => c.status === 'done');
    const errored = state.filter((c) => c.status === 'error');
    if (!done.length) fail(`${tag}: no clips finished`);
    else pass(`${tag}: ${done.length} clip(s) finished, ${errored.length} failed`);
    for (const c of errored) fail(`${tag}: clip ${c.id} -> ${c.error}`);

    // What the app itself verified (read back from the UI).
    const selfCheck = await page.evaluate(() =>
      [...document.querySelectorAll('[data-clip-id]')].map((el) => ({
        id: el.getAttribute('data-clip-id'),
        text: el.textContent.replace(/\s+/g, ' ').trim().slice(0, 400),
      })),
    );
    runReport.selfCheck = selfCheck;
    for (const s of selfCheck) {
      const m = /Checked: ([\d.]+)s long, picture moves to (\d+)%, sound (\w+)/.exec(s.text);
      if (m) info(`app self-check ${s.id}: ${m[1]}s, motion to ${m[2]}%, sound ${m[3]}`);
    }

    // Downloads: each clip should have been handed over the moment it was ready.
    const files = await waitForDownloads(dlDir, 5000, 180000);
    runReport.files = files;
    if (!files.length) {
      fail(`${tag}: no files were downloaded`);
    } else {
      pass(`${tag}: ${files.length} file(s) downloaded automatically`);
    }

    // Expected duration per clip, taken from the UI badges (e.g. "0:28").
    const expected = state.map((c) => {
      const b = c.badges.find((x) => /^\d+:\d\d$/.test(x));
      return b ? b.split(':').reduce((acc, n, i) => acc + Number(n) * (i === 0 ? 60 : 1), 0) : 28;
    });

    files
      .filter((f) => /\.(mp4|webm|mov)$/i.test(f))
      .sort()
      .forEach((f, i) => {
        const full = join(dlDir, f);
        console.log(`\n    --- ffmpeg check: ${f} ---`);
        const v = verifyFile(full, expected[i] ?? expected[0] ?? 28, { label: `[${tag}] ${f}` });
        runReport.files.push = null;
        (runReport.ffmpeg ||= []).push({ file: f, ...v, checks: v.checks });
        if (!v.ok) fail(`${tag}: ${f} did not pass the ffmpeg checks`);
      });

    runReport.ok = done.length > 0 && files.length > 0 && (runReport.ffmpeg || []).every((f) => f.ok);
  } catch (e) {
    fail(`${tag}: ${e.message}`);
    runReport.error = e.message;
    try {
      await page.screenshot({ path: join(SHOTS, `${tag}-ERROR.png`), fullPage: true });
    } catch {
      /* ignore */
    }
  } finally {
    await page.close().catch(() => undefined);
  }
  report.runs.push(runReport);
  return runReport;
}

async function pageChecks(browser) {
  console.log('\n=== PAGES: phone-size screenshots + overflow checks ===');
  const page = await browser.newPage();
  await page.emulate(PIXEL7);
  await page.goto(APP, { waitUntil: 'networkidle0' });

  const routes = [
    ['clips', '#/clips'],
    ['history', '#/history'],
    ['settings', '#/settings'],
    ['director', '#/director'],
    ['streams', '#/streams'],
    ['editor', '#/editor'],
  ];

  for (const [name, hash] of routes) {
    await page.goto(APP + hash, { waitUntil: 'domcontentloaded' });
    await new Promise((r) => setTimeout(r, 400));
    const shot = join(SHOTS, `page-${name}.png`);
    await page.screenshot({ path: shot, fullPage: true });
    const m = await page.evaluate(() => {
      const de = document.documentElement;
      const wide = [];
      document.querySelectorAll('body *').forEach((el) => {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && (r.right > window.innerWidth + 1 || r.left < -1)) {
          wide.push(`${el.tagName.toLowerCase()}${el.className ? '.' + String(el.className).split(' ')[0] : ''} right=${Math.round(r.right)}`);
        }
      });
      const bar = document.querySelector('.topbar')?.getBoundingClientRect();
      return {
        innerWidth: window.innerWidth,
        scrollWidth: de.scrollWidth,
        clientWidth: de.clientWidth,
        overflowing: wide.slice(0, 8),
        barBottom: bar ? Math.round(bar.bottom) : null,
        bodyBottom: document.body.scrollHeight,
      };
    });
    const noHScroll = m.scrollWidth <= m.clientWidth + 1;
    if (noHScroll) pass(`page ${name}: no horizontal scrolling (scrollWidth ${m.scrollWidth} <= ${m.clientWidth})`);
    else fail(`page ${name}: horizontal scrolling — scrollWidth ${m.scrollWidth} > clientWidth ${m.clientWidth}: ${m.overflowing.join(', ')}`);
    report.pages.push({ name, ...m, noHScroll, shot });
  }

  // More menu opens and every feature stays reachable.
  await page.goto(APP + '#/clips', { waitUntil: 'domcontentloaded' });
  await page.evaluate(() => [...document.querySelectorAll('.tabbtn')].find((b) => b.textContent === 'More')?.click());
  await new Promise((r) => setTimeout(r, 300));
  const menu = await page.evaluate(() => [...document.querySelectorAll('.sheet button')].map((b) => b.textContent.trim()));
  const want = ['AI Director', 'Streams', 'Editor', 'Latest results'];
  if (want.every((w) => menu.includes(w))) pass(`More menu has ${menu.join(' / ')}`);
  else fail(`More menu missing items: got ${menu.join(' / ')}`);
  await page.screenshot({ path: join(SHOTS, 'page-more-menu.png') });
  report.pages.push({ name: 'more-menu', items: menu });

  // Close the menu again — its dismiss backdrop is a full-screen fixed layer
  // and must not be mistaken for a bottom bar.
  await page.keyboard.press('Escape');
  await new Promise((r) => setTimeout(r, 250));
  const menuGone = await page.evaluate(() => !document.querySelector('.sheet'));
  if (menuGone) pass('More menu closes again');
  else fail('More menu stays open after Escape');

  // No bottom bar anywhere.
  const bottomBar = await page.evaluate(() => {
    const els = [...document.querySelectorAll('body *')].filter((el) => {
      const cs = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      return (
        (cs.position === 'fixed' || cs.position === 'sticky') &&
        Math.abs(r.bottom - window.innerHeight) < 3 &&
        r.height > 30 &&
        r.width > window.innerWidth * 0.6
      );
    });
    return els.map((e) => e.tagName + '.' + e.className);
  });
  if (!bottomBar.length) pass('no bottom bar covering the screen');
  else fail('something is fixed to the bottom of the screen: ' + bottomBar.join(', '));

  await page.close();
}

async function colourCheck(browser) {
  console.log('\n=== LOOK: black and white only, follows the phone theme ===');
  for (const scheme of ['light', 'dark']) {
    const page = await browser.newPage();
    await page.emulate(PIXEL7);
    await page.emulateMediaFeatures([{ name: 'prefers-color-scheme', value: scheme }]);
    await page.goto(APP + '#/clips', { waitUntil: 'domcontentloaded' });
    await new Promise((r) => setTimeout(r, 300));
    const res = await page.evaluate(() => {
      const bad = [];
      let gradients = 0;
      let shadows = 0;
      document.querySelectorAll('body *').forEach((el) => {
        const cs = getComputedStyle(el);
        for (const prop of ['color', 'backgroundColor', 'borderTopColor', 'borderLeftColor']) {
          const v = cs[prop];
          const m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/.exec(v);
          if (!m) continue;
          const [r, g, b] = [m[1], m[2], m[3]].map(Number);
          const alpha = m[4] === undefined ? 1 : Number(m[4]);
          if (alpha < 0.02) continue;
          const spread = Math.max(r, g, b) - Math.min(r, g, b);
          if (spread > 12) bad.push(`${el.tagName.toLowerCase()}.${el.className} ${prop}=${v}`);
        }
        if (cs.backgroundImage && cs.backgroundImage !== 'none' && /gradient/.test(cs.backgroundImage)) gradients++;
        if (cs.boxShadow && cs.boxShadow !== 'none') shadows++;
      });
      const bodyBg = getComputedStyle(document.body).backgroundColor;
      const font = getComputedStyle(document.body).fontFamily;
      return { bad: bad.slice(0, 10), badCount: bad.length, gradients, shadows, bodyBg, font };
    });
    await page.screenshot({ path: join(SHOTS, `theme-${scheme}.png`), fullPage: true });
    if (!res.badCount) pass(`${scheme}: every colour is black, white or grey`);
    else fail(`${scheme}: coloured elements found: ${res.bad.join(', ')}`);
    if (res.gradients === 0) pass(`${scheme}: no gradients`);
    else fail(`${scheme}: ${res.gradients} gradient background(s)`);
    if (res.shadows === 0) pass(`${scheme}: no glows/shadows`);
    else fail(`${scheme}: ${res.shadows} box-shadow(s)`);
    const expectBg = scheme === 'dark' ? 'rgb(0, 0, 0)' : 'rgb(255, 255, 255)';
    if (res.bodyBg === expectBg) pass(`${scheme}: page background is ${res.bodyBg}`);
    else fail(`${scheme}: page background is ${res.bodyBg}, expected ${expectBg}`);
    info(`${scheme}: font stack = ${res.font.slice(0, 60)}`);
    report.pages.push({ name: `theme-${scheme}`, ...res });
    await page.close();
  }
}

/* ------------------------------------------------------------------ */

async function main() {
  mkdirSync(SHOTS, { recursive: true });
  mkdirSync(DL, { recursive: true });
  console.log(`app:     ${APP}`);
  console.log(`media:   ${MEDIA}`);
  console.log(`shots:   ${SHOTS}`);
  console.log(`downloads: ${DL}`);

  // Sanity: the source itself must be good before we blame the app.
  console.log('\n=== SOURCE CHECK ===');
  const srcProbe = ffprobeJson(MEDIA.startsWith('http') ? MEDIA : MEDIA);
  const sv = srcProbe.streams.find((s) => s.codec_type === 'video');
  const sa = srcProbe.streams.find((s) => s.codec_type === 'audio');
  info(`source: ${sv?.codec_name} ${sv?.width}x${sv?.height} ${srcProbe.format.duration}s, audio ${sa?.codec_name}`);
  if (sv?.codec_name !== 'h264') fail('test source is not H.264 — the brief requires an H.264/AAC MP4');
  if (sa?.codec_name !== 'aac') fail('test source audio is not AAC');

  const browser = await launch();
  console.log('browser: ' + (await browser.version()));

  try {
    if (!ONLY || ONLY === 'pages') {
      await pageChecks(browser);
      await colourCheck(browser);
    }
    if (!ONLY || ONLY === 'fast') await fullRun(browser, 'fast', { realtime: false });
    if (!ONLY || ONLY === 'realtime') await fullRun(browser, 'realtime', { realtime: true });
  } finally {
    await browser.close();
  }

  report.finishedAt = new Date().toISOString();
  report.passed = report.failures.length === 0;
  writeFileSync(RESULTS, JSON.stringify(report, null, 2));
  console.log('\n=========================================');
  console.log(report.passed ? 'ALL CHECKS PASSED' : `${report.failures.length} CHECK(S) FAILED`);
  if (!report.passed) report.failures.forEach((f, i) => console.log(`  ${i + 1}. ${f}`));
  console.log('report: ' + RESULTS);
  console.log('=========================================');
  process.exit(report.passed ? 0 : 1);
}

main().catch((e) => {
  console.error('harness crashed:', e);
  report.failures.push('harness crashed: ' + e.message);
  writeFileSync(RESULTS, JSON.stringify(report, null, 2));
  process.exit(1);
});

import { readFileSync } from 'node:fs';
import MP4Box from 'mp4box';
const buf = readFileSync('/tmp/cf-test/source-180s.mp4');
const CH = 4<<20;
const f = MP4Box.createFile();
let info=null, started=false;
const seen=[];
f.onReady=(i)=>{info=i;};
f.onSamples=(id,u,samples)=>{ for(const s of samples){ if(id===info.videoTracks[0].id) seen.push(s.number); f.releaseUsedSamples(id,s.number);} };
let off=0;
while(off<buf.length){
  const slice=buf.subarray(off,Math.min(off+CH,buf.length));
  const ab=slice.buffer.slice(slice.byteOffset,slice.byteOffset+slice.byteLength);
  ab.fileStart=off;
  const next=f.appendBuffer(ab);
  if(!started && info){ started=true; f.setExtractionOptions(info.videoTracks[0].id,null,{nbSamples:24}); f.start(); }
  off = (typeof next==='number'&&next>off)?next:off+slice.byteLength;
  if(off>=buf.length) f.flush();
}
console.log('video samples delivered:', seen.length, '(file has 5400)');
console.log('first delivered sample number:', seen[0], 'last:', seen[seen.length-1]);
console.log('missing at the start:', seen[0] > 0 ? seen[0] + ' sample(s) LOST' : 'none');

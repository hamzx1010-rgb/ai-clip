/**
 * Stop-behaviour check, driven through the real UI:
 *   start a run -> wait until two clips are finished -> press Stop ->
 *   then prove that finished clips are STILL playable and downloadable,
 *   unfinished ones went back to "not made yet" (not "error"), and the page
 *   says plainly what happened instead of showing a failure.
 */
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import puppeteer from 'puppeteer-core';

const APP = 'http://127.0.0.1:4173';
const MEDIA = 'http://127.0.0.1:8099/source-180s.mp4';
const DL = resolve('/tmp/cf-stop');
rmSync(DL, { recursive: true, force: true });
mkdirSync(DL, { recursive: true });

const browser = await puppeteer.launch({
  executablePath: '/usr/bin/google-chrome-stable',
  headless: true,
  args: [
    '--no-sandbox',
    '--disable-dev-shm-usage',
    '--disable-gpu',
    '--mute-audio',
    '--autoplay-policy=no-user-gesture-required',
  ],
});
const page = await browser.newPage();
await page.emulate({
  name: 'Pixel 7',
  userAgent:
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36',
  viewport: { width: 412, height: 915, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
});
const cdp = await page.createCDPSession();
await cdp.send('Page.setDownloadBehavior', { behavior: 'allow', downloadPath: DL, eventsEnabled: true });

await page.goto(APP, { waitUntil: 'domcontentloaded' });
await page.waitForSelector('#src', { timeout: 30000 });
await page.evaluate((url) => {
  const el = document.querySelector('#src');
  const set = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  set.call(el, url);
  el.dispatchEvent(new Event('input', { bubbles: true }));
}, MEDIA);

// exact-number mode: 4 clips, so stopping after 2 leaves real leftovers
await page.evaluate(() => {
  const btns = [...document.querySelectorAll('.seg button')];
  btns.find((b) => b.textContent === 'Exact number')?.click();
  btns.find((b) => b.textContent === '4')?.click();
});

await page.evaluate(() => {
  [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Make clips')?.click();
});

// wait until two clips are done
await page.waitForFunction(
  () => document.querySelectorAll('[data-clip-id][data-status="done"]').length >= 2,
  { timeout: 300000, polling: 1000 },
);
console.log('two clips done — pressing Stop');
await page.evaluate(() => {
  [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Stop')?.click();
});

// the run unwinds calmly
await page.waitForFunction(() => !document.querySelector('.meter'), { timeout: 60000, polling: 500 });
await new Promise((r) => setTimeout(r, 1500));

const state = await page.evaluate(() => {
  const rows = [...document.querySelectorAll('[data-clip-id]')].map((el) => ({
    status: el.getAttribute('data-status'),
    play: !![...el.querySelectorAll('button')].find(
      (b) => b.textContent.includes('Play') && !b.disabled,
    ),
    download: !![...el.querySelectorAll('button')].find(
      (b) => b.textContent.includes('Download') && !b.disabled,
    ),
    err: el.querySelector('.err')?.textContent?.trim() || null,
  }));
  const status = [...document.querySelectorAll('p.strong')].map((p) => p.textContent.trim());
  const banner = document.querySelector('p.err')?.textContent?.trim() || null;
  const downloadAll = !![...document.querySelectorAll('button')].find(
    (b) => b.textContent.includes('Download all') && !b.disabled,
  );
  return { rows, status, banner, downloadAll };
});
console.log(JSON.stringify(state, null, 2));

let failed = 0;
const check = (ok, msg) => {
  console.log((ok ? '  ok:   ' : '  FAIL: ') + msg);
  if (!ok) failed++;
};

const doneRows = state.rows.filter((r) => r.status === 'done');
check(doneRows.length >= 2, `${doneRows.length} clip(s) still marked done after Stop`);
check(doneRows.every((r) => r.play && r.download), 'every done clip has Play AND Download enabled');
check(state.rows.every((r) => r.status !== 'error'), 'no clip left in error state after Stop');
check(!state.banner, 'no failure banner on the page');
check(
  state.status.some((t) => /Stopped/.test(t)),
  `status says stopped plainly: ${state.status.find((t) => /Stopped/.test(t)) || '(none)'}`,
);
check(state.downloadAll, 'Download all is available after Stop');

// download one finished clip and let ffmpeg judge it
await page.evaluate(() => {
  const row = document.querySelector('[data-clip-id][data-status="done"]');
  const btn = [...(row?.querySelectorAll('button') || [])].find((b) =>
    b.textContent.includes('Download'),
  );
  btn?.click();
});
await new Promise((r) => setTimeout(r, 6000));
const files = readdirSync(DL).filter((f) => !f.endsWith('.crdownload'));
check(files.length >= 1, `a file reached the download folder: ${files[0] || '(none)'}`);
if (files.length) {
  const probe = spawnSync('ffprobe', [
    '-v', 'error', '-show_entries', 'format=duration', '-show_entries', 'stream=codec_type',
    '-of', 'csv=p=0', join(DL, files[0]),
  ], { encoding: 'utf8' });
  const kinds = String(probe.stdout).trim().split('\n');
  const dur = Number(kinds.find((k) => /^\d/.test(k)) || 0);
  check(kinds.includes('video') && kinds.includes('audio'), 'downloaded file has video AND audio');
  check(dur > 5, `downloaded file has a real length (${dur.toFixed(1)}s)`);
  writeFileSync('/tmp/stopcheck-verdict.txt', `dur=${dur} streams=${kinds.join(',')}`);
}

// reload: finished clips must survive from IndexedDB
await page.goto(APP + '/#/history', { waitUntil: 'domcontentloaded' });
await page.waitForFunction(
  () => [...document.querySelectorAll('button')].some((b) => b.textContent.trim() === 'Open'),
  { timeout: 30000, polling: 500 },
);
const after = await page.evaluate(() => {
  const rows = [...document.querySelectorAll('.rowline')].map((r) => r.textContent || '');
  return {
    hasOpen: true,
    stoppedNote: rows.some((t) => /Stopped by you/.test(t)),
  };
});
check(after.hasOpen, 'History offers Open for the stopped run (finished clips persisted)');
check(after.stoppedNote, 'History says why the run ended early, in plain words');

console.log(failed ? `\nSTOPCHECK FAILED (${failed})` : '\nSTOPCHECK PASSED');
await browser.close();
process.exit(failed ? 1 : 0);

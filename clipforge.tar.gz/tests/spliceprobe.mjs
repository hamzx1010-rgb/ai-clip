import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,protocolTimeout:180000,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('pageerror',e=>console.log('[pageerror]',String(e.message).slice(0,200)));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const out={};
  const M = await import('/src/lib/mp4demux.ts');
  const res = await fetch('http://127.0.0.1:8099/source-180s.mp4',{cache:'no-store'});
  const ab = await res.arrayBuffer();
  const blob = new Blob([ab],{type:'video/mp4'});
  const t0=performance.now();
  const h = await M.readHeader(blob);
  out.readHeaderMs = Math.round(performance.now()-t0);
  out.headerBytesLen = h.headerBytes?.length ?? null;
  out.mdatDataStart = h.mdatDataStart;
  out.videoSamples = h.videoSamples.length;
  const vStart = M.byteOffsetForTime(h.videoSamples, 40);
  const vEnd = M.byteEndForTime(h.videoSamples, 45, blob.size);
  out.vRange = {vStart, vEnd, mb: ((vEnd-vStart)/1048576).toFixed(2)};
  // try a spliced reader
  const rd = new M.SourceReader({blob, wantVideo:true, wantAudio:false, startByte:vStart, endByte:vEnd, headerBytes:h.headerBytes, chunkBytes:1<<20});
  let readyOk=false, readyErr=null;
  const readyP = rd.ready().then(()=>{readyOk=true;}).catch(e=>{readyErr=String(e.message||e);});
  const loop = rd.start();
  await Promise.race([readyP, new Promise(r=>setTimeout(()=>r('timeout'),15000))]);
  out.ready={readyOk, readyErr};
  if (readyOk) {
    let n=0, first=null, last=null;
    const t1=performance.now();
    while(n<5000){
      const s = await rd.nextVideo();
      if(!s) break;
      if(!first) first={sec:s.seconds, sync:s.is_sync, len:s.data.length};
      last={sec:s.seconds, len:s.data.length};
      n++;
      if(s.seconds>46) break;
    }
    out.samples={n, first, last, ms:Math.round(performance.now()-t1)};
  }
  rd.destroy(); await loop.catch(()=>{});
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

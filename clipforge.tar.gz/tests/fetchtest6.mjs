import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('requestfailed',r=>console.log('  [reqfail]',r.url().slice(0,95),'|',r.failure()?.errorText));
p.on('response',r=>{ if(r.url().includes('8099')) console.log('  [resp]',r.status(),r.url().slice(0,95)); });
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const out = {};
  for (const [k,u] of Object.entries({plain:'http://127.0.0.1:8099/source-180s.mp4', q:'http://127.0.0.1:8099/source-180s.mp4?x=1', q2:'http://127.0.0.1:8099/source-180s.mp4?a=b'})) {
    try { const res = await fetch(u); const bl = await res.blob(); out[k]={status:res.status,size:bl.size}; }
    catch(e){ out[k]=String(e.message); }
  }
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

import puppeteer from 'puppeteer-core';
for (const mode of ['default','cache-disabled','fresh-profile']) {
  const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,
    userDataDir: mode==='fresh-profile' ? undefined : '/tmp/cf-profile',
    args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu', ...(mode==='cache-disabled'?['--disk-cache-size=1']:[])]});
  const p = await b.newPage();
  const cdp = await p.createCDPSession();
  if (mode==='cache-disabled') await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
  await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
  const r = await p.evaluate(async () => {
    try { const res = await fetch('http://127.0.0.1:8099/source-180s.mp4'); const bl = await res.blob(); return {ok:true,status:res.status,size:bl.size}; }
    catch(e){ return {ok:false,error:String(e.message)}; }
  });
  console.log(mode.padEnd(16), JSON.stringify(r));
  await b.close();
}

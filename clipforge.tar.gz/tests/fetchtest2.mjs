import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('response', async r => { if (!r.url().includes('5173/@') && !r.url().includes('/src/')) console.log('[resp]', r.status(), r.url().slice(0,110), JSON.stringify(r.headers()).slice(0,220)); });
p.on('requestfailed', r => console.log('[reqfail]', r.url().slice(0,110), r.failure()?.errorText));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
// try several fetch styles
const r = await p.evaluate(async () => {
  const out = {};
  const tries = {
    plain: () => fetch('http://127.0.0.1:8099/source-180s.mp4'),
    noCors: () => fetch('http://127.0.0.1:8099/source-180s.mp4', {mode:'no-cors'}),
    head: () => fetch('http://127.0.0.1:8099/source-180s.mp4', {method:'HEAD'}),
    smallFile: () => fetch('http://127.0.0.1:8099/index.html'),
  };
  for (const [k, fn] of Object.entries(tries)) {
    try { const res = await fn(); out[k] = {status:res.status, type:res.type, len:res.headers.get('content-length')}; }
    catch(e){ out[k] = {error:String(e.message||e)}; }
  }
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

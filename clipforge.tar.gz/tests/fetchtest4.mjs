import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
async function mk(name, url){ const p = await b.newPage(); p.on('requestfailed',r=>console.log(`[${name}][reqfail]`,r.url().slice(0,80),r.failure()?.errorText)); await p.goto(url,{waitUntil:'domcontentloaded'}); return p; }
const run = async (p,name) => p.evaluate(async () => {
  const out = {};
  try { const r = await fetch('http://127.0.0.1:8099/source-180s.mp4'); const bl = await r.blob(); out.fetch={status:r.status,size:bl.size}; } catch(e){ out.fetch=String(e.message); }
  try { const r = await fetch('http://127.0.0.1:8099/source-180s.mp4?x=1',{cache:'no-store'}); out.fetch2=r.status; } catch(e){ out.fetch2=String(e.message); }
  out.xhr = await new Promise(res=>{ const x=new XMLHttpRequest(); x.open('GET','http://127.0.0.1:8099/source-180s.mp4'); x.responseType='blob'; x.onload=()=>res({status:x.status,size:x.response?.size}); x.onerror=()=>res('xhr error'); x.send(); });
  out.mp4boxPatched = typeof window.MP4Box !== 'undefined';
  return out;
});
const p1 = await mk('probe','http://127.0.0.1:5173/tests/probe.html');
console.log('probe page:', JSON.stringify(await run(p1)));
const p2 = await mk('blank','http://127.0.0.1:5173/');
console.log('app page:  ', JSON.stringify(await run(p2)));
await b.close();

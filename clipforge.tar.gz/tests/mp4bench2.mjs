import { readFileSync } from 'node:fs';
import MP4Box from 'mp4box';
const buf = readFileSync('/tmp/cf-test/source-180s.mp4');
const CH = 4<<20;
const f = MP4Box.createFile();
let info=null, ready=false;
f.onReady=(i)=>{info=i;ready=true;};
f.onError=(e)=>console.log('ERR',e);
let vSamples=0, aSamples=0, vBytes=0, firstV=null, firstA=null;
f.onSamples=(id,user,samples)=>{
  for(const s of samples){
    if(id===info.videoTracks[0].id){ vSamples++; vBytes+=s.data?.length||0; if(!firstV) firstV={cts:s.cts,dur:s.duration,sync:s.is_sync,len:s.data?.length, head:[...s.data.slice(0,8)]}; }
    else { aSamples++; if(!firstA) firstA={cts:s.cts,dur:s.duration,len:s.data?.length, head:[...s.data.slice(0,6)]}; }
    f.releaseUsedSamples(id, s.number);
  }
};
let t=Date.now();
let off=0;
// need info before setExtractionOptions -> append first chunk, wait onReady
while(off < buf.length){
  const slice = buf.subarray(off, Math.min(off+CH, buf.length));
  const ab = slice.buffer.slice(slice.byteOffset, slice.byteOffset+slice.byteLength);
  ab.fileStart = off;
  const next = f.appendBuffer(ab);
  off = (typeof next === 'number' && next > off) ? next : off + slice.byteLength;
  if(ready && !f.__started){
    f.__started=true;
    f.setExtractionOptions(info.videoTracks[0].id, null, {nbSamples: 30});
    f.setExtractionOptions(info.audioTracks[0].id, null, {nbSamples: 100});
    f.start();
    console.log('extraction started after', off, 'bytes');
  }
  if(off>=buf.length) f.flush();
}
console.log('chunked append total:', Date.now()-t,'ms');
console.log('video samples with data:', vSamples, 'bytes', vBytes, 'first', JSON.stringify(firstV));
console.log('audio samples with data:', aSamples, 'first', JSON.stringify(firstA));
const vt=f.getTrackById(info.videoTracks[0].id), at=f.getTrackById(info.audioTracks[0].id);
console.log('trak keys(video):', Object.keys(vt).filter(k=>/avc|hvc|esds|stsd|edts/.test(k)));
console.log('trak keys(audio):', Object.keys(at).filter(k=>/avc|hvc|esds|stsd|edts/.test(k)));
console.log('avcC?', !!vt.avcC, 'esds?', !!at.esds);
if(at.esds) console.log('esds type:', typeof at.esds, at.esds.type, 'has write:', typeof at.esds.write);

// ---- locate the sample description boxes ----
const stsdV = vt.mdia?.minf?.stbl?.stsd;
const stsdA = at.mdia?.minf?.stbl?.stsd;
console.log('video stsd entries:', stsdV?.entries?.length, stsdV?.entries?.[0]?.type);
console.log('audio stsd entries:', stsdA?.entries?.length, stsdA?.entries?.[0]?.type);
const avc1 = stsdV?.entries?.[0];
const mp4a = stsdA?.entries?.[0];
console.log('avc1.avcC?', !!avc1?.avcC, avc1?.avcC?.type, 'write fn:', typeof avc1?.avcC?.write);
console.log('mp4a.esds?', !!mp4a?.esds, mp4a?.esds?.type, 'write fn:', typeof mp4a?.esds?.write);
console.log('avcC fields:', avc1?.avcC ? JSON.stringify({AVCProfileIndication:avc1.avcC.AVCProfileIndication,profile_compatibility:avc1.avcC.profile_compatibility,AVCLevelIndication:avc1.avcC.AVCLevelIndication,SPS:avc1.avcC.SPS?.length,PPS:avc1.avcC.PPS?.length}) : 'none');
console.log('esds fields:', mp4a?.esds ? JSON.stringify({type:mp4a.esds.type, hasEsd:!!mp4a.esds.esd}) : 'none');
console.log('mp4a samplerate/channelcount:', mp4a?.samplerate, mp4a?.channel_count, mp4a?.samplesize);
console.log('BoxParser available:', typeof MP4Box.BoxParser, typeof (await import('mp4box')).default.BoxParser);

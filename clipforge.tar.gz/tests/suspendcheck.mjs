/**
 * Reproduce the phone hang: an AudioContext created outside a user gesture
 * starts "suspended" unless the browser was launched with an autoplay
 * exemption. On some Android browsers decodeAudioData then never answers.
 *
 * This launches Chrome WITHOUT --autoplay-policy=no-user-gesture-required and
 * compares the old approach (live AudioContext) with the new one
 * (OfflineAudioContext), against the real test source.
 */
import puppeteer from 'puppeteer-core';

const browser = await puppeteer.launch({
  executablePath: '/usr/bin/google-chrome-stable',
  headless: true,
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu'], // note: NO autoplay flag
});
const page = await browser.newPage();
await page.goto('about:blank');

const out = await page.evaluate(async () => {
  const res = {};
  // Build a 2 s stereo WAV in memory: the hang we are reproducing is about the
  // AudioContext state, not about any particular codec.
  const rate = 44100, secs = 2, n = rate * secs;
  const bytes = 44 + n * 2 * 2;
  const ab = new ArrayBuffer(bytes);
  const dv = new DataView(ab);
  const wstr = (o, t) => { for (let i = 0; i < t.length; i++) dv.setUint8(o + i, t.charCodeAt(i)); };
  wstr(0, 'RIFF'); dv.setUint32(4, bytes - 8, true); wstr(8, 'WAVEfmt ');
  dv.setUint32(16, 16, true); dv.setUint16(20, 1, true); dv.setUint16(22, 2, true);
  dv.setUint32(24, rate, true); dv.setUint32(28, rate * 4, true); dv.setUint16(32, 4, true);
  dv.setUint16(34, 16, true); wstr(36, 'data'); dv.setUint32(40, n * 4, true);
  for (let i = 0; i < n; i++) {
    const v = Math.sin(2 * Math.PI * 440 * (i / rate)) * 0.3;
    dv.setInt16(44 + i * 4, v * 32767, true);
    dv.setInt16(46 + i * 4, v * 32767, true);
  }
  const buf = ab;

  const race = (p, ms) =>
    Promise.race([p.then((v) => ({ done: true, v }), () => ({ done: false, err: true })), new Promise((r) => setTimeout(() => r({ done: false, slow: true }), ms))]);

  // 1. OLD way: live AudioContext created outside any gesture
  try {
    const ctx = new AudioContext();
    res.liveState = ctx.state;
    const r = await race(ctx.decodeAudioData(buf.slice(0, 4_000_000)), 8000);
    res.live = r.slow ? 'STILL HANGING after 8s' : r.done ? 'resolved' : 'rejected';
    await ctx.close?.();
  } catch (e) {
    res.live = 'threw ' + e.message;
  }

  // 2. NEW way: OfflineAudioContext (never suspended)
  try {
    const off = new OfflineAudioContext(1, 1, 44100);
    res.offState = off.state;
    const r = await race(off.decodeAudioData(buf.slice(0, 4_000_000)), 8000);
    res.offline = r.slow ? 'STILL HANGING after 8s' : r.done ? `resolved ${r.v.duration.toFixed(1)}s` : 'rejected';
  } catch (e) {
    res.offline = 'threw ' + e.message;
  }
  return res;
});

console.log(JSON.stringify(out, null, 2));
await browser.close();

import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('requestfailed', r => console.log('[reqfail]', r.url().slice(0,90), r.failure()?.errorText));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});

const test = async (label) => {
  const r = await p.evaluate(async () => {
    try { const res = await fetch('http://127.0.0.1:8099/source-180s.mp4'); const bl = await res.blob(); return {ok:true,status:res.status,size:bl.size}; }
    catch(e){ return {ok:false,error:String(e.message||e)}; }
  });
  console.log(label, JSON.stringify(r));
};
await test('BEFORE setDownloadBehavior:');
const cdp = await p.createCDPSession();
await cdp.send('Page.setDownloadBehavior', {behavior:'allow', downloadPath:'/tmp/cf-probe2', eventsEnabled:true});
await test('AFTER  setDownloadBehavior:');
await b.close();

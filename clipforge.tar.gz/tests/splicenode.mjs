import { readFileSync } from 'node:fs';
import MP4Box from 'mp4box';
const buf = readFileSync('/tmp/cf-test/source-180s.mp4');

// pass 1: header
const f1 = MP4Box.createFile();
let info=null;
f1.onReady=(i)=>{info=i;};
const h = buf.subarray(0, 1<<20);
let ab = h.buffer.slice(h.byteOffset,h.byteOffset+h.byteLength); ab.fileStart=0;
f1.appendBuffer(ab); f1.flush();
const vs = f1.getTrackSamplesInfo(info.videoTracks[0].id);
const mdatDataStart = (()=>{ let p=0; while(p+8<=buf.length){ const size=buf.readUInt32BE(p); const type=buf.toString('ascii',p+4,p+8); if(type==='mdat') return p+8; if(size<8) return 0; p+=size; } return 0; })();
const headerBytes = buf.subarray(0, mdatDataStart);
console.log('mdatDataStart', mdatDataStart, 'headerBytes', headerBytes.length);
let idx = vs.findIndex(s=>s.cts/vs[0].timescale >= 40);
let key = idx; while(key>0 && !vs[key].is_sync) key--;
const vStart = Math.max(0, vs[key].offset - 8);
const endIdx = vs.findIndex(s=>s.cts/vs[0].timescale > 45);
const vEnd = vs[endIdx-1].offset + vs[endIdx-1].size;
console.log('vStart',vStart,'vEnd',vEnd, 'keyOffset', vs[key].offset);

// pass 2: spliced
const f2 = MP4Box.createFile();
let ready2=false, err2=null, samples=0, first=null;
f2.onReady=()=>{ready2=true;};
f2.onError=(e)=>{err2=String(e?.message||e);};
f2.onSamples=(id,u,ss)=>{ for(const s of ss){ samples++; if(!first) first={n:s.number,cts:s.cts,len:s.data?.length}; f2.releaseUsedSamples(id,s.number);} };
const slice = buf.subarray(vStart, vEnd);
const pad = vStart - headerBytes.length;
const virt = Buffer.alloc(headerBytes.length + pad + slice.length);
headerBytes.copy(virt,0);
slice.copy(virt, headerBytes.length+pad);
console.log('virt len', virt.length, 'pad', pad, 'expected vEnd', vEnd);
let ab2 = virt.buffer.slice(virt.byteOffset, virt.byteOffset+virt.byteLength); ab2.fileStart = vStart - pad;
try { f2.appendBuffer(ab2); } catch(e){ console.log('append THREW', e.message); }
f2.flush();
console.log('ready2', ready2, 'err2', err2, 'samples delivered', samples, 'first', JSON.stringify(first));
if (ready2) { f2.setExtractionOptions(info.videoTracks[0].id,null,{nbSamples:24}); f2.start(); f2.flush(); console.log('after start: samples', samples, 'first', JSON.stringify(first)); }

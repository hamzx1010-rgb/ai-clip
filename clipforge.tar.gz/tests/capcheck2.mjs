import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
await p.goto('http://127.0.0.1:4173/', {waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const out = {aac:{}, flac:{}, opus:{}, mimes:{}};
  for (const sr of [8000,11025,12000,16000,22050,24000,32000,44100,48000]) {
    for (const ch of [1,2]) {
      try {
        const s = await AudioEncoder.isConfigSupported({codec:'mp4a.40.2',sampleRate:sr,numberOfChannels:ch,bitrate:128000});
        if (s.supported) out.aac[`${sr}x${ch}`] = true;
      } catch(e) { out.aac.err = String(e.message).slice(0,80); }
    }
  }
  for (const c of ['flac','opus','mp3','vorbis','pcm-s16']) {
    try { const s = await AudioEncoder.isConfigSupported({codec:c,sampleRate:48000,numberOfChannels:2}); out.flac[c]=!!s.supported; } catch(e){ out.flac[c]='err'; }
  }
  const mimes = ['video/mp4;codecs="avc1.42E01E,mp4a.40.2"','video/mp4;codecs=avc1.42E01E','video/mp4;codecs="avc1,mp4a"','video/mp4;codecs="h264,aac"','video/webm;codecs="vp8,opus"','video/webm;codecs="vp9,opus"','video/x-matroska;codecs="vp8,opus"'];
  for (const m of mimes) { try { out.mimes[m] = MediaRecorder.isTypeSupported(m); } catch { out.mimes[m]='err'; } }
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

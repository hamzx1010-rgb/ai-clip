import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,protocolTimeout:240000,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('pageerror',e=>console.log('[pageerror]',String(e.message).slice(0,200)));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const M = await import('/src/lib/mp4demux.ts');
  const res = await fetch('http://127.0.0.1:8099/source-180s.mp4',{cache:'no-store'});
  const ab = await res.arrayBuffer();
  const blob = new Blob([ab],{type:'video/mp4'});
  const h = await M.readHeader(blob);
  const out = {readHeaderOk: !!h.tracks, mdat: h.mdatDataStart};

  // from byte 0, but stop as soon as we pass 46s
  const rd = new M.SourceReader({blob, wantVideo:true, wantAudio:false, stopAtSeconds:46, chunkBytes:1<<20});
  const t0=performance.now();
  const loop = rd.start();
  await rd.ready();
  out.readyMs = Math.round(performance.now()-t0);
  let n=0, first=null, last=null;
  while(true){
    const s = await rd.nextVideo();
    if(!s) break;
    if(!first) first={sec:+s.seconds.toFixed(2), sync:s.is_sync, len:s.data.length};
    last={sec:+s.seconds.toFixed(2), len:s.data.length};
    n++;
  }
  out.got = {n, first, last, totalMs: Math.round(performance.now()-t0)};
  rd.destroy(); await loop.catch(()=>{});

  // how long does a FULL read take (no stop)?
  const rd2 = new M.SourceReader({blob, wantVideo:false, wantAudio:true, chunkBytes:1<<20});
  const t1=performance.now();
  const loop2 = rd2.start(); await rd2.ready();
  let a=0; while(true){ const s=await rd2.nextAudio(); if(!s) break; a++; }
  out.audioFullRead = {samples:a, ms: Math.round(performance.now()-t1)};
  rd2.destroy(); await loop2.catch(()=>{});
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

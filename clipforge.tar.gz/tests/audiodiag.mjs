/**
 * Audio diagnostic: does this Chrome read sound out of the clip we built?
 *
 * Compares three files with the same code path:
 *   mine.mp4      - the clip ClipForge's fast engine wrote
 *   reffull.mp4   - the same 5 s cut produced by ffmpeg (known good)
 *   refaudio.mp4  - just the copied AAC track, also from ffmpeg
 *
 * For each it reports what decodeAudioData says and what the WebCodecs
 * AudioDecoder says, so a container problem can be told apart from a
 * "this Chrome has no audio stack" problem.
 */
import puppeteer from 'puppeteer-core';

const CHROME = process.env.CHROME || '/usr/bin/google-chrome-stable';
const files = ['mine.mp4', 'ref-full.mp4', 'refaudio.mp4'];

const browser = await puppeteer.launch({
  executablePath: CHROME,
  headless: 'new',
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--autoplay-policy=no-user-gesture-required'],
});
const page = await browser.newPage();
page.on('console', (m) => console.log('  [page]', m.text().slice(0, 300)));
await page.goto('http://127.0.0.1:5173/tests/probe.html', { waitUntil: 'domcontentloaded' });

const out = await page.evaluate(async (names) => {
  const res = {};
  for (const n of names) {
    const r = { name: n };
    try {
      const resp = await fetch(`http://127.0.0.1:8099/${n}`);
      const buf = await resp.arrayBuffer();
      r.bytes = buf.byteLength;

      // 1. Web Audio decodeAudioData (what verify.ts uses today)
      try {
        const Ctor = window.AudioContext || window.webkitAudioContext;
        const ctx = new Ctor();
        r.ctxState = ctx.state;
        const ab = await ctx.decodeAudioData(buf.slice(0));
        r.decodeAudioData = { duration: ab.duration, channels: ab.numberOfChannels, rate: ab.sampleRate };
        let peak = 0;
        const d = ab.getChannelData(0);
        for (let i = 0; i < d.length; i += 37) peak = Math.max(peak, Math.abs(d[i]));
        r.decodeAudioData.peak = peak;
        await ctx.close?.();
      } catch (e) {
        r.decodeAudioData = { error: String(e && e.name) + ': ' + String(e && e.message).slice(0, 160) };
      }

      // 2. WebCodecs AudioDecoder on the demuxed AAC
      try {
        const MP4Box = (await import('/node_modules/mp4box/dist/mp4box.all.js')).default;
        const f = MP4Box.createFile();
        let info = null;
        f.onReady = (i) => { info = i; };
        buf.fileStart = 0;
        f.appendBuffer(buf);
        f.flush();
        const at = info.audioTracks[0];
        r.audioTrack = { codec: at.codec, rate: at.audio.sample_rate, ch: at.audio.channel_count, nb: at.nb_samples };
        const trak = f.getTrackById(at.id);
        const entry = trak.mdia.minf.stbl.stsd.entries[0];
        const esds = entry.esds;
        let desc = null;
        if (esds && esds.esd && esds.esd.descs) {
          const dc = esds.esd.descs.find((d) => d.descs);
          const ds = dc && dc.descs.find((d) => d.data);
          if (ds) desc = ds.data;
        }
        r.esdsFound = !!desc;
        const cfg = { codec: at.codec, sampleRate: at.audio.sample_rate, numberOfChannels: at.audio.channel_count, description: desc };
        r.decCfgSupport = (await AudioDecoder.isConfigSupported(cfg)).supported;
        const dec = new AudioDecoder({
          output: (d) => { r.decodedFrames = (r.decodedFrames || 0) + 1; r.decodedSamples = (r.decodedSamples || 0) + d.numberOfFrames; if (r.decodedFrames === 1) { r.firstFrameCh = d.numberOfChannels; r.firstFrameRate = d.sampleRate; } d.close(); },
          error: (e) => { r.decoderError = String(e.message).slice(0, 200); },
        });
        dec.configure(cfg);
        f.setExtractionOptions(at.id, null, { nbSamples: 200 });
        f.onSamples = (id, u, samples) => {
          for (const s of samples) {
            const data = s.data.slice(0);
            dec.decode(new EncodedAudioChunk({ type: s.is_sync ? 'key' : 'delta', timestamp: Math.round((s.cts / s.timescale) * 1e6), duration: Math.round((s.duration / s.timescale) * 1e6), data }));
          }
        };
        f.start();
        await dec.flush().catch((e) => { r.flushError = String(e.message).slice(0, 200); });
        dec.close();
      } catch (e) {
        r.webcodecs = { error: String(e && e.message).slice(0, 200) };
      }
    } catch (e) {
      r.fetchError = String(e && e.message).slice(0, 200);
    }
    res[n] = r;
  }
  return res;
}, files);

console.log(JSON.stringify(out, null, 2));
await browser.close();

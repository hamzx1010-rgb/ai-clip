import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('pageerror',e=>console.log('[pageerror]',String(e.message).slice(0,200)));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const out={};
  // pull avcC bytes via the app's reader
  const {SourceReader} = await import('/src/lib/mp4demux.ts');
  const res = await fetch('http://127.0.0.1:8099/source-180s.mp4',{cache:'no-store'});
  const parts=[]; const rd=res.body.getReader();
  for(;;){const{done,value}=await rd.read(); if(done)break; parts.push(value);}
  const blob=new Blob(parts,{type:'video/mp4'});
  const reader=new SourceReader({blob,wantVideo:true,wantAudio:false});
  const loop=reader.start(); await reader.ready();
  const t=reader.tracks;
  out.tracks={codec:t.videoCodec,w:t.width,h:t.height};
  const s=await reader.nextVideo();
  reader.destroy(); await loop.catch(()=>{});
  out.firstSample={len:s.data.length, sync:s.is_sync, head:[...s.data.slice(0,6)]};
  // Build Annex-B version of the first (key) sample using SPS/PPS from avcC bytes
  const avcC=t.avcCBytes; // full box incl 8-byte header
  const p9=avcC[9]; const nalLen=(avcC[13]&3)+1;
  const spsLen=(avcC[12]<<8)|avcC[13-1+0]; // careful: compute properly below
  // proper parse
  let o=11; const numSPS=avcC[o]&0x1f; o++;
  const sps=[]; for(let i=0;i<numSPS;i++){ const L=(avcC[o]<<8)|avcC[o+1]; o+=2; sps.push(avcC.slice(o,o+L)); o+=L; }
  const numPPS=avcC[o]; o++;
  const pps=[]; for(let i=0;i<numPPS;i++){ const L=(avcC[o]<<8)|avcC[o+1]; o+=2; pps.push(avcC.slice(o,o+L)); o+=L; }
  out.parsed={nalLen, numSPS, spsLens:sps.map(x=>x.length), numPPS, ppsLens:pps.map(x=>x.length)};
  const nalus=[]; let q=0; const d=s.data;
  while(q+4<=d.length){ const L=(d[q]<<24)|(d[q+1]<<16)|(d[q+2]<<8)|d[q+3]; q+=4; if(L<=0||q+L>d.length) break; nalus.push(d.slice(q,q+L)); q+=L; }
  out.nalusInSample=nalus.map(n=>({len:n.length, type:n[0]&0x1f}));
  const sc=new Uint8Array([0,0,0,1]);
  const all=[...sps,...pps,...nalus];
  const total=all.reduce((a,x)=>a+x.length+4,0);
  const ab=new Uint8Array(total); let w2=0;
  for(const n of all){ ab.set(sc,w2); w2+=4; ab.set(n,w2); w2+=n.length; }
  out.annexBLen=ab.length;
  const results={};
  for (const [name,cfg] of Object.entries({
    withDesc:{codec:t.videoCodec,codedWidth:t.width,codedHeight:t.height,description:avcC},
    noDesc:{codec:t.videoCodec,codedWidth:t.width,codedHeight:t.height},
    noDescNoDims:{codec:t.videoCodec},
  })) {
    try { results[name]=await VideoDecoder.isConfigSupported(cfg); } catch(e){ results[name]={err:String(e.message).slice(0,120)}; }
  }
  out.isConfig=results;
  // real decode test without description, Annex-B input
  out.decode = await new Promise((resolve)=>{
    let got=null;
    const dec=new VideoDecoder({output:(f)=>{ got={w:f.codedWidth,h:f.codedHeight,ts:f.timestamp,fmt:f.format}; f.close(); },error:(e)=>resolve({err:String(e.message).slice(0,150)})});
    try{
      dec.configure({codec:t.videoCodec,codedWidth:t.width,codedHeight:t.height});
      dec.decode(new EncodedVideoChunk({type:'key',timestamp:0,duration:33333,data:ab}));
      dec.flush().then(()=>resolve(got?{ok:true,...got}:{ok:false,note:'no frame output'})).catch(e=>resolve({err:'flush '+String(e.message).slice(0,120)}));
    }catch(e){ resolve({err:'cfg '+String(e.message).slice(0,150)}); }
  });
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const U='http://127.0.0.1:8099/source-180s.mp4', S='http://127.0.0.1:8099/small.bin';
  const out={};
  const t = async (k,fn)=>{ try{ out[k]=await fn(); }catch(e){ out[k]='ERR '+e.message; } };
  await t('small_blob', async()=>{const b=await (await fetch(S)).blob(); return b.size;});
  await t('small_array', async()=>{const b=await (await fetch(S)).arrayBuffer(); return b.byteLength;});
  await t('big_blob', async()=>{const b=await (await fetch(U,{cache:'no-store'})).blob(); return b.size;});
  await t('big_stream_to_blob', async()=>{
    const res=await fetch(U,{cache:'no-store'}); const rd=res.body.getReader(); const parts=[]; let n=0;
    for(;;){const{done,value}=await rd.read(); if(done)break; parts.push(value); n+=value.byteLength;}
    return new Blob(parts,{type:res.headers.get('content-type')||'video/mp4'}).size;
  });
  await t('big_array_to_blob', async()=>{const ab=await (await fetch(U,{cache:'no-store'})).arrayBuffer(); return new Blob([ab]).size;});
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({ executablePath: '/usr/bin/google-chrome-stable', headless: true, args: ['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--hide-scrollbars'] });
const p = await b.newPage();
await p.emulate({ name:'Pixel 7', userAgent:'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36', viewport:{ width:412, height:915, deviceScaleFactor:2, isMobile:true, hasTouch:true } });
await p.goto('http://127.0.0.1:4173/', { waitUntil:'domcontentloaded' });
await p.waitForSelector('#src');
// switch to Exact number to show the count row too
await p.evaluate(() => { const b=[...document.querySelectorAll('.seg button')]; b.find(x=>x.textContent==='Exact number')?.click(); });
await new Promise(r=>setTimeout(r,300));
await p.evaluate(() => { const b=[...document.querySelectorAll('.seg button')]; b.find(x=>x.textContent==='3')?.click(); });
await new Promise(r=>setTimeout(r,300));
const m = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
console.log('overflow check:', JSON.stringify(m));
await p.screenshot({ path: 'tests/screenshots/main-picker.png', fullPage: true });
await b.close();

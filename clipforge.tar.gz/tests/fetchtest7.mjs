import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({executablePath:'/usr/bin/google-chrome-stable',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
const p = await b.newPage();
p.on('requestfailed',r=>console.log('  [reqfail]',r.url().slice(30),'|',r.failure()?.errorText));
await p.goto('http://127.0.0.1:5173/tests/probe.html',{waitUntil:'domcontentloaded'});
const r = await p.evaluate(async () => {
  const out = {};
  const tryIt = async (k, u, kind) => {
    try {
      const res = await fetch(u);
      if (kind==='array') { const ab = await res.arrayBuffer(); out[k]={status:res.status,bytes:ab.byteLength}; }
      else if (kind==='stream') { const rd=res.body.getReader(); let n=0; for(;;){const{done,value}=await rd.read(); if(done)break; n+=value.byteLength;} out[k]={status:res.status,bytes:n}; }
      else { const bl = await res.blob(); out[k]={status:res.status,size:bl.size}; }
    } catch(e){ out[k]='ERR '+String(e.message); }
  };
  await tryIt('small_blob','http://127.0.0.1:8099/small.bin','blob');
  await tryIt('big_array','http://127.0.0.1:8099/source-180s.mp4','array');
  await tryIt('big_stream','http://127.0.0.1:8099/source-180s.mp4','stream');
  await tryIt('same_origin','/tests/probe.html','array');
  return out;
});
console.log(JSON.stringify(r,null,1));
await b.close();

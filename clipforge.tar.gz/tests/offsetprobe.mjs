import { readFileSync } from 'node:fs';
import MP4Box from 'mp4box';
const buf = readFileSync('/tmp/cf-test/source-180s.mp4');
const f = MP4Box.createFile();
let info=null, started=false;
f.onReady=(i)=>{info=i;};
f.onSamples=(id,u,ss)=>{ for(const s of ss) f.releaseUsedSamples(id,s.number); };
// Only append the first 1MB: moov is at the front (faststart), so onReady fires.
const sl = buf.subarray(0, 1<<20);
const ab = sl.buffer.slice(sl.byteOffset, sl.byteOffset+sl.byteLength); ab.fileStart=0;
f.appendBuffer(ab); f.flush();
console.log('onReady after 1MB:', !!info);
if(!info) process.exit(1);
const vt = f.getTrackById(info.videoTracks[0].id);
const at = f.getTrackById(info.audioTracks[0].id);
const vs = f.getTrackSamplesInfo(info.videoTracks[0].id);
const as = f.getTrackSamplesInfo(info.audioTracks[0].id);
console.log('video sample table:', vs.length, 'first:', JSON.stringify({n:vs[0].number,cts:vs[0].cts,offset:vs[0].offset,size:vs[0].size,sync:vs[0].is_sync,hasData:!!vs[0].data}));
console.log('audio sample table:', as.length, 'first:', JSON.stringify({n:as[0].number,cts:as[0].cts,offset:as[0].offset,size:as[0].size}));
const ts = vt.mdia.mdhd.timescale;
// find the sample nearest t=40s and its byte offset
const target = 40*ts;
let idx = vs.findIndex(s=>s.cts>=target);
let key = idx; while(key>0 && !vs[key].is_sync) key--;
console.log(`t=40s -> sample #${idx}, keyframe #${key}, byteOffset=${vs[key].offset}, cts=${(vs[key].cts/ts).toFixed(3)}s`);
const ats = at.mdia.mdhd.timescale;
let aidx = as.findIndex(s=>s.cts>=40*ats);
console.log(`audio t=40s -> sample #${aidx}, byteOffset=${as[aidx].offset}`);
console.log('moov position: file size', buf.length, 'last video offset', vs[vs.length-1].offset);

# ClipForge — AI shorts clipper & AI documentary maker

Two tools, both **9:16 only** (Shorts / TikTok / Reels):

1. **Clipper**: paste a video link. ClipForge downloads it, finds the most viral moments, scores them 0–100, reframes each one to 9:16 and adds animated captions (free on-device Whisper, no API key). It exports everything as one zip, faster than real time. Gameplay and wide shots use a blurred-background layout, so the whole frame stays visible. Talking heads get face tracking. There's no shake, no zooms, no sound effects and no watermark.
2. **AI Director**: describe a video (and optionally give a reference). The AI researches it, writes and narrates the script, finds real archival footage and photos, cuts it together with captions, chapter titles and music, and gives you a finished, fully editable 9:16 documentary. Length can be 1–30 minutes, or Auto.

## Use it
**Clip a video:** paste a **direct video link** (e.g. `https://github.com/<user>/<repo>/releases/download/<tag>/video.mp4`) on the home page and click **Clip it**. Deep links work too: `https://<your-app>.onrender.com/?url=<direct video link>`. Supported links: GitHub release assets, Dropbox (`?dl=1`), public Google Drive files, S3/R2/CDN URLs. YouTube/TikTok page URLs aren't video files and get a clear error message.

**Make a documentary:** open **AI Director** and type the idea, for example *"The rise and fall of the 2b2t Minecraft server — dark, mysterious tone"*. Optional inputs:
- **Reference**: links to articles (used as sources) and/or a reference video (direct link or upload). ClipForge copies the reference's editing pace and narration speed, not its footage.
- **Interviews**: upload your own interview recordings. They're transcribed and the best soundbites go into the matching chapters, with name titles. ClipForge never fabricates interviews. Without any, it uses real quotes from Wikiquote, shown on screen and read by a second voice.
- **Mode**: **⚡ Fast** (default) or **🔬 Deep**, see below.
- **Length** (Auto, 1–30 min), **narrator voice** (free on-device English voices), captions, music, slow photo pans, and AI illustrations (only used when no real footage exists; labelled in the credits).

When it's done, click **Open in editor & export**. Every cut, caption and title can be changed. You also get a ready-to-paste description with chapters and a `sources.txt` with all credits and licences.

**Fast vs Deep (AI Director):**
| | ⚡ Fast | 🔬 Deep |
|---|---|---|
| Research | up to 2 articles, fetched in parallel | up to 4 articles |
| Script | fewer, longer chapters; with your own key, 3 chapters are written at once; time limits so a busy free AI can't stall it (it falls back to writing from the sources) | more, shorter chapters, written one by one so each follows on from the last |
| Footage | 5 beats searched at once; about half as many video clips (≤15) | 4 at once; up to 40 video clips |
| Reference video | editing pace only | editing pace + narration speed (downloads a small speech model) |

In both modes the narration is recorded **while** footage is being found, not after it. On devices with enough cores and memory (6+ cores/4 GB+), 2–3 voices record different sentences at the same time.

**Export: Fast vs Best quality** (in the Export window):
- **⚡ Fast** (default): 720p, 24 fps. About 2× quicker than before and plenty for phones.
- **💎 Best quality**: your chosen resolution (up to 4K) at 30 fps. Still about 1.7× quicker than before, thanks to a faster drawing path and audio encoding in parallel with video.

How it works:
| Step | What happens | Where |
|---|---|---|
| Research | Wikipedia articles, your links, Wikiquote | browser + `/api/page` |
| Script | AI writes chapters from the research (facts only). If no AI is available, the narration is built from the sources directly | free AI via `/api/ai`, or your key |
| Footage | Wikimedia Commons video & photos, NASA, Openverse, Pexels (with key) | browser |
| Voice | Kokoro-82M neural TTS, runs on your device (≈92 MB, downloaded once) | browser |
| Edit | Timeline built in the ClipForge editor, 1080×1920 | browser |
| Export | WebCodecs, faster than real time, streamed to disk-backed memory (fine for 30 min) | browser |

Tips:
- **Free Gemini or Groq key (recommended):** the keyless AI is a free community service and is often busy. In **Settings → AI providers**, tap the *Google Gemini* or *Groq* preset and paste a free key from aistudio.google.com or console.groq.com. Scripts get much better and more reliable.
- **Narration speed:** narration is recorded on your device. A computer takes roughly the video's length or less; a phone takes longer. Keep the tab open while it runs.
- **Export size:** for long videos, 720p is plenty on phones and half the file size.

## Deploy on Render
**Option A — Blueprint:** push this folder to GitHub → Render → **New + → Blueprint** → select the repo. `render.yaml` configures everything.

**Option B — manual Web Service:**
| Setting | Value |
|---|---|
| Runtime | Node |
| Build Command | `tar -xzf clipforge.tar.gz && npm install --include=dev && npm run build` |
| Start Command | `npm start` |
| Health Check Path | `/api/health` |
| Env var | `NODE_VERSION` = `22.12.0` |

The server listens on `$PORT` automatically. (If you pushed the unpacked source instead of `clipforge.tar.gz`, drop the `tar -xzf clipforge.tar.gz &&` part.)

## Run locally
```bash
npm install
npm run build
npm start            # http://localhost:3000
# dev mode with hot reload (in two terminals):
npm start            # API on :3000
npm run dev          # UI on :5173 (proxies /api → :3000)
```

## How it works
- `server.js` — zero-dependency Node server:
  - serves the built app (`dist/`)
  - `GET /api/proxy?url=` streams remote videos with Range support, so hosts without CORS headers (like GitHub Releases) work. Private/internal IPs are blocked.
  - `GET /api/audio?url=` uses ffmpeg (`ffmpeg-static`, optional) to extract a small 16 kHz MP3 so huge videos don't exhaust browser memory. If ffmpeg is missing, the browser decodes the audio itself.
  - `GET /api/page?url=` fetches article text/JSON (≤3 MB) for AI Director research.
  - `POST /api/ai` relays AI Director prompts to the free keyless text model (one request at a time, as the free tier requires).
  - `GET /api/health` returns `{ ok, ffmpeg }`.
- `src/` — React + TypeScript app (Vite). Analysis (audio energy/spikes, face tracking via MediaPipe, motion, scene cuts, scoring), captions, rendering and export all run in the browser.

## Subtitles & export (no keys needed)
- **Subtitles**: Whisper runs in your browser (transformers.js + ONNX wasm). Only the chosen clips get transcribed. The model downloads once and is then cached: Fast ≈ 40 MB, Accurate ≈ 76 MB (Settings → Subtitles). The server sends cross-origin-isolation headers so the model can run multi-threaded.
- **Export**: WebCodecs via mediabunny decodes → renders → encodes each clip faster than real time (MP4 H.264, or WebM VP9 if H.264 isn't available). If the browser can't do this, it falls back to real-time recording. You get one `.zip` with every clip plus optional `.srt` files.

## Optional keys (Settings page, stored in the browser)
- **OpenAI-compatible API key**, with presets for OpenAI, Google Gemini (free) and Groq (free). Used for AI Director scripts and clip titles/hooks. A real OpenAI key also unlocks whole-video Whisper, OpenAI voices and image generation.
- **Pexels key** (free): stock video for the AI Director and the editor.

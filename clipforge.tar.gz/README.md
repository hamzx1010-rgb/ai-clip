# ClipForge — AI video clipping & creation

Paste a video link, and ClipForge downloads it, finds the most viral moments, scores them 0–100, picks 9:16 or 16:9 per clip, adds animated captions (free on-device Whisper, no API key), and exports everything as one zip — fast, not real-time. It also has a livestream clipper and a full multi-track editor.

## Use it
1. Open the site.
2. Paste a **direct video link** into the box on the home page (or on *Clip a Video*), e.g.
   `https://github.com/<user>/<repo>/releases/download/<tag>/video.mp4`
3. Click **Clip it**. The video is fetched through the server, then analysed and clipped automatically.

**Clip shape:** by default each clip gets its own layout: gameplay and wide shots stay **16:9 with the full frame** (nothing cropped), clips where a person is on camera become **9:16 with face tracking**. You can switch any clip (or all of them) on the results page, or pick *Always 16:9* / *Always 9:16* before processing. No watermark is added.

Deep links work too: `https://<your-app>.onrender.com/?url=<direct video link>`

Supported links: GitHub release assets, Dropbox (`?dl=1`), public Google Drive files, S3/R2/CDN URLs, anything that serves a video file.
YouTube/TikTok page URLs are **not** video files and are rejected with a clear message.

## Deploy on Render
**Option A — Blueprint:** push this folder to GitHub → Render → **New + → Blueprint** → select the repo. `render.yaml` configures everything.

**Option B — manual Web Service:**
| Setting | Value |
|---|---|
| Runtime | Node |
| Build Command | `npm install --include=dev && npm run build` |
| Start Command | `npm start` |
| Health Check Path | `/api/health` |
| Env var | `NODE_VERSION` = `22.12.0` |

The server listens on `$PORT` automatically.

## Run locally
```bash
npm install
npm run build
npm start            # http://localhost:3000
# dev mode with hot reload (in two terminals):
npm start            # API on :3000
npm run dev          # UI on :5173 (proxies /api → :3000)
```

## How it works
- `server.js` — zero-dependency Node server:
  - serves the built app (`dist/`)
  - `GET /api/proxy?url=` streams remote videos with Range support, so hosts without CORS headers (like GitHub Releases) work. Private/internal IPs are blocked.
  - `GET /api/audio?url=` uses ffmpeg (`ffmpeg-static`, optional) to extract a small 16 kHz MP3 so huge videos don't exhaust browser memory. If ffmpeg is missing, the browser decodes the audio itself.
  - `GET /api/health` returns `{ ok, ffmpeg }`.
- `src/` — React + TypeScript app (Vite). Analysis (audio energy/spikes, face tracking via MediaPipe, motion, scene cuts, scoring), captions, rendering and export all run in the browser.

## Subtitles & export (no keys needed)
- **Subtitles**: Whisper runs in your browser (transformers.js + ONNX wasm). Only the chosen clips get transcribed. The model downloads once and is then cached: Fast ≈ 40 MB, Accurate ≈ 76 MB (Settings → Subtitles). The server sends cross-origin-isolation headers so the model can run multi-threaded.
- **Export**: WebCodecs via mediabunny decodes → renders → encodes each clip faster than real time (MP4 H.264, or WebM VP9 if H.264 isn't available). If the browser can't do this, it falls back to real-time recording. You get one `.zip` with every clip plus optional `.srt` files.

## Optional keys (Settings page, stored in the browser)
- OpenAI-compatible API key: Whisper transcription of the whole video (instead of on-device), GPT titles/hooks re-ranking, AI scripts, TTS, image generation.
- Pexels key: stock footage in the editor.

# ClipForge

Turn a long video into 9:16 Shorts **in your phone's browser**. No server, no
upload — the video never leaves the device.

Paste a link to a long MP4 (or pick a file), and ClipForge analyses it, picks
the moments worth keeping, and writes out vertical clips with a title burned in,
the original sound, and a per-file check that the clip is actually watchable
before it is offered for download.

Built with Vite + React + TypeScript. Static output — any static host serves it.

---

## Build and run

```bash
npm install
npm run build      # tsc -b && vite build  ->  dist/
npm run dev        # local dev server on :5173
npm run preview    # serve the built dist/ on :4173
npm start          # serve the built dist/ on $PORT (or 4173) - no dependencies
```

## Deploying on Render

ClipForge is a **static site**: the build produces plain files in `dist/` and
all the video work happens in the visitor's browser. There are two ways to put
it on Render. **Option A is the one to use.**

### Option A — Static Site (recommended)

Create the service as **Static Site**, not Web Service.

| Setting | Value |
| --- | --- |
| Environment | **Static Site** |
| Build Command | `npm install --include=dev && npm run build` |
| Publish Directory | `dist` |

A Static Site never runs `npm start`, so there is no server process to keep
alive, and Render serves `dist/` from its CDN. This is the cheapest and fastest
option and the one the app was designed for.

### Option B — Web Service (also works now)

If the service was already created as a **Web Service**, Render runs
`npm start` after the build and expects a process listening on `$PORT`.
`npm start` is wired up for exactly that: it runs `scripts/serve-dist.mjs`, a
small dependency-free static server that reads `PORT` (falling back to 4173)
and serves `dist/`.

| Setting | Value |
| --- | --- |
| Environment | Web Service (Node) |
| Build Command | `tar -xzf clipforge.tar.gz && npm install --include=dev && npm run build` |
| Start Command | `npm start` |

If `npm start` ever reports *Nothing to serve: ... has no index.html*, it means
the build step did not run or did not produce `dist/`.

### Two things that make the deploy fail, and how to avoid them

1. **`npm error Missing script: "start"`** — the service is a Web Service but
   the project had no `start` script. Fixed: `npm start` now serves `dist/`.
   Or switch the service to a Static Site (Option A) and it never comes up.
2. **`node_modules` committed to the repo** — a repo carrying `node_modules`
   downloads as hundreds of MB, and a `node_modules` built on one OS can
   confuse `npm install` on another. `.gitignore` here excludes `node_modules/`
   and `dist/`. If they are already committed, remove them with
   `git rm -r --cached node_modules dist && git commit -m "drop build output"`.

Node >= 18 (tested on Node 20 and Node 24). Every file in the archive sits at
the top level, so a build command works as-is with no path tweaks — the
`tar -xzf` prefix is only needed when the archive itself is what is committed.

---

## Using it

1. **Home** — one box. Paste a video link or pick a file, then press
   **Make clips**.
2. ClipForge reads the video index, decodes the sound once into a loudness
   envelope, finds real pauses and the stretches with a person in frame, and
   proposes clips.
3. **Clips** — each clip shows its picture, title, length and score, with
   **Play** and **Download**. A **Face / Full-frame** switch changes the crop
   for that clip only.
4. **Download all** sits at the top. Clips download one at a time, in order,
   and each file is freed from memory once its download has started.
5. **Edit** (on a clip) hides the advanced controls: exact in/out, frame rate,
   crop, title text, bitrate.
6. Top bar: **Clips · History · Settings · More**. *More* holds AI Director,
   Streams and the Editor — every feature still works, it is just out of the
   way on a phone.

Design rules it follows: black and white only (honours
`prefers-color-scheme`), system font, no cards/gradients/glows, one column on
phones, big tap targets, nothing wider than the screen.

---

## What changed in this rebuild

### 1. Exports no longer freeze at ~11 seconds

**Cause.** The old export recorded a `<canvas>` with `MediaRecorder`. That runs
at wall-clock speed, so anything that interrupts the picture — a seek that
stalls, the tab being throttled, the page hidden — makes the recorder keep
writing the *same* frame. The file ends up the right length with a frozen
picture, and nothing ever looked at the finished file to notice.

**Fix.** A finished clip is now read back and checked on its own before it is
offered (`src/lib/verify.ts`):

- length against the requested length;
- the picture is sampled window by window across the **whole** clip and the
  grey thumbnails compared, so a freeze at second 20 of a 28 s clip is caught,
  not just a freeze at the start;
- every decoded frame is counted (`framesDecoded`, `framesWritten`,
  `framesExpected`) and the count has to match;
- the video track and the audio track have to be the same length (±0.6 s);
- the sound is actually measured, not assumed;
- longest stretch with no picture change must stay under a limit.

If a clip fails, it is **rebuilt silently with the other engine** and checked
again. A broken clip is never shipped, and a clip that cannot be fixed gets a
plain-word message next to it instead of a spinner.

### 2. Exports are fast now (faster than real time)

**Cause.** The whole source was read into memory as one blob and parsed in full
before anything started. On a 20-minute file that is a large allocation and
minutes of waiting before the first frame appears.

**Fix.** `src/lib/mp4demux.ts` now streams the file in 1 MB chunks with
backpressure (`SourceReader`), stops as soon as the clip's last frame has been
delivered (`stopAtSeconds`), and never holds the file in memory. Reading the
index alone costs tens of milliseconds, and parsing without extraction is
nearly free.

Measured on a 180 s / 33 MB 720p source: a 5 s clip exports in **3.6 s**, a
28 s clip in **10.8 s** — about 2.6× real time.

### 3. The MP4 is written by a real muxer

**Cause.** `mp4box.js`'s writer cannot produce a playable progressive MP4: its
`addSample()` always emits a one-sample `moof`+`mdat` pair and leaves the
sample tables empty. ffmpeg refuses such a file outright
(`could not find corresponding trex`).

**Fix.** `src/lib/mp4mux.ts` — a small hand-written muxer that writes
`ftyp` + `mdat` + `moov` with correct `stts` / `stsc` / `stsz` / `stco` /
`stss`, real `mvhd` / `tkhd` / `mdhd` durations, chunks interleaved about every
0.5 s so the file plays while it downloads, the encoder's **own** `avcC` (not
the source's — the source's SPS describes the landscape picture and makes
players report the wrong size), and an `esds` built from the real sample rate
and channel count.

mp4box is still used, but only for what it is excellent at: demuxing.

### 4. The sound is copied, never re-encoded

**Cause.** The real-time engine took its audio from a live
`createMediaElementSource` graph. That is silent in several real situations — no
audio device, an `AudioContext` that never resumes without a tap, a `<video>`
being seeked rather than played — so the clip came out with a 5.1 s silent
audio track. Chrome also has **no AAC `AudioEncoder`** at all, and
`MediaRecorder` cannot write `mp4 + aac`.

**Fix.** `src/lib/remux-audio.ts` copies the source's own AAC frames for
exactly the clip's time range and re-packages them into the finished MP4. No
decode, no re-encode, so the sound cannot drift or be lost, and it works in
browsers with no AAC encoder. If the re-package cannot be done, the original
recording is returned untouched and the verifier flags the silence rather than
letting it through.

### 5. Frame timing is exact

**Cause.** The source has B-frames, so the decoder returns pictures in
presentation order — a *different* order from the one they went in. The old
code popped timestamps off a FIFO of input times, mislabelling frames. The
result: pairs of frames 5 ms apart with 100 ms gaps, an average frame rate of
19.85 fps, and visible judder even though every picture was correct.

**Fix.** Take the timestamp from the `VideoFrame` itself. Output is now exactly
30 fps with uniform 0.033333 s deltas.

### 6. Real-time capture records every picture it draws

`canvas.captureStream(fps)` samples the canvas on Chrome's own clock, which on
a busy phone (or in a headless test) lands at about half the intended rate —
150 pictures drawn, 78 recorded. Now `captureStream(0)` is used with
`requestFrame()` after each draw, and the recorded timestamps are put on an
exact 1/fps grid, which also removes the duplicate-DTS warnings ffmpeg gives.

### 7. A phone can no longer sit at "Loaded ..." forever

Found on a real handset (Opera on Android): a run would show *Loaded <file>*
with an empty progress bar and never move, and History just said `0/0 clips`
with no reason. Three separate holes, all closed:

- **The sound decode could hang.** Analysis decoded the source on a live
  `AudioContext`. On a phone, a context created outside a tap starts
  *suspended*, and a suspended context's `decodeAudioData` has been seen to
  never answer on Android browsers. Analysis now decodes on an
  `OfflineAudioContext` (never suspended - and the right tool anyway), with a
  60 s cap: a stall becomes an answer, not a hang. A device that cannot decode
  sound at all is reported as "could not measure", which skips the sound check
  with a note instead of condemning good clips as silent.
- **No stage had a budget.** The whole analysis now runs under a watchdog
  (150-600 s depending on source length). Running out produces a plain
  sentence - "The analysis stopped answering after Ns..." - instead of a
  spinner that outlives the user's patience.
- **Nothing said where it was stuck.** Stage text ("Listening for pauses",
  "Scanning the video", "Checking clip 2 of 6") now shows next to the progress
  bar, and a failed run stores its reason, so History says why instead of
  just `0/0 clips`.

### 8. Nothing crashes, nothing is wasted

- Wake Lock held for the whole analyse/export run, released after.
- Clean pause/resume on tab pause: recording stops, the hidden time is
  measured, and it resumes — a frozen picture is never recorded.
- One clip at a time, low memory: no giant ZIP, files freed once downloaded.
- A finished clip is never re-exported; its state lives in IndexedDB.
- A failed clip does not stop the others.
- Plain-word errors next to the affected clip.

---

### 9. Stop is safe, and the page counts out loud

- **Pressing Stop never wastes finished work.** Clips that are already done
  stay `done`: playable, downloadable, kept in IndexedDB, listed by
  **Download all**, and still there after a reload or from History. Clips that
  were mid-render go back to "not made yet" instead of being marked as
  failures, so they can be made later. The page says plainly
  *"Stopped — 2 clips ready to play and download"*, and History records
  *"Stopped by you - the finished clips stay playable and downloadable."*
  (`tests/stopcheck.mjs` proves all of it through the real UI, including an
  ffmpeg check of a file downloaded after a stop.)
- **The bar moves and counts.** One sentence drives the whole run:
  *Listening for pauses -> Scanning the video -> Making 4 clips ->
  Rendering clip 2 of 4 - 43% -> Clip 3 of 4 done - 3 good so far ->
  Finished - 4/4 clips good.* The bar only ever moves forward, on the results
  screen as well as the home screen, and the Stop button sits next to it
  wherever you are watching.
- **Clip picking lives on the main page**, right above *Make clips*:
  **Auto** (every moment that works as a Short), **High-rated only**
  (score 80+), or **Exact number** (the N best clips, 1-6). The choice is
  stored with your settings. Picking never leaves you empty: if nothing
  qualifies, the single best clip is kept and the log says so.

## How it was tested

Real Google Chrome 154 (not the headless shell) with Pixel 7 emulation
(412×915, DSF 2, Android 13 UA), and a real H.264/AAC MP4 fetched over HTTP
from a **separate origin** so the cross-origin path is exercised.

### Test source

`scripts/make-test-source.mjs` builds a deliberately awkward 180 s file:
720p30 H.264 High + 48 kHz stereo AAC, `moov` at the front (faststart), 45 real
pauses, a face on screen from 36–81 s, motion throughout.

```bash
npm run test:source     # writes a 180s source you can point the app at
npm run build && npm run preview
node scripts/serve.mjs  # serves the test media on :8099 with permissive CORS
npm test                # full end-to-end harness -> tests/results.json
```

### Per-engine probe

`tests/probe-run.mjs` drives one engine over one time range in the browser,
pulls the finished bytes out of the page, and checks them with ffmpeg
independently of the app's own verifier:

```bash
node tests/probe-run.mjs --engine=fast     --start=40 --end=45
node tests/probe-run.mjs --engine=fast     --start=40 --end=68
node tests/probe-run.mjs --engine=realtime --start=40 --end=45
```

### Results

Fast engine (WebCodecs + mp4box demux + own muxer), 40 s → 68 s (28 s clip):

| Check | Result |
| --- | --- |
| Export time | **10.8 s** for a 28 s clip (2.6× real time) |
| Container | `h264 720x1280` + `aac 48000 Hz 2ch` |
| Frames | **841** written, 840 expected |
| Frame rate | `avg_frame_rate = 30/1`, every delta exactly 0.033333 s, monotonic |
| Length | 28.117 s (video 28.033 s, audio 28.117 s — within 0.1 s) |
| Frames in the last 1 s | **173** decoded (the clip is alive at the end) |
| Freezes ≥ 1.0 s | **0** |
| Motion across the clip | present through **98.4 %** of the length |
| Audio level | mean −28.0 dB, peak **−19.7 dB** |
| Full ffmpeg decode | clean, no errors |
| App's own verifier | `ok: true`, no messages |

Real-time engine (MediaRecorder + source-audio re-package), 40 s → 45 s:

| Check | Result |
| --- | --- |
| Container | `h264 720x1280` + `aac 48000 Hz 2ch` |
| Frames | **150** written, 150 expected |
| Frame rate | `avg_frame_rate = 30/1`, all 149 deltas exactly 0.03333 s |
| Length | 5.12 s (video 5.000 s, audio 5.120 s) |
| Frames in the last 1 s | **26** decoded |
| Freezes ≥ 1.0 s | **0** |
| Audio level | mean −27.6 dB, peak **−19.7 dB** |
| Full ffmpeg decode | clean, no errors |
| App's own verifier | `ok: true`, no messages |

### Browser capabilities this build was designed around

Measured in the target Chrome (`tests/capcheck*.mjs`), and the reason the
architecture looks the way it does:

| Capability | Available |
| --- | --- |
| WebCodecs `VideoEncoder` (all `avc1` profiles) | yes |
| WebCodecs H.264 `VideoDecoder` | yes |
| WebCodecs `AudioEncoder` AAC | **no** (any rate/channels) |
| `MediaRecorder` `video/mp4` with `avc1` (video only) | yes |
| `MediaRecorder` `video/mp4` with `avc1 + mp4a` | **no** |
| `FaceDetector` | **no** |
| Wake Lock, `requestVideoFrameCallback` | yes |

Hence: audio is always **copied** from the source, never encoded, and face
framing uses canvas-based detection with a manual override rather than
`FaceDetector`.

### Full app run - the thing that answers "does it actually work?"

`npm test` drives the real UI in that Chrome: paste the link, press
**Make clips**, let it analyse, export **all** clips, let each one download by
itself, then check every downloaded file with ffmpeg. Then the whole thing
again with real-time mode forced on. Latest run:

- **165 checks, 0 failures.**
- **12 finished clips** (6 per mode), each checked 12 ways by ffmpeg:
  not empty, readable, `h264 720x1280`, vertical 9:16, full length
  (28.1 s where ~27-28 s were asked for), audio present (`aac 48000 Hz 2ch`),
  video and audio the same length (within 0.13 s), frames decoded in the
  last second (23-27), frame count vs expected (838-841 of ~843),
  **no freeze over 1.5 s anywhere**, picture still changing in the last
  2.5 s (17-18 of 18-19 frames different), audio audible (mean -28 dB,
  peak -19.7 dB).
- Every clip row in the UI shows its own check line - e.g.
  *"Checked: 28.1s long, picture moves to 99%, sound present"* - so the
  user sees the verification, not just the file.
- Pages at 412 px wide: no horizontal scroll on any page, More menu holds
  AI Director / Streams / Editor, no bottom bar. Light and dark themes are
  strictly black/white/grey with no gradients and no glows, system font.

Two honest limits of that run: it used Pixel 7 *emulation* (real Chrome,
phone size and user agent) rather than a physical handset, and the clip
thumbnails come out grey in a headless screenshot because there is no GPU to
paint the canvas - on a real phone they draw from the video normally. The
finished files themselves were checked with ffmpeg, so what matters is
verified either way.

### Pages

`tests/e2e.mjs --only=pages` screenshots every page at phone size and asserts
no horizontal overflow and no overlapping bars. Screenshots land in
`tests/screenshots/`.

---

## Layout

```
index.html            entry
vite.config.ts        static build, base './' so any path works
package.json          scripts: dev / build / preview / start / test
.gitignore            keeps node_modules and dist out of the repo
src/
  App.tsx             routing + top bar
  store.ts            app state, IndexedDB persistence
  styles.css          black & white, system font, one column
  pages/              Clips, History, Settings, Director, Streams, Editor
  components/         ClipRow, TopBar
  lib/
    source.ts         streaming fetch (never res.blob() — it rejects for
                      large cross-origin bodies in this Chrome)
    mp4demux.ts       SourceReader: chunked streaming demux + sample tables
    mp4mux.ts         the progressive MP4 writer
    export-webcodecs.ts   Engine A: decode -> canvas -> encode, faster than real time
    export-realtime.ts    Engine B: captureStream + MediaRecorder, wall clock
    remux-audio.ts    copy the source AAC into a finished recording
    export.ts         engine choice, cross-engine rebuild, sequencing
    verify.ts         post-export read-back checks
    analyze.ts        pause/scene/motion analysis, crop rects
    audio.ts          loudness envelope, pause finding
    faces.ts          canvas-based face framing
    frames.ts         grey thumbnails + diff, used by the freeze check
    title.ts          titles and hooks
    thumb.ts          clip pictures
    download.ts       one at a time, freed after each
    wake.ts           Wake Lock
    db.ts             IndexedDB: clips, history, never re-export finished work
scripts/
  serve-dist.mjs      the `npm start` static server (reads $PORT, no deps)
  make-test-source.mjs    builds the 180 s test source with ffmpeg
  serve.mjs               serves dist/ and the test media with permissive CORS
tests/
  e2e.mjs             full harness: analyse -> export all -> ffmpeg every file,
                      then the same in forced real-time mode, then page shots
  probe.html/probe.tsx    in-browser single-engine probe
  probe-run.mjs       drives the probe and checks the bytes with ffmpeg
  capcheck*.mjs       browser capability measurement
  mp4bench*.mjs       demux speed benches
```

## Known limits

- The source must be MP4/MOV with H.264 video for the fast engine; AAC audio
  for copied sound. Anything else falls back to the real-time engine, and a
  source with no copyable audio produces a silent clip that the verifier says
  so plainly.
- A link must allow cross-origin reads (CORS). A file picked from the device
  always works.
- The real-time engine takes as long as the clip, by definition.

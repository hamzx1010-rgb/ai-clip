# ClipForge

Turn a long video into 9:16 Shorts **in your phone's browser**. No server, no
upload — the video never leaves the device.

Paste a link to a long MP4 (or pick a file), and ClipForge analyses it, picks
the moments worth keeping, and writes out vertical clips with a title burned in,
the original sound, and a per-file check that the clip is actually watchable
before it is offered for download.

Built with Vite + React + TypeScript. Static output — any static host serves it.

---

## Build and run

```bash
npm install
npm run build      # tsc -b && vite build  ->  dist/
npm run dev        # local dev server on :5173
npm run preview    # serve the built dist/ on :4173
```

### Deploying on Render

| Setting | Value |
| --- | --- |
| Environment | **Static Site** |
| Build Command | `npm install && npm run build` |
| Publish Directory | `dist` |

Node >= 18. Every file in this archive sits at the top level, so the build
command above works as-is with no path tweaks.

---

## Using it

1. **Home** — one box. Paste a video link or pick a file, then press
   **Make clips**.
2. ClipForge reads the video index, decodes the sound once into a loudness
   envelope, finds real pauses and the stretches with a person in frame, and
   proposes clips.
3. **Clips** — each clip shows its picture, title, length and score, with
   **Play** and **Download**. A **Face / Full-frame** switch changes the crop
   for that clip only.
4. **Download all** sits at the top. Clips download one at a time, in order,
   and each file is freed from memory once its download has started.
5. **Edit** (on a clip) hides the advanced controls: exact in/out, frame rate,
   crop, title text, bitrate.
6. Top bar: **Clips · History · Settings · More**. *More* holds AI Director,
   Streams and the Editor — every feature still works, it is just out of the
   way on a phone.

Design rules it follows: black and white only (honours
`prefers-color-scheme`), system font, no cards/gradients/glows, one column on
phones, big tap targets, nothing wider than the screen.

---

## What changed in this rebuild

### 1. Exports no longer freeze at ~11 seconds

**Cause.** The old export recorded a `<canvas>` with `MediaRecorder`. That runs
at wall-clock speed, so anything that interrupts the picture — a seek that
stalls, the tab being throttled, the page hidden — makes the recorder keep
writing the *same* frame. The file ends up the right length with a frozen
picture, and nothing ever looked at the finished file to notice.

**Fix.** A finished clip is now read back and checked on its own before it is
offered (`src/lib/verify.ts`):

- length against the requested length;
- the picture is sampled window by window across the **whole** clip and the
  grey thumbnails compared, so a freeze at second 20 of a 28 s clip is caught,
  not just a freeze at the start;
- every decoded frame is counted (`framesDecoded`, `framesWritten`,
  `framesExpected`) and the count has to match;
- the video track and the audio track have to be the same length (±0.6 s);
- the sound is actually measured, not assumed;
- longest stretch with no picture change must stay under a limit.

If a clip fails, it is **rebuilt silently with the other engine** and checked
again. A broken clip is never shipped, and a clip that cannot be fixed gets a
plain-word message next to it instead of a spinner.

### 2. Exports are fast now (faster than real time)

**Cause.** The whole source was read into memory as one blob and parsed in full
before anything started. On a 20-minute file that is a large allocation and
minutes of waiting before the first frame appears.

**Fix.** `src/lib/mp4demux.ts` now streams the file in 1 MB chunks with
backpressure (`SourceReader`), stops as soon as the clip's last frame has been
delivered (`stopAtSeconds`), and never holds the file in memory. Reading the
index alone costs tens of milliseconds, and parsing without extraction is
nearly free.

Measured on a 180 s / 33 MB 720p source: a 5 s clip exports in **3.6 s**, a
28 s clip in **10.8 s** — about 2.6× real time.

### 3. The MP4 is written by a real muxer

**Cause.** `mp4box.js`'s writer cannot produce a playable progressive MP4: its
`addSample()` always emits a one-sample `moof`+`mdat` pair and leaves the
sample tables empty. ffmpeg refuses such a file outright
(`could not find corresponding trex`).

**Fix.** `src/lib/mp4mux.ts` — a small hand-written muxer that writes
`ftyp` + `mdat` + `moov` with correct `stts` / `stsc` / `stsz` / `stco` /
`stss`, real `mvhd` / `tkhd` / `mdhd` durations, chunks interleaved about every
0.5 s so the file plays while it downloads, the encoder's **own** `avcC` (not
the source's — the source's SPS describes the landscape picture and makes
players report the wrong size), and an `esds` built from the real sample rate
and channel count.

mp4box is still used, but only for what it is excellent at: demuxing.

### 4. The sound is copied, never re-encoded

**Cause.** The real-time engine took its audio from a live
`createMediaElementSource` graph. That is silent in several real situations — no
audio device, an `AudioContext` that never resumes without a tap, a `<video>`
being seeked rather than played — so the clip came out with a 5.1 s silent
audio track. Chrome also has **no AAC `AudioEncoder`** at all, and
`MediaRecorder` cannot write `mp4 + aac`.

**Fix.** `src/lib/remux-audio.ts` copies the source's own AAC frames for
exactly the clip's time range and re-packages them into the finished MP4. No
decode, no re-encode, so the sound cannot drift or be lost, and it works in
browsers with no AAC encoder. If the re-package cannot be done, the original
recording is returned untouched and the verifier flags the silence rather than
letting it through.

### 5. Frame timing is exact

**Cause.** The source has B-frames, so the decoder returns pictures in
presentation order — a *different* order from the one they went in. The old
code popped timestamps off a FIFO of input times, mislabelling frames. The
result: pairs of frames 5 ms apart with 100 ms gaps, an average frame rate of
19.85 fps, and visible judder even though every picture was correct.

**Fix.** Take the timestamp from the `VideoFrame` itself. Output is now exactly
30 fps with uniform 0.033333 s deltas.

### 6. Real-time capture records every picture it draws

`canvas.captureStream(fps)` samples the canvas on Chrome's own clock, which on
a busy phone (or in a headless test) lands at about half the intended rate —
150 pictures drawn, 78 recorded. Now `captureStream(0)` is used with
`requestFrame()` after each draw, and the recorded timestamps are put on an
exact 1/fps grid, which also removes the duplicate-DTS warnings ffmpeg gives.

### 7. Nothing crashes, nothing is wasted

- Wake Lock held for the whole analyse/export run, released after.
- Clean pause/resume on tab pause: recording stops, the hidden time is
  measured, and it resumes — a frozen picture is never recorded.
- One clip at a time, low memory: no giant ZIP, files freed once downloaded.
- A finished clip is never re-exported; its state lives in IndexedDB.
- A failed clip does not stop the others.
- Plain-word errors next to the affected clip.

---

## How it was tested

Real Google Chrome 154 (not the headless shell) with Pixel 7 emulation
(412×915, DSF 2, Android 13 UA), and a real H.264/AAC MP4 fetched over HTTP
from a **separate origin** so the cross-origin path is exercised.

### Test source

`scripts/make-test-source.mjs` builds a deliberately awkward 180 s file:
720p30 H.264 High + 48 kHz stereo AAC, `moov` at the front (faststart), 45 real
pauses, a face on screen from 36–81 s, motion throughout.

```bash
npm run test:source     # writes a 180s source you can point the app at
npm run build && npm run preview
node scripts/serve.mjs  # serves the test media on :8099 with permissive CORS
npm test                # full end-to-end harness -> tests/results.json
```

### Per-engine probe

`tests/probe-run.mjs` drives one engine over one time range in the browser,
pulls the finished bytes out of the page, and checks them with ffmpeg
independently of the app's own verifier:

```bash
node tests/probe-run.mjs --engine=fast     --start=40 --end=45
node tests/probe-run.mjs --engine=fast     --start=40 --end=68
node tests/probe-run.mjs --engine=realtime --start=40 --end=45
```

### Results

Fast engine (WebCodecs + mp4box demux + own muxer), 40 s → 68 s (28 s clip):

| Check | Result |
| --- | --- |
| Export time | **10.8 s** for a 28 s clip (2.6× real time) |
| Container | `h264 720x1280` + `aac 48000 Hz 2ch` |
| Frames | **841** written, 840 expected |
| Frame rate | `avg_frame_rate = 30/1`, every delta exactly 0.033333 s, monotonic |
| Length | 28.117 s (video 28.033 s, audio 28.117 s — within 0.1 s) |
| Frames in the last 1 s | **173** decoded (the clip is alive at the end) |
| Freezes ≥ 1.0 s | **0** |
| Motion across the clip | present through **98.4 %** of the length |
| Audio level | mean −28.0 dB, peak **−19.7 dB** |
| Full ffmpeg decode | clean, no errors |
| App's own verifier | `ok: true`, no messages |

Real-time engine (MediaRecorder + source-audio re-package), 40 s → 45 s:

| Check | Result |
| --- | --- |
| Container | `h264 720x1280` + `aac 48000 Hz 2ch` |
| Frames | **150** written, 150 expected |
| Frame rate | `avg_frame_rate = 30/1`, all 149 deltas exactly 0.03333 s |
| Length | 5.12 s (video 5.000 s, audio 5.120 s) |
| Frames in the last 1 s | **26** decoded |
| Freezes ≥ 1.0 s | **0** |
| Audio level | mean −27.6 dB, peak **−19.7 dB** |
| Full ffmpeg decode | clean, no errors |
| App's own verifier | `ok: true`, no messages |

### Browser capabilities this build was designed around

Measured in the target Chrome (`tests/capcheck*.mjs`), and the reason the
architecture looks the way it does:

| Capability | Available |
| --- | --- |
| WebCodecs `VideoEncoder` (all `avc1` profiles) | yes |
| WebCodecs H.264 `VideoDecoder` | yes |
| WebCodecs `AudioEncoder` AAC | **no** (any rate/channels) |
| `MediaRecorder` `video/mp4` with `avc1` (video only) | yes |
| `MediaRecorder` `video/mp4` with `avc1 + mp4a` | **no** |
| `FaceDetector` | **no** |
| Wake Lock, `requestVideoFrameCallback` | yes |

Hence: audio is always **copied** from the source, never encoded, and face
framing uses canvas-based detection with a manual override rather than
`FaceDetector`.

### Pages

`tests/e2e.mjs --only=pages` screenshots every page at phone size and asserts
no horizontal overflow and no overlapping bars. Screenshots land in
`tests/screenshots/`.

---

## Layout

```
index.html            entry
vite.config.ts        static build, base './' so any path works
package.json
src/
  App.tsx             routing + top bar
  store.ts            app state, IndexedDB persistence
  styles.css          black & white, system font, one column
  pages/              Clips, History, Settings, Director, Streams, Editor
  components/         ClipRow, TopBar
  lib/
    source.ts         streaming fetch (never res.blob() — it rejects for
                      large cross-origin bodies in this Chrome)
    mp4demux.ts       SourceReader: chunked streaming demux + sample tables
    mp4mux.ts         the progressive MP4 writer
    export-webcodecs.ts   Engine A: decode -> canvas -> encode, faster than real time
    export-realtime.ts    Engine B: captureStream + MediaRecorder, wall clock
    remux-audio.ts    copy the source AAC into a finished recording
    export.ts         engine choice, cross-engine rebuild, sequencing
    verify.ts         post-export read-back checks
    analyze.ts        pause/scene/motion analysis, crop rects
    audio.ts          loudness envelope, pause finding
    faces.ts          canvas-based face framing
    frames.ts         grey thumbnails + diff, used by the freeze check
    title.ts          titles and hooks
    thumb.ts          clip pictures
    download.ts       one at a time, freed after each
    wake.ts           Wake Lock
    db.ts             IndexedDB: clips, history, never re-export finished work
scripts/
  make-test-source.mjs    builds the 180 s test source with ffmpeg
  serve.mjs               serves dist/ and the test media with permissive CORS
tests/
  e2e.mjs             full harness: analyse -> export all -> ffmpeg every file,
                      then the same in forced real-time mode, then page shots
  probe.html/probe.tsx    in-browser single-engine probe
  probe-run.mjs       drives the probe and checks the bytes with ffmpeg
  capcheck*.mjs       browser capability measurement
  mp4bench*.mjs       demux speed benches
```

## Known limits

- The source must be MP4/MOV with H.264 video for the fast engine; AAC audio
  for copied sound. Anything else falls back to the real-time engine, and a
  source with no copyable audio produces a silent clip that the verifier says
  so plainly.
- A link must allow cross-origin reads (CORS). A file picked from the device
  always works.
- The real-time engine takes as long as the clip, by definition.

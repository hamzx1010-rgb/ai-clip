# ClipForge — AI shorts clipper & AI documentary maker

Two tools, both **9:16 only** (Shorts / TikTok / Reels):

1. **Clipper**: paste a video link. ClipForge downloads it, finds the most viral moments, scores them 0–100, reframes each one to 9:16 and adds animated captions (free on-device Whisper, no API key). It exports everything as one zip, faster than real time. Gameplay and wide shots use a blurred-background layout, so the whole frame stays visible. Talking heads get face tracking. There's no shake, no zooms, no sound effects and no watermark.
2. **AI Director**: describe a video (and optionally give a reference). The AI researches it, writes and narrates the script, finds real archival footage and photos, cuts it together with captions, chapter titles and music, and gives you a finished, fully editable 9:16 documentary. Length can be 1–30 minutes, or Auto.

## Use it
**Clip a video:** paste a **direct video link** (e.g. `https://github.com/<user>/<repo>/releases/download/<tag>/video.mp4`) on the home page and click **Clip it**. Deep links work too: `https://<your-app>.onrender.com/?url=<direct video link>`. Supported links: GitHub release assets, Dropbox (`?dl=1`), public Google Drive files, S3/R2/CDN URLs. YouTube/TikTok page URLs aren't video files and get a clear error message.

**Home, tabs & history:** the app opens on the **Dashboard**. **Clip a Video**, **Clip a Stream**, **AI Director** and **Editor** each open in their own browser tab (↗ in the sidebar), so you can keep working elsewhere while a job runs. You can turn this off in Settings → Appearance. Switching pages never loses work in progress: pages stay alive in the background, a spinner in the sidebar shows what's still running, the Back button moves between pages, and the browser warns you before you close a tab mid-job.
Every clip job is saved in your browser (clips + analysis + the source video) under **Dashboard → Clip history**. Reopen, re-edit and re-export any time, even after closing the browser. Delete entries there. Settings → Storage → auto-delete removes only old *source videos*; the clip list stays.

**Make a documentary:** open **AI Director** and type the idea, for example *"The rise and fall of the 2b2t Minecraft server — dark, mysterious tone"*. Optional inputs:
- **Reference**: links to articles (used as sources) and/or a reference video (direct link or upload). ClipForge copies the reference's editing pace and narration speed, not its footage.
- **Interviews**: upload your own interview recordings. They're transcribed and the best soundbites go into the matching chapters, with name titles. ClipForge never fabricates interviews. Without any, it uses real quotes from Wikiquote, shown on screen and read by a second voice.
- **Mode**: **⚡ Fast** (default) or **🔬 Deep**, see below.
- **Length** (Auto, 1–30 min), **narrator voice** (free on-device English voices), captions, music, slow photo pans, and AI illustrations (only used when no real footage exists; labelled in the credits).

When it's done, click **Open in editor & export**. Every cut, caption and title can be changed. You also get a ready-to-paste description with chapters and a `sources.txt` with all credits and licences.

**Fast vs Deep (AI Director):**
| | ⚡ Fast | 🔬 Deep |
|---|---|---|
| Research | up to 2 articles, fetched in parallel | up to 4 articles |
| Script | fewer, longer chapters; with your own key, 3 chapters are written at once; time limits so a busy free AI can't stall it (it falls back to writing from the sources) | more, shorter chapters, written one by one so each follows on from the last |
| Footage | 5 beats searched at once; about half as many video clips (≤15) | 4 at once; up to 40 video clips |
| Reference video | editing pace only | editing pace + narration speed (downloads a small speech model) |

In both modes the narration is recorded **while** footage is being found, not after it. On devices with enough cores and memory (6+ cores/4 GB+), 2–3 voices record different sentences at the same time.

**Export: Fast vs Best quality** (in the Export window):
- **⚡ Fast** (default): 720p, 24 fps. About 2× quicker than before and plenty for phones.
- **💎 Best quality**: your chosen resolution (up to 4K) at 30 fps. Still about 1.7× quicker than before, thanks to a faster drawing path and audio encoding in parallel with video.

How it works:
| Step | What happens | Where |
|---|---|---|
| Research | Wikipedia articles, your links, Wikiquote | browser + `/api/page` |
| Script | AI writes chapters from the research (facts only). If no AI is available, the narration is built from the sources directly | free AI via `/api/ai`, or your key |
| Footage | Wikimedia Commons video & photos, NASA, Openverse, Pexels (with key) | browser |
| Voice | Kokoro-82M neural TTS, runs on your device (≈92 MB, downloaded once) | browser |
| Edit | Timeline built in the ClipForge editor, 1080×1920 | browser |
| Export | WebCodecs, faster than real time, streamed to disk-backed memory (fine for 30 min) | browser |

Tips:
- **Free Gemini or Groq key (recommended):** the keyless AI is a free community service and is often busy. In **Settings → AI providers**, tap the *Google Gemini* or *Groq* preset and paste a free key from aistudio.google.com or console.groq.com. Scripts get much better and more reliable.
- **Narration speed:** narration is recorded on your device. A computer takes roughly the video's length or less; a phone takes longer. Keep the tab open while it runs.
- **Export size:** for long videos, 720p is plenty on phones and half the file size.

## On your Android phone

- Open your Render URL in Chrome, then tap **Install app** on Home (or ⋮ → *Add to Home screen*). ClipForge then opens full-screen like a normal app.
- Navigation is the bottom bar (Home · Clip · Stream · Director · Settings). On phones, tools switch **in place** instead of opening new tabs, because Android freezes background tabs. Every page stays alive, so switching never loses your work.
- While clips, a documentary or an export are being made, the screen is kept on so Android doesn't sleep and kill the job. Keep ClipForge in front until it finishes.
- The Editor works by touch: preview on top, the timeline at the bottom, and the tool bar opens Media/Text/… as sheets. **Edit** opens the properties of the selected item. You can drag clips on the timeline with your finger.

## How clips are cut (based on how YouTube Shorts ranks videos)

YouTube ranks Shorts mainly by **how many viewers choose to watch instead of swiping away** (decided in about 1–1.5 s), **average % viewed**, and **replays** (every loop counts as a view). The engine is built around those three signals:

- **Two passes:** it shortlists moments from the audio, transcribes just those parts on your device, then re-picks and re-cuts every clip on actual sentences.
- **Clean cut points:** a clip may only start where a sentence begins and end where one ends. The cut itself goes **inside the real silent gap between words**, found on the waveform at 10 ms resolution, because Whisper's word times are often 0.2–0.4 s off. The voice comes in ~0.1 s after the clip starts and the clip ends on a short breath after the last word. It never clips a syllable or runs into the next speaker. Spots with no real pause are never used as cut points. Each piece gets a tiny 12 ms fade so splices don't click.
- **Hook first:** a clip starts on the first real word, with lead-in "so / and / um / but" trimmed and no silence before it. Openers that stop the scroll (a question, a bold claim, a number, "why / how / nobody / the truth…") score higher. Greetings ("welcome back", "hey guys"), filler, and lines that need earlier context ("he said…", "that's why…") are penalised.
- **Ends on the payoff:** the cut comes right after the punchline or reveal, plus a breath (a laugh gets up to 1.2 s). There is no trailing tail, so more people finish the clip.
- **Loops:** short punchy last lines, and endings that echo the opening, score higher because they replay seamlessly.
- **No dead stretches:** long low-energy runs are penalised. On export, pauses longer than ~0.7 s are shortened (only where the audio is really silent), and um/uh are removed only when there's a pause on both sides, so no word gets chopped.
- **Length:** the sweet spot is ~18–42 s. Longer clips only win when they keep holding attention.
- **Cold open (optional, off by default):** you can turn on the "teaser" to show the clip's best line first, then "How it started…".
- **Hook text** (first 3 s on screen) is written from what is actually said: a real question from the clip, or an open loop cut before the payoff ("The biggest mistake I made was…"). If AI polish is on, the free AI rewrites the hook and title under the same rules, with no fake "you won't believe" bait. If the AI is down, the built-in hooks are used.
- No zooms, shakes or sound effects: the pace comes only from cuts and captions.

## Deploy on Render
**Option A — Blueprint:** push this folder to GitHub → Render → **New + → Blueprint** → select the repo. `render.yaml` configures everything.

**Option B — manual Web Service:**
| Setting | Value |
|---|---|
| Runtime | Node |
| Build Command | `tar -xzf clipforge.tar.gz && npm install --include=dev && npm run build` |
| Start Command | `npm start` |
| Health Check Path | `/api/health` |
| Env var | `NODE_VERSION` = `22.12.0` |

The server listens on `$PORT` automatically. (If you pushed the unpacked source instead of `clipforge.tar.gz`, drop the `tar -xzf clipforge.tar.gz &&` part.)

## Run locally
```bash
npm install
npm run build
npm start            # http://localhost:3000
# dev mode with hot reload (in two terminals):
npm start            # API on :3000
npm run dev          # UI on :5173 (proxies /api → :3000)
```

## How it works
- `server.js` — zero-dependency Node server:
  - serves the built app (`dist/`)
  - `GET /api/proxy?url=` streams remote videos with Range support, so hosts without CORS headers (like GitHub Releases) work. Private/internal IPs are blocked.
  - `GET /api/audio?url=` uses ffmpeg (`ffmpeg-static`, optional) to extract a small 16 kHz MP3 so huge videos don't exhaust browser memory. If ffmpeg is missing, the browser decodes the audio itself.
  - `GET /api/page?url=` fetches article text/JSON (≤3 MB) for AI Director research.
  - `POST /api/ai` relays AI Director prompts to the free keyless text model (one request at a time, as the free tier requires).
  - `GET /api/health` returns `{ ok, ffmpeg }`.
- `src/` — React + TypeScript app (Vite). Analysis (audio energy/spikes, face tracking via MediaPipe, motion, scene cuts, scoring), captions, rendering and export all run in the browser.

## Watching & downloading clips
- **▶ Play:** tap ▶ on any clip, or **Play & download** under the preview. The finished clip opens in a popup in your **browser's own video player** (full screen, seeking, and on most phones its own ⋮ → Download), with:
  - **Download**
  - **Share / Save** (Android share sheet: save to your gallery, or send to TikTok/YouTube)
  - **Open in browser player**
- **Export clips → "Each clip when ready" (default):** every clip downloads **the moment it's finished**, so you don't wait for the whole batch. If the browser asks "Allow multiple downloads?", tap Allow. You can still pick "One ZIP at the end".
  - Anything you already played in the popup is reused instantly.
  - When it's done, the window lists every file with its own ⬇ button, in case one got blocked.
- **No more broken files:** every exported file is read back and checked (length, picture at start, middle and end, and sound). If a phone encoder produced a bad file, it's re-made automatically with another setup. Download links now stay valid for 10 minutes. They used to expire after 10 s, which broke downloads on Android when the browser asked "Download?" first.
- **Never 0:00 in the phone gallery:** every clip's MP4 header is checked for its length. Browser recordings used by real-time mode are "streamed" files with length 0, so galleries showed 0:00. Those are now rewritten into a normal MP4: on the phone first, or by the server's ffmpeg (`POST /api/remux`) if that fails. Fast-mode files use a standard 57600 time unit. Clips made in real-time mode get a "real-time" tag in the export list.
- **Sound decoding:** the soundtrack is now decoded piece by piece (WebCodecs), so long videos no longer fail on phones. It falls back to the one-shot decoder, and then to server extraction for linked videos.

## Subtitles & export (no keys needed)
- **Subtitles**: Whisper runs in your browser (transformers.js + ONNX wasm). The model downloads once and is then cached: Fast ≈ 40 MB, Accurate ≈ 76 MB. The server sends cross-origin-isolation headers so the model can run multi-threaded.
  - **Auto (default)** picks Fast on phones and Accurate on computers. You can change it in Settings → Subtitles.
  - **Only the best moments get transcribed**, with a time budget of about 40 s of speech per clip. The audio is split at silences into pieces of 28 s or less. A live "Xs of Ys · about N left" counter shows progress, so the bar never sits at 0.
  - **Loop guard:** small Whisper models sometimes repeat one sentence over and over. ClipForge blocks repeated phrases while decoding and detects loops afterwards. Any piece that loops is redone once with the accurate model, or left out if it still loops, so garbage never becomes a clip.
  - The free "AI polish" (hooks & titles) step gives up after 20 s if the free service is down, and the built-in hooks are used instead.
  - For an 8-min talk, subtitles take about 90 s on the phone path (was about 270 s) and about 130 s on the computer path.
- **Export**: WebCodecs via mediabunny decodes → renders → encodes each clip faster than real time (MP4 H.264, or WebM VP9 if H.264 isn't available). If the browser can't do this, it falls back to real-time recording. You get one `.zip` with every clip plus optional `.srt` files.

## Optional keys (Settings page, stored in the browser)
- **OpenAI-compatible API key**, with presets for OpenAI, Google Gemini (free) and Groq (free). Used for AI Director scripts and clip titles/hooks. A real OpenAI key also unlocks whole-video Whisper, OpenAI voices and image generation.
- **Pexels key** (free): stock video for the AI Director and the editor.

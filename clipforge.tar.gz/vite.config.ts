import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// ClipForge is a static site: everything (decode, analyse, export) runs in the
// browser, so the build output is plain files that any static host can serve.
export default defineConfig({
  plugins: [react()],
  base: './',
  build: {
    outDir: 'dist',
    assetsInlineLimit: 0,
    // One bundle keeps the first load on a phone down to a single request.
    rollupOptions: { output: { manualChunks: undefined } },
    chunkSizeWarningLimit: 1600,
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: false,
  },
  preview: {
    host: '0.0.0.0',
    port: 4173,
  },
});

#!/usr/bin/env node
/**
 * A tiny static file server for the built site in dist/.
 *
 * Why this exists: ClipForge is a static site - all the video work happens in
 * the browser - so on Render the right setup is a Static Site whose Publish
 * Directory is dist. But if the service is created as a "Web Service" instead,
 * Render runs `npm start` and expects a process that listens on $PORT. This
 * file makes that work too, so the same archive deploys either way.
 *
 * No dependencies: node's own http and fs only.
 */
import { createServer } from 'node:http';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { extname, join, normalize, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('../dist', import.meta.url)));
const port = Number(process.env.PORT || 4173);
const host = process.env.HOST || '0.0.0.0';

if (!existsSync(join(root, 'index.html'))) {
  console.error(
    `\n  Nothing to serve: ${root} has no index.html.\n` +
      `  Run "npm run build" first, then "npm start".\n`,
  );
  process.exit(1);
}

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

const server = createServer((req, res) => {
  try {
    const url = new URL(req.url || '/', 'http://localhost');
    let p = decodeURIComponent(url.pathname);
    if (p.endsWith('/')) p += 'index.html';

    // Never let a path escape dist/.
    const full = join(root, normalize(p).replace(/^([/\\])+/, ''));
    if (!full.startsWith(root)) {
      res.writeHead(403).end('Forbidden');
      return;
    }

    // The app uses hash routing (#/history), so every unknown path is the app.
    let file = full;
    if (!existsSync(file) || statSync(file).isDirectory()) {
      if (existsSync(file) && statSync(file).isDirectory()) file = join(file, 'index.html');
      if (!existsSync(file)) file = join(root, 'index.html');
    }

    const ext = extname(file).toLowerCase();
    const isHtml = ext === '.html';
    res.writeHead(200, {
      'Content-Type': TYPES[ext] || 'application/octet-stream',
      'Content-Length': statSync(file).size,
      // Hashed build assets never change; the shell must always be re-checked.
      'Cache-Control': isHtml ? 'no-cache' : 'public, max-age=31536000, immutable',
      'X-Content-Type-Options': 'nosniff',
    });
    if (req.method === 'HEAD') {
      res.end();
      return;
    }
    createReadStream(file).pipe(res);
  } catch (e) {
    res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Server error: ' + String((e && e.message) || e));
  }
});

server.listen(port, host, () => {
  console.log(`ClipForge serving ${root} on http://${host}:${port}`);
});

#!/usr/bin/env node
/**
 * Build a realistic test source: H.264 (High profile) + AAC in an MP4, 720p,
 * with movement all the way through the file, speech-like audio that has real
 * pauses, and a real human face visible during part of the timeline.
 *
 * That combination is what the brief asks us to reproduce with:
 *   - H.264/AAC MP4 so a real Chrome decoder is involved;
 *   - motion throughout so a frozen export is obvious;
 *   - pauses so cut-point snapping has something to find;
 *   - a face window so the per-clip Face/Full-frame decision can be checked.
 *
 * ffmpeg quirks handled here (learned the hard way):
 *   - expression values must stay single-quoted so the commas inside
 *     if()/between() survive the filtergraph parser (semicolons do NOT work
 *     there, despite what some answers say);
 *   - the johnvansickle static build has no drawtext (no freetype), so the
 *     "timecode" comes from continuous hue/brightness movement instead.
 *
 * Usage:
 *   node scripts/make-test-source.mjs [durationSeconds] [outDir]
 */
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const duration = Number(process.argv[2] || 180);
const outDir = resolve(process.argv[3] || '/tmp/cf-test');
const face = resolve('/home/user/image-search/portrait-photo-person-face-looking-at-ca-3.jpg');
const outFile = resolve(outDir, `source-${duration}s.mp4`);

mkdirSync(outDir, { recursive: true });
void here;

if (!Number.isFinite(duration) || duration < 20) {
  console.error('duration must be at least 20 seconds');
  process.exit(1);
}

const faceIn = Math.round(duration * 0.2);
const faceOut = Math.round(duration * 0.45);
const faceDur = Math.max(2, faceOut - faceIn);
const hasFace = existsSync(face);

/* ---------------- inputs ----------------
   [0] video pattern source (testsrc2 has a moving element + scrolling gradations)
   [1] "voice": gated tone cluster, so there are real pauses to cut on
   [2] "bed":   low pink noise, so the file always has an audio track
   [3] a real portrait, visible during part of the timeline
----------------------------------------- */
const inputs = [
  ['-f', 'lavfi', '-i', `testsrc2=size=1280x720:rate=30:duration=${duration}`],
  ['-f', 'lavfi', '-i', `sine=frequency=190:sample_rate=48000:duration=${duration}`],
  ['-f', 'lavfi', '-i', `anoisesrc=color=pink:sample_rate=48000:amplitude=0.05:duration=${duration}`],
];
if (hasFace) inputs.push(['-i', face]);
else console.warn('WARN: no face image at ' + face + ' — source will contain no person');

/* ---------------- filter graph ---------------- */
const fc = [];
fc.push(`[0:v]hue=h=360*t/${duration}:b=0.25*sin(t*1.7)[base]`);
fc.push(
  `[1:a]tremolo=f=6:d=0.7,volume='if(lt(mod(t,4),2.7),1.0,0)':eval=frame[voice]`,
);
// The noise bed is gated on the same cycle and left with a tiny room tone, so
// the file genuinely has silent stretches (about 1.3s every 4s) for the
// cut-point snapping to find.
fc.push(`[2:a]volume='if(lt(mod(t,4),2.7),0.22,0.012)':eval=frame[bed]`);
fc.push(`[voice][bed]amix=inputs=2:normalize=0,alimiter=limit=0.9,atrim=0:${duration}[aout]`);

if (hasFace) {
  const xExpr = `if(between(t,${faceIn},${faceOut}),80+380*abs(sin((t-${faceIn})/${faceDur}*PI)),-9999)`;
  fc.push(`[3:v]scale=300:-1[face]`);
  fc.push(
    `[base][face]overlay=x='${xExpr}':y=180:enable='between(t,${faceIn},${faceOut})'[vout]`,
  );
} else {
  fc.push(`[base]null[vout]`);
}

/* ---------------- command ---------------- */
const args = ['-hide_banner', '-y', ...inputs.flat()];

args.push(
  '-filter_complex', fc.join(';'),
  '-map', '[vout]',
  '-map', '[aout]',
  '-c:v', 'libx264',
  '-profile:v', 'high',
  '-level', '3.1',
  '-pix_fmt', 'yuv420p',
  '-preset', 'veryfast',
  '-g', '60',
  '-keyint_min', '60',
  '-sc_threshold', '0',
  '-b:v', '1400k',
  '-maxrate', '1800k',
  '-bufsize', '2800k',
  '-c:a', 'aac',
  '-b:a', '128k',
  '-ar', '48000',
  '-ac', '2',
  '-movflags', '+faststart',
  '-t', String(duration),
  outFile,
);

console.log(`building ${duration}s source -> ${outFile}`);
const t0 = Date.now();
const r = spawnSync('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });
if (r.status !== 0) {
  console.error(String(r.stderr).split('\n').slice(-25).join('\n'));
  process.exit(1);
}
console.log(`built in ${((Date.now() - t0) / 1000).toFixed(1)}s`);

/* ---------------- prove the source is good ---------------- */
const probe = spawnSync(
  'ffprobe',
  ['-v', 'error', '-show_format', '-show_streams', '-of', 'default=noprint_wrappers=1', outFile],
  { encoding: 'utf8' },
);
const pl = probe.stdout.split('\n');
const vcodec = pl.filter((l) => l.startsWith('codec_name')).map((l) => l.split('=')[1]);
const dur = pl.find((l) => l.startsWith('duration='))?.split('=')[1];
console.log(`container duration=${dur}s codecs=${vcodec.join('/')}`);

// Motion check on the SOURCE: freeze detection must find nothing.
const fz = spawnSync(
  'ffmpeg',
  ['-hide_banner', '-i', outFile, '-vf', 'freezedetect=n=-50dB:d=3', '-f', 'null', '-'],
  { encoding: 'utf8' },
);
const freezes = (String(fz.stderr).match(/freeze_start/g) || []).length;
console.log(`source freezes longer than 3s: ${freezes}`);
console.log(`FACE_WINDOW=${hasFace ? `${faceIn}..${faceOut}` : 'none'}`);
console.log(outFile);
if (freezes > 0) process.exit(2);

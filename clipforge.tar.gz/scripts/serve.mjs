#!/usr/bin/env node
/**
 * Two tiny static servers for testing:
 *   - the built app on APP_PORT (default 4173)
 *   - the test media on MEDIA_PORT (default 8099), with permissive CORS so the
 *     app can fetch() it exactly like a real remote video link.
 *
 * Usage: node scripts/serve.mjs [distDir] [mediaDir] [appPort] [mediaPort]
 */
import { createServer } from 'node:http';
import { createReadStream, statSync, existsSync } from 'node:fs';
import { extname, join, normalize, resolve } from 'node:path';

const distDir = resolve(process.argv[2] || 'dist');
const mediaDir = resolve(process.argv[3] || '/tmp/cf-test');
const appPort = Number(process.argv[4] || 4173);
const mediaPort = Number(process.argv[5] || 8099);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mov': 'video/quicktime',
  '.m4a': 'audio/mp4',
  '.woff2': 'font/woff2',
  '.map': 'application/json',
};

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Range, Content-Type');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges');
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
}

function serveFile(root, req, res, { spa = false } = {}) {
  cors(res);
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }
  let p = decodeURIComponent((req.url || '/').split('?')[0]);
  if (p === '/' || p === '') p = '/index.html';
  const full = join(root, normalize(p).replace(/^(\.\.[/\\])+/, ''));
  if (!full.startsWith(root)) {
    res.writeHead(403);
    return res.end('forbidden');
  }
  const path = existsSync(full) && statSync(full).isDirectory() ? join(full, 'index.html') : full;
  if (!existsSync(path)) {
    if (spa) {
      const idx = join(root, 'index.html');
      if (existsSync(idx)) return serveFile(root, { ...req, url: '/index.html' }, res, { spa });
    }
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    return res.end('not found');
  }
  const st = statSync(path);
  const type = MIME[extname(path).toLowerCase()] || 'application/octet-stream';
  const range = req.headers.range;
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    if (m) {
      const start = m[1] ? parseInt(m[1], 10) : 0;
      const end = m[2] ? parseInt(m[2], 10) : st.size - 1;
      res.writeHead(206, {
        'Content-Type': type,
        'Content-Range': `bytes ${start}-${end}/${st.size}`,
        'Content-Length': end - start + 1,
        'Cache-Control': 'no-store',
      });
      return createReadStream(path, { start, end }).pipe(res);
    }
  }
  res.writeHead(200, { 'Content-Type': type, 'Content-Length': st.size, 'Cache-Control': 'no-store' });
  if (req.method === 'HEAD') return res.end();
  createReadStream(path).pipe(res);
}

const app = createServer((req, res) => serveFile(distDir, req, res, { spa: true }));
app.listen(appPort, '0.0.0.0', () => console.log(`app   http://127.0.0.1:${appPort}/`));

const media = createServer((req, res) => serveFile(mediaDir, req, res));
media.listen(mediaPort, '0.0.0.0', () => console.log(`media http://127.0.0.1:${mediaPort}/`));

for (const s of [app, media]) {
  s.on('error', (e) => {
    console.error('server error', e.message);
    process.exit(1);
  });
}
process.on('SIGTERM', () => process.exit(0));
process.on('SIGINT', () => process.exit(0));

// Minimal service worker: makes ClipForge installable as an Android app.
// It deliberately does NOT intercept fetches — video files, models and the cross-origin-isolation headers
// all come straight from the network/browser cache, exactly as in a normal tab.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

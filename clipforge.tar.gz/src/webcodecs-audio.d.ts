/**
 * TypeScript 5.6 ships DOM types for VideoEncoder/VideoDecoder/VideoFrame but
 * NOT for the audio side of WebCodecs. These are the minimal declarations for
 * the pieces ClipForge uses. They are declared only when absent, so a newer
 * lib.dom.d.ts still wins.
 */

type BufferSourceLike = ArrayBufferView | ArrayBuffer;

interface AudioDataInit {
  format: string;
  sampleRate: number;
  numberOfFrames: number;
  timestamp: number;
  data: BufferSourceLike;
  numberOfChannels?: number;
  transfer?: ArrayBuffer[];
}

interface AudioData {
  readonly format: string | null;
  readonly sampleRate: number;
  readonly numberOfFrames: number;
  readonly numberOfChannels: number;
  readonly duration: number;
  readonly timestamp: number;
  copyTo(destination: BufferSourceLike, options?: { planeIndex?: number; format?: string }): void;
  close(): void;
  clone(): AudioData;
}

declare var AudioData: {
  prototype: AudioData;
  new (init: AudioDataInit): AudioData;
};

interface EncodedAudioChunkInit {
  type: 'key' | 'delta';
  timestamp: number;
  duration?: number;
  data: BufferSourceLike;
}

interface EncodedAudioChunk {
  readonly type: 'key' | 'delta';
  readonly timestamp: number;
  readonly byteLength: number;
  readonly duration: number | null;
  copyTo(destination: BufferSourceLike): void;
}

declare var EncodedAudioChunk: {
  prototype: EncodedAudioChunk;
  new (init: EncodedAudioChunkInit): EncodedAudioChunk;
};

interface AudioDecoderConfig {
  codec: string;
  sampleRate?: number;
  numberOfChannels?: number;
  description?: BufferSourceLike;
}

interface AudioEncoderConfig {
  codec: string;
  sampleRate: number;
  numberOfChannels: number;
  bitrate?: number;
  bitrateMode?: 'constant' | 'variable';
  opus?: { complexity?: number; signal?: 'auto' | 'voice' | 'music'; frameDuration?: number };
}

interface AudioEncoderSupport {
  supported?: boolean;
  config?: AudioEncoderConfig;
}

interface AudioDecoderSupport {
  supported?: boolean;
  config?: AudioDecoderConfig;
}

interface AudioEncoderOutput {
  chunk: EncodedAudioChunk;
  metadata?: { decoderConfig?: { codec?: string; description?: BufferSourceLike; sampleRate?: number; numberOfChannels?: number } };
}

interface AudioEncoderInit {
  output: (chunk: EncodedAudioChunk, metadata?: AudioEncoderOutput['metadata']) => void;
  error: (e: DOMException) => void;
}

interface AudioEncoder {
  readonly encodeQueueSize: number;
  readonly state: 'unconfigured' | 'configured' | 'closed';
  configure(config: AudioEncoderConfig): void;
  encode(data: AudioData): void;
  flush(): Promise<void>;
  reset(): void;
  close(): void;
}

declare var AudioEncoder: {
  prototype: AudioEncoder;
  new (init: AudioEncoderInit): AudioEncoder;
  isConfigSupported(config: AudioEncoderConfig): Promise<AudioEncoderSupport>;
};

interface AudioDecoderOutput {
  chunk: unknown;
  metadata?: { decoderConfig?: AudioDecoderConfig };
}

interface AudioDecoderInit {
  output: (data: AudioData, metadata?: AudioDecoderOutput['metadata']) => void;
  error: (e: DOMException) => void;
}

interface AudioDecoder {
  readonly decodeQueueSize: number;
  readonly state: 'unconfigured' | 'configured' | 'closed';
  configure(config: AudioDecoderConfig): void;
  decode(chunk: EncodedAudioChunk): void;
  flush(): Promise<void>;
  reset(): void;
  close(): void;
}

declare var AudioDecoder: {
  prototype: AudioDecoder;
  new (init: AudioDecoderInit): AudioDecoder;
  isConfigSupported(config: AudioDecoderConfig): Promise<AudioDecoderSupport>;
};

/** Some builds expose a richer VideoFrame metadata type than lib.dom. */
interface VideoFrameCallbackMetadata {
  presentationTime: DOMHighResTimeStamp;
  expectedDisplayTime: DOMHighResTimeStamp;
  width: number;
  height: number;
  mediaTime: number;
  presentedFrames: number;
  processingDuration?: number;
}

interface HTMLVideoElementWithRvfc extends HTMLVideoElement {
  requestVideoFrameCallback?(
    callback: (now: DOMHighResTimeStamp, metadata: VideoFrameCallbackMetadata) => void,
  ): number;
  cancelVideoFrameCallback?(handle: number): void;
}

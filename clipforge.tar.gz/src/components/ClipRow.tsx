import { useCallback, useEffect, useRef, useState } from 'react';
import { formatBytes, formatTime } from '../lib/download';
import * as db from '../lib/db';
import { verificationSummary } from '../lib/verify';
import type { Clip } from '../lib/types';
import { useStore } from '../store';

interface Props {
  clip: Clip;
  /** Show the per-clip editor controls. */
  editable?: boolean;
  onPlay?: (clip: Clip) => void;
  onDownload?: (clip: Clip) => void;
  onLayout?: (clip: Clip, layout: 'face' | 'full') => void;
  onReExport?: (clip: Clip) => void;
  onDelete?: (clip: Clip) => void;
  playing?: string | null;
}

const STATUS_LABEL: Record<Clip['status'], string> = {
  pending: 'Waiting',
  analysing: 'Analysing',
  ready: 'Ready to make',
  exporting: 'Making',
  verifying: 'Checking the file',
  done: 'Done',
  error: 'Failed',
};

export default function ClipRow({
  clip,
  editable,
  onPlay,
  onDownload,
  onLayout,
  onReExport,
  onDelete,
  playing,
}: Props) {
  const { ui } = useStore();
  const [thumb, setThumb] = useState<string | null>(clip.thumbUrl ?? null);
  const [localUrl, setLocalUrl] = useState<string | null>(clip.url ?? null);
  const [sizeText, setSizeText] = useState(clip.sizeBytes ? formatBytes(clip.sizeBytes) : '');
  const [trimOpen, setTrimOpen] = useState(false);
  const [start, setStart] = useState(clip.start.toFixed(2));
  const [end, setEnd] = useState(clip.end.toFixed(2));
  const videoRef = useRef<HTMLVideoElement | null>(null);

  /* Load the stored file from disk on demand — it never sits in RAM. */
  const ensureUrl = useCallback(async (): Promise<string | null> => {
    if (localUrl) return localUrl;
    const blob = await db.getBlob(clip.id);
    if (!blob || blob.size < 1024) return null;
    const u = URL.createObjectURL(blob);
    setLocalUrl(u);
    setSizeText(formatBytes(blob.size));
    return u;
  }, [clip.id, localUrl]);

  useEffect(() => {
    return () => {
      if (localUrl && localUrl !== clip.url) URL.revokeObjectURL(localUrl);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handlePlay = async () => {
    const u = await ensureUrl();
    if (!u) return;
    onPlay?.(clip);
    // let the player component pick it up
    setTimeout(() => {
      if (videoRef.current) {
        videoRef.current.src = u;
        void videoRef.current.play();
      }
    }, 30);
  };

  const handleDownload = async () => {
    const u = await ensureUrl();
    if (!u) return;
    onDownload?.(clip);
  };

  const busy = clip.status === 'exporting' || clip.status === 'verifying' || clip.status === 'analysing';

  return (
    <article className="clip" data-clip-id={clip.id} data-status={clip.status}>
      <div className="clip-head">
        {thumb ? (
          <img className="thumb" src={thumb} alt="" width={74} height={132} />
        ) : (
          <div className="thumb" aria-hidden="true" />
        )}
        <div className="clip-meta">
          <h3 className="clip-title">{clip.analysis?.title || `Clip ${clip.index + 1}`}</h3>
          {clip.analysis?.hook ? <p className="clip-hook">{clip.analysis.hook}</p> : null}

          <div className="badges">
            <span className="badge badge-solid">{clip.analysis?.score ?? '—'}</span>
            <span className="badge">{formatTime(clip.duration)}</span>
            <span className="badge">{formatTime(clip.start)}–{formatTime(clip.end)}</span>
            <span className="badge">{clip.layout === 'face' ? 'Face' : 'Full frame'}</span>
            {clip.analysis?.hasFace ? <span className="badge">person on camera</span> : null}
            {sizeText ? <span className="badge">{sizeText}</span> : null}
            {clip.engine ? <span className="badge">{clip.engine === 'webcodecs-mp4' ? 'fast' : 'real-time'}</span> : null}
          </div>

          <p className="tiny dim">
            {STATUS_LABEL[clip.status]}
            {busy && clip.progressText ? ` — ${clip.progressText}` : ''}
          </p>

          {busy ? (
            <div className="meter" aria-hidden="true">
              <i style={{ width: `${Math.round((clip.progress || 0) * 100)}%` }} />
            </div>
          ) : null}

          {clip.error ? <p className="err">{clip.error}</p> : null}

          {clip.verification && !clip.error ? (
            <p className={`tiny ${clip.verification.ok ? 'dim' : 'err'}`}>
              {verificationSummary(clip.verification)}
            </p>
          ) : null}
        </div>
      </div>

      {/* inline player, only when asked for */}
      {playing === clip.id ? (
        <video
          ref={videoRef}
          className="player"
          controls
          playsInline
          preload="metadata"
          aria-label={`Play ${clip.analysis?.title || 'clip'}`}
        />
      ) : null}

      <div className="clip-actions">
        <button className="btn btn-sm" onClick={handlePlay} disabled={clip.status !== 'done'}>
          ▶ Play
        </button>
        <button className="btn btn-sm" onClick={handleDownload} disabled={clip.status !== 'done'}>
          ⬇ Download
        </button>
      </div>

      <div className="seg" role="group" aria-label="Layout">
        <button
          aria-pressed={clip.layout === 'face'}
          onClick={() => onLayout?.(clip, 'face')}
          disabled={!editable && !ui.exportSettings.preferFace}
        >
          Face
        </button>
        <button
          aria-pressed={clip.layout === 'full'}
          onClick={() => onLayout?.(clip, 'full')}
        >
          Full frame
        </button>
      </div>

      {editable ? (
        <details open={trimOpen} onToggle={(e) => setTrimOpen((e.target as HTMLDetailsElement).open)}>
          <summary>Edit</summary>
          <div className="details-body">
            <div className="btn-row">
              <label className="sr" htmlFor={`s-${clip.id}`}>Start seconds</label>
              <input
                id={`s-${clip.id}`}
                type="number"
                step="0.05"
                min={0}
                value={start}
                onChange={(e) => setStart(e.target.value)}
                aria-label="Start (seconds)"
              />
              <label className="sr" htmlFor={`e-${clip.id}`}>End seconds</label>
              <input
                id={`e-${clip.id}`}
                type="number"
                step="0.05"
                min={0}
                value={end}
                onChange={(e) => setEnd(e.target.value)}
                aria-label="End (seconds)"
              />
            </div>
            <p className="field-note">Seconds into the original video.</p>
            <div className="btn-row">
              <button
                className="btn"
                onClick={() => {
                  const s = Number(start);
                  const e = Number(end);
                  if (!Number.isFinite(s) || !Number.isFinite(e) || e - s < 1) return;
                  setTrimOpen(false);
                  onReExport?.({ ...clip, start: s, end: e, duration: e - s, edited: true });
                }}
              >
                Re-make with these cuts
              </button>
              <button className="btn" onClick={() => onReExport?.(clip)}>
                Re-make
              </button>
              <button className="btn" onClick={() => onDelete?.(clip)}>
                Delete
              </button>
            </div>
            {clip.analysis ? (
              <div className="logbox" aria-label="Why this score">
                {clip.analysis.scoreNotes.join('\n')}
                {'\n'}movement {clip.analysis.motion.toFixed(2)} · speech{' '}
                {Math.round(clip.analysis.speechRatio * 100)}% · face frames{' '}
                {Math.round(clip.analysis.faceRatio * 100)}%
                {clip.verification
                  ? `\nfile check: ${clip.verification.duration.toFixed(1)}s, ${clip.verification.framesDecoded}/${clip.verification.framesExpected} frames, longest freeze ${clip.verification.longestFreeze.toFixed(1)}s, motion to ${Math.round(clip.verification.motionThrough * 100)}%`
                  : ''}
              </div>
            ) : null}
          </div>
        </details>
      ) : null}

      {/* thumbnail source: a stored data URL kept next to the clip */}
      <ThumbLoader clipId={clip.id} onThumb={setThumb} />
    </article>
  );
}

/** Reads the stored thumbnail (a small data URL) out of IndexedDB. */
function ThumbLoader({ clipId, onThumb }: { clipId: string; onThumb: (d: string) => void }) {
  useEffect(() => {
    let alive = true;
    (async () => {
      const t = await db.getBlob(`thumb:${clipId}`);
      if (!alive || !t) return;
      // stored as a text data URL inside a Blob
      const text = await t.text();
      if (alive && text.startsWith('data:image')) onThumb(text);
    })();
    return () => {
      alive = false;
    };
  }, [clipId, onThumb]);
  return null;
}

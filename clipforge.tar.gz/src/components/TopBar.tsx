import { useEffect, useRef, useState } from 'react';
import { useStore, type Route } from '../store';

const PRIMARY: Array<{ id: Route; label: string }> = [
  { id: 'clips', label: 'Clips' },
  { id: 'history', label: 'History' },
  { id: 'settings', label: 'Settings' },
];

const MORE: Array<{ id: Route; label: string }> = [
  { id: 'director', label: 'AI Director' },
  { id: 'streams', label: 'Streams' },
  { id: 'editor', label: 'Editor' },
];

/**
 * Plain top bar: Clips · History · Settings + "More".
 * No bottom bar, nothing covering the screen.
 */
export default function TopBar() {
  const { route, go } = useStore();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const inMore = MORE.some((m) => m.id === route);
  const active: Route = route === 'results' ? 'clips' : route;

  return (
    <header className="topbar" ref={ref}>
      <div className="topbar-brand">ClipForge</div>
      <nav className="topbar-nav" aria-label="Main">
        {PRIMARY.map((t) => (
          <button
            key={t.id}
            className="tabbtn"
            aria-current={active === t.id ? 'page' : undefined}
            onClick={() => {
              go(t.id);
              setOpen(false);
            }}
          >
            {t.label}
          </button>
        ))}
        <button
          className="tabbtn"
          aria-haspopup="menu"
          aria-expanded={open}
          aria-current={inMore ? 'page' : undefined}
          onClick={() => setOpen((o) => !o)}
        >
          More
        </button>
      </nav>

      {open && (
        <>
          <div className="sheet-backdrop" onClick={() => setOpen(false)} aria-hidden="true" />
          <div className="sheet" role="menu">
            {MORE.map((t) => (
              <button
                key={t.id}
                role="menuitem"
                aria-current={route === t.id ? 'page' : undefined}
                onClick={() => {
                  go(t.id);
                  setOpen(false);
                }}
              >
                {t.label}
              </button>
            ))}
            <button
              role="menuitem"
              aria-current={route === 'results' ? 'page' : undefined}
              onClick={() => {
                go('results');
                setOpen(false);
              }}
            >
              Latest results
            </button>
          </div>
        </>
      )}
    </header>
  );
}

import { isPhone, isStandalone, isTouchDevice } from './lib/mobile';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AudioAnalysis, ChatAnalysis, ChatMsg, Clip, ClipRenderOptions, ScheduledPost, Transcript, VisualAnalysis } from './lib/types';
import { uid } from './lib/util';
import { deleteSession, saveSession, updateSessionSoon } from './lib/sessionStore';

// ── routes live in the URL (#/clip-video, #/results/<id> …) so every page has its own link, the back button
//    works inside the app, and a page can be opened in its own browser tab.
export function routeToHash(r: Route): string {
  if (r.name === 'results') return `#/results/${r.sessionId}`;
  if (r.name === 'editor') return r.projectId ? `#/editor/${r.projectId}` : '#/editor';
  if (r.name === 'landing' || r.name === 'publish') return '#/dashboard';
  return `#/${r.name}`;
}
export function hashToRoute(h: string): Route {
  const [name, id] = h.replace(/^#\/?/, '').split('/');
  switch (name) {
    case 'clip-video': case 'clip-stream': case 'director': case 'settings': case 'dashboard': return { name };
    case 'results': return id ? { name: 'results', sessionId: id } : { name: 'dashboard' };
    case 'editor': return { name: 'editor', projectId: id || undefined };
    default: return { name: 'dashboard' }; // home
  }
}
/** Tools that open in their own browser tab (when that setting is on). */
export const TAB_ROUTES: Route['name'][] = ['clip-video', 'clip-stream', 'director', 'editor'];

export type Route =
  | { name: 'landing' }
  | { name: 'dashboard' }
  | { name: 'clip-video' }
  | { name: 'clip-stream' }
  | { name: 'results'; sessionId: string }
  | { name: 'editor'; projectId?: string }
  | { name: 'director' }
  | { name: 'publish' }
  | { name: 'settings' };

export type ClipSession = {
  id: string;
  name: string;
  mode: 'video' | 'stream';
  url: string;
  file?: Blob;
  /** the pasted link it came from, so the video can be re-downloaded if its local copy was freed */
  sourceUrl?: string;
  duration: number;
  width: number;
  height: number;
  createdAt: number;
  transcript: Transcript | null;
  audio: AudioAnalysis | null;
  visual: VisualAnalysis | null;
  chat: ChatAnalysis | null;
  chatLog: ChatMsg[];
  clips: Clip[];
  platform: string;
  options: ClipRenderOptions;
  exported: string[];
};

export type Toast = { id: string; text: string; kind: 'info' | 'success' | 'error' | 'fire' };

export type Settings = {
  openaiKey: string;
  openaiBase: string;
  llmModel: string;
  handle: string;
  brandColor: string;
  brandAccent: string;
  brandFont: string;
  logo: string; // dataURL
  defaultCaption: string;
  exportRes: 720 | 1080;
  theme: 'dark' | 'light';
  autoDeleteDays: number;
  pexelsKey: string;
  /** free on-device subtitles model */
  localAsr?: 'auto' | 'tiny' | 'base' | 'off';
  /** open Clip a Video / Stream / AI Director / Editor in their own browser tabs */
  newTabs?: boolean;
};

export const defaultOptions = (s: Settings, platformAspect: ClipRenderOptions['aspect'] = '9:16'): ClipRenderOptions => ({
  aspect: platformAspect,
  reframe: 'track',
  speakerFocus: 'auto',
  captionStyle: s.defaultCaption || 'hormozi',
  captionPos: 'bottom',
  captionScale: 1,
  captions: true,
  emojis: true,
  keywordEmphasis: true,
  censor: true,
  hookText: '',
  hookOverlay: true,
  teaser: false,
  removeSilence: true,
  removeFillers: true,
  speed: 1,
  zoomPulses: false,
  shake: false,
  flash: false,
  progressBar: true,
  grade: 'none',
  music: '',
  musicVolume: 0.35,
  ducking: true,
  sfx: false,
  beatZoom: false,
  handle: s.handle,
  watermark: false,
  endCard: false,
  commentBait: false,
  chatOverlay: false,
});

type AppState = {
  route: Route;
  go: (r: Route) => void;
  settings: Settings;
  setSettings: (p: Partial<Settings>) => void;
  sessions: ClipSession[];
  addSession: (s: ClipSession) => void;
  updateSession: (id: string, p: Partial<ClipSession>) => void;
  removeSession: (id: string) => void;
  /** put a session loaded from storage back into memory (no re-save) */
  hydrateSession: (s: ClipSession) => void;
  /** go to a page — tools open in their own browser tab when enabled */
  open: (r: Route) => void;
  toasts: Toast[];
  toast: (text: string, kind?: Toast['kind']) => void;
  dismiss: (id: string) => void;
  posts: ScheduledPost[];
  setPosts: (p: ScheduledPost[]) => void;
  connected: Record<string, boolean>;
  setConnected: (k: string, v: boolean) => void;
  credits: number;
  spendCredits: (n: number) => void;
  paletteOpen: boolean;
  setPalette: (v: boolean) => void;
  history: { id: string; title: string; score: number; at: number; kind: string }[];
  logHistory: (h: { title: string; score: number; kind: string }) => void;
  pendingEditorImport: null | { url: string; name: string; start: number; end: number; captions: { text: string; start: number; end: number }[]; aspect: string; file?: Blob };
  setPendingEditorImport: (p: AppState['pendingEditorImport']) => void;
  pendingUrl: string | null;
  setPendingUrl: (u: string | null) => void;
};

export const useApp = create<AppState>()(
  persist(
    (set, get) => ({
      route: hashToRoute(location.hash),
      go: (r) => {
        const h = routeToHash(r);
        if (location.hash !== h) history.pushState(null, '', h);
        set({ route: r }); window.scrollTo(0, 0);
      },
      open: (r) => {
        const s = get();
        const target = r.name === 'editor' && r.projectId ? 'cf-editor-' + r.projectId : 'cf-' + r.name; // one tab per project
        // tools get their own tab; inside that tab (or with the setting off) just navigate
        // phones: switch in place — every tool page stays alive, so nothing is lost, and Android freezes background tabs
        const phone = isTouchDevice() || isPhone() || isStandalone();
        if (!phone && s.settings.newTabs !== false && TAB_ROUTES.includes(r.name) && window.name !== target) {
          const w = window.open(location.pathname + location.search + routeToHash(r), target);
          if (w) { w.focus?.(); return; }
        }
        s.go(r);
      },
      settings: {
        openaiKey: '',
        openaiBase: 'https://api.openai.com/v1',
        llmModel: 'gpt-4o-mini',
        handle: '',
        brandColor: '#7c5cff',
        brandAccent: '#ffd23f',
        brandFont: 'Montserrat',
        logo: '',
        defaultCaption: 'hormozi',
        exportRes: 720,
        theme: 'dark',
        autoDeleteDays: 0, // 0 = only when space runs out (clip history itself is never deleted)
        pexelsKey: '',
        localAsr: 'auto',
        newTabs: true,
      },
      setSettings: (p) => set({ settings: { ...get().settings, ...p } }),
      sessions: [],
      addSession: (s) => {
        set({ sessions: [s, ...get().sessions.filter((x) => x.id !== s.id)] });
        // save to the browser right away (thumbnail of the best clip first, if it's quick)
        (async () => {
          let thumb: string | undefined;
          try {
            const best = [...s.clips].sort((a, b) => b.score - a.score)[0];
            if (best && s.url) {
              const { clipThumb } = await import('./lib/clipRender');
              thumb = await Promise.race([clipThumb(s.url, best, s.visual, s.transcript, s.options.aspect, s.options.reframe), new Promise<undefined>((r) => setTimeout(() => r(undefined), 8000))]);
            }
          } catch { /* no thumbnail */ }
          await saveSession(s, thumb);
        })().catch((e) => { console.warn('saving session failed', e); get().toast('Couldn’t save these clips to your history (browser storage full?)', 'error'); });
      },
      updateSession: (id, p) => {
        set({ sessions: get().sessions.map((s) => (s.id === id ? { ...s, ...p } : s)) });
        const s = get().sessions.find((x) => x.id === id);
        if (s) updateSessionSoon(s);
      },
      removeSession: (id) => { set({ sessions: get().sessions.filter((s) => s.id !== id) }); deleteSession(id); },
      hydrateSession: (s) => set({ sessions: [s, ...get().sessions.filter((x) => x.id !== s.id)] }),
      toasts: [],
      toast: (text, kind = 'info') => {
        const id = uid();
        set({ toasts: [...get().toasts, { id, text, kind }] });
        setTimeout(() => get().dismiss(id), kind === 'error' ? 7000 : 4200);
      },
      dismiss: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),
      posts: [],
      setPosts: (p) => set({ posts: p }),
      connected: {},
      setConnected: (k, v) => set({ connected: { ...get().connected, [k]: v } }),
      credits: 500,
      spendCredits: (n) => set({ credits: Math.max(0, get().credits - n) }),
      paletteOpen: false,
      setPalette: (v) => set({ paletteOpen: v }),
      history: [],
      logHistory: (h) => set({ history: [{ ...h, id: uid(), at: Date.now() }, ...get().history].slice(0, 200) }),
      pendingEditorImport: null,
      setPendingEditorImport: (p) => set({ pendingEditorImport: p }),
      pendingUrl: null,
      setPendingUrl: (u) => set({ pendingUrl: u }),
    }),
    {
      name: 'clipforge-app',
      version: 2,
      // v1: on-device subtitles default to "auto" (fast model on phones) instead of always "base"
      migrate: (state, v) => {
        const st = state as { settings?: { localAsr?: string } };
        if (v < 1 && st?.settings && (!st.settings.localAsr || st.settings.localAsr === 'base')) st.settings.localAsr = 'auto';
        // v2: unlimited history: source videos are no longer deleted after 30 days by default, only when space runs out
        if (v < 2 && st?.settings && (st.settings as { autoDeleteDays?: number }).autoDeleteDays === 30) (st.settings as { autoDeleteDays?: number }).autoDeleteDays = 0;
        return st as never;
      },
      partialize: (s) => ({ settings: s.settings, posts: s.posts, connected: s.connected, credits: s.credits, history: s.history }),
    },
  ),
);

export const PLATFORMS = [
  { id: 'tiktok', name: 'TikTok', aspect: '9:16', maxLen: 180, color: '#ff0050' },
  { id: 'shorts', name: 'YouTube Shorts', aspect: '9:16', maxLen: 60, color: '#ff0000' },
  { id: 'reels', name: 'Instagram Reels', aspect: '9:16', maxLen: 90, color: '#e1306c' },
  { id: 'youtube', name: 'YouTube', aspect: '16:9', maxLen: 3600, color: '#ff4e45' },
  { id: 'facebook', name: 'Facebook', aspect: '1:1', maxLen: 240, color: '#1877f2' },
  { id: 'x', name: 'Twitter / X', aspect: '16:9', maxLen: 140, color: '#e7e7e7' },
  { id: 'snapchat', name: 'Snapchat Spotlight', aspect: '9:16', maxLen: 60, color: '#fffc00' },
  { id: 'linkedin', name: 'LinkedIn', aspect: '1:1', maxLen: 600, color: '#0a66c2' },
  { id: 'pinterest', name: 'Pinterest', aspect: '9:16', maxLen: 60, color: '#e60023' },
  { id: 'all', name: 'All at once', aspect: '9:16', maxLen: 60, color: '#7c5cff' },
] as const;

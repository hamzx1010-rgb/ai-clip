/**
 * App-wide state. Deliberately small: one context, plain useState/useReducer.
 * Clips live in IndexedDB; React only holds what the screen shows.
 */

import { createContext, useContext } from 'react';
import type { VideoSource } from './lib/source';
import type { AiDirectorConfig } from './lib/title';
import { NO_AI } from './lib/title';
import type { Clip, ExportSettings, RunMeta } from './lib/types';
import { DEFAULT_SETTINGS } from './lib/types';

export type Route = 'clips' | 'results' | 'history' | 'settings' | 'director' | 'streams' | 'editor';

export interface UiSettings {
  exportSettings: ExportSettings;
  keywords: string;
  ai: AiDirectorConfig;
  downloadEach: boolean;
  showLog: boolean;
  forceRealtime: boolean;
}

export const DEFAULT_UI: UiSettings = {
  exportSettings: DEFAULT_SETTINGS,
  keywords: '',
  ai: NO_AI,
  downloadEach: true,
  showLog: false,
  forceRealtime: false,
};

export interface Store {
  route: Route;
  go: (r: Route) => void;

  run: RunMeta | null;
  setRun: (r: RunMeta | null) => void;
  clips: Clip[];
  setClips: (c: Clip[]) => void;
  updateClip: (c: Clip) => void;

  busy: boolean;
  setBusy: (b: boolean) => void;
  status: string;
  setStatus: (s: string) => void;
  progress: number;
  setProgress: (p: number) => void;
  logs: string[];
  pushLog: (s: string) => void;
  clearLogs: () => void;

  error: string | null;
  setError: (e: string | null) => void;

  source: VideoSource | null;
  setSource: (s: VideoSource | null) => void;
  sourceHasAudio: boolean;
  setSourceHasAudio: (b: boolean) => void;

  ui: UiSettings;
  setUi: (u: Partial<UiSettings>) => void;

  abortRef: { current: AbortController | null };
}

export const StoreContext = createContext<Store | null>(null);

export function useStore(): Store {
  const s = useContext(StoreContext);
  if (!s) throw new Error('Store missing');
  return s;
}

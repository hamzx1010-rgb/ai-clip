import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { AudioAnalysis, ChatAnalysis, ChatMsg, Clip, ClipRenderOptions, ScheduledPost, Transcript, VisualAnalysis } from './lib/types';
import { uid } from './lib/util';

export type Route =
  | { name: 'landing' }
  | { name: 'dashboard' }
  | { name: 'clip-video' }
  | { name: 'clip-stream' }
  | { name: 'results'; sessionId: string }
  | { name: 'editor'; projectId?: string }
  | { name: 'director' }
  | { name: 'publish' }
  | { name: 'settings' };

export type ClipSession = {
  id: string;
  name: string;
  mode: 'video' | 'stream';
  url: string;
  file?: Blob;
  duration: number;
  width: number;
  height: number;
  createdAt: number;
  transcript: Transcript | null;
  audio: AudioAnalysis | null;
  visual: VisualAnalysis | null;
  chat: ChatAnalysis | null;
  chatLog: ChatMsg[];
  clips: Clip[];
  platform: string;
  options: ClipRenderOptions;
  exported: string[];
};

export type Toast = { id: string; text: string; kind: 'info' | 'success' | 'error' | 'fire' };

export type Settings = {
  openaiKey: string;
  openaiBase: string;
  llmModel: string;
  handle: string;
  brandColor: string;
  brandAccent: string;
  brandFont: string;
  logo: string; // dataURL
  defaultCaption: string;
  exportRes: 720 | 1080;
  theme: 'dark' | 'light';
  autoDeleteDays: number;
  pexelsKey: string;
  /** free on-device subtitles model */
  localAsr?: 'tiny' | 'base' | 'off';
};

export const defaultOptions = (s: Settings, platformAspect: ClipRenderOptions['aspect'] = '9:16'): ClipRenderOptions => ({
  aspect: platformAspect,
  reframe: 'track',
  speakerFocus: 'auto',
  captionStyle: s.defaultCaption || 'hormozi',
  captionPos: 'bottom',
  captionScale: 1,
  captions: true,
  emojis: true,
  keywordEmphasis: true,
  censor: true,
  hookText: '',
  hookOverlay: true,
  teaser: false,
  removeSilence: true,
  removeFillers: true,
  speed: 1,
  zoomPulses: false,
  shake: false,
  flash: false,
  progressBar: true,
  grade: 'none',
  music: '',
  musicVolume: 0.35,
  ducking: true,
  sfx: false,
  beatZoom: false,
  handle: s.handle,
  watermark: false,
  endCard: false,
  commentBait: false,
  chatOverlay: false,
});

type AppState = {
  route: Route;
  go: (r: Route) => void;
  settings: Settings;
  setSettings: (p: Partial<Settings>) => void;
  sessions: ClipSession[];
  addSession: (s: ClipSession) => void;
  updateSession: (id: string, p: Partial<ClipSession>) => void;
  removeSession: (id: string) => void;
  toasts: Toast[];
  toast: (text: string, kind?: Toast['kind']) => void;
  dismiss: (id: string) => void;
  posts: ScheduledPost[];
  setPosts: (p: ScheduledPost[]) => void;
  connected: Record<string, boolean>;
  setConnected: (k: string, v: boolean) => void;
  credits: number;
  spendCredits: (n: number) => void;
  paletteOpen: boolean;
  setPalette: (v: boolean) => void;
  history: { id: string; title: string; score: number; at: number; kind: string }[];
  logHistory: (h: { title: string; score: number; kind: string }) => void;
  pendingEditorImport: null | { url: string; name: string; start: number; end: number; captions: { text: string; start: number; end: number }[]; aspect: string; file?: Blob };
  setPendingEditorImport: (p: AppState['pendingEditorImport']) => void;
  pendingUrl: string | null;
  setPendingUrl: (u: string | null) => void;
};

export const useApp = create<AppState>()(
  persist(
    (set, get) => ({
      route: { name: 'clip-video' },
      go: (r) => { set({ route: r }); window.scrollTo(0, 0); },
      settings: {
        openaiKey: '',
        openaiBase: 'https://api.openai.com/v1',
        llmModel: 'gpt-4o-mini',
        handle: '',
        brandColor: '#7c5cff',
        brandAccent: '#ffd23f',
        brandFont: 'Montserrat',
        logo: '',
        defaultCaption: 'hormozi',
        exportRes: 720,
        theme: 'dark',
        autoDeleteDays: 30,
        pexelsKey: '',
        localAsr: 'base',
      },
      setSettings: (p) => set({ settings: { ...get().settings, ...p } }),
      sessions: [],
      addSession: (s) => set({ sessions: [s, ...get().sessions] }),
      updateSession: (id, p) => set({ sessions: get().sessions.map((s) => (s.id === id ? { ...s, ...p } : s)) }),
      removeSession: (id) => set({ sessions: get().sessions.filter((s) => s.id !== id) }),
      toasts: [],
      toast: (text, kind = 'info') => {
        const id = uid();
        set({ toasts: [...get().toasts, { id, text, kind }] });
        setTimeout(() => get().dismiss(id), kind === 'error' ? 7000 : 4200);
      },
      dismiss: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),
      posts: [],
      setPosts: (p) => set({ posts: p }),
      connected: {},
      setConnected: (k, v) => set({ connected: { ...get().connected, [k]: v } }),
      credits: 500,
      spendCredits: (n) => set({ credits: Math.max(0, get().credits - n) }),
      paletteOpen: false,
      setPalette: (v) => set({ paletteOpen: v }),
      history: [],
      logHistory: (h) => set({ history: [{ ...h, id: uid(), at: Date.now() }, ...get().history].slice(0, 200) }),
      pendingEditorImport: null,
      setPendingEditorImport: (p) => set({ pendingEditorImport: p }),
      pendingUrl: null,
      setPendingUrl: (u) => set({ pendingUrl: u }),
    }),
    {
      name: 'clipforge-app',
      partialize: (s) => ({ settings: s.settings, posts: s.posts, connected: s.connected, credits: s.credits, history: s.history }),
    },
  ),
);

export const PLATFORMS = [
  { id: 'tiktok', name: 'TikTok', aspect: '9:16', maxLen: 180, color: '#ff0050' },
  { id: 'shorts', name: 'YouTube Shorts', aspect: '9:16', maxLen: 60, color: '#ff0000' },
  { id: 'reels', name: 'Instagram Reels', aspect: '9:16', maxLen: 90, color: '#e1306c' },
  { id: 'youtube', name: 'YouTube', aspect: '16:9', maxLen: 3600, color: '#ff4e45' },
  { id: 'facebook', name: 'Facebook', aspect: '1:1', maxLen: 240, color: '#1877f2' },
  { id: 'x', name: 'Twitter / X', aspect: '16:9', maxLen: 140, color: '#e7e7e7' },
  { id: 'snapchat', name: 'Snapchat Spotlight', aspect: '9:16', maxLen: 60, color: '#fffc00' },
  { id: 'linkedin', name: 'LinkedIn', aspect: '1:1', maxLen: 600, color: '#0a66c2' },
  { id: 'pinterest', name: 'Pinterest', aspect: '9:16', maxLen: 60, color: '#e60023' },
  { id: 'all', name: 'All at once', aspect: '9:16', maxLen: 60, color: '#7c5cff' },
] as const;

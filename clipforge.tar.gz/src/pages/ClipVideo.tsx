import { useEffect, useRef, useState } from 'react';
import { audioUrl, fetchRemoteVideo, type DlProgress } from '../lib/ingest';
import { FileText, Link2, Play, Sparkles, Upload, X, Film, KeyRound } from 'lucide-react';
import { useApp, PLATFORMS, defaultOptions, type ClipSession } from '../store';
import { CATEGORIES } from '../lib/nlp';
import { Seg, Slider, Toggle } from '../components/ui';
import { runPipeline, type StepState } from '../lib/pipeline';
import { parseSubtitles, hasAI } from '../lib/llm';
import type { ChatMsg, Transcript } from '../lib/types';
import { fmtBytes, fmtTime, uid } from '../lib/util';
import { PLATFORM_IDEAL } from '../lib/engine';

export const LANGS = [['auto', 'Auto-detect'], ['en', 'English'], ['es', 'Spanish'], ['fr', 'French'], ['ar', 'Arabic'], ['de', 'German'], ['pt', 'Portuguese'], ['hi', 'Hindi'], ['ja', 'Japanese'], ['ko', 'Korean'], ['zh', 'Chinese'], ['it', 'Italian'], ['ru', 'Russian'], ['tr', 'Turkish']];

export type SourceFile = { file: Blob; name: string; url: string; sample?: boolean; remote?: string };

export function useClipSettings(stream = false) {
  const [count, setCount] = useState(stream ? 8 : 6);
  const [minLen, setMinLen] = useState(stream ? 10 : 12);
  const [maxLen, setMaxLen] = useState(stream ? 35 : 45);
  const [cats, setCats] = useState<string[]>(stream ? ['funny', 'hype', 'shocking'] : ['hot', 'shocking', 'story', 'educational']);
  const [keywords, setKeywords] = useState('');
  const [platform, setPlatform] = useState('tiktok');
  const [language, setLanguage] = useState('en');
  const [speaker, setSpeaker] = useState('all');
  const [faces, setFaces] = useState(true);
  const [llm, setLlm] = useState(true);
  return { count, setCount, minLen, setMinLen, maxLen, setMaxLen, cats, setCats, keywords, setKeywords, platform, setPlatform, language, setLanguage, speaker, setSpeaker, faces, setFaces, llm, setLlm };
}
export type ClipSettingsState = ReturnType<typeof useClipSettings>;

export function ClipSettingsPanel({ s, speakers, stream }: { s: ClipSettingsState; speakers: string[]; stream?: boolean }) {
  return (
    <div className="col gap16">
      <div className="card">
        <h3>Output</h3>
        <div className="col gap16">
          <Slider label="Number of clips" value={s.count} min={1} max={500} onChange={s.setCount} />
          <div className="grid g2">
            <Slider label="Min length" value={s.minLen} min={7} max={120} onChange={(v) => { s.setMinLen(v); if (v > s.maxLen) s.setMaxLen(v); }} fmt={(v) => v + 's'} />
            <Slider label="Max length" value={s.maxLen} min={10} max={180} onChange={(v) => { s.setMaxLen(v); if (v < s.minLen) s.setMinLen(v); }} fmt={(v) => (v >= 60 ? fmtTime(v) : v + 's')} />
          </div>
          <div className="dim tiny">▯ Every clip is a 9:16 short. People on camera get a face-tracking crop; gameplay and wide shots show the whole frame on a blurred background so nothing is cut off.</div>
          <div>
            <div className="section-title">Length preset</div>
            <div className="row wrap gap6">
              {PLATFORMS.filter((p) => p.id !== 'all' && p.aspect === '9:16').map((p) => (
                <div key={p.id} className={'chip' + (s.platform === p.id ? ' on' : '')} onClick={() => {
                  s.setPlatform(p.id);
                  const ideal = PLATFORM_IDEAL[p.id];
                  if (ideal && !stream) { s.setMinLen(Math.max(7, Math.round(ideal[0] * 0.6))); s.setMaxLen(Math.min(p.maxLen, Math.round(ideal[1] * 1.4))); }
                }}>
                  <span style={{ width: 8, height: 8, borderRadius: 9, background: p.color }} />{p.name}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="card">
        <h3>What should the AI look for?</h3>
        <div className="row wrap gap6">
          {CATEGORIES.map((c) => (
            <div key={c.id} className={'chip' + (s.cats.includes(c.id) ? ' on' : '')} onClick={() => s.setCats(s.cats.includes(c.id) ? s.cats.filter((x) => x !== c.id) : [...s.cats, c.id])}>{c.emoji} {c.label}</div>
          ))}
        </div>
        <label className="field mt16">Custom keyword triggers <span className="dim" style={{ fontWeight: 400 }}>— e.g. find every time they say “bitcoin”</span>
          <input className="input" placeholder="bitcoin, money, viral" value={s.keywords} onChange={(e) => s.setKeywords(e.target.value)} />
        </label>
      </div>
      <div className="card">
        <h3>Intelligence</h3>
        <div className="grid g2">
          <label className="field">Content language
            <select className="input" value={s.language} onChange={(e) => s.setLanguage(e.target.value)}>{LANGS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
          </label>
          <label className="field">Speaker priority
            <select className="input" value={s.speaker} onChange={(e) => s.setSpeaker(e.target.value)}>
              <option value="all">All speakers equally</option>
              {speakers.map((sp) => <option key={sp} value={sp}>Prioritize {sp}</option>)}
            </select>
          </label>
        </div>
        <div className="mt8">
          <Toggle label="On-device face detection & tracking (MediaPipe)" value={s.faces} onChange={s.setFaces} />
          <Toggle label={<span>LLM re-ranking, titles & hooks {!hasAI() && <span className="badge warn">needs API key</span>}</span>} value={s.llm && hasAI()} onChange={s.setLlm} />
        </div>
      </div>
    </div>
  );
}

export default function ClipVideo() {
  const { go, addSession, settings, toast, logHistory, pendingUrl, setPendingUrl } = useApp();
  const s = useClipSettings(false);
  const [files, setFiles] = useState<SourceFile[]>([]);
  const [over, setOver] = useState(false);
  const [urlIn, setUrlIn] = useState('');
  const [queueUrl, setQueueUrl] = useState('');
  const [dl, setDl] = useState<{ url: string; p: DlProgress | null } | null>(null);
  const dlAbort = useRef<AbortController | null>(null);
  const [srt, setSrt] = useState<Transcript | null>(null);
  const [steps, setSteps] = useState<StepState[] | null>(null);
  const [batchIdx, setBatchIdx] = useState(0);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const srtRef = useRef<HTMLInputElement>(null);

  const addFiles = (list: FileList | File[]) => {
    const arr = Array.from(list).filter((f) => f.type.startsWith('video/') || f.type.startsWith('audio/') || /\.(mp4|mov|webm|mkv|avi|m4v|mp3|wav|m4a|ogg|flv|wmv|3gp)$/i.test(f.name));
    if (!arr.length) { toast('Please drop video or audio files', 'error'); return; }
    setFiles((f) => [...f, ...arr.map((file) => ({ file, name: file.name, url: URL.createObjectURL(file) }))]);
  };
  const useSample = async () => {
    const r = await fetch(import.meta.env.BASE_URL + 'sample/sample.mp4');
    const b = await r.blob();
    setFiles([{ file: b, name: 'The Forge Podcast — Ep. 12 (sample).mp4', url: URL.createObjectURL(b), sample: true }]);
    s.setSpeaker('all');
  };

  const speakers = files.some((f) => f.sample) ? ['Maya', 'Jordan'] : Array.from(new Set((srt?.segments || []).map((x) => x.speaker).filter(Boolean) as string[]));

  /** Download a pasted link; optionally start clipping right away. */
  const importLink = async (raw: string, autoStart: boolean) => {
    if (!raw.trim() || dl) return;
    const ac = new AbortController(); dlAbort.current = ac;
    setDl({ url: raw.trim(), p: null });
    try {
      const r = await fetchRemoteVideo(raw, (p) => setDl((d) => (d ? { ...d, p } : d)), ac.signal);
      const sf: SourceFile = { file: r.blob, name: r.name, url: URL.createObjectURL(r.blob), remote: r.url };
      setDl(null); setUrlIn('');
      if (autoStart) { setFiles([sf]); start([sf]); }
      else { setFiles((f) => [...f, sf]); toast(`Added “${r.name}” to the queue`, 'success'); }
    } catch (e) {
      setDl(null);
      if ((e as Error).name !== 'AbortError') toast((e as Error).message, 'error');
    }
  };
  useEffect(() => {
    if (pendingUrl) { const u = pendingUrl; setPendingUrl(null); setUrlIn(u); importLink(u, true); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingUrl]);

  const start = async (list: SourceFile[] = files) => {
    const files = list;
    if (!files.length) { toast('Add a video first — or paste a link', 'error'); return; }
    setBusy(true);
    let lastId = '';
    for (let i = 0; i < files.length; i++) {
      setBatchIdx(i);
      const f = files[i];
      try {
        const res = await runPipeline({
          file: f.file, url: f.url, audioUrl: f.remote ? audioUrl(f.remote) : undefined, isSample: f.sample, transcript: f.sample ? null : srt, transcribe: hasAI() ? 'whisper' : 'none',
          language: s.language, faces: s.faces, llm: s.llm, localAsr: settings.localAsr ?? 'base',
          settings: { count: s.count, minLen: s.minLen, maxLen: s.maxLen, categories: s.cats, keywords: s.keywords.split(',').map((k) => k.trim()).filter(Boolean), platform: s.platform, speakerPriority: s.speaker },
        }, setSteps);
        const plat = PLATFORMS.find((p) => p.id === s.platform)!;
        const session: ClipSession = {
          id: uid('s_'), name: f.name.replace(/\.[^.]+$/, ''), mode: 'video', url: f.url, file: f.file, duration: res.duration, width: res.width, height: res.height,
          createdAt: Date.now(), transcript: res.transcript, audio: res.audio, visual: res.visual, chat: null, chatLog: [] as ChatMsg[], clips: res.clips,
          platform: s.platform, options: defaultOptions(settings, plat.aspect as '9:16'), exported: [],
        };
        addSession(session);
        res.clips.slice(0, 3).forEach((c) => logHistory({ title: c.title, score: c.score, kind: 'video' }));
        lastId = session.id;
        toast(`✨ ${res.clips.length} clips found in “${session.name}”`, 'success');
      } catch (e) {
        console.error(e);
        toast('Processing failed: ' + (e as Error).message, 'error');
      }
    }
    setBusy(false);
    if (lastId) go({ name: 'results', sessionId: lastId });
  };

  if (dl) {
    const p = dl.p;
    const pct = p && p.total ? p.loaded / p.total : 0;
    const eta = p && p.total && p.speed > 0 ? (p.total - p.loaded) / p.speed : 0;
    return (
      <div className="page" style={{ maxWidth: 780 }}>
        <div className="page-head"><div><h1>Fetching your video…</h1><div className="muted ellipsis" style={{ maxWidth: 700 }}>{dl.url}</div></div></div>
        <div className="card">
          <div className="bar" style={{ height: 10 }}><div style={{ width: `${p?.total ? pct * 100 : 5}%` }} /></div>
          <div className="row between mt8 small">
            <b>{p ? (p.total ? `${Math.round(pct * 100)}%` : fmtBytes(p.loaded)) : 'Connecting…'}</b>
            <span className="muted">{p ? `${fmtBytes(p.loaded)}${p.total ? ' / ' + fmtBytes(p.total) : ''} · ${fmtBytes(p.speed)}/s${eta ? ` · ~${fmtTime(eta)} left` : ''}` : ''}</span>
          </div>
          <div className="dim small mt16">When the download finishes, clipping starts automatically.</div>
          <button className="btn mt16" onClick={() => dlAbort.current?.abort()}><X size={14} /> Cancel</button>
        </div>
      </div>
    );
  }

  if (busy && steps) {
    const done = steps.filter((x) => x.status === 'done' || x.status === 'skip' || x.status === 'error').length;
    return (
      <div className="page" style={{ maxWidth: 780 }}>
        <div className="page-head"><div><h1>Finding your viral moments…</h1><div className="muted">{files[batchIdx]?.name} {files.length > 1 && `· video ${batchIdx + 1} of ${files.length}`}</div></div></div>
        <div className="bar mb8"><div style={{ width: `${(done / steps.length) * 100}%` }} /></div>
        <div className="steps mt16">
          {steps.map((st) => (
            <div key={st.id} className={'step ' + (st.status === 'done' ? 'done' : st.status === 'run' ? 'run' : '')}>
              {st.status === 'run' ? <div className="spin" /> : <span style={{ width: 16, textAlign: 'center' }}>{st.status === 'done' ? '✅' : st.status === 'skip' ? '⏭️' : st.status === 'error' ? '⚠️' : '⏳'}</span>}
              <div className="grow">
                <div style={{ fontWeight: 600 }}>{st.label}</div>
                {st.detail && <div className="small muted">{st.detail}</div>}
                {st.status === 'run' && st.progress !== undefined && <div className="bar mt8" style={{ height: 4 }}><div style={{ width: st.progress * 100 + '%' }} /></div>}
              </div>
            </div>
          ))}
        </div>
        <p className="dim small mt16">{files[batchIdx]?.remote ? 'Linked videos are fetched through your ClipForge server; the analysis runs in your browser' : 'All analysis runs locally in your browser — your video never leaves this device'}{hasAI() ? ' (audio is sent to Whisper for transcription)' : ''}.</p>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-head">
        <div><h1>🎬 Clip from a Video</h1><div className="muted">Paste a link or upload → it finds the best moments → captioned clips.</div></div>
        <button className="btn lg glow" onClick={() => start()} disabled={!files.length}><Sparkles size={18} /> Find {s.count} clip{s.count > 1 ? 's' : ''}</button>
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'minmax(0,1.1fr) minmax(0,1fr)', alignItems: 'start' }}>
        <div className="col gap16">
          <form className="card" style={{ borderColor: '#7c5cff66' }} onSubmit={(e) => { e.preventDefault(); importLink(urlIn, true); }}>
            <h3 className="row"><Link2 size={16} /> Paste a video link</h3>
            <div className="row">
              <input className="input" placeholder="https://github.com/…/releases/download/…/video.mp4" value={urlIn} onChange={(e) => setUrlIn(e.target.value)} />
              <button className="btn glow" type="submit" disabled={!urlIn.trim()}><Sparkles size={16} /> Clip it</button>
            </div>
            <div className="dim tiny mt8">Direct video links: GitHub release files, Dropbox, public Google Drive, S3/R2, any URL ending in .mp4 / .mov / .webm. It downloads and starts clipping automatically.</div>
          </form>
          <div className={'drop' + (over ? ' over' : '')}
            onClick={() => inputRef.current?.click()}
            onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
            onDrop={(e) => { e.preventDefault(); setOver(false); addFiles(e.dataTransfer.files); }}>
            <Upload size={34} color="#b8a6ff" />
            <h2 style={{ margin: '12px 0 4px' }}>Drop videos here</h2>
            <div className="muted">MP4, MOV, WEBM, MKV, M4V, MP3, WAV… — drop several for batch processing</div>
            <div className="row center mt16 gap6">
              <button className="btn primary" onClick={(e) => { e.stopPropagation(); inputRef.current?.click(); }}><Film size={16} /> Choose files</button>
              <button className="btn" onClick={(e) => { e.stopPropagation(); useSample(); }}><Play size={16} /> Try sample podcast</button>
            </div>
            <input ref={inputRef} type="file" multiple accept="video/*,audio/*,.mkv,.mov" hidden onChange={(e) => e.target.files && addFiles(e.target.files)} />
          </div>
          {files.length > 0 && (
            <div className="card tight">
              <div className="section-title">Queue ({files.length})</div>
              {files.map((f, i) => (
                <div key={i} className="row" style={{ padding: '6px 4px' }}>
                  <video src={f.url} muted style={{ width: 72, height: 40, objectFit: 'cover', borderRadius: 6, background: '#000' }} />
                  <div className="grow"><div className="ellipsis" style={{ fontWeight: 600 }}>{f.name}</div><div className="dim small">{fmtBytes(f.file.size)} {f.sample && '· transcript included'}</div></div>
                  <button className="btn ghost sm icon" onClick={() => setFiles(files.filter((_, k) => k !== i))}><X size={14} /></button>
                </div>
              ))}
            </div>
          )}
          <div className="card">
            <h3 className="row"><Link2 size={16} /> Add a link to the queue</h3>
            <div className="row">
              <input className="input" placeholder="Another direct video link (for batch processing)" value={queueUrl} onChange={(e) => setQueueUrl(e.target.value)} />
              <button className="btn" disabled={!queueUrl.trim()} onClick={() => { importLink(queueUrl, false); setQueueUrl(''); }}>Add to queue</button>
            </div>
          </div>
          <div className="card">
            <h3 className="row"><FileText size={16} /> Transcript source</h3>
            {hasAI() ? <div className="row small"><span className="badge ok">Whisper API ready</span><span className="muted">The whole video is transcribed with word-level timestamps.</span></div>
              : (settings.localAsr ?? 'base') !== 'off' ? <div className="row small wrap"><span className="badge ok">✓ Free subtitles</span><span className="muted">No key needed — Whisper runs on your device and subtitles the chosen clips automatically. The speech model downloads once (~{(settings.localAsr ?? 'base') === 'tiny' ? 40 : 76} MB), then it's cached.</span></div>
              : <div className="row small wrap"><span className="badge warn"><KeyRound size={11} /> subtitles off</span><span className="muted">Turn on free on-device subtitles in Settings, or import an .srt.</span></div>}
            <div className="row mt8">
              <button className="btn sm" onClick={() => srtRef.current?.click()}><FileText size={13} /> Import .srt / .vtt</button>
              {srt && <span className="badge ok">{srt.segments.length} subtitle lines loaded</span>}

            </div>
            <input ref={srtRef} type="file" accept=".srt,.vtt,text/vtt" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) { setSrt(parseSubtitles(await f.text())); toast('Subtitles imported', 'success'); } }} />
          </div>
        </div>
        <ClipSettingsPanel s={s} speakers={speakers} />
      </div>
    </div>
  );
}

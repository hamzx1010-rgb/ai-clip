import { useInstall } from '../lib/mobile';
import { useEffect, useState } from 'react';
import { Film, Radio, Wand2, Plus, Trash2, Copy, Flame, HardDrive, Sparkles, ArrowRight, Scissors, Download } from 'lucide-react';
import { useApp } from '../store';
import { Empty, ScoreRing } from '../components/ui';
import { deleteProject, listProjects, loadProject, saveProject, type ProjectMeta } from './editor/store';
import { fmtBytes, fmtTime, uid } from '../lib/util';
import { deleteSession, listSessions, onSessionsChanged, type SessionMeta } from '../lib/sessionStore';

export default function Dashboard() {
  const { go, open, history } = useApp();
  const [projects, setProjects] = useState<ProjectMeta[] | null>(null);
  const [saved, setSaved] = useState<SessionMeta[] | null>(null);
  const [showAll, setShowAll] = useState(false);
  const [storage, setStorage] = useState<{ usage: number; quota: number } | null>(null);
  const refresh = () => listProjects().then(setProjects);
  const active = useApp((st) => st.route.name === 'dashboard');
  useEffect(() => {
    if (!active) return;
    const load = () => { listSessions().then(setSaved); refresh(); navigator.storage?.estimate?.().then((e) => setStorage({ usage: e.usage || 0, quota: e.quota || 0 })); };
    load(); // refresh every time you come back to the Dashboard…
    const off = onSessionsChanged(load); // …and when clips finish in another tab
    const vis = () => { if (document.visibilityState === 'visible') load(); };
    document.addEventListener('visibilitychange', vis);
    return () => { off(); document.removeEventListener('visibilitychange', vis); };
  }, [active]);

  const sess = saved || [];
  const totalClips = sess.reduce((a, m) => a + m.clips, 0);
  const scored = history.filter((h) => h.score > 0);
  const avg = scored.length ? Math.round(scored.reduce((a, b) => a + b.score, 0) / scored.length) : 0;
  const hour = new Date().getHours();
  const inst = useInstall();
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>{greet} 👋</h1>
          <div className="muted">What are we making today?<span className="hide-ph"> <span className="kbd">Ctrl</span> + <span className="kbd">K</span> for quick actions.</span></div>
        </div>
        {inst.can && <button className="btn primary" onClick={inst.install}><Download size={15} /> Install app</button>}
      </div>

      <div className="grid g3">
        {[
          { r: 'clip-video' as const, icon: <Film size={26} />, t: 'Clip from Video', d: 'Upload a podcast, vlog or webinar → get viral shorts with captions & virality scores.', c: '#7c5cff' },
          { r: 'clip-stream' as const, icon: <Radio size={26} />, t: 'Clip from Livestream', d: 'Twitch / YouTube / Kick VODs or monitor a live stream and auto-capture hype moments.', c: '#ff4f6d' },
          { r: 'director' as const, icon: <Wand2 size={26} />, t: 'AI Director', d: 'Describe a video → the AI researches, writes, narrates, finds footage and edits a full 9:16 documentary.', c: '#3ddc97' },
        ].map((m) => (
          <div key={m.r} className="card mode-card" style={{ cursor: 'pointer', borderColor: m.c + '44', background: `linear-gradient(160deg, ${m.c}22, transparent 60%), var(--panel)` }} onClick={() => open({ name: m.r } as never)}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: m.c + '33', color: m.c, display: 'grid', placeItems: 'center' }}>{m.icon}</div>
            <h3 style={{ margin: '14px 0 6px' }}>{m.t}</h3>
            <div className="muted small">{m.d}</div>
            <div className="row gap4 mt16 small" style={{ color: m.c, fontWeight: 700 }}>Start <ArrowRight size={14} /></div>
          </div>
        ))}
      </div>

      <div className="grid g4 mt16">
        <Stat icon={<Sparkles size={16} />} label="Clips generated" value={String(totalClips)} sub={`${sess.length} video${sess.length === 1 ? '' : 's'} in your history`} />
        <Stat icon={<Flame size={16} />} label="Avg. virality score" value={avg ? String(avg) : '—'} sub={avg >= 80 ? 'Excellent 🔥' : avg ? 'Keep optimizing' : 'No clips yet'} />
        <Stat icon={<Scissors size={16} />} label="Clips exported" value={String(history.filter((h) => h.kind === 'export').length)} sub="all time" />
        <Stat icon={<HardDrive size={16} />} label="Clip history" value="∞ Unlimited" sub={storage ? `${fmtBytes(storage.usage)} used · old videos auto-freed, clips kept forever` : 'Clips are kept forever'} />
      </div>

      <div className="mt16">
        <div className="card">
          <div className="row between mb8">
            <h3 style={{ margin: 0 }}>🕘 Clip history</h3>
            <button className="btn sm" onClick={() => open({ name: 'clip-video' })}><Plus size={13} /> New</button>
          </div>
          {saved === null ? <div className="spin" /> : sess.length ? (
            <div className="col gap6">
              {(showAll ? sess : sess.slice(0, 8)).map((m) => (
                <div key={m.id} className="clip-card" onClick={() => go({ name: 'results', sessionId: m.id })}>
                  {m.thumb ? <img src={m.thumb} alt="" style={{ width: 36, height: 64, objectFit: 'cover', borderRadius: 6, flex: 'none' }} /> : <ScoreRing score={m.top} size={42} stroke={4} />}
                  <div className="grow" style={{ minWidth: 0 }}>
                    <b className="ellipsis" style={{ display: 'block' }}>{m.name}</b>
                    <div className="dim tiny ellipsis">{m.clips} clip{m.clips === 1 ? '' : 's'} · best {m.top} · {new Date(m.createdAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}{m.hasFile ? ` · ${fmtBytes(m.bytes)}` : ' · source removed'}</div>
                    {m.titles[0] && <div className="tiny muted ellipsis">“{m.titles[0]}”{m.titles.length > 1 ? ` +${m.clips - 1} more` : ''}</div>}
                  </div>
                  <span className="badge" style={{ alignSelf: 'center', flex: 'none', whiteSpace: 'nowrap' }}>{m.mode === 'stream' ? '🎮 stream' : '🎬 video'}</span>
                  <button className="btn ghost sm icon" style={{ alignSelf: 'center' }} title="Delete from history" onClick={async (e) => { e.stopPropagation(); if (!confirm(`Delete “${m.name}” and its clips from your history?`)) return; useApp.getState().removeSession(m.id); await deleteSession(m.id); }}><Trash2 size={12} /></button>
                </div>
              ))}
              {sess.length > 8 && <button className="btn ghost sm" onClick={() => setShowAll(!showAll)}>{showAll ? 'Show less' : `Show all ${sess.length}`}</button>}
              <div className="dim tiny">Saved in this browser with the source video, so you can reopen, re-edit and re-export any time.</div>
            </div>
          ) : (
            <Empty icon={<Film size={28} />} title="No clips yet">Upload a video or try the sample podcast. Every result is saved here so you can come back to it.
              <div className="mt16"><button className="btn primary" onClick={() => open({ name: 'clip-video' })}>Clip my first video</button></div>
            </Empty>
          )}
        </div>
      </div>

      <div className="card mt16">
        <div className="row between mb8">
          <h3 style={{ margin: 0 }}>Editor projects</h3>
          <button className="btn sm primary" onClick={() => open({ name: 'editor' })}><Plus size={13} /> New project</button>
        </div>
        {projects === null ? <div className="spin" /> : projects.length ? (
          <div className="grid g4">
            {projects.map((pr) => (
              <div key={pr.id} className="card tight" style={{ cursor: 'pointer', padding: 0, overflow: 'hidden' }} onClick={() => open({ name: 'editor', projectId: pr.id })}>
                <div style={{ height: 140, background: '#000', display: 'grid', placeItems: 'center' }}>
                  {pr.thumb ? <img src={pr.thumb} style={{ maxHeight: '100%', maxWidth: '100%' }} /> : <Wand2 size={26} color="#555" />}
                </div>
                <div style={{ padding: 10 }}>
                  <b className="ellipsis small" style={{ display: 'block' }}>{pr.name}</b>
                  <div className="row between">
                    <span className="dim tiny">{pr.w}×{pr.h} · {pr.items} items · {new Date(pr.updatedAt).toLocaleDateString()}</span>
                    <span className="row gap4" onClick={(e) => e.stopPropagation()}>
                      <button className="btn ghost sm icon" title="Duplicate" onClick={async () => { const p = await loadProject(pr.id); if (p) { await saveProject({ ...p, id: uid('proj_'), name: p.name + ' (copy)' }, pr.thumb); refresh(); } }}><Copy size={12} /></button>
                      <button className="btn ghost sm icon" title="Delete" onClick={async () => { if (confirm(`Delete “${pr.name}”?`)) { await deleteProject(pr.id); refresh(); } }}><Trash2 size={12} /></button>
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : <div className="dim small">No projects yet. Projects autosave to your browser every few seconds with version history.</div>}
      </div>
    </div>
  );
}

function Stat({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub: string }) {
  return (
    <div className="card tight">
      <div className="row gap6 muted small">{icon}{label}</div>
      <div style={{ fontSize: 28, fontWeight: 800, marginTop: 6 }}>{value}</div>
      <div className="dim tiny">{sub}</div>
    </div>
  );
}


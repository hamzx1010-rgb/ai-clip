import { useEffect, useMemo, useState } from 'react';
import { Film, Radio, Wand2, Plus, Trash2, Copy, CalendarDays, Flame, HardDrive, Coins, TrendingUp, Clock, Sparkles, ArrowRight } from 'lucide-react';
import { useApp, PLATFORMS } from '../store';
import { Empty, ScoreRing, Sparkline } from '../components/ui';
import { deleteProject, listProjects, loadProject, saveProject, type ProjectMeta } from './editor/store';
import { fmtBytes, fmtTime, seeded, uid } from '../lib/util';

export default function Dashboard() {
  const { go, sessions, history, posts, credits, settings } = useApp();
  const [projects, setProjects] = useState<ProjectMeta[] | null>(null);
  const [storage, setStorage] = useState<{ usage: number; quota: number } | null>(null);
  const refresh = () => listProjects().then(setProjects);
  useEffect(() => {
    refresh();
    navigator.storage?.estimate?.().then((e) => setStorage({ usage: e.usage || 0, quota: e.quota || 0 }));
  }, []);

  const allClips = sessions.flatMap((s) => s.clips.map((c) => ({ ...c, session: s })));
  const scored = history.filter((h) => h.score > 0);
  const avg = scored.length ? Math.round(scored.reduce((a, b) => a + b.score, 0) / scored.length) : allClips.length ? Math.round(allClips.reduce((a, c) => a + c.score, 0) / allClips.length) : 0;
  const now = Date.now();
  const upcoming = posts.filter((p) => p.status === 'scheduled' && +new Date(p.when) >= now && +new Date(p.when) < now + 7 * 864e5).sort((a, b) => +new Date(a.when) - +new Date(b.when));
  const demo = useMemo(() => { const r = seeded(7); let v = 1200; return Array.from({ length: 30 }, (_, i) => (v = Math.max(300, v * (0.92 + r() * 0.2) + i * 40 + (i === 21 ? 9000 : 0)))); }, []);
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>{greet}, {settings.handle.replace('@', '') || 'creator'} 👋</h1>
          <div className="muted">What are we making today? <span className="kbd">Ctrl</span> + <span className="kbd">K</span> for quick actions.</div>
        </div>
        <div className="row gap6"><span className="badge brand"><Coins size={12} /> {credits} credits</span><span className="badge">Pro trial</span></div>
      </div>

      <div className="grid g3">
        {[
          { r: 'clip-video' as const, icon: <Film size={26} />, t: 'Clip from Video', d: 'Upload a podcast, vlog or webinar → get viral shorts with captions & virality scores.', c: '#7c5cff' },
          { r: 'clip-stream' as const, icon: <Radio size={26} />, t: 'Clip from Livestream', d: 'Twitch / YouTube / Kick VODs or monitor a live stream and auto-capture hype moments.', c: '#ff4f6d' },
          { r: 'editor' as const, icon: <Wand2 size={26} />, t: 'Create from Scratch', d: 'Multi-track editor with templates, animated text, stickers, music, keyframes & AI tools.', c: '#3ddc97' },
        ].map((m) => (
          <div key={m.r} className="card mode-card" style={{ cursor: 'pointer', borderColor: m.c + '44', background: `linear-gradient(160deg, ${m.c}22, transparent 60%), var(--panel)` }} onClick={() => go({ name: m.r } as never)}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: m.c + '33', color: m.c, display: 'grid', placeItems: 'center' }}>{m.icon}</div>
            <h3 style={{ margin: '14px 0 6px' }}>{m.t}</h3>
            <div className="muted small">{m.d}</div>
            <div className="row gap4 mt16 small" style={{ color: m.c, fontWeight: 700 }}>Start <ArrowRight size={14} /></div>
          </div>
        ))}
      </div>

      <div className="grid g4 mt16">
        <Stat icon={<Sparkles size={16} />} label="Clips generated" value={String(Math.max(allClips.length, history.filter((h) => h.kind !== 'editor').length))} sub={`${sessions.length} sessions this visit`} />
        <Stat icon={<Flame size={16} />} label="Avg. virality score" value={avg ? String(avg) : '—'} sub={avg >= 80 ? 'Excellent 🔥' : avg ? 'Keep optimizing' : 'No clips yet'} />
        <Stat icon={<CalendarDays size={16} />} label="Scheduled posts" value={String(posts.filter((p) => p.status === 'scheduled').length)} sub={`${upcoming.length} in the next 7 days`} />
        <Stat icon={<HardDrive size={16} />} label="Local storage" value={storage ? fmtBytes(storage.usage) : '—'} sub={storage ? `of ${fmtBytes(storage.quota)} available` : 'Estimating…'} />
      </div>

      <div className="grid g2 mt16" style={{ gridTemplateColumns: '1.4fr 1fr' }}>
        <div className="card">
          <div className="row between mb8"><h3 style={{ margin: 0 }}>Recent clips</h3><button className="btn sm" onClick={() => go({ name: 'clip-video' })}><Plus size={13} /> New</button></div>
          {allClips.length ? (
            <div className="col gap6">
              {allClips.sort((a, b) => b.score - a.score).slice(0, 6).map((c) => (
                <div key={c.id} className="clip-card" onClick={() => go({ name: 'results', sessionId: c.session.id })}>
                  <ScoreRing score={c.score} size={42} stroke={4} />
                  <div className="grow" style={{ minWidth: 0 }}>
                    <b className="ellipsis" style={{ display: 'block' }}>{c.title}</b>
                    <div className="dim tiny">{c.session.name} · {fmtTime(c.end - c.start)} · {c.categories.slice(0, 2).join(', ')}</div>
                  </div>
                  <span className="badge">{c.session.mode === 'stream' ? '🎮 stream' : '🎬 video'}</span>
                </div>
              ))}
            </div>
          ) : history.length ? (
            <div className="col gap6">
              {history.slice(0, 6).map((h) => (
                <div key={h.id} className="row between card tight">
                  <div><b className="small">{h.title}</b><div className="dim tiny">{h.kind} · {new Date(h.at).toLocaleString()}</div></div>
                  {h.score > 0 && <span className="badge ok">{h.score}</span>}
                </div>
              ))}
              <div className="dim tiny">Clip sessions (source video + analysis) live in memory for this visit; exports are logged here.</div>
            </div>
          ) : (
            <Empty icon={<Film size={28} />} title="No clips yet">Upload a video or try the sample podcast — you'll have viral-ready clips in under a minute.
              <div className="mt16"><button className="btn primary" onClick={() => go({ name: 'clip-video' })}>Clip my first video</button></div>
            </Empty>
          )}
        </div>
        <div className="col gap16">
          <div className="card">
            <div className="row between mb8"><h3 style={{ margin: 0 }}>Next 7 days</h3><button className="btn sm ghost" onClick={() => go({ name: 'publish' })}>Calendar <ArrowRight size={12} /></button></div>
            {upcoming.length ? upcoming.slice(0, 5).map((p) => {
              const pl = PLATFORMS.find((x) => x.id === p.platform);
              return (
                <div key={p.id} className="row gap6" style={{ padding: '6px 0', borderBottom: '1px solid var(--line)' }}>
                  <span style={{ width: 8, height: 8, borderRadius: 9, background: pl?.color || '#7c5cff' }} />
                  <span className="small grow ellipsis">{p.clipTitle}</span>
                  <span className="tiny dim"><Clock size={10} /> {new Date(p.when).toLocaleString([], { weekday: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              );
            }) : <div className="dim small">Nothing scheduled. Schedule clips from any results page or the Publish calendar.</div>}
          </div>
          <div className="card">
            <div className="row between"><h3 style={{ margin: 0 }}>Views (30 days)</h3><span className="badge warn">demo data</span></div>
            <div className="row gap6 mt8"><b style={{ fontSize: 26 }}>{Math.round(demo.reduce((a, b) => a + b, 0) / 1000)}K</b><span className="badge ok"><TrendingUp size={11} /> +38%</span></div>
            <Sparkline data={demo} h={70} color="#7c5cff" />
            <div className="dim tiny">Connect accounts in Publish to see real analytics.</div>
          </div>
        </div>
      </div>

      <div className="card mt16">
        <div className="row between mb8">
          <h3 style={{ margin: 0 }}>Editor projects</h3>
          <button className="btn sm primary" onClick={() => go({ name: 'editor' })}><Plus size={13} /> New project</button>
        </div>
        {projects === null ? <div className="spin" /> : projects.length ? (
          <div className="grid g4">
            {projects.map((pr) => (
              <div key={pr.id} className="card tight" style={{ cursor: 'pointer', padding: 0, overflow: 'hidden' }} onClick={() => go({ name: 'editor', projectId: pr.id })}>
                <div style={{ height: 140, background: '#000', display: 'grid', placeItems: 'center' }}>
                  {pr.thumb ? <img src={pr.thumb} style={{ maxHeight: '100%', maxWidth: '100%' }} /> : <Wand2 size={26} color="#555" />}
                </div>
                <div style={{ padding: 10 }}>
                  <b className="ellipsis small" style={{ display: 'block' }}>{pr.name}</b>
                  <div className="row between">
                    <span className="dim tiny">{pr.w}×{pr.h} · {pr.items} items · {new Date(pr.updatedAt).toLocaleDateString()}</span>
                    <span className="row gap4" onClick={(e) => e.stopPropagation()}>
                      <button className="btn ghost sm icon" title="Duplicate" onClick={async () => { const p = await loadProject(pr.id); if (p) { await saveProject({ ...p, id: uid('proj_'), name: p.name + ' (copy)' }, pr.thumb); refresh(); } }}><Copy size={12} /></button>
                      <button className="btn ghost sm icon" title="Delete" onClick={async () => { if (confirm(`Delete “${pr.name}”?`)) { await deleteProject(pr.id); refresh(); } }}><Trash2 size={12} /></button>
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : <div className="dim small">No projects yet. Projects autosave to your browser every few seconds with version history.</div>}
      </div>
    </div>
  );
}

function Stat({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub: string }) {
  return (
    <div className="card tight">
      <div className="row gap6 muted small">{icon}{label}</div>
      <div style={{ fontSize: 28, fontWeight: 800, marginTop: 6 }}>{value}</div>
      <div className="dim tiny">{sub}</div>
    </div>
  );
}


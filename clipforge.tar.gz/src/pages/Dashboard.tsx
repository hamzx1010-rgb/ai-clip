import { useEffect, useState } from 'react';
import { Film, Radio, Wand2, Plus, Trash2, Copy, Flame, HardDrive, Sparkles, ArrowRight, Scissors } from 'lucide-react';
import { useApp } from '../store';
import { Empty, ScoreRing } from '../components/ui';
import { deleteProject, listProjects, loadProject, saveProject, type ProjectMeta } from './editor/store';
import { fmtBytes, fmtTime, uid } from '../lib/util';

export default function Dashboard() {
  const { go, sessions, history } = useApp();
  const [projects, setProjects] = useState<ProjectMeta[] | null>(null);
  const [storage, setStorage] = useState<{ usage: number; quota: number } | null>(null);
  const refresh = () => listProjects().then(setProjects);
  useEffect(() => {
    refresh();
    navigator.storage?.estimate?.().then((e) => setStorage({ usage: e.usage || 0, quota: e.quota || 0 }));
  }, []);

  const allClips = sessions.flatMap((s) => s.clips.map((c) => ({ ...c, session: s })));
  const scored = history.filter((h) => h.score > 0);
  const avg = scored.length ? Math.round(scored.reduce((a, b) => a + b.score, 0) / scored.length) : allClips.length ? Math.round(allClips.reduce((a, c) => a + c.score, 0) / allClips.length) : 0;
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>{greet} 👋</h1>
          <div className="muted">What are we making today? <span className="kbd">Ctrl</span> + <span className="kbd">K</span> for quick actions.</div>
        </div>
      </div>

      <div className="grid g3">
        {[
          { r: 'clip-video' as const, icon: <Film size={26} />, t: 'Clip from Video', d: 'Upload a podcast, vlog or webinar → get viral shorts with captions & virality scores.', c: '#7c5cff' },
          { r: 'clip-stream' as const, icon: <Radio size={26} />, t: 'Clip from Livestream', d: 'Twitch / YouTube / Kick VODs or monitor a live stream and auto-capture hype moments.', c: '#ff4f6d' },
          { r: 'director' as const, icon: <Wand2 size={26} />, t: 'AI Director', d: 'Describe a video → the AI researches, writes, narrates, finds footage and edits a full 9:16 documentary.', c: '#3ddc97' },
        ].map((m) => (
          <div key={m.r} className="card mode-card" style={{ cursor: 'pointer', borderColor: m.c + '44', background: `linear-gradient(160deg, ${m.c}22, transparent 60%), var(--panel)` }} onClick={() => go({ name: m.r } as never)}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: m.c + '33', color: m.c, display: 'grid', placeItems: 'center' }}>{m.icon}</div>
            <h3 style={{ margin: '14px 0 6px' }}>{m.t}</h3>
            <div className="muted small">{m.d}</div>
            <div className="row gap4 mt16 small" style={{ color: m.c, fontWeight: 700 }}>Start <ArrowRight size={14} /></div>
          </div>
        ))}
      </div>

      <div className="grid g4 mt16">
        <Stat icon={<Sparkles size={16} />} label="Clips generated" value={String(Math.max(allClips.length, history.filter((h) => h.kind !== 'editor').length))} sub={`${sessions.length} sessions this visit`} />
        <Stat icon={<Flame size={16} />} label="Avg. virality score" value={avg ? String(avg) : '—'} sub={avg >= 80 ? 'Excellent 🔥' : avg ? 'Keep optimizing' : 'No clips yet'} />
        <Stat icon={<Scissors size={16} />} label="Clips exported" value={String(history.filter((h) => h.kind === 'export').length)} sub="all time" />
        <Stat icon={<HardDrive size={16} />} label="Local storage" value={storage ? fmtBytes(storage.usage) : '—'} sub={storage ? `of ${fmtBytes(storage.quota)} available` : 'Estimating…'} />
      </div>

      <div className="mt16">
        <div className="card">
          <div className="row between mb8"><h3 style={{ margin: 0 }}>Recent clips</h3><button className="btn sm" onClick={() => go({ name: 'clip-video' })}><Plus size={13} /> New</button></div>
          {allClips.length ? (
            <div className="col gap6">
              {allClips.sort((a, b) => b.score - a.score).slice(0, 6).map((c) => (
                <div key={c.id} className="clip-card" onClick={() => go({ name: 'results', sessionId: c.session.id })}>
                  <ScoreRing score={c.score} size={42} stroke={4} />
                  <div className="grow" style={{ minWidth: 0 }}>
                    <b className="ellipsis" style={{ display: 'block' }}>{c.title}</b>
                    <div className="dim tiny">{c.session.name} · {fmtTime(c.end - c.start)} · {c.categories.slice(0, 2).join(', ')}</div>
                  </div>
                  <span className="badge">{c.session.mode === 'stream' ? '🎮 stream' : '🎬 video'}</span>
                </div>
              ))}
            </div>
          ) : history.length ? (
            <div className="col gap6">
              {history.slice(0, 6).map((h) => (
                <div key={h.id} className="row between card tight">
                  <div><b className="small">{h.title}</b><div className="dim tiny">{h.kind} · {new Date(h.at).toLocaleString()}</div></div>
                  {h.score > 0 && <span className="badge ok">{h.score}</span>}
                </div>
              ))}
              <div className="dim tiny">Clip sessions (source video + analysis) live in memory for this visit; exports are logged here.</div>
            </div>
          ) : (
            <Empty icon={<Film size={28} />} title="No clips yet">Upload a video or try the sample podcast — you'll have viral-ready clips in under a minute.
              <div className="mt16"><button className="btn primary" onClick={() => go({ name: 'clip-video' })}>Clip my first video</button></div>
            </Empty>
          )}
        </div>
      </div>

      <div className="card mt16">
        <div className="row between mb8">
          <h3 style={{ margin: 0 }}>Editor projects</h3>
          <button className="btn sm primary" onClick={() => go({ name: 'editor' })}><Plus size={13} /> New project</button>
        </div>
        {projects === null ? <div className="spin" /> : projects.length ? (
          <div className="grid g4">
            {projects.map((pr) => (
              <div key={pr.id} className="card tight" style={{ cursor: 'pointer', padding: 0, overflow: 'hidden' }} onClick={() => go({ name: 'editor', projectId: pr.id })}>
                <div style={{ height: 140, background: '#000', display: 'grid', placeItems: 'center' }}>
                  {pr.thumb ? <img src={pr.thumb} style={{ maxHeight: '100%', maxWidth: '100%' }} /> : <Wand2 size={26} color="#555" />}
                </div>
                <div style={{ padding: 10 }}>
                  <b className="ellipsis small" style={{ display: 'block' }}>{pr.name}</b>
                  <div className="row between">
                    <span className="dim tiny">{pr.w}×{pr.h} · {pr.items} items · {new Date(pr.updatedAt).toLocaleDateString()}</span>
                    <span className="row gap4" onClick={(e) => e.stopPropagation()}>
                      <button className="btn ghost sm icon" title="Duplicate" onClick={async () => { const p = await loadProject(pr.id); if (p) { await saveProject({ ...p, id: uid('proj_'), name: p.name + ' (copy)' }, pr.thumb); refresh(); } }}><Copy size={12} /></button>
                      <button className="btn ghost sm icon" title="Delete" onClick={async () => { if (confirm(`Delete “${pr.name}”?`)) { await deleteProject(pr.id); refresh(); } }}><Trash2 size={12} /></button>
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : <div className="dim small">No projects yet. Projects autosave to your browser every few seconds with version history.</div>}
      </div>
    </div>
  );
}

function Stat({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub: string }) {
  return (
    <div className="card tight">
      <div className="row gap6 muted small">{icon}{label}</div>
      <div style={{ fontSize: 28, fontWeight: 800, marginTop: 6 }}>{value}</div>
      <div className="dim tiny">{sub}</div>
    </div>
  );
}


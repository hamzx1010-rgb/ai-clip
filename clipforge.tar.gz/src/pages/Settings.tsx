import { useEffect, useRef, useState } from 'react';
import { KeyRound, Palette, Download, HardDrive, CreditCard, Moon, Sun, Upload, Trash2, Check, Sparkles, Users } from 'lucide-react';
import { clear } from 'idb-keyval';
import { useApp } from '../store';
import { CaptionStylePicker, Seg } from '../components/ui';
import { chatJSON } from '../lib/llm';
import { FONT_LIST } from '../lib/captions';
import { fmtBytes } from '../lib/util';

const PLANS = [
  { id: 'free', name: 'Free', price: '$0', credits: 60, feats: ['60 min / month', '720p export', 'Watermark', '5 caption styles'] },
  { id: 'creator', name: 'Creator', price: '$19', credits: 600, feats: ['10 hrs / month', '1080p, no watermark', 'All caption styles', 'Scheduling'] },
  { id: 'pro', name: 'Pro', price: '$49', credits: 2000, feats: ['Unlimited clips', '4K export', 'Livestream monitor', 'API access', 'Analytics'] },
  { id: 'business', name: 'Business', price: '$99', credits: 6000, feats: ['Team seats (5)', 'Brand kits', 'Approval workflows', 'Priority support'] },
  { id: 'enterprise', name: 'Enterprise', price: 'Custom', credits: 0, feats: ['SSO / SAML', 'Dedicated infra', 'Custom AI models', 'SLA'] },
  { id: 'payg', name: 'Pay-as-you-go', price: '$0.50/clip', credits: 0, feats: ['No subscription', 'Top up anytime', 'All Creator features'] },
];

export default function SettingsPage() {
  const { settings, setSettings, toast, credits } = useApp();
  const [plan, setPlan] = useState(() => localStorage.getItem('cf-plan') || 'free');
  const [testing, setTesting] = useState(false);
  const [storage, setStorage] = useState<{ usage: number; quota: number } | null>(null);
  const logoRef = useRef<HTMLInputElement>(null);
  useEffect(() => { navigator.storage?.estimate?.().then((e) => setStorage({ usage: e.usage || 0, quota: e.quota || 0 })); }, []);

  const testKey = async () => {
    setTesting(true);
    try { const r = await chatJSON<{ ok: boolean }>('Reply with JSON {"ok":true}', 'ping'); toast(r.ok ? '✅ API key works' : 'Unexpected response', r.ok ? 'success' : 'error'); }
    catch (e) { toast('API error: ' + (e as Error).message, 'error'); }
    setTesting(false);
  };
  const upgrade = (id: string) => {
    const p = PLANS.find((x) => x.id === id)!;
    if (id === 'enterprise') { toast('📧 Our sales team will reach out (demo)', 'success'); return; }
    setPlan(id); localStorage.setItem('cf-plan', id);
    if (p.credits) useApp.setState({ credits: credits + p.credits });
    toast(`🎉 Switched to ${p.name} (simulated checkout)`, 'success');
  };

  return (
    <div className="page" style={{ maxWidth: 1100 }}>
      <div className="page-head"><div><h1>Brand Kit & Settings</h1><div className="muted">Everything is stored locally in your browser.</div></div></div>

      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="col gap16">
          <Section icon={<Palette size={16} />} title="Brand kit">
            <div className="row gap16">
              <div onClick={() => logoRef.current?.click()} style={{ width: 72, height: 72, borderRadius: 16, border: '1px dashed var(--line2)', display: 'grid', placeItems: 'center', cursor: 'pointer', overflow: 'hidden', background: 'var(--bg2)' }}>
                {settings.logo ? <img src={settings.logo} style={{ width: '100%', height: '100%', objectFit: 'contain' }} /> : <Upload size={18} color="var(--dim)" />}
              </div>
              <div className="col gap6 grow">
                <label className="field">Handle / watermark<input className="input" value={settings.handle} onChange={(e) => setSettings({ handle: e.target.value })} /></label>
                {settings.logo && <button className="btn ghost sm" style={{ alignSelf: 'flex-start' }} onClick={() => setSettings({ logo: '' })}>Remove logo</button>}
              </div>
              <input ref={logoRef} type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; const r = new FileReader(); r.onload = () => setSettings({ logo: String(r.result) }); r.readAsDataURL(f); }} />
            </div>
            <div className="grid g3 mt16">
              <label className="field">Primary<input type="color" value={settings.brandColor} onChange={(e) => setSettings({ brandColor: e.target.value })} /></label>
              <label className="field">Accent<input type="color" value={settings.brandAccent} onChange={(e) => setSettings({ brandAccent: e.target.value })} /></label>
              <label className="field">Font<select className="input sm" value={settings.brandFont} onChange={(e) => setSettings({ brandFont: e.target.value })}>{FONT_LIST.map((f) => <option key={f}>{f}</option>)}</select></label>
            </div>
            <div className="mt16 card tight row gap16" style={{ background: `linear-gradient(135deg, ${settings.brandColor}33, ${settings.brandAccent}22)` }}>
              {settings.logo && <img src={settings.logo} style={{ height: 36 }} />}
              <div><div style={{ fontFamily: settings.brandFont, fontWeight: 900, fontSize: 20, color: settings.brandAccent }}>YOUR HOOK HERE</div><div className="small" style={{ color: settings.brandColor, fontWeight: 700 }}>{settings.handle}</div></div>
            </div>
            <div className="section-title mt16">Default caption style</div>
            <CaptionStylePicker value={settings.defaultCaption} onChange={(id) => setSettings({ defaultCaption: id })} />
          </Section>
        </div>

        <div className="col gap16">
          <Section icon={<KeyRound size={16} />} title="AI providers">
            <div className="muted small mb8">Optional. Without a key ClipForge runs its on-device analysis (audio energy, faces, motion, lexicon scoring). With a key you unlock Whisper transcription, GPT titles/hooks re-ranking, TTS voices and image generation.</div>
            <label className="field">OpenAI-compatible API key<input className="input mono" type="password" placeholder="sk-…" value={settings.openaiKey} onChange={(e) => setSettings({ openaiKey: e.target.value.trim() })} /></label>
            <div className="grid g2 mt8">
              <label className="field">Base URL<input className="input sm mono" value={settings.openaiBase} onChange={(e) => setSettings({ openaiBase: e.target.value })} /></label>
              <label className="field">Chat model<input className="input sm mono" value={settings.llmModel} onChange={(e) => setSettings({ llmModel: e.target.value })} /></label>
            </div>
            <div className="row gap6 mt8">
              <button className="btn sm" disabled={!settings.openaiKey || testing} onClick={testKey}>{testing ? 'Testing…' : 'Test connection'}</button>
              {settings.openaiKey && <span className="badge ok"><Check size={11} /> key saved locally</span>}
            </div>
            <label className="field mt16">Pexels API key (stock media in editor)<input className="input sm mono" type="password" value={settings.pexelsKey || ''} onChange={(e) => setSettings({ pexelsKey: e.target.value.trim() })} /></label>
          </Section>

          <Section icon={settings.theme === 'dark' ? <Moon size={16} /> : <Sun size={16} />} title="Appearance & export">
            <div className="row between"><span className="small">Theme</span><Seg value={settings.theme} options={[{ v: 'dark', l: '🌙 Dark' }, { v: 'light', l: '☀️ Light' }]} onChange={(v) => setSettings({ theme: v })} /></div>
            <div className="row between mt16"><span className="small row gap6"><Download size={14} /> Default clip export</span><Seg value={settings.exportRes} options={[{ v: 720, l: '720p' }, { v: 1080, l: '1080p' }]} onChange={(v) => setSettings({ exportRes: v })} /></div>
          </Section>

          <Section icon={<HardDrive size={16} />} title="Storage & privacy">
            <div className="small muted">{storage ? `${fmtBytes(storage.usage)} used of ${fmtBytes(storage.quota)} browser quota.` : 'Estimating…'} Videos never leave your device unless you enable an AI provider.</div>
            <div className="row between mt8"><span className="small">Auto-delete processed sources after</span>
              <select className="input sm" style={{ width: 120 }} value={settings.autoDeleteDays} onChange={(e) => setSettings({ autoDeleteDays: +e.target.value })}>{[7, 14, 30, 90, 0].map((d) => <option key={d} value={d}>{d ? `${d} days` : 'Never'}</option>)}</select>
            </div>
            <button className="btn danger sm mt16" onClick={async () => { if (!confirm('Delete all projects, media, settings and history from this browser?')) return; await clear(); localStorage.removeItem('clipforge-app'); localStorage.removeItem('cf-plan'); location.reload(); }}><Trash2 size={13} /> Clear all local data</button>
          </Section>

          <Section icon={<Users size={16} />} title="Team">
            <div className="small muted">Invite editors, set approval workflows and share brand kits on the Business plan.</div>
            <div className="row gap6 mt8"><input className="input sm" placeholder="teammate@company.com" /><button className="btn sm" onClick={() => toast(plan === 'business' || plan === 'enterprise' ? '✉️ Invite sent (demo)' : 'Team seats require the Business plan', plan === 'business' || plan === 'enterprise' ? 'success' : 'error')}>Invite</button></div>
          </Section>
        </div>
      </div>

      <Section icon={<CreditCard size={16} />} title="Plan & billing" style={{ marginTop: 16 }}>
        <div className="row gap6 mb8"><span className="small muted">Current plan:</span><span className="badge brand">{PLANS.find((p) => p.id === plan)?.name}</span><span className="badge"><Sparkles size={11} /> {credits} credits</span></div>
        <div className="grid g3">
          {PLANS.map((p) => (
            <div key={p.id} className={'price' + (p.id === 'pro' ? ' hot' : '')} style={{ padding: 16 }}>
              <div className="row between"><b>{p.name}</b>{p.id === 'pro' && <span className="badge brand">Popular</span>}</div>
              <div style={{ fontSize: 26, fontWeight: 900, margin: '6px 0' }}>{p.price}<span className="tiny dim">{p.price.startsWith('$') && !p.price.includes('clip') && p.price !== '$0' ? '/mo' : ''}</span></div>
              <ul className="small muted" style={{ paddingLeft: 16, margin: '6px 0 12px' }}>{p.feats.map((f) => <li key={f}>{f}</li>)}</ul>
              <button className={'btn sm' + (plan === p.id ? '' : ' primary')} style={{ width: '100%' }} disabled={plan === p.id} onClick={() => upgrade(p.id)}>{plan === p.id ? 'Current plan' : p.id === 'enterprise' ? 'Contact sales' : p.id === 'payg' ? 'Top up 20 clips' : 'Choose'}</button>
            </div>
          ))}
        </div>
        <div className="dim tiny mt8">Checkout is simulated in the prototype. Annual billing saves 20%.</div>
      </Section>
    </div>
  );
}

function Section({ icon, title, children, style }: { icon: React.ReactNode; title: string; children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div className="card" style={style}>
      <div className="row gap6 mb8" style={{ fontWeight: 800 }}>{icon}{title}</div>
      {children}
    </div>
  );
}

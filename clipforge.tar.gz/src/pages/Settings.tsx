import { useEffect, useRef, useState } from 'react';
import { KeyRound, Palette, Download, HardDrive, Moon, Sun, Upload, Trash2, Check } from 'lucide-react';
import { clear } from 'idb-keyval';
import { useApp } from '../store';
import { CaptionStylePicker, Seg, Toggle } from '../components/ui';
import { chatJSON } from '../lib/llm';
import { FONT_LIST } from '../lib/captions';
import { fmtBytes } from '../lib/util';

export default function SettingsPage() {
  const { settings, setSettings, toast } = useApp();
  const [testing, setTesting] = useState(false);
  const [storage, setStorage] = useState<{ usage: number; quota: number } | null>(null);
  const logoRef = useRef<HTMLInputElement>(null);
  useEffect(() => { navigator.storage?.estimate?.().then((e) => setStorage({ usage: e.usage || 0, quota: e.quota || 0 })); }, []);

  const testKey = async () => {
    setTesting(true);
    try { const r = await chatJSON<{ ok: boolean }>('Reply with JSON {"ok":true}', 'ping'); toast(r.ok ? '✅ API key works' : 'Unexpected response', r.ok ? 'success' : 'error'); }
    catch (e) { toast('API error: ' + (e as Error).message, 'error'); }
    setTesting(false);
  };
  return (
    <div className="page" style={{ maxWidth: 1100 }}>
      <div className="page-head"><div><h1>Settings</h1><div className="muted">Everything is stored locally in your browser.</div></div></div>

      <div className="grid g2" style={{ alignItems: 'start' }}>
        <div className="col gap16">
          <Section icon={<Palette size={16} />} title="Style (logo, colors, captions)">
            <div className="row gap16">
              <div onClick={() => logoRef.current?.click()} style={{ width: 72, height: 72, borderRadius: 16, border: '1px dashed var(--line2)', display: 'grid', placeItems: 'center', cursor: 'pointer', overflow: 'hidden', background: 'var(--bg2)' }}>
                {settings.logo ? <img src={settings.logo} style={{ width: '100%', height: '100%', objectFit: 'contain' }} /> : <Upload size={18} color="var(--dim)" />}
              </div>
              <div className="col gap6 grow">
                <div className="small muted">Optional logo (only used on the end card if you turn it on).</div>
                {settings.logo && <button className="btn ghost sm" style={{ alignSelf: 'flex-start' }} onClick={() => setSettings({ logo: '' })}>Remove logo</button>}
              </div>
              <input ref={logoRef} type="file" accept="image/*" hidden onChange={(e) => { const f = e.target.files?.[0]; if (!f) return; const r = new FileReader(); r.onload = () => setSettings({ logo: String(r.result) }); r.readAsDataURL(f); }} />
            </div>
            <div className="grid g3 mt16">
              <label className="field">Primary<input type="color" value={settings.brandColor} onChange={(e) => setSettings({ brandColor: e.target.value })} /></label>
              <label className="field">Accent<input type="color" value={settings.brandAccent} onChange={(e) => setSettings({ brandAccent: e.target.value })} /></label>
              <label className="field">Font<select className="input sm" value={settings.brandFont} onChange={(e) => setSettings({ brandFont: e.target.value })}>{FONT_LIST.map((f) => <option key={f}>{f}</option>)}</select></label>
            </div>
            <div className="mt16 card tight row gap16" style={{ background: `linear-gradient(135deg, ${settings.brandColor}33, ${settings.brandAccent}22)` }}>
              {settings.logo && <img src={settings.logo} style={{ height: 36 }} />}
              <div><div style={{ fontFamily: settings.brandFont, fontWeight: 900, fontSize: 20, color: settings.brandAccent }}>YOUR HOOK HERE</div></div>
            </div>
            <div className="section-title mt16">Default caption style</div>
            <CaptionStylePicker value={settings.defaultCaption} onChange={(id) => setSettings({ defaultCaption: id })} />
          </Section>
        </div>

        <div className="col gap16">
          <Section icon={<KeyRound size={16} />} title="Subtitles (free, on your device)">
            <div className="muted small mb8">Whisper runs in your browser — no API key, nothing to pay. Only the chosen clips are transcribed, so it's quick. The model downloads once and is cached.</div>
            <Seg value={settings.localAsr ?? 'base'} options={[{ v: 'tiny', l: '⚡ Fast (~40 MB)' }, { v: 'base', l: '🎯 Accurate (~76 MB)' }, { v: 'off', l: 'Off' }]} onChange={(v) => setSettings({ localAsr: v })} />
          </Section>

          <Section icon={<KeyRound size={16} />} title="AI providers (optional)">
            <div className="muted small mb8">Optional. Without a key ClipForge runs its on-device analysis (audio energy, faces, motion, lexicon scoring). With a key you unlock Whisper transcription, GPT titles/hooks re-ranking, TTS voices and image generation.</div>
            <div className="row wrap gap6 mb8"><span className="tiny dim">Presets:</span>
              {[
                { l: 'OpenAI', base: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
                { l: 'Google Gemini (free key: aistudio.google.com)', base: 'https://generativelanguage.googleapis.com/v1beta/openai', model: 'gemini-2.5-flash' },
                { l: 'Groq (free key: console.groq.com)', base: 'https://api.groq.com/openai/v1', model: 'llama-3.3-70b-versatile' },
              ].map((p) => <button key={p.l} className={'chip' + (settings.openaiBase === p.base ? ' on' : '')} onClick={() => setSettings({ openaiBase: p.base, llmModel: p.model })}>{p.l}</button>)}
            </div>
            <div className="dim tiny mb8">The AI Director writes scripts with this key. Gemini and Groq are free and work well for that. Transcription, OpenAI voices and images need a real OpenAI key.</div>
            <label className="field">OpenAI-compatible API key<input className="input mono" type="password" placeholder="sk-…" value={settings.openaiKey} onChange={(e) => setSettings({ openaiKey: e.target.value.trim() })} /></label>
            <div className="grid g2 mt8">
              <label className="field">Base URL<input className="input sm mono" value={settings.openaiBase} onChange={(e) => setSettings({ openaiBase: e.target.value })} /></label>
              <label className="field">Chat model<input className="input sm mono" value={settings.llmModel} onChange={(e) => setSettings({ llmModel: e.target.value })} /></label>
            </div>
            <div className="row gap6 mt8">
              <button className="btn sm" disabled={!settings.openaiKey || testing} onClick={testKey}>{testing ? 'Testing…' : 'Test connection'}</button>
              {settings.openaiKey && <span className="badge ok"><Check size={11} /> key saved locally</span>}
            </div>
            <label className="field mt16">Pexels API key (stock media in editor)<input className="input sm mono" type="password" value={settings.pexelsKey || ''} onChange={(e) => setSettings({ pexelsKey: e.target.value.trim() })} /></label>
          </Section>

          <Section icon={settings.theme === 'dark' ? <Moon size={16} /> : <Sun size={16} />} title="Appearance & export">
            <div className="row between"><span className="small">Theme</span><Seg value={settings.theme} options={[{ v: 'dark', l: '🌙 Dark' }, { v: 'light', l: '☀️ Light' }]} onChange={(v) => setSettings({ theme: v })} /></div>
            <div className="row between mt16"><span className="small row gap6"><Download size={14} /> Default clip export</span><Seg value={settings.exportRes} options={[{ v: 720, l: '720p' }, { v: 1080, l: '1080p' }]} onChange={(v) => setSettings({ exportRes: v })} /></div>
            <div className="mt16"><Toggle label="Open Clip a Video, Clip a Stream, AI Director & Editor in their own browser tabs" value={settings.newTabs !== false} onChange={(v) => setSettings({ newTabs: v })} /></div>
            <div className="tiny dim mt8">On phones, tools always switch in place instead (Android freezes background tabs). Your work is still kept when you switch.</div>
            <div className="dim tiny mt4">Off = everything opens in this tab. Either way, work in progress is kept when you switch pages.</div>
          </Section>

          <Section icon={<HardDrive size={16} />} title="Storage & privacy">
            <div className="small muted">{storage ? `${fmtBytes(storage.usage)} used of ${fmtBytes(storage.quota)} browser quota.` : 'Estimating…'} Uploaded videos stay on your device; linked videos pass through your server only to get downloaded.</div>
            <div className="row between mt8"><span className="small">Auto-delete processed sources after</span>
              <select className="input sm" style={{ width: 120 }} value={settings.autoDeleteDays} onChange={(e) => setSettings({ autoDeleteDays: +e.target.value })}>{[7, 14, 30, 90, 0].map((d) => <option key={d} value={d}>{d ? `${d} days` : 'Never'}</option>)}</select>
            </div>
            <button className="btn danger sm mt16" onClick={async () => { if (!confirm('Delete all projects, media, settings and history from this browser?')) return; await clear(); localStorage.removeItem('clipforge-app'); location.reload(); }}><Trash2 size={13} /> Clear all local data</button>
          </Section>

        </div>
      </div>

    </div>
  );
}

function Section({ icon, title, children, style }: { icon: React.ReactNode; title: string; children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div className="card" style={style}>
      <div className="row gap6 mb8" style={{ fontWeight: 800 }}>{icon}{title}</div>
      {children}
    </div>
  );
}

import { useState } from 'react';
import { engineSupport } from '../lib/export';
import { canEncodeH264, webcodecsSupported } from '../lib/export-webcodecs';
import { pickRecorderMime } from '../lib/export-realtime';
import { DEFAULT_SETTINGS, type ExportSettings } from '../lib/types';
import { useStore } from '../store';

export default function SettingsPage() {
  const s = useStore();
  const ui = s.ui;
  const set = (patch: Partial<ExportSettings>) =>
    s.setUi({ exportSettings: { ...ui.exportSettings, ...patch } });
  const [cap, setCap] = useState<string>('');

  const check = async () => {
    setCap('Checking…');
    const lines: string[] = [];
    lines.push(`WebCodecs: ${webcodecsSupported() ? 'yes' : 'no'}`);
    lines.push(`H.264 encode: ${(await canEncodeH264()) ? 'yes' : 'no'}`);
    lines.push(`MediaRecorder: ${engineSupport().recorder ? 'yes' : 'no'}`);
    lines.push(`Recordable format: ${pickRecorderMime() || 'none'}`);
    lines.push(`FaceDetector: ${typeof (window as never as { FaceDetector?: unknown }).FaceDetector !== 'undefined' ? 'yes' : 'no'}`);
    lines.push(`Wake Lock: ${'wakeLock' in navigator ? 'yes' : 'no'}`);
    lines.push(`Secure context: ${window.isSecureContext ? 'yes' : 'no'}`);
    setCap(lines.join('\n'));
  };

  return (
    <>
      <h1>Settings</h1>

      <h2>Clip length</h2>
      <div className="rowline">
        <label htmlFor="min">Shortest clip (seconds)</label>
        <input
          id="min"
          type="number"
          min={4}
          max={120}
          step={1}
          value={ui.exportSettings.minSeconds}
          onChange={(e) => set({ minSeconds: clampNum(e.target.value, 4, 120) })}
        />
        <label htmlFor="target">Aim for (seconds)</label>
        <input
          id="target"
          type="number"
          min={5}
          max={180}
          step={1}
          value={ui.exportSettings.targetSeconds}
          onChange={(e) => set({ targetSeconds: clampNum(e.target.value, 5, 180) })}
        />
        <label htmlFor="max">Longest clip (seconds)</label>
        <input
          id="max"
          type="number"
          min={6}
          max={240}
          step={1}
          value={ui.exportSettings.maxSeconds}
          onChange={(e) => set({ maxSeconds: clampNum(e.target.value, 6, 240) })}
        />
        <p className="field-note">Shorts do best between 15 and 40 seconds.</p>
      </div>

      <h2>Output</h2>
      <div className="rowline">
        <label htmlFor="size">Size</label>
        <select
          id="size"
          value={`${ui.exportSettings.width}x${ui.exportSettings.height}`}
          onChange={(e) => {
            const [w, h] = e.target.value.split('x').map(Number);
            set({ width: w, height: h });
          }}
        >
          <option value="540x960">540 × 960 (smaller files, faster)</option>
          <option value="720x1280">720 × 1280 (default)</option>
          <option value="1080x1920">1080 × 1920 (biggest, slowest)</option>
        </select>

        <label htmlFor="fps">Frames per second</label>
        <select
          id="fps"
          value={String(ui.exportSettings.fps)}
          onChange={(e) => set({ fps: Number(e.target.value) })}
        >
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="30">30</option>
          <option value="60">60</option>
        </select>
        <p className="field-note">Lower fps exports faster on a phone and still looks right for Shorts.</p>
      </div>

      <h2>How clips are made</h2>
      <div className="rowline">
        <div className="checkrow">
          <input
            id="preferFace"
            type="checkbox"
            checked={ui.exportSettings.preferFace}
            onChange={(e) => set({ preferFace: e.target.checked })}
          />
          <span>
            <label htmlFor="preferFace" style={{ margin: 0, display: 'inline' }}>
              Use the face crop only when that clip really shows a person
            </label>
          </span>
        </div>
        <div className="checkrow">
          <input
            id="autoRebuild"
            type="checkbox"
            checked={ui.exportSettings.autoRebuild}
            onChange={(e) => set({ autoRebuild: e.target.checked })}
          />
          <span>
            <label htmlFor="autoRebuild" style={{ margin: 0, display: 'inline' }}>
              Re-make a clip automatically if the finished file fails its check
            </label>
          </span>
        </div>
        <div className="checkrow">
          <input
            id="burnTitle"
            type="checkbox"
            checked={ui.exportSettings.burnTitle}
            onChange={(e) => set({ burnTitle: e.target.checked })}
          />
          <span>
            <label htmlFor="burnTitle" style={{ margin: 0, display: 'inline' }}>
              Write the title onto the first 3 seconds of the video
            </label>
          </span>
        </div>
        <div className="checkrow">
          <input
            id="downloadEach"
            type="checkbox"
            checked={ui.downloadEach}
            onChange={(e) => s.setUi({ downloadEach: e.target.checked })}
          />
          <span>
            <label htmlFor="downloadEach" style={{ margin: 0, display: 'inline' }}>
              Download each clip the moment it is ready
            </label>
          </span>
        </div>
        <div className="checkrow">
          <input
            id="showLog"
            type="checkbox"
            checked={ui.showLog}
            onChange={(e) => s.setUi({ showLog: e.target.checked })}
          />
          <span>
            <label htmlFor="showLog" style={{ margin: 0, display: 'inline' }}>
              Show the working log on the Clips page
            </label>
          </span>
        </div>
      </div>

      <h2>Engine</h2>
      <div className="rowline">
        <label htmlFor="mode">Export mode</label>
        <select
          id="mode"
          value={ui.exportSettings.mode}
          onChange={(e) => set({ mode: e.target.value as ExportSettings['mode'] })}
        >
          <option value="fast">Fast — frame by frame (WebCodecs, cannot freeze)</option>
          <option value="realtime">Real-time — record while it plays (MediaRecorder)</option>
        </select>
        <div className="checkrow">
          <input
            id="forceRealtime"
            type="checkbox"
            checked={ui.forceRealtime}
            onChange={(e) => s.setUi({ forceRealtime: e.target.checked })}
          />
          <span>
            <label htmlFor="forceRealtime" style={{ margin: 0, display: 'inline' }}>
              Force real-time mode even when fast mode is available
            </label>
          </span>
        </div>
        <p className="field-note">
          Fast mode decodes and re-encodes every frame with its own timestamp, so a throttled tab
          cannot produce a frozen picture. Real-time mode is kept because some browsers cannot
          encode H.264; it now has a stall watchdog and refuses to hand over a frozen file.
        </p>
      </div>

      <h2>Keywords for titles</h2>
      <div className="rowline">
        <label htmlFor="kw">One per line (used when the AI Director is off)</label>
        <textarea
          id="kw"
          value={ui.keywords}
          placeholder={'your topic\nyour niche'}
          onChange={(e) => s.setUi({ keywords: e.target.value })}
        />
      </div>

      <h2>This browser</h2>
      <div className="rowline">
        <button className="btn" onClick={() => void check()}>
          Check what this browser can do
        </button>
        {cap ? <div className="logbox" style={{ marginTop: 8 }}>{cap}</div> : null}
      </div>

      <hr />
      <div className="btn-row">
        <button className="btn" onClick={() => s.setUi({ exportSettings: DEFAULT_SETTINGS })}>
          Reset to defaults
        </button>
      </div>
    </>
  );
}

function clampNum(v: string, lo: number, hi: number): number {
  const n = Number(v);
  if (!Number.isFinite(n)) return lo;
  return Math.max(lo, Math.min(hi, Math.round(n)));
}

import { useRef, useState } from 'react';
import ClipRow from '../components/ClipRow';
import { parseKeywords } from '../lib/title';
import { runPipeline } from '../lib/pipeline';
import { downloadBlob, clipFileName, formatBytes } from '../lib/download';
import { engineSupport } from '../lib/export';
import * as db from '../lib/db';
import { useStore } from '../store';
import type { Clip } from '../lib/types';

/**
 * Home. One box: paste a link or pick a file, then "Make clips".
 * Under it, the clip history.
 */
export default function ClipsPage() {
  const s = useStore();
  const [input, setInput] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [playing, setPlaying] = useState<string | null>(null);
  const support = useRef(engineSupport()).current;

  const start = async () => {
    if (s.busy) return;
    const value = file ?? input.trim();
    if (!value) {
      s.setError('Paste a link or pick a video file first.');
      return;
    }
    s.setError(null);
    s.setBusy(true);
    s.setProgress(0);
    s.setStatus('Starting');
    s.setClips([]);
    s.clearLogs();
    setPlaying(null);

    const ctrl = new AbortController();
    s.abortRef.current = ctrl;

    try {
      const out = await runPipeline({
        input: value,
        settings: s.ui.exportSettings,
        keywords: parseKeywords(s.ui.keywords),
        ai: s.ui.ai,
        downloadEach: s.ui.downloadEach,
        forceRealtime: s.ui.forceRealtime || s.ui.exportSettings.mode === 'realtime',
        signal: ctrl.signal,
        callbacks: {
          onRun: (r) => {
            s.setRun(r);
            s.setStatus(`Loaded ${r.sourceName}`);
          },
          onClips: (clips) => {
            s.setClips(clips);
            s.go('results');
          },
          onClip: (clip) => {
            s.updateClip(clip);
            s.setProgress(clip.progress);
            s.setStatus(clip.progressText || `Clip ${clip.index + 1}`);
          },
          onLog: (line) => s.pushLog(line),
          onFinished: (r, clips) => {
            s.setRun(r);
            s.setStatus(`Finished — ${clips.filter((c) => c.status === 'done').length}/${clips.length} clips good`);
            s.setProgress(1);
          },
        },
      });
      s.setSource(out.source);
      s.setSourceHasAudio(out.analysis.audio.ok);
      s.setRun(out.run);
      s.setClips(out.clips);
      if (out.failures) {
        s.setError(`${out.failures} clip(s) failed. The others are fine — see the list.`);
      }
      s.go('results');
    } catch (e) {
      s.setError((e as Error).message || 'The run failed');
      s.setStatus('Failed');
    } finally {
      s.setBusy(false);
      s.setProgress(0);
    }
  };

  const stop = () => {
    s.abortRef.current?.abort();
    s.setBusy(false);
    s.setStatus('Stopped');
    s.pushLog('Stopped by you');
  };

  const downloadAll = async () => {
    const done = s.clips.filter((c) => c.status === 'done');
    if (!done.length) {
      s.setError('Nothing finished yet.');
      return;
    }
    s.setError(null);
    s.setStatus(`Downloading ${done.length} file(s) one at a time`);
    // One at a time, straight from IndexedDB — never a ZIP held in memory.
    for (const c of done) {
      const blob = await db.getBlob(c.id);
      if (!blob) continue;
      await downloadBlob({ blob: blob, fileName: c.fileName });
      s.setStatus(`Downloaded ${c.fileName}`);
    }
    s.setStatus('All downloads handed over');
  };

  const hasResults = s.clips.length > 0;

  return (
    <>
      <h1>Make clips</h1>
      <p className="dim">
        Paste a video link or pick a file. Everything runs on your phone — nothing is uploaded.
      </p>

      <div className="rowline">
        <label htmlFor="src">Video link</label>
        <input
          id="src"
          type="url"
          inputMode="url"
          autoComplete="off"
          spellCheck={false}
          placeholder="https://…/video.mp4"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={s.busy}
        />
        <p className="field-note">
          MP4 works best. GitHub page links are converted to the raw file automatically.
        </p>

        <label htmlFor="file">…or pick a file</label>
        <input
          id="file"
          ref={fileRef}
          type="file"
          accept="video/*,.mp4,.mov,.webm,.mkv"
          onChange={(e) => {
            const f = e.target.files?.[0] ?? null;
            setFile(f);
            if (f) setInput('');
          }}
          disabled={s.busy}
        />
        {file ? (
          <p className="field-note">
            Chosen: {file.name} ({formatBytes(file.size)})
          </p>
        ) : null}

        <div className="btn-row" style={{ marginTop: 14 }}>
          <button className="btn btn-primary" onClick={start} disabled={s.busy || (!input.trim() && !file)}>
            Make clips
          </button>
          {s.busy ? (
            <button className="btn" onClick={stop}>
              Stop
            </button>
          ) : null}
        </div>
      </div>

      {s.busy ? (
        <div className="rowline">
          <p className="strong">{s.status || 'Working…'}</p>
          <div className="meter" aria-hidden="true">
            <i style={{ width: `${Math.round((s.progress || 0) * 100)}%` }} />
          </div>
          <p className="tiny dim">
            Keep this tab in front. ClipForge holds a wake lock, and it pauses cleanly and resumes
            if your phone hides the tab.
          </p>
        </div>
      ) : null}

      {s.error ? <p className="err">{s.error}</p> : null}

      {hasResults ? (
        <>
          <div className="spread" style={{ marginTop: 18 }}>
            <h2 style={{ margin: 0 }}>Clips ({s.clips.length})</h2>
            <button className="btn btn-sm" onClick={downloadAll}>
              ⬇ Download all
            </button>
          </div>

          {s.clips.map((c) => (
            <ClipRow
              key={c.id}
              clip={c}
              playing={playing}
              onPlay={(clip) => setPlaying(playing === clip.id ? null : clip.id)}
              onDownload={async (clip) => {
                const blob = await db.getBlob(clip.id);
                if (!blob) {
                  s.setError('That file is no longer stored on this device. Re-make the clip.');
                  return;
                }
                await downloadBlob({
                  blob,
                  fileName: clip.fileName || clipFileName('clip', clip.index, clip.analysis?.title ?? '', 'mp4'),
                });
                s.setStatus(`Downloaded ${clip.fileName}`);
              }}
              onLayout={(clip, layout) => {
                if (clip.layout === layout) return;
                const next: Clip = { ...clip, layout, edited: true };
                s.updateClip(next);
                void db.saveClip(next);
                s.setStatus(`Layout set to ${layout === 'face' ? 'Face' : 'Full frame'} — press Re-make in Edit`);
              }}
              onReExport={() => s.go('editor')}
              onDelete={async (clip) => {
                await db.deleteClipData(clip.id);
                await db.deleteClipData(`thumb:${clip.id}`);
                s.setClips(s.clips.filter((x) => x.id !== clip.id));
              }}
            />
          ))}
        </>
      ) : (
        <div className="empty">
          No clips yet. Paste a link above and press <strong>Make clips</strong>.
        </div>
      )}

      <details style={{ marginTop: 18 }}>
        <summary>What this browser can do</summary>
        <div className="details-body">
          <div className="logbox">
            {`WebCodecs (frame-accurate export): ${support.webcodecs ? 'yes' : 'no'}
MediaRecorder (real-time export):   ${support.recorder ? 'yes' : 'no'}
Recordable format:                  ${support.recorderMime || 'none'}
FaceDetector (per-clip face crop):  ${typeof (window as never as { FaceDetector?: unknown }).FaceDetector !== 'undefined' ? 'yes' : 'no — full frame will be used'}
Wake Lock (keep screen on):         ${'wakeLock' in navigator ? 'yes' : 'no'}
Secure context (needed to record):  ${window.isSecureContext ? 'yes' : 'no'}`}
          </div>
          <p className="field-note">
            If WebCodecs says yes, exports are made frame by frame and cannot freeze. Real-time mode
            is still available in Settings.
          </p>
        </div>
      </details>

      {s.ui.showLog ? (
        <>
          <h2>Log</h2>
          <div className="logbox" id="logbox">
            {s.logs.join('\n') || '(empty)'}
          </div>
        </>
      ) : null}
    </>
  );
}

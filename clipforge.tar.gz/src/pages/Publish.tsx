import { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, CalendarPlus, Link2, Check, Trash2, Clock, TrendingUp, Eye, Heart, Share2, Users, Wand2 } from 'lucide-react';
import { useApp, PLATFORMS } from '../store';
import type { ScheduledPost } from '../lib/types';
import { Modal, Sparkline } from '../components/ui';
import { seeded, hashStr, uid } from '../lib/util';

const BEST: Record<string, number[]> = { tiktok: [12, 19, 21], shorts: [14, 17, 20], reels: [11, 13, 19], youtube: [15, 17], facebook: [9, 13], x: [8, 12, 17], snapchat: [20, 22], linkedin: [8, 12], pinterest: [20, 21] };
const REAL = PLATFORMS.filter((p) => p.id !== 'all');
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function Publish() {
  const [tab, setTab] = useState<'calendar' | 'analytics' | 'accounts'>('calendar');
  const { posts, setPosts, connected, toast } = useApp();
  // simulated auto-posting
  useEffect(() => {
    const now = Date.now();
    let changed = 0;
    const next = posts.map((p) => { if (p.status === 'scheduled' && +new Date(p.when) < now && connected[p.platform]) { changed++; return { ...p, status: 'posted' as const }; } return p; });
    if (changed) { setPosts(next); toast(`✅ ${changed} scheduled post(s) published automatically`, 'success'); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Publish & Analytics</h1><div className="muted">Schedule everywhere, auto-post at the best times, and track what goes viral.</div></div>
        <div className="tabs">
          <div className={'tab' + (tab === 'calendar' ? ' on' : '')} onClick={() => setTab('calendar')}>Calendar</div>
          <div className={'tab' + (tab === 'analytics' ? ' on' : '')} onClick={() => setTab('analytics')}>Analytics</div>
          <div className={'tab' + (tab === 'accounts' ? ' on' : '')} onClick={() => setTab('accounts')}>Accounts</div>
        </div>
      </div>
      {tab === 'calendar' && <CalendarTab />}
      {tab === 'analytics' && <Analytics />}
      {tab === 'accounts' && <Accounts />}
    </div>
  );
}

function bestSlot(platform: string, day: Date, i = 0): Date {
  const hrs = BEST[platform] || [18];
  const d = new Date(day); d.setHours(hrs[i % hrs.length], 0, 0, 0);
  return d;
}

function CalendarTab() {
  const { posts, setPosts, sessions, connected, toast } = useApp();
  const [month, setMonth] = useState(() => { const d = new Date(); d.setDate(1); d.setHours(0, 0, 0, 0); return d; });
  const [edit, setEdit] = useState<ScheduledPost | null>(null);
  const [creating, setCreating] = useState<Date | null>(null);
  const [over, setOver] = useState<string>('');
  const drafts = posts.filter((p) => p.status === 'draft');
  const today = new Date(); today.setHours(0, 0, 0, 0);

  const cells = useMemo(() => {
    const first = new Date(month);
    const offset = (first.getDay() + 6) % 7;
    const start = new Date(first); start.setDate(1 - offset);
    return Array.from({ length: 42 }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return d; });
  }, [month]);
  const key = (d: Date) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
  const byDay = useMemo(() => {
    const m = new Map<string, ScheduledPost[]>();
    for (const p of posts) { if (p.status === 'draft') continue; const k = key(new Date(p.when)); m.set(k, [...(m.get(k) || []), p]); }
    for (const v of m.values()) v.sort((a, b) => +new Date(a.when) - +new Date(b.when));
    return m;
  }, [posts]);

  const dropOn = (d: Date, id: string) => {
    setOver('');
    const p = posts.find((x) => x.id === id); if (!p) return;
    let when: Date;
    if (p.status === 'draft') when = bestSlot(p.platform, d);
    else { const old = new Date(p.when); when = new Date(d); when.setHours(old.getHours(), old.getMinutes(), 0, 0); }
    setPosts(posts.map((x) => (x.id === id ? { ...x, when: when.toISOString(), status: 'scheduled' } : x)));
    toast(`Scheduled for ${when.toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`, 'success');
  };
  const bulk = () => {
    let i = 0;
    const next = posts.map((p) => {
      if (p.status !== 'draft') return p;
      const d = new Date(); d.setDate(d.getDate() + 1 + Math.floor(i / 2));
      const w = bestSlot(p.platform, d, i++);
      return { ...p, status: 'scheduled' as const, when: w.toISOString() };
    });
    setPosts(next);
    toast(`📅 ${i} drafts auto-scheduled at peak times`, 'success');
  };
  const sampleDrafts = () => {
    const clips = sessions.flatMap((s) => s.clips).slice(0, 6);
    const titles = clips.length ? clips.map((c) => ({ t: c.title, s: c.score, cap: c.hookLine })) : [{ t: 'The 5AM myth nobody talks about', s: 88, cap: 'Wait for the end 👀' }, { t: 'I tried it for 30 days…', s: 81, cap: 'Results shocked me' }, { t: 'Hot take: stop posting daily', s: 76, cap: 'Agree? 👇' }];
    const add: ScheduledPost[] = titles.map((x, i) => ({ id: uid('post_'), clipTitle: x.t, platform: ['tiktok', 'reels', 'shorts'][i % 3], when: new Date().toISOString(), caption: x.cap + ' #fyp #viral', status: 'draft', score: x.s }));
    setPosts([...posts, ...add]);
  };

  return (
    <div className="grid" style={{ gridTemplateColumns: '1fr 290px', gap: 16, alignItems: 'start' }}>
      <div className="card">
        <div className="row between mb8">
          <div className="row gap6">
            <button className="btn sm icon" onClick={() => { const d = new Date(month); d.setMonth(d.getMonth() - 1); setMonth(d); }}><ChevronLeft size={14} /></button>
            <h3 style={{ margin: 0, minWidth: 160, textAlign: 'center' }}>{month.toLocaleString([], { month: 'long', year: 'numeric' })}</h3>
            <button className="btn sm icon" onClick={() => { const d = new Date(month); d.setMonth(d.getMonth() + 1); setMonth(d); }}><ChevronRight size={14} /></button>
            <button className="btn sm ghost" onClick={() => { const d = new Date(); d.setDate(1); d.setHours(0, 0, 0, 0); setMonth(d); }}>Today</button>
          </div>
          <button className="btn sm primary" onClick={() => setCreating(new Date())}><Plus size={13} /> New post</button>
        </div>
        <div className="cal">
          {DAYS.map((d) => <div key={d} className="tiny dim" style={{ textAlign: 'center', fontWeight: 700, padding: 4 }}>{d}</div>)}
          {cells.map((d) => {
            const k = key(d);
            const list = byDay.get(k) || [];
            const other = d.getMonth() !== month.getMonth();
            return (
              <div key={k} className={'cal-day' + (+d === +today ? ' today' : '') + (over === k ? ' over' : '')} style={{ opacity: other ? 0.45 : 1 }}
                onDragOver={(e) => { e.preventDefault(); setOver(k); }} onDragLeave={() => setOver('')} onDrop={(e) => { e.preventDefault(); dropOn(d, e.dataTransfer.getData('text/post')); }}
                onDoubleClick={() => setCreating(d)}>
                <div className="tiny" style={{ fontWeight: 700, marginBottom: 3 }}>{d.getDate()}</div>
                {list.slice(0, 3).map((p) => {
                  const pl = PLATFORMS.find((x) => x.id === p.platform);
                  return (
                    <div key={p.id} className="cal-post" draggable onDragStart={(e) => e.dataTransfer.setData('text/post', p.id)} onClick={() => setEdit(p)}
                      style={{ borderLeft: `3px solid ${pl?.color || '#7c5cff'}`, opacity: p.status === 'posted' ? 0.6 : 1 }} title={`${pl?.name} · ${p.clipTitle}`}>
                      {p.status === 'posted' ? '✓ ' : ''}{new Date(p.when).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} {p.clipTitle}
                    </div>
                  );
                })}
                {list.length > 3 && <div className="tiny dim">+{list.length - 3} more</div>}
              </div>
            );
          })}
        </div>
        <div className="dim tiny mt8">Drag posts between days to reschedule · drag drafts onto a day to auto-pick the best time · double-click a day to add a post.</div>
      </div>

      <div className="col gap16">
        <div className="card">
          <div className="row between"><h3 style={{ margin: 0 }}>Drafts queue</h3><span className="badge">{drafts.length}</span></div>
          <div className="col gap6 mt8">
            {drafts.map((p) => {
              const pl = PLATFORMS.find((x) => x.id === p.platform);
              return (
                <div key={p.id} className="clip-card" draggable onDragStart={(e) => e.dataTransfer.setData('text/post', p.id)} onClick={() => setEdit(p)} style={{ padding: 8, cursor: 'grab' }}>
                  <span style={{ width: 8, height: 8, borderRadius: 9, background: pl?.color, marginTop: 5, flexShrink: 0 }} />
                  <div className="grow" style={{ minWidth: 0 }}><b className="small ellipsis" style={{ display: 'block' }}>{p.clipTitle}</b><div className="tiny dim">{pl?.name}{p.score ? ` · score ${p.score}` : ''}</div></div>
                </div>
              );
            })}
            {!drafts.length && <div className="dim small">No drafts. Schedule clips from a results page, or <a style={{ color: 'var(--brand)', cursor: 'pointer' }} onClick={sampleDrafts}>add sample drafts</a>.</div>}
          </div>
          {drafts.length > 0 && <button className="btn sm primary mt16" style={{ width: '100%' }} onClick={bulk}><Wand2 size={13} /> Bulk auto-schedule all</button>}
        </div>
        <div className="card">
          <h3 style={{ margin: 0 }}>Best times to post</h3>
          <div className="dim tiny mb8">Your timezone · based on audience activity (demo model)</div>
          {REAL.map((p) => (
            <div key={p.id} className="row between small" style={{ padding: '4px 0', borderBottom: '1px solid var(--line)' }}>
              <span className="row gap6"><span style={{ width: 8, height: 8, borderRadius: 9, background: p.color }} />{p.name}{connected[p.id] && <Check size={11} color="#3ddc97" />}</span>
              <span className="mono tiny">{(BEST[p.id] || []).map((h) => `${h}:00`).join(' · ')}</span>
            </div>
          ))}
        </div>
      </div>

      <PostModal post={edit} onClose={() => setEdit(null)} />
      <NewPostModal day={creating} onClose={() => setCreating(null)} />
    </div>
  );
}

function PostModal({ post, onClose }: { post: ScheduledPost | null; onClose: () => void }) {
  const { posts, setPosts, toast, connected } = useApp();
  const [d, setD] = useState<ScheduledPost | null>(post);
  useEffect(() => setD(post), [post]);
  if (!d) return null;
  const local = new Date(new Date(d.when).getTime() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  const save = (p: Partial<ScheduledPost>) => { setPosts(posts.map((x) => (x.id === d.id ? { ...d, ...p } : x))); onClose(); };
  return (
    <Modal open={!!post} onClose={onClose} title="Edit post" width={500}>
      <div className="col gap16">
        <label className="field">Title<input className="input" value={d.clipTitle} onChange={(e) => setD({ ...d, clipTitle: e.target.value })} /></label>
        <label className="field">Caption<textarea className="input" rows={4} value={d.caption} onChange={(e) => setD({ ...d, caption: e.target.value })} /></label>
        <div className="grid g2">
          <label className="field">Platform<select className="input" value={d.platform} onChange={(e) => setD({ ...d, platform: e.target.value })}>{REAL.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
          <label className="field">When<input className="input" type="datetime-local" value={local} onChange={(e) => setD({ ...d, when: new Date(e.target.value).toISOString() })} /></label>
        </div>
        {!connected[d.platform] && <div className="small"><span className="badge warn">not connected</span> <span className="muted">Connect this account under Accounts to enable auto-posting.</span></div>}
        <div className="row gap6">
          <button className="btn primary grow" onClick={() => save({ status: d.status === 'draft' ? 'scheduled' : d.status })}><CalendarPlus size={14} /> {d.status === 'draft' ? 'Schedule' : 'Save'}</button>
          {d.status !== 'posted' && <button className="btn" onClick={() => { save({ status: 'posted', when: new Date().toISOString() }); toast(connected[d.platform] ? '🚀 Posted now (simulated)' : 'Marked as posted', 'success'); }}>Post now</button>}
          {d.status === 'scheduled' && <button className="btn" onClick={() => save({ status: 'draft' })}>Unschedule</button>}
          <button className="btn danger icon" onClick={() => { setPosts(posts.filter((x) => x.id !== d.id)); onClose(); }}><Trash2 size={14} /></button>
        </div>
      </div>
    </Modal>
  );
}

function NewPostModal({ day, onClose }: { day: Date | null; onClose: () => void }) {
  const { posts, setPosts, sessions, toast } = useApp();
  const clips = sessions.flatMap((s) => s.clips);
  const [title, setTitle] = useState('');
  const [caption, setCaption] = useState('');
  const [plats, setPlats] = useState<string[]>(['tiktok']);
  const [auto, setAuto] = useState(true);
  const [when, setWhen] = useState('');
  useEffect(() => { if (day) { const d = new Date(day); d.setHours(18, 0, 0, 0); if (d < new Date()) d.setDate(new Date().getDate() + 1); setWhen(new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16)); } }, [day]);
  const create = () => {
    const base = new Date(when);
    const add: ScheduledPost[] = plats.map((pl, i) => ({ id: uid('post_'), clipTitle: title || 'Untitled clip', platform: pl, caption, status: 'scheduled', when: (auto ? bestSlot(pl, base, i) : base).toISOString() }));
    setPosts([...posts, ...add]);
    toast(`📅 Scheduled on ${plats.length} platform(s)`, 'success');
    onClose(); setTitle(''); setCaption('');
  };
  return (
    <Modal open={!!day} onClose={onClose} title="New scheduled post" width={520}>
      <div className="col gap16">
        {clips.length > 0 && <label className="field">From a generated clip<select className="input" onChange={(e) => { const c = clips.find((x) => x.id === e.target.value); if (c) { setTitle(c.title); setCaption(`${c.hookLine}\n\n${c.hashtags.join(' ')}`); } }} defaultValue=""><option value="">— choose —</option>{clips.map((c) => <option key={c.id} value={c.id}>{c.score} · {c.title}</option>)}</select></label>}
        <label className="field">Title<input className="input" value={title} onChange={(e) => setTitle(e.target.value)} /></label>
        <label className="field">Caption & hashtags<textarea className="input" rows={3} value={caption} onChange={(e) => setCaption(e.target.value)} /></label>
        <div>
          <div className="section-title">Platforms (cross-post)</div>
          <div className="row wrap gap6">{REAL.map((p) => <div key={p.id} className={'chip' + (plats.includes(p.id) ? ' on' : '')} onClick={() => setPlats(plats.includes(p.id) ? plats.filter((x) => x !== p.id) : [...plats, p.id])}><span style={{ width: 7, height: 7, borderRadius: 9, background: p.color }} />{p.name}</div>)}</div>
        </div>
        <div className="grid g2">
          <label className="field">Date / time<input className="input" type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} /></label>
          <div className="toggle" onClick={() => setAuto(!auto)} style={{ alignSelf: 'end' }}><span className="small">Use each platform's best time that day</span><div className={'switch' + (auto ? ' on' : '')} /></div>
        </div>
        <button className="btn primary" disabled={!plats.length || !when} onClick={create}><CalendarPlus size={14} /> Schedule</button>
      </div>
    </Modal>
  );
}

function Analytics() {
  const { posts, history } = useApp();
  const [plat, setPlat] = useState('all');
  const r = seeded(hashStr(plat) + posts.length);
  const days = 30;
  const views = Array.from({ length: days }, (_, i) => Math.round(2000 + r() * 4000 + i * 180 + (i % 7 === 5 ? 6000 : 0) + (i === 22 ? 42000 : 0)));
  const total = views.reduce((a, b) => a + b, 0);
  const kpis = [
    { icon: <Eye size={15} />, l: 'Views', v: total, d: '+42%' },
    { icon: <Heart size={15} />, l: 'Likes', v: Math.round(total * 0.071), d: '+18%' },
    { icon: <Share2 size={15} />, l: 'Shares', v: Math.round(total * 0.012), d: '+61%' },
    { icon: <Users size={15} />, l: 'New followers', v: Math.round(total * 0.004), d: '+27%' },
  ];
  const posted = posts.filter((p) => p.status === 'posted');
  const top = (posted.length ? posted : [{ id: 'd1', clipTitle: 'The 5AM myth nobody talks about', platform: 'tiktok', score: 91 }, { id: 'd2', clipTitle: 'Why I quit my $200k job', platform: 'reels', score: 86 }, { id: 'd3', clipTitle: 'This one habit doubled my output', platform: 'shorts', score: 79 }] as Partial<ScheduledPost>[])
    .map((p) => { const rr = seeded(hashStr(p.id!)); const v = Math.round(5000 + rr() * 90000 * ((p.score || 70) / 70)); return { ...p, views: v, ret: Math.round(35 + rr() * 45), watch: (8 + rr() * 30).toFixed(1) }; })
    .sort((a, b) => b.views - a.views);
  const fmt = (n: number) => (n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'K' : String(n));
  const scores = history.filter((h) => h.score > 0);
  return (
    <div className="col gap16">
      <div className="row between">
        <div className="row wrap gap6">
          <div className={'chip' + (plat === 'all' ? ' on' : '')} onClick={() => setPlat('all')}>All platforms</div>
          {REAL.slice(0, 6).map((p) => <div key={p.id} className={'chip' + (plat === p.id ? ' on' : '')} onClick={() => setPlat(p.id)}>{p.name}</div>)}
        </div>
        <span className="badge warn">demo data — connect accounts for live stats</span>
      </div>
      <div className="grid g4">
        {kpis.map((k) => <div key={k.l} className="card tight"><div className="row gap6 muted small">{k.icon}{k.l}</div><div style={{ fontSize: 26, fontWeight: 800 }}>{fmt(k.v)}</div><span className="badge ok"><TrendingUp size={10} /> {k.d}</span></div>)}
      </div>
      <div className="card">
        <div className="row between"><h3 style={{ margin: 0 }}>Views over time</h3><span className="tiny dim">last 30 days · spike = viral clip</span></div>
        <Sparkline data={views} h={140} w={900} color="#7c5cff" />
      </div>
      <div className="grid g2">
        <div className="card">
          <h3 style={{ margin: 0 }}>Top performing clips</h3>
          <table className="small mt8" style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr className="dim tiny" style={{ textAlign: 'left' }}><th>Clip</th><th>Views</th><th>Retention</th><th>Avg watch</th></tr></thead>
            <tbody>{top.slice(0, 8).map((p) => <tr key={p.id} style={{ borderTop: '1px solid var(--line)' }}><td style={{ padding: '6px 0' }} className="ellipsis">{p.clipTitle}</td><td>{fmt(p.views)}</td><td>{p.ret}%</td><td>{p.watch}s</td></tr>)}</tbody>
          </table>
        </div>
        <div className="card">
          <h3 style={{ margin: 0 }}>Virality score vs. real performance</h3>
          <div className="dim tiny">The model learns from your results to improve future scoring.</div>
          <svg viewBox="0 0 300 160" style={{ width: '100%', marginTop: 8 }}>
            <line x1="30" y1="140" x2="290" y2="140" stroke="var(--line2)" /><line x1="30" y1="10" x2="30" y2="140" stroke="var(--line2)" />
            {(scores.length ? scores : Array.from({ length: 18 }, (_, i) => ({ id: String(i), score: 55 + ((i * 37) % 45) }))).slice(0, 40).map((s) => { const rr = seeded(hashStr(s.id)); const x = 30 + ((s.score - 40) / 60) * 260; const y = 140 - Math.min(125, ((s.score - 40) / 60) * 110 + (rr() - 0.5) * 40); return <circle key={s.id} cx={x} cy={y} r="4" fill="#7c5cff" opacity=".8" />; })}
            <line x1="30" y1="135" x2="290" y2="25" stroke="#ffd23f" strokeDasharray="4 4" />
            <text x="160" y="156" fontSize="9" fill="var(--dim)" textAnchor="middle">Virality score</text>
            <text x="12" y="80" fontSize="9" fill="var(--dim)" transform="rotate(-90 12 80)" textAnchor="middle">Views</text>
          </svg>
          <div className="row gap6 small"><Clock size={12} /><span className="muted">Best-performing length: <b>24–38s</b> · Best day: <b>Thursday</b></span></div>
        </div>
      </div>
    </div>
  );
}

function Accounts() {
  const { connected, setConnected, toast, settings } = useApp();
  const [busy, setBusy] = useState('');
  const connect = async (id: string, name: string) => {
    setBusy(id);
    await new Promise((r) => setTimeout(r, 1100));
    setConnected(id, true); setBusy('');
    toast(`🔗 ${name} connected (simulated OAuth)`, 'success');
  };
  return (
    <div className="col gap16">
      <div className="card tight small"><span className="badge warn">prototype</span> <span className="muted">OAuth is simulated in this build — connecting enables auto-post, best-time scheduling and analytics UI. The hosted version uses official TikTok, YouTube, Meta, X, LinkedIn, Snapchat & Pinterest APIs.</span></div>
      <div className="grid g3">
        {[...REAL, { id: 'twitch', name: 'Twitch', color: '#9146ff' }, { id: 'kick', name: 'Kick', color: '#53fc18' }, { id: 'drive', name: 'Google Drive / Dropbox', color: '#4285f4' }].map((p) => (
          <div key={p.id} className="card tight row gap16">
            <div style={{ width: 42, height: 42, borderRadius: 12, background: p.color + '26', color: p.color, display: 'grid', placeItems: 'center', fontWeight: 900 }}>{p.name[0]}</div>
            <div className="grow"><b>{p.name}</b><div className="dim tiny">{connected[p.id] ? `${settings.handle} · connected` : 'Not connected'}</div></div>
            {connected[p.id] ? <button className="btn sm" onClick={() => setConnected(p.id, false)}><Check size={12} color="#3ddc97" /> Disconnect</button>
              : <button className="btn sm primary" disabled={busy === p.id} onClick={() => connect(p.id, p.name)}>{busy === p.id ? 'Authorizing…' : <><Link2 size={12} /> Connect</>}</button>}
          </div>
        ))}
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { looksLikeUrl, normaliseMediaUrl } from '../lib/source';
import { useStore } from '../store';

const LS = 'clipforge.streams.v1';

interface StreamEntry {
  id: string;
  url: string;
  label: string;
  addedAt: number;
  lastUsed?: number;
}

/**
 * Streams — a saved list of sources so a repeat run is two taps.
 * Kept deliberately dumb: URLs in localStorage, one at a time, no queue that
 * could hold several big files in memory at once.
 */
export default function StreamsPage() {
  const s = useStore();
  const [items, setItems] = useState<StreamEntry[]>([]);
  const [url, setUrl] = useState('');
  const [label, setLabel] = useState('');
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(LS);
      if (raw) setItems(JSON.parse(raw) as StreamEntry[]);
    } catch {
      /* ignore */
    }
  }, []);

  const save = (next: StreamEntry[]) => {
    setItems(next);
    try {
      localStorage.setItem(LS, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  };

  const add = () => {
    const u = url.trim();
    if (!looksLikeUrl(u)) {
      setErr('That does not look like a http(s) link.');
      return;
    }
    setErr(null);
    save([
      {
        id: `s-${Date.now()}`,
        url: normaliseMediaUrl(u),
        label: label.trim() || fileName(u),
        addedAt: Date.now(),
      },
      ...items,
    ]);
    setUrl('');
    setLabel('');
  };

  const use = (e: StreamEntry) => {
    save(items.map((x) => (x.id === e.id ? { ...x, lastUsed: Date.now() } : x)));
    // Hand it to the Clips page and start.
    window.location.hash = '/clips';
    const box = document.getElementById('src') as HTMLInputElement | null;
    if (box) {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      setter?.call(box, e.url);
      box.dispatchEvent(new Event('input', { bubbles: true }));
      box.scrollIntoView({ block: 'center' });
    }
    s.setStatus(`Link filled in: ${e.label}`);
  };

  return (
    <>
      <h1>Streams</h1>
      <p className="dim">
        Save links you clip often. Nothing is downloaded until you press Make clips.
      </p>

      <div className="rowline">
        <label htmlFor="surl">Link</label>
        <input
          id="surl"
          type="url"
          value={url}
          placeholder="https://…/video.mp4"
          onChange={(e) => setUrl(e.target.value)}
        />
        <label htmlFor="slabel">Name (optional)</label>
        <input id="slabel" type="text" value={label} onChange={(e) => setLabel(e.target.value)} />
        <div className="btn-row" style={{ marginTop: 12 }}>
          <button className="btn btn-primary" onClick={add}>
            Save link
          </button>
        </div>
        {err ? <p className="err">{err}</p> : null}
      </div>

      {!items.length ? (
        <div className="empty">No saved links yet.</div>
      ) : (
        items.map((e) => (
          <div className="rowline" key={e.id}>
            <p className="strong" style={{ margin: 0 }}>
              {e.label}
            </p>
            <p className="tiny dim mono" style={{ margin: '2px 0 8px', overflowWrap: 'anywhere' }}>
              {e.url}
            </p>
            <div className="btn-row">
              <button className="btn btn-sm" onClick={() => use(e)}>
                Use
              </button>
              <button className="btn btn-sm" onClick={() => save(items.filter((x) => x.id !== e.id))}>
                Remove
              </button>
            </div>
            {e.lastUsed ? (
              <p className="tiny dim">Last used {new Date(e.lastUsed).toLocaleString()}</p>
            ) : null}
          </div>
        ))
      )}

      <h2>Notes</h2>
      <div className="logbox">
        {`GitHub page links are converted to raw.githubusercontent.com automatically.

A link only works if the site allows cross-origin reads. If a site refuses,
ClipForge tries two public relays, then tells you in plain words. Saving the
video to your phone and picking the file always works.

Live streams (HLS/RTMP) are not supported: there is no finished file to read
frames from, and a clip made from a live stream cannot be verified.`}
      </div>
    </>
  );
}

function fileName(u: string): string {
  try {
    return new URL(u).pathname.split('/').filter(Boolean).pop() || u;
  } catch {
    return u;
  }
}

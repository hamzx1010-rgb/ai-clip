import { useEffect, useRef } from 'react';
import { ArrowRight, Check, Film, Play, Radio, Wand2, Zap } from 'lucide-react';
import { useApp, defaultOptions } from '../store';
import { Logo } from '../App';
import { ClipEngine } from '../lib/clipRender';
import { loadSampleTranscript } from '../lib/llm';
import type { Clip } from '../lib/types';

const PRICING = [
  { name: 'Free', price: '$0', per: '', items: ['3 clips / month', '720p export', 'Watermark', 'Basic editor'], cta: 'Start free' },
  { name: 'Creator', price: '$19', per: '/mo', items: ['50 clips / month', '1080p, no watermark', 'All effects & caption styles', '10 GB storage'], cta: 'Go Creator' },
  { name: 'Pro', price: '$49', per: '/mo', items: ['200 clips / month', '4K export', 'Priority rendering', '100 GB storage', 'Scheduling + analytics'], cta: 'Go Pro', hot: true },
  { name: 'Business', price: '$99', per: '/mo', items: ['Unlimited clips', '5 team seats + collaboration', 'API access', '500 GB storage', 'Custom branding'], cta: 'Go Business' },
  { name: 'Enterprise', price: 'Custom', per: '', items: ['Unlimited everything', 'SLA & SSO', 'White-label', 'Dedicated manager'], cta: 'Contact sales' },
  { name: 'Pay-as-you-go', price: '$0.50', per: '/clip', items: ['No subscription', 'All Creator features', 'Buy AI credits anytime'], cta: 'Buy credits' },
];

function DemoPhone() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    let eng: ClipEngine | null = null;
    let dead = false;
    (async () => {
      const tr = await loadSampleTranscript();
      if (dead || !ref.current) return;
      const clip: Clip = {
        id: 'demo', start: 15.2, end: 34.9, score: 94, breakdown: { hook: 92, retention: 88, comments: 81, shares: 90, saves: 70, replay: 77 },
        reasons: [], categories: ['hot'], title: 'The hook is everything', hooks: ['This advice is ruining creators 😬'], text: '', keywordHits: [], hashtags: [],
      };
      const opts = { ...defaultOptions(useApp.getState().settings), hookText: 'This advice is ruining creators 😬', handle: '@clipforge', sfx: false };
      eng = new ClipEngine({ url: import.meta.env.BASE_URL + 'sample/sample.mp4', clip, options: opts, transcript: tr, audio: null, visual: null }, ref.current);
      try {
        const j = await (await fetch(import.meta.env.BASE_URL + 'sample/sample.json')).json();
        eng.track = (j.shots as { start: number; end: number; cx: number; cy: number }[]).flatMap((s) => [
          { t: s.start + 0.01, cx: s.cx, cy: s.cy, faces: 1 }, { t: s.end - 0.01, cx: s.cx, cy: s.cy, faces: 1 },
        ]);
      } catch { eng.track = [{ t: 0, cx: 0.3, cy: 0.4, faces: 1 }]; }
      eng.onEnd = () => { eng?.seekOut(0).then(() => eng?.play(true)); };
      await eng.ready;
      if (!dead) eng.play(true);
    })();
    return () => { dead = true; eng?.destroy(); };
  }, []);
  return (
    <div className="phone" style={{ width: 250 }}>
      <canvas ref={ref} width={720} height={1280} />
    </div>
  );
}

export default function Landing() {
  const { go } = useApp();
  return (
    <div className="landing">
      <nav className="lnav">
        <Logo onClick={() => go({ name: 'landing' })} />
        <div className="row gap16 small" style={{ fontWeight: 600 }}>
          <a className="muted" href="#features" style={{ textDecoration: 'none' }}>Features</a>
          <a className="muted" href="#how" style={{ textDecoration: 'none' }}>How it works</a>
          <a className="muted" href="#pricing" style={{ textDecoration: 'none' }}>Pricing</a>
          <button className="btn sm" onClick={() => go({ name: 'dashboard' })}>Dashboard</button>
          <button className="btn sm glow" onClick={() => go({ name: 'clip-video' })}>Try it free</button>
        </div>
      </nav>

      <section className="hero">
        <span className="badge brand" style={{ position: 'relative', padding: '6px 12px', fontSize: 12 }}><Zap size={12} /> Opus Clip + CapCut + Premiere + Descript — in one browser tab</span>
        <h1>Turn anything into <span className="grad-text">scroll-stopping</span> content.</h1>
        <p className="lead">Upload a video, paste a stream, or start from a blank canvas. ClipForge finds the viral moments, reframes, captions, scores and publishes them — while you sleep.</p>
        <div className="mode-btns">
          <div className="mode-btn" onClick={() => go({ name: 'clip-video' })}>
            <div className="ic" style={{ background: '#7c5cff33' }}><Film color="#b8a6ff" /></div>
            <b>Clip a Video</b>
            <div className="muted small">Upload a podcast, vlog or VOD → get ranked, captioned, vertical clips.</div>
            <div className="row mt16 small" style={{ color: '#b8a6ff', fontWeight: 700 }}>Start clipping <ArrowRight size={14} /></div>
          </div>
          <div className="mode-btn" onClick={() => go({ name: 'clip-stream' })}>
            <div className="ic" style={{ background: '#ff2d5533' }}><Radio color="#ff7b93" /></div>
            <b>Clip a Stream</b>
            <div className="muted small">Twitch, YouTube, Kick… chat-spike detection and real-time live monitoring.</div>
            <div className="row mt16 small" style={{ color: '#ff7b93', fontWeight: 700 }}>Go live <ArrowRight size={14} /></div>
          </div>
          <div className="mode-btn" onClick={() => go({ name: 'editor' })}>
            <div className="ic" style={{ background: '#ffb54733' }}><Wand2 color="#ffc978" /></div>
            <b>Create from Scratch</b>
            <div className="muted small">Multi-track timeline, keyframes, effects, templates, music & AI tools.</div>
            <div className="row mt16 small" style={{ color: '#ffc978', fontWeight: 700 }}>Open editor <ArrowRight size={14} /></div>
          </div>
        </div>
      </section>

      <section className="lsec" id="how" style={{ paddingTop: 30 }}>
        <div className="row gap24 wrap center" style={{ alignItems: 'center' }}>
          <div className="col" style={{ alignItems: 'center' }}>
            <div className="section-title">Before · 16:9 · 88s podcast</div>
            <div style={{ width: 420, maxWidth: '86vw', aspectRatio: '16/9', borderRadius: 14, overflow: 'hidden', background: `#000 url(${import.meta.env.BASE_URL}sample/poster.jpg) center/cover`, boxShadow: '0 0 0 1px #ffffff18', position: 'relative' }}>
              <div className="badge" style={{ position: 'absolute', left: 10, bottom: 10, background: '#000a', color: '#fff' }}><Play size={10} /> raw upload</div>
            </div>
            <div className="muted small mt8" style={{ maxWidth: 420, textAlign: 'center' }}>Two speakers, landscape, no captions, dead air, filler words.</div>
          </div>
          <ArrowRight size={36} className="dim" />
          <div className="col" style={{ alignItems: 'center' }}>
            <div className="section-title">After · 9:16 · virality 94</div>
            <DemoPhone />
            <div className="muted small mt8">Face-tracked reframe · animated captions · hook overlay · emojis</div>
          </div>
        </div>
      </section>

      <section className="lsec">
        <div className="logos"><span>▶ YouTube</span><span>♪ TikTok</span><span>◎ Instagram</span><span>◆ Twitch</span><span>𝕏 Twitter</span><span>in LinkedIn</span><span>◉ Kick</span></div>
      </section>

      <section className="lsec" id="features">
        <h2>Every tool. <span className="grad-text">One tab.</span></h2>
        <p className="sub">Built on Web Audio, WebGL-accelerated canvas, MediaPipe and MediaRecorder — the heavy lifting happens right in your browser.</p>
        <div className="grid g3">
          {[
            ['🧠', 'Virality engine', 'Every moment scored 0–100 with a breakdown: hook, retention, comments, shares, saves, replay — and plain-English reasoning.'],
            ['🎯', 'Face-tracked reframing', 'On-device face detection follows the active speaker, with split-screen, blur-fill and letterbox layouts.'],
            ['💬', '24 caption styles', 'Hormozi, MrBeast, karaoke, neon, glitch, 3D… keyword emphasis, auto-emojis, profanity bleeps.'],
            ['🪝', 'Hook engineering', 'Teaser-first edits with rewind effect, A/B/C hook overlays and AI-written titles.'],
            ['✂️', 'Descript-style pacing', 'Filler words and dead air removed automatically with seamless jump cuts.'],
            ['🔴', 'Live stream monitor', 'Capture any tab or connect Twitch chat — clips are detected while you are still live.'],
            ['🎵', 'Royalty-free music & SFX', 'Procedurally generated tracks by mood & BPM with auto-ducking and beat-synced zooms.'],
            ['🎬', 'Full timeline editor', 'Multi-track, keyframes, transitions, 12 LUTs, chroma key, AI background removal, templates.'],
            ['📅', 'Publish everywhere', 'Per-platform captions & hashtags, drag-and-drop calendar, bulk scheduling and analytics.'],
          ].map(([ic, t, d]) => (
            <div key={t} className="feature"><div className="ic">{ic}</div><b>{t}</b><div className="muted">{d}</div></div>
          ))}
        </div>
      </section>

      <section className="lsec">
        <h2>Creators ship <span className="grad-text">10× more</span></h2>
        <p className="sub">From a 14-year-old with zero editing experience to agencies managing 50 clients.</p>
        <div className="grid g3">
          {[
            ['“I dropped a 3-hour podcast in and had 40 clips scheduled before lunch. Two of them crossed a million views.”', 'Dana R.', 'Podcast host · 410K followers'],
            ['“The live monitor clipped my clutch while I was still in the game. Posted it mid-stream and gained 12K followers.”', 'NoScopeNate', 'Twitch partner'],
            ['“We replaced four tools and two freelancers. Brand presets keep all 50 clients consistent.”', 'Marco L.', 'Agency founder'],
          ].map(([q, n, r]) => (
            <div key={n} className="testi"><div style={{ fontSize: 15 }}>{q}</div><div className="row mt16"><div style={{ width: 34, height: 34, borderRadius: 99, background: 'var(--grad)' }} /><div><b>{n}</b><div className="dim small">{r}</div></div></div></div>
          ))}
        </div>
      </section>

      <section className="lsec" id="pricing">
        <h2>Simple pricing</h2>
        <p className="sub">Start free. Upgrade when your clips start printing views.</p>
        <div className="grid g3">
          {PRICING.map((p) => (
            <div key={p.name} className={'price' + (p.hot ? ' hot' : '')}>
              <div className="row between"><b style={{ fontSize: 17 }}>{p.name}</b>{p.hot && <span className="badge brand">Most popular</span>}</div>
              <div><span className="amt">{p.price}</span><span className="muted">{p.per}</span></div>
              <ul>{p.items.map((i) => <li key={i}>{i}</li>)}</ul>
              <div className="grow" />
              <button className={'btn ' + (p.hot ? 'glow' : '')} onClick={() => go({ name: 'dashboard' })}>{p.cta}</button>
            </div>
          ))}
        </div>
        <div className="row center wrap gap16 mt24 muted small">
          {['AI credit top-ups', 'Premium template packs', 'Premium music', 'Extra storage', 'Extra seats', 'White-label / resell'].map((a) => <span key={a} className="row gap4"><Check size={14} color="#3ddc97" /> {a}</span>)}
        </div>
      </section>

      <section className="lsec" style={{ textAlign: 'center' }}>
        <h2>Ready to dominate the algorithm?</h2>
        <p className="sub">No install. No credit card. Try it on our sample podcast in 20 seconds.</p>
        <button className="btn lg glow" onClick={() => go({ name: 'clip-video' })}>Clip your first video <ArrowRight size={18} /></button>
      </section>
      <footer className="lsec muted small" style={{ borderTop: '1px solid var(--line)', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
        <span>© 2026 ClipForge · GDPR/CCPA-ready · files auto-delete after 30 days</span>
        <span>Privacy · Terms · DMCA · Status</span>
      </footer>
    </div>
  );
}

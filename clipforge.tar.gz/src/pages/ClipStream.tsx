import { applyLayoutMode } from '../lib/clipRender';
import { useEffect, useRef, useState } from 'react';
import { Radio, Upload, MessageSquare, Play, Square, MonitorPlay, Camera, Sparkles, Download, Bell, Zap } from 'lucide-react';
import { useApp, PLATFORMS, defaultOptions, type ClipSession } from '../store';
import { ClipSettingsPanel, useClipSettings, type SourceFile } from './ClipVideo';
import { Sparkline, Toggle, useInterval } from '../components/ui';
import { detectStreamPlatform, parseChatLog, sampleChat, TwitchChat, hypeScore } from '../lib/chat';
import { runPipeline, type StepState } from '../lib/pipeline';
import { hasAI } from '../lib/llm';
import type { ChatMsg } from '../lib/types';
import { download, fmtTime, uid, clamp } from '../lib/util';
import { pickMime, extFor } from '../lib/recorder';

export default function ClipStream() {
  const [tab, setTab] = useState<'vod' | 'live'>('vod');
  return (
    <div className="page" style={{ maxWidth: 1360 }}>
      <div className="page-head">
        <div><h1>🔴 Clip from a Livestream</h1><div className="muted">Twitch, YouTube Live, Kick, Facebook, TikTok, X Spaces, Rumble — chat-aware highlight detection.</div></div>
        <div className="tabs">
          <div className={'tab' + (tab === 'vod' ? ' on' : '')} onClick={() => setTab('vod')}>📼 Stream / VOD</div>
          <div className={'tab' + (tab === 'live' ? ' on' : '')} onClick={() => setTab('live')}><span className="badge live" style={{ marginRight: 6 }}>LIVE</span>Real-time monitor</div>
        </div>
      </div>
      {tab === 'vod' ? <VodTab /> : <LiveTab />}
    </div>
  );
}

function StepsView({ steps, name }: { steps: StepState[]; name: string }) {
  const done = steps.filter((x) => x.status !== 'wait' && x.status !== 'run').length;
  return (
    <div className="card">
      <h3>Processing {name}…</h3>
      <div className="bar mb8"><div style={{ width: `${(done / steps.length) * 100}%` }} /></div>
      <div className="steps mt16">
        {steps.map((st) => (
          <div key={st.id} className={'step ' + (st.status === 'done' ? 'done' : st.status === 'run' ? 'run' : '')}>
            {st.status === 'run' ? <div className="spin" /> : <span>{st.status === 'done' ? '✅' : st.status === 'skip' ? '⏭️' : st.status === 'error' ? '⚠️' : '⏳'}</span>}
            <div className="grow"><div style={{ fontWeight: 600 }}>{st.label}</div>{st.detail && <div className="small muted">{st.detail}</div>}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

async function processStream(src: SourceFile, chat: ChatMsg[], s: ReturnType<typeof useClipSettings>, setSteps: (x: StepState[]) => void, markers?: { t: number; label: string; strength: number }[]) {
  const st = useApp.getState();
  const res = await runPipeline({
    file: src.file, url: src.url, isSample: src.sample, transcribe: hasAI() ? 'whisper' : 'none', language: s.language, faces: s.faces, llm: s.llm, chatLog: chat, markers, localAsr: st.settings.localAsr ?? 'base',
    settings: { count: s.count, minLen: s.minLen, maxLen: s.maxLen, categories: s.cats, keywords: s.keywords.split(',').map((k) => k.trim()).filter(Boolean), platform: s.platform, speakerPriority: s.speaker, stream: true },
  }, setSteps);
  const plat = PLATFORMS.find((p) => p.id === s.platform)!;
  const session: ClipSession = {
    id: uid('s_'), name: src.name, mode: 'stream', url: src.url, file: src.file, duration: res.duration, width: res.width, height: res.height, createdAt: Date.now(),
    transcript: res.transcript, audio: res.audio, visual: res.visual, chat: res.chat, chatLog: chat, clips: applyLayoutMode(res.clips, s.layout, res.visual, res.width, res.height), platform: s.platform,
    options: { ...defaultOptions(st.settings, plat.aspect as '9:16'), chatOverlay: chat.length > 0, captionStyle: 'gamer' }, exported: [],
  };
  st.addSession(session);
  res.clips.slice(0, 3).forEach((c) => st.logHistory({ title: c.title, score: c.score, kind: 'stream' }));
  st.toast(`🔥 ${res.clips.length} stream highlights ready`, 'success');
  st.go({ name: 'results', sessionId: session.id });
}

function VodTab() {
  const { toast } = useApp();
  const s = useClipSettings(true);
  const [url, setUrl] = useState('');
  const [src, setSrc] = useState<SourceFile | null>(null);
  const [chat, setChat] = useState<ChatMsg[]>([]);
  const [chatText, setChatText] = useState('');
  const [steps, setSteps] = useState<StepState[] | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const chatRef = useRef<HTMLInputElement>(null);
  const plat = detectStreamPlatform(url);

  const loadSample = async () => {
    const r = await fetch(import.meta.env.BASE_URL + 'sample/sample.mp4');
    const b = await r.blob();
    const j = await (await fetch(import.meta.env.BASE_URL + 'sample/sample.json')).json();
    setSrc({ file: b, name: 'Forge Podcast LIVE — VOD (sample)', url: URL.createObjectURL(b), sample: true });
    const msgs = sampleChat(88, j.events.map((e: { start: number; fx: string }) => ({ t: e.start, kind: e.fx })));
    setChat(msgs);
    setChatText(msgs.slice(0, 40).map((m) => `[${fmtTime(m.t)}] ${m.user}: ${m.text}`).join('\n') + '\n…');
    toast(`Loaded sample VOD + ${msgs.length} chat messages`, 'success');
  };

  if (steps && src) return <StepsView steps={steps} name={src.name} />;
  return (
    <div className="grid" style={{ gridTemplateColumns: 'minmax(0,1.1fr) minmax(0,1fr)', alignItems: 'start' }}>
      <div className="col gap16">
        <div className="card">
          <h3>Stream URL</h3>
          <input className="input" placeholder="https://twitch.tv/videos/…  ·  youtube.com/live/…  ·  kick.com/…" value={url} onChange={(e) => setUrl(e.target.value)} />
          {url && (plat ? (
            <div className="card tight mt8 small">
              <div className="row"><span className="badge brand">{plat.name}</span>{plat.live ? <span className="badge live">live channel</span> : <span className="badge">VOD / past stream</span>}</div>
              <div className="muted mt8">
                The hosted ClipForge ingest worker pulls this {plat.live ? 'live stream (streamlink)' : 'VOD (yt-dlp)'} server-side. Browsers can't download platform streams directly, so in this prototype: upload the VOD file below
                {plat.id === 'twitch' && plat.live ? <>, or switch to <b>Real-time monitor</b> — it connects to this channel's live chat for real.</> : '.'}
              </div>
            </div>
          ) : <div className="dim small mt8">Paste a Twitch, YouTube, Kick, Facebook, Instagram, TikTok, X Spaces, Discord or Rumble link.</div>)}
        </div>
        <div className="drop" onClick={() => fileRef.current?.click()} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) setSrc({ file: f, name: f.name, url: URL.createObjectURL(f) }); }}>
          <Upload size={30} color="#ff7b93" />
          <h3 style={{ margin: '10px 0 4px' }}>{src ? src.name : 'Upload the VOD file'}</h3>
          <div className="muted small">{src ? 'Click to replace' : 'MP4 / MKV / WEBM from Twitch, OBS or YouTube Studio'}</div>
          <div className="row center mt16 gap6">
            <button className="btn" onClick={(e) => { e.stopPropagation(); loadSample(); }}><Play size={14} /> Use sample stream (VOD + chat)</button>
          </div>
          <input ref={fileRef} type="file" accept="video/*,audio/*,.mkv" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) setSrc({ file: f, name: f.name, url: URL.createObjectURL(f) }); }} />
        </div>
        <div className="card">
          <h3 className="row"><MessageSquare size={16} /> Chat replay (optional, strongly recommended)</h3>
          <div className="muted small mb8">Paste or upload a chat log — Twitch Downloader JSON, chat-downloader JSON, or lines like <span className="mono">[0:12:34] user: message</span>. We detect spam spikes (LMAO, W, POG, NO WAY…), subs, bits, donations & raids.</div>
          <textarea className="input mono small" rows={6} placeholder="[0:00:12] viewer1: LMAO&#10;[0:00:13] viewer2: NO WAY" value={chatText} onChange={(e) => { setChatText(e.target.value); setChat(parseChatLog(e.target.value)); }} />
          <div className="row between mt8">
            <button className="btn sm" onClick={() => chatRef.current?.click()}><Upload size={13} /> Upload log</button>
            <span className="small">{chat.length ? <span className="badge ok">{chat.length} messages parsed · {chat.filter((m) => m.kind !== 'msg').length} events</span> : <span className="dim">no chat loaded</span>}</span>
          </div>
          <input ref={chatRef} type="file" accept=".json,.txt,.log,.csv" hidden onChange={async (e) => { const f = e.target.files?.[0]; if (f) { const t = await f.text(); setChat(parseChatLog(t)); setChatText(t.slice(0, 5000)); } }} />
        </div>
        <button className="btn glow lg" disabled={!src} onClick={() => src && processStream(src, chat, s, setSteps).catch((e) => { toast('Failed: ' + e.message, 'error'); setSteps(null); })}><Sparkles size={18} /> Find stream highlights</button>
      </div>
      <div className="col gap16">
        <div className="card tight small">
          <div className="section-title">Stream-specific detection</div>
          <div className="grid g2 muted">
            <span>💬 Chat spam spike detection</span><span>📈 Chat-velocity × audio correlation</span><span>💸 Subs / bits / donations as markers</span><span>🚀 Raid & host moments</span>
            <span>😂 Laughter & crowd reactions</span><span>🎮 Hype / rage / clutch audio spikes</span><span>⏱️ 15–30s duration optimisation</span><span>🗨️ Top-chat overlay on clips</span>
          </div>
        </div>
        <ClipSettingsPanel s={s} speakers={src?.sample ? ['Maya', 'Jordan'] : []} stream />
      </div>
    </div>
  );
}

type Moment = { id: string; t: number; score: number; reason: string; posted?: boolean };

function LiveTab() {
  const { toast } = useApp();
  const s = useClipSettings(true);
  const [source, setSource] = useState<'tab' | 'cam'>('tab');
  const [channel, setChannel] = useState('');
  const [chatStatus, setChatStatus] = useState('');
  const [live, setLive] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [energy, setEnergy] = useState<number[]>([]);
  const [chatRate, setChatRate] = useState<number[]>([]);
  const [moments, setMoments] = useState<Moment[]>([]);
  const [feed, setFeed] = useState<ChatMsg[]>([]);
  const [autoPost, setAutoPost] = useState(false);
  const [notify, setNotify] = useState(true);
  const [sens, setSens] = useState(1.8);
  const [recording, setRecording] = useState<SourceFile | null>(null);
  const [steps, setSteps] = useState<StepState[] | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const R = useRef<{ stream?: MediaStream; rec?: MediaRecorder; chunks: Blob[]; ac?: AudioContext; an?: AnalyserNode; t0: number; base: number; short: number[]; last: number; chat?: TwitchChat; chatLog: ChatMsg[]; chatBucket: number; chatBase: number; lastChat: number; markers: { t: number; label: string; strength: number }[] }>({ chunks: [], t0: 0, base: 0.02, short: [], last: -99, chatLog: [], chatBucket: 0, chatBase: 1, lastChat: -99, markers: [] });

  const addMoment = (t: number, score: number, reason: string) => {
    const m: Moment = { id: uid(), t, score, reason, posted: autoPost };
    setMoments((x) => [m, ...x]);
    R.current.markers.push({ t, label: reason, strength: clamp((score - 50) / 50, 0.2, 1) });
    toast(`🔥 Clip detected! Virality score: ${score} — ${reason}`, 'fire');
    if (notify && 'Notification' in window && Notification.permission === 'granted') new Notification('🔥 Clip detected!', { body: `Virality score ${score} · ${reason}` });
    if (autoPost) setTimeout(() => toast(`📤 Auto-post queued: clip @ ${fmtTime(t)} → TikTok & Shorts`, 'success'), 1200);
  };

  const start = async () => {
    try {
      const stream = source === 'tab'
        ? await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 30 }, audio: true })
        : await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      const r = R.current;
      r.stream = stream; r.chunks = []; r.t0 = performance.now(); r.base = 0.02; r.short = []; r.last = -99; r.chatLog = []; r.markers = []; r.chatBucket = 0; r.chatBase = 1;
      if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.muted = true; videoRef.current.play(); }
      if (stream.getAudioTracks().length) {
        const ac = new AudioContext();
        const an = ac.createAnalyser(); an.fftSize = 2048;
        ac.createMediaStreamSource(stream).connect(an);
        r.ac = ac; r.an = an;
      } else toast('No audio track captured — tick “Share tab audio” for audio-based detection', 'error');
      const mime = pickMime();
      const rec = new MediaRecorder(stream, { mimeType: mime });
      rec.ondataavailable = (e) => e.data.size && r.chunks.push(e.data);
      rec.start(1000);
      r.rec = rec;
      stream.getVideoTracks()[0].addEventListener('ended', () => stop());
      if (notify && 'Notification' in window && Notification.permission === 'default') Notification.requestPermission();
      setMoments([]); setEnergy([]); setChatRate([]); setFeed([]); setRecording(null); setLive(true);
      toast('🔴 Live monitoring started', 'success');
    } catch (e) {
      toast('Could not start capture: ' + (e as Error).message, 'error');
    }
  };

  const stop = () => {
    const r = R.current;
    if (!r.rec) return;
    const mime = r.rec.mimeType;
    r.rec.onstop = () => {
      const blob = new Blob(r.chunks, { type: mime.split(';')[0] });
      setRecording({ file: blob, name: `Live session ${new Date().toLocaleString()}`, url: URL.createObjectURL(blob) });
    };
    r.rec.stop(); r.rec = undefined;
    r.stream?.getTracks().forEach((t) => t.stop());
    r.ac?.close(); r.ac = undefined; r.an = undefined;
    setLive(false);
    toast('Stream ended — post-stream summary ready', 'success');
  };

  const connectChat = () => {
    R.current.chat?.close();
    const c = new TwitchChat(channel, (m) => {
      const t = R.current.rec ? (performance.now() - R.current.t0) / 1000 : 0;
      const msg: ChatMsg = { t, user: m.user, text: m.text, kind: m.kind };
      R.current.chatLog.push(msg);
      R.current.chatBucket += 1 + hypeScore(m.text) * 0.5 + (m.kind !== 'msg' ? 3 : 0);
      setFeed((f) => [...f.slice(-60), msg]);
    }, setChatStatus);
    c.connect();
    R.current.chat = c;
  };
  useEffect(() => () => { R.current.chat?.close(); if (R.current.rec) stop(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // audio loop 10x/s
  useInterval(() => {
    const r = R.current;
    const t = (performance.now() - r.t0) / 1000;
    setElapsed(t);
    if (!r.an) return;
    const buf = new Float32Array(r.an.fftSize);
    r.an.getFloatTimeDomainData(buf);
    let sum = 0; for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
    const rms = Math.sqrt(sum / buf.length);
    r.short.push(rms); if (r.short.length > 10) r.short.shift();
    const shortMean = r.short.reduce((a, b) => a + b, 0) / r.short.length;
    r.base = r.base * 0.995 + rms * 0.005;
    setEnergy((e) => [...e.slice(-299), rms]);
    const ratio = shortMean / (r.base + 0.004);
    if (t > 6 && ratio > sens && shortMean > 0.02 && t - r.last > 8) {
      r.last = t;
      const chatBoost = t - r.lastChat < 8 ? 10 : 0;
      addMoment(Math.max(0, t - 12), Math.round(clamp(62 + (ratio - sens) * 14 + chatBoost, 55, 99)), chatBoost ? 'audio spike + chat explosion' : `audio spike ${ratio.toFixed(1)}× baseline`);
    }
  }, live ? 100 : null);

  // chat velocity every 5s
  useInterval(() => {
    const r = R.current;
    const t = (performance.now() - r.t0) / 1000;
    const v = r.chatBucket; r.chatBucket = 0;
    setChatRate((x) => [...x.slice(-119), v]);
    const ratio = v / (r.chatBase + 1);
    r.chatBase = r.chatBase * 0.85 + v * 0.15;
    if (t > 15 && v >= 6 && ratio > 2.2 && t - r.lastChat > 10) {
      r.lastChat = t;
      if (t - r.last > 8) { r.last = t; addMoment(Math.max(0, t - 15), Math.round(clamp(60 + ratio * 8, 55, 98)), `chat exploded ${ratio.toFixed(1)}× normal`); }
    }
  }, live ? 5000 : null);

  if (steps && recording) return <StepsView steps={steps} name={recording.name} />;
  return (
    <div className="grid" style={{ gridTemplateColumns: 'minmax(0,1.4fr) minmax(0,1fr)', alignItems: 'start' }}>
      <div className="col gap16">
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ aspectRatio: '16/9', background: '#000', position: 'relative', display: 'grid', placeItems: 'center' }}>
            <video ref={videoRef} playsInline style={{ width: '100%', height: '100%', objectFit: 'contain', display: live ? 'block' : 'none' }} />
            {!live && (
              <div className="col" style={{ alignItems: 'center', textAlign: 'center', padding: 20 }}>
                <MonitorPlay size={40} color="#ff7b93" />
                <b style={{ fontSize: 17 }}>Monitor any stream in real time</b>
                <div className="muted small" style={{ maxWidth: 440 }}>Open your stream (or any Twitch/YouTube/Kick stream) in another tab, then capture that tab with audio. ClipForge listens for hype moments and marks clips while you're still live.</div>
              </div>
            )}
            {live && <div className="row" style={{ position: 'absolute', top: 12, left: 12 }}><span className="badge live pulse">● LIVE</span><span className="badge" style={{ background: '#000a', color: '#fff' }}>{fmtTime(elapsed)}</span><span className="badge" style={{ background: '#000a', color: '#fff' }}>{moments.length} clips</span></div>}
          </div>
          <div style={{ padding: 14 }}>
            <div className="row between small"><span className="section-title" style={{ margin: 0 }}>Audio energy</span><span className="dim tiny">threshold {sens.toFixed(1)}× rolling baseline</span></div>
            <Sparkline data={energy} h={50} color="#ff4fa3" />
            <div className="row between small mt8"><span className="section-title" style={{ margin: 0 }}>Chat velocity (per 5s)</span><span className="dim tiny">{chatStatus || 'chat not connected'}</span></div>
            <Sparkline data={chatRate} h={40} color="#7c5cff" />
          </div>
        </div>
        {recording && !live && (
          <div className="card">
            <h3>📋 Post-stream summary</h3>
            <div className="row wrap gap16 small"><span><b>{fmtTime(elapsed)}</b> streamed</span><span><b>{moments.length}</b> live-detected moments</span><span><b>{R.current.chatLog.length}</b> chat messages</span></div>
            <div className="row mt16 gap6">
              <button className="btn glow" onClick={() => processStream(recording, R.current.chatLog, s, setSteps, R.current.markers).catch((e) => { toast(e.message, 'error'); setSteps(null); })}><Sparkles size={16} /> Build highlight clips</button>
              <button className="btn" onClick={() => download(recording.file, `live-session.${extFor(recording.file.type)}`)}><Download size={16} /> Download full recording</button>
            </div>
          </div>
        )}
      </div>
      <div className="col gap16">
        <div className="card">
          <h3>Source</h3>
          <div className="row gap6">
            <button className={'btn grow' + (source === 'tab' ? ' active' : '')} onClick={() => setSource('tab')} disabled={live}><MonitorPlay size={15} /> Tab / screen + audio</button>
            <button className={'btn grow' + (source === 'cam' ? ' active' : '')} onClick={() => setSource('cam')} disabled={live}><Camera size={15} /> Webcam + mic</button>
          </div>
          <label className="field mt16">Twitch channel for live chat (optional, read-only)
            <div className="row"><input className="input" placeholder="e.g. kaicenat or twitch.tv/xqc" value={channel} onChange={(e) => setChannel(e.target.value)} /><button className="btn" onClick={connectChat} disabled={!channel}><MessageSquare size={14} /> Connect</button></div>
          </label>
          <div className="mt8"><Slider2 value={sens} onChange={setSens} /></div>
          <Toggle label={<span><Bell size={13} /> Browser notifications on detection</span>} value={notify} onChange={setNotify} />
          <Toggle label={<span><Zap size={13} /> Auto-post clips during the stream</span>} value={autoPost} onChange={setAutoPost} />
          <div className="mt16">
            {!live ? <button className="btn glow lg" style={{ width: '100%' }} onClick={start}><Radio size={18} /> Start live monitoring</button>
              : <button className="btn lg danger" style={{ width: '100%' }} onClick={stop}><Square size={16} /> End stream & summarise</button>}
          </div>
        </div>
        <div className="card">
          <h3>Detected moments</h3>
          {!moments.length && <div className="dim small">Moments appear here the instant they're detected (audio spikes, chat explosions, or both).</div>}
          <div className="col gap6">
            {moments.map((m) => (
              <div key={m.id} className="row card tight" style={{ padding: 10 }}>
                <b className="mono" style={{ color: m.score >= 85 ? 'var(--ok)' : 'var(--accent)', fontSize: 18 }}>{m.score}</b>
                <div className="grow"><div style={{ fontWeight: 600 }}>🔥 Clip @ {fmtTime(m.t)}</div><div className="dim small">{m.reason}</div></div>
                {m.posted && <span className="badge ok">auto-posted</span>}
              </div>
            ))}
          </div>
        </div>
        {feed.length > 0 && (
          <div className="card tight" style={{ maxHeight: 260, overflow: 'auto' }}>
            <div className="section-title">Live chat</div>
            {feed.slice(-40).map((m, i) => <div key={i} className="small" style={{ padding: '2px 0' }}><b style={{ color: m.kind !== 'msg' ? '#ffd23f' : '#b8a6ff' }}>{m.user}</b>: {m.text}</div>)}
          </div>
        )}
      </div>
    </div>
  );
}

function Slider2({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <label className="field">
      <div className="row between"><span>Detection sensitivity</span><span className="mono">{value <= 1.5 ? 'high' : value <= 2.2 ? 'medium' : 'low'}</span></div>
      <input type="range" min={1.3} max={3} step={0.1} value={3.3 - value} onChange={(e) => onChange(+(3.3 - +e.target.value).toFixed(1))} />
    </label>
  );
}

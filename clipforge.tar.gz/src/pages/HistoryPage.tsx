import { useEffect, useState } from 'react';
import { formatBytes, formatTime } from '../lib/download';
import * as db from '../lib/db';
import type { Clip, RunMeta } from '../lib/types';
import { useStore } from '../store';

interface Row {
  run: RunMeta;
  clips: Clip[];
}

export default function HistoryPage() {
  const s = useStore();
  const [rows, setRows] = useState<Row[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [usage, setUsage] = useState<{ usage: number; quota: number } | null>(null);
  const [loading, setLoading] = useState(true);

  const reload = async () => {
    setLoading(true);
    const runs = await db.listRuns();
    const out: Row[] = [];
    for (const r of runs) {
      const clips = await db.listClips(r.id);
      out.push({ run: r, clips });
    }
    setRows(out);
    setUsage(await db.storageEstimate());
    setLoading(false);
  };

  useEffect(() => {
    void reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openRun = async (r: RunMeta) => {
    const clips = await db.listClips(r.id);
    s.setRun(r);
    s.setClips(clips.map((c) => ({ ...c, url: null, thumbUrl: c.thumbUrl ?? null })));
    s.setSource(null); // the bytes are gone; re-making needs the source again
    s.go('results');
  };

  return (
    <>
      <h1>History</h1>
      <p className="dim">Runs stored on this device. Finished clips are never made twice.</p>

      {loading ? <p className="dim">Loading…</p> : null}

      {!loading && !rows.length ? (
        <div className="empty">Nothing stored yet.</div>
      ) : null}

      {rows.map(({ run, clips }) => {
        const good = clips.filter((c) => c.status === 'done').length;
        const bytes = clips.reduce((a, c) => a + (c.sizeBytes || 0), 0);
        const isOpen = open === run.id;
        return (
          <div className="rowline" key={run.id}>
            <div className="spread wrap">
              <div style={{ minWidth: 0, flex: '1 1 200px' }}>
                <p className="strong" style={{ margin: 0, overflowWrap: 'anywhere' }}>
                  {run.sourceName}
                </p>
                <p className="tiny dim" style={{ margin: '2px 0 0' }}>
                  {new Date(run.createdAt).toLocaleString()} · {formatTime(run.sourceDuration)} source ·{' '}
                  {good}/{clips.length} clips · {formatBytes(bytes)}
                </p>
              </div>
              <div className="btn-row" style={{ flex: '0 1 auto' }}>
                <button className="btn btn-sm" onClick={() => void openRun(run)} disabled={!good}>
                  Open
                </button>
                <button className="btn btn-sm" onClick={() => setOpen(isOpen ? null : run.id)}>
                  {isOpen ? 'Hide' : 'Details'}
                </button>
              </div>
            </div>

            {isOpen ? (
              <div style={{ marginTop: 10 }}>
                <div className="logbox">
                  {clips
                    .map(
                      (c) =>
                        `#${c.index + 1} ${formatTime(c.start)}–${formatTime(c.end)} · ${c.status}` +
                        `${c.analysis ? ` · score ${c.analysis.score}` : ''}` +
                        `${c.analysis ? ` · ${c.layout === 'face' ? 'face' : 'full frame'}` : ''}` +
                        `${c.verification ? ` · file ${c.verification.duration.toFixed(1)}s · ${c.verification.framesDecoded}/${c.verification.framesExpected} frames · audio ${c.verification.audioPresent ? 'yes' : 'no'}` : ''}` +
                        `${c.error ? ` · ${c.error}` : ''}`,
                    )
                    .join('\n') || '(no clips)'}
                </div>
                <div className="btn-row" style={{ marginTop: 8 }}>
                  <button
                    className="btn btn-sm"
                    onClick={async () => {
                      await db.deleteRun(run.id);
                      await reload();
                    }}
                  >
                    Delete this run and its files
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        );
      })}

      <hr />
      <h2>Storage</h2>
      <p className="small dim">
        {usage
          ? `Using ${formatBytes(usage.usage)} of about ${formatBytes(usage.quota)} allowed on this device.`
          : 'This browser will not say how much storage it allows.'}
      </p>
      <div className="btn-row">
        <button
          className="btn"
          onClick={async () => {
            if (!confirm('Delete every stored run and clip file on this device?')) return;
            for (const r of rows) await db.deleteRun(r.run.id);
            await reload();
          }}
        >
          Clear everything
        </button>
      </div>
    </>
  );
}

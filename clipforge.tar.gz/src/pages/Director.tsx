import { useEffect, useRef, useState } from 'react';
import { setBusy } from '../lib/busy';
import { Clapperboard, Upload, Link2, Play, Mic, X, Sparkles, Copy, Download, KeyRound, BookOpen } from 'lucide-react';
import { useApp } from '../store';
import { Seg, Toggle } from '../components/ui';
import { runDirector, type DStep, type DirectorResult } from '../lib/director/run';
import { VOICES, TTS_MB, speak } from '../lib/director/tts';
import { aiLabel, aiMode } from '../lib/director/ai';
import type { Script } from '../lib/director/script';
import { download, fmtTime, slug } from '../lib/util';

const LENGTHS = [0, 1, 3, 5, 10, 20, 30];
const IDEAS = [
  'The rise and fall of the 2b2t Minecraft server — dark, mysterious tone, focus on the players who shaped it',
  'How the Apollo 11 crew actually landed on the Moon — minute by minute, suspenseful',
  'The fall of the Roman Empire explained simply — epic tone',
  'The story of the Titanic — from the shipyard to the iceberg, emotional',
];

export default function Director() {
  const { go, toast, settings } = useApp();
  const [desc, setDesc] = useState('');
  const [refs, setRefs] = useState('');
  const [refFile, setRefFile] = useState<File | null>(null);
  const [minutes, setMinutes] = useState(5);
  const [mode, setMode] = useState<'fast' | 'deep'>((localStorage.getItem('cf-director-mode') as 'fast' | 'deep') || 'fast');
  const [voice, setVoice] = useState<string>(localStorage.getItem('cf-voice') || 'am_michael');
  const [engine, setEngine] = useState<'kokoro' | 'openai'>('kokoro');
  const [captions, setCaptions] = useState(true);
  const [music, setMusic] = useState(true);
  const [gentle, setGentle] = useState(true);
  const [aiImages, setAiImages] = useState(true);
  const [quotes, setQuotes] = useState(true);
  const [interviews, setInterviews] = useState<{ file: File; name: string }[]>([]);
  const [steps, setSteps] = useState<DStep[] | null>(null);
  const [script, setScript] = useState<Partial<Script> | null>(null);
  const [result, setResult] = useState<DirectorResult | null>(null);
  const [error, setError] = useState('');
  const [previewing, setPreviewing] = useState(false);
  const [t0, setT0] = useState(0);
  const ac = useRef<AbortController | null>(null);
  const ivInput = useRef<HTMLInputElement>(null);
  const refInput = useRef<HTMLInputElement>(null);

  const preview = async () => {
    setPreviewing(true);
    try {
      const s = await speak('This is the story of an idea that changed everything. And it started with a single question.', voice, { engine: 'kokoro', onProgress: (p) => { if (p.phase === 'download' && p.total) toast(`Downloading voice ${Math.round(((p.loaded || 0) / p.total) * 100)}%`, 'info'); } });
      const a = new Audio(URL.createObjectURL(s.blob)); await a.play();
    } catch (e) { toast('Voice preview failed: ' + (e as Error).message, 'error'); }
    setPreviewing(false);
  };

  const start = async () => {
    if (desc.trim().length < 8) { toast('Describe your video first (a sentence or two).', 'error'); return; }
    localStorage.setItem('cf-voice', voice);
    localStorage.setItem('cf-director-mode', mode);
    setError(''); setResult(null); setScript(null); setT0(performance.now());
    ac.current = new AbortController();
    try {
      const r = await runDirector({
        description: desc.trim(), references: refs.split(/\s+/).filter((x) => /^https?:\/\//.test(x)), referenceFile: refFile, minutes,
        voice: engine === 'openai' ? 'onyx' : voice, voiceEngine: engine, mode, captions, music, gentleMoves: gentle, aiImages, quotes, interviews,
      }, setSteps, (s) => setScript((x) => ({ ...x, ...s })), ac.current.signal);
      setResult(r);
      toast(`🎬 “${r.title}” is ready (${fmtTime(r.duration)})`, 'success');
    } catch (e) {
      if ((e as Error).name === 'AbortError') { toast('Stopped', 'info'); setSteps(null); }
      else { console.error(e); setError((e as Error).message); }
    }
    ac.current = null;
  };

  const running = !!ac.current && !result;
  useEffect(() => { setBusy('director', running, 'making your documentary'); }, [running]);
  if (steps) {
    return (
      <div className="page" style={{ maxWidth: 980 }}>
        <div className="page-head"><div><h1>🎬 {result?.title || script?.title || 'Making your video…'}</h1><div className="muted">{result ? `Done in ${fmtTime((performance.now() - t0) / 1000)} · ${fmtTime(result.duration)} long · 9:16` : 'Keep this tab open (you can switch pages or tabs). Everything runs in your browser.'}</div></div></div>
        <div className="grid g2" style={{ alignItems: 'start' }}>
          <div className="card col gap8">
            <div className="steps">
              {steps.map((s) => (
                <div key={s.id} className={'step ' + (s.status === 'run' ? 'run' : '')}>
                  <span style={{ width: 22 }}>{s.status === 'done' ? '✅' : s.status === 'run' ? <span className="spin" /> : s.status === 'error' ? '⚠️' : s.status === 'skip' ? '⏭️' : '⏳'}</span>
                  <div className="grow"><div>{s.label}</div>{s.detail && <div className="dim tiny">{s.detail}</div>}{s.status === 'run' && s.progress !== undefined && <div className="bar mt8"><div style={{ width: `${Math.round(s.progress * 100)}%` }} /></div>}</div>
                </div>
              ))}
            </div>
            {error && <div className="card tight" style={{ borderColor: '#ff4f6d88' }}><b>Couldn’t finish:</b> <span className="muted small">{error}</span></div>}
            <div className="row gap8">
              {running && <button className="btn" onClick={() => ac.current?.abort()}><X size={14} /> Stop</button>}
              {result && <button className="btn glow lg grow" onClick={() => go({ name: 'editor', projectId: result.projectId })}><Clapperboard size={16} /> Open in editor &amp; export</button>}
              {(result || error) && <button className="btn ghost" onClick={() => { setSteps(null); setResult(null); setError(''); }}>New video</button>}
            </div>
            {result && <div className="dim tiny">Tip: in the editor press Export — it renders faster than real time. Every cut, caption and title is editable.</div>}
          </div>
          <div className="card col gap8" style={{ maxHeight: 640, overflow: 'auto' }}>
            <div className="section-title" style={{ margin: 0 }}><BookOpen size={14} /> Script</div>
            {!script?.chapters ? <div className="dim small">The script appears here as it’s written…</div> : (
              <>
                <div className="small"><b>Cold open:</b> {script.hook}</div>
                {script.chapters.map((c, i) => (
                  <div key={i} className="small"><b style={{ color: 'var(--accent, #e8c872)' }}>Chapter {i + 1} — {c.title}</b>
                    {c.beats.map((b, k) => <div key={k} className="muted" style={{ marginTop: 4 }}>{b.quote ? <i>“{b.quote.text}” — {b.quote.by}</i> : b.narration}</div>)}
                  </div>
                ))}
                <div className="small"><b>Outro:</b> {script.outro}</div>
              </>
            )}
            {result && (
              <div className="row gap6 mt8">
                <button className="btn sm" onClick={() => { navigator.clipboard.writeText(result.description); toast('Description with chapters & credits copied', 'success'); }}><Copy size={12} /> Copy description</button>
                <button className="btn sm" onClick={() => download(new Blob([result.credits], { type: 'text/plain' }), `${slug(result.title)}-sources.txt`)}><Download size={12} /> sources.txt</button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page" style={{ maxWidth: 980 }}>
      <div className="page-head"><div><h1>🎬 AI Director</h1><div className="muted">Describe the video. The AI researches it, writes and narrates the script, finds real footage, cuts it, adds captions, titles and music — you get a finished, editable 9:16 video.</div></div></div>
      <div className="card col gap16">
        <label className="field" style={{ fontSize: 15 }}><b>Describe your video</b>
          <textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={4} placeholder="e.g. A documentary about the rise and fall of the 2b2t Minecraft server — dark, mysterious tone, focus on the players who shaped it" style={{ fontSize: 15, lineHeight: 1.5 }} />
        </label>
        <div className="row wrap gap6">{IDEAS.map((i) => <div key={i} className="chip" onClick={() => setDesc(i)} style={{ maxWidth: 440 }}><Sparkles size={11} /> {i.length > 64 ? i.slice(0, 62) + '…' : i}</div>)}</div>

        <div className="grid g2">
          <label className="field"><span><Link2 size={13} /> Reference (optional)</span>
            <textarea value={refs} onChange={(e) => setRefs(e.target.value)} rows={2} placeholder={'Links, one per line:\n• a video to copy the style/pacing of (direct .mp4 link)\n• articles to use as sources'} />
            <div className="row gap6 mt8">
              <button className="btn sm" onClick={() => refInput.current?.click()}><Upload size={12} /> {refFile ? refFile.name.slice(0, 28) : 'Upload a reference video'}</button>
              {refFile && <button className="btn sm ghost icon" onClick={() => setRefFile(null)}><X size={12} /></button>}
              <input ref={refInput} type="file" accept="video/*" hidden onChange={(e) => setRefFile(e.target.files?.[0] || null)} />
            </div>
            <span className="dim tiny">From a reference video it copies the editing pace and narration speed. It won’t reuse its footage.</span>
          </label>
          <div className="field"><span><Mic size={13} /> Your interviews / footage (optional)</span>
            <div className="col gap6">
              {interviews.map((iv, i) => (
                <div key={i} className="row gap6"><span className="tiny dim" style={{ width: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{iv.file.name}</span>
                  <input className="grow" value={iv.name} placeholder="Name — role (lower third)" onChange={(e) => setInterviews(interviews.map((x, k) => (k === i ? { ...x, name: e.target.value } : x)))} />
                  <button className="btn sm ghost icon" onClick={() => setInterviews(interviews.filter((_, k) => k !== i))}><X size={12} /></button></div>
              ))}
              <button className="btn sm" onClick={() => ivInput.current?.click()}><Upload size={12} /> Add interview recordings</button>
              <input ref={ivInput} type="file" accept="video/*,audio/*" multiple hidden onChange={(e) => { const fs = [...(e.target.files || [])]; setInterviews([...interviews, ...fs.map((file) => ({ file, name: '' }))]); e.target.value = ''; }} />
            </div>
            <span className="dim tiny">The AI transcribes them and cuts the best soundbites into the matching chapters, with name titles. Without interviews it uses real quotes from Wikiquote, shown on screen and read out by a second voice.</span>
          </div>
        </div>

        <div>
          <div className="section-title">Mode</div>
          <div className="grid g2" style={{ gap: 8 }}>
            {([['fast', '⚡ Fast', 'Quicker research & script, narration recorded while footage is found, fewer video clips. Great for most videos.'],
              ['deep', '🔬 Deep', 'More sources, more & shorter chapters written one by one, twice the video b-roll, measures the reference narration speed. Slower, richer.']] as const).map(([v, l, d]) => (
              <div key={v} className={'chip' + (mode === v ? ' on' : '')} style={{ flexDirection: 'column', alignItems: 'flex-start', padding: 12, borderRadius: 12 }} onClick={() => setMode(v)}><b>{l}</b><span className="tiny dim">{d}</span></div>
            ))}
          </div>
        </div>

        <div>
          <div className="section-title">Length</div>
          <Seg value={minutes} options={LENGTHS.map((m) => ({ v: m, l: m === 0 ? '✨ Auto' : `${m} min` }))} onChange={setMinutes} />
          {minutes >= 10 && <div className="dim tiny mt8">Long videos take a while: the narration is recorded on your device (roughly as long as the video on a computer, longer on a phone).</div>}
        </div>

        <div className="grid g2">
          <div>
            <div className="section-title">Narrator</div>
            <div className="row gap6">
              <select value={engine === 'openai' ? 'openai' : voice} onChange={(e) => { if (e.target.value === 'openai') setEngine('openai'); else { setEngine('kokoro'); setVoice(e.target.value); } }} className="grow">
                {VOICES.map((v) => <option key={v.id} value={v.id}>{v.label}</option>)}
                {settings.openaiKey && /api\.openai\.com/.test(settings.openaiBase || '') && <option value="openai">OpenAI voice “onyx” (uses your key)</option>}
              </select>
              <button className="btn sm" disabled={previewing || engine === 'openai'} onClick={preview}>{previewing ? <span className="spin" /> : <Play size={12} />} Preview</button>
            </div>
            <div className="dim tiny mt8">Free AI voice running on your device (English). It downloads once (~{TTS_MB} MB), then it’s cached.</div>
          </div>
          <div className="col gap6">
            <Toggle label="Captions" value={captions} onChange={setCaptions} />
            <Toggle label="Background music" value={music} onChange={setMusic} />
            <Toggle label="Slow pan on photos (no zooms)" value={gentle} onChange={setGentle} />
            <Toggle label="AI illustrations when no real footage exists (labelled in credits)" value={aiImages} onChange={setAiImages} />
            <Toggle label="Real quotes from Wikiquote" value={quotes} onChange={setQuotes} />
          </div>
        </div>

        <div className="card tight small muted row gap8 wrap">
          <KeyRound size={14} /> Script writer: <b style={{ color: 'var(--text)' }}>{aiLabel()}</b>.
          {aiMode() === 'free' && <span>The free service is sometimes busy. If it is, ClipForge writes the narration straight from the sources. For better, more reliable scripts, add a free <b>Google Gemini</b> or <b>Groq</b> key in <a href="#" onClick={(e) => { e.preventDefault(); go({ name: 'settings' }); }}>Settings</a>.</span>}
        </div>
        <button className="btn glow lg" onClick={start}><Clapperboard size={18} /> Make my video</button>
        <div className="dim tiny">Footage: Wikimedia Commons, Openverse and NASA (plus Pexels if you add a key). Credits are collected automatically. Facts come from Wikipedia and your links.</div>
      </div>
    </div>
  );
}

import type { Item, Project, Asset } from './model';
import { kfValue, LUTS, projectDuration } from './model';
import { clamp, easing, roundRect, seeded, wrapText } from '../../lib/util';
import { getSegmenter, segmentToMask } from '../../lib/faces';
import { pickMime } from '../../lib/recorder';
import type { ImageSegmenter } from '@mediapipe/tasks-vision';

type Box = { id: string; x: number; y: number; w: number; h: number };
type Media = { el: HTMLMediaElement; src?: MediaElementAudioSourceNode; gain?: GainNode; chainIn?: AudioNode; enhance?: boolean; assetId: string };

export class Compositor {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  layer = document.createElement('canvas');
  lctx: CanvasRenderingContext2D;
  tmp = document.createElement('canvas');
  project: Project;
  time = 0;
  playing = false;
  p0 = 0; t0 = 0;
  raf = 0;
  media = new Map<string, Media>();
  images = new Map<string, HTMLImageElement>();
  ac: AudioContext | null = null;
  master?: GainNode; dest?: MediaStreamAudioDestinationNode; analyser?: AnalyserNode; freq = new Uint8Array(64);
  boxes: Box[] = [];
  onTime?: (t: number) => void;
  onEnd?: () => void;
  endAt: number | null = null;
  grain: HTMLCanvasElement;
  seg: ImageSegmenter | null = null;
  segLoading = false;
  selected: string | null = null;
  guides = true;
  /** Offline (export) mode: video frames come from `frameSrc` (decoded with WebCodecs) instead of <video> elements. */
  offline = false;
  frameSrc = new Map<string, { img: CanvasImageSource; w: number; h: number }>();

  constructor(canvas: HTMLCanvasElement, project: Project) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.lctx = this.layer.getContext('2d', { willReadFrequently: true })!;
    this.project = project;
    this.grain = document.createElement('canvas');
    this.grain.width = this.grain.height = 256;
    const g = this.grain.getContext('2d')!;
    const id = g.createImageData(256, 256);
    const r = seeded(99);
    for (let i = 0; i < id.data.length; i += 4) { const v = r() * 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; }
    g.putImageData(id, 0, 0);
  }

  setProject(p: Project) {
    this.project = p;
    // drop media for removed items
    for (const [id, m] of this.media) {
      const it = p.items.find((i) => i.id === id);
      if (!it || it.assetId !== m.assetId) { m.el.pause(); m.src?.disconnect(); this.media.delete(id); }
    }
    if (!this.playing) this.render();
  }

  asset(id?: string): Asset | undefined { return this.project.assets.find((a) => a.id === id); }

  getMedia(it: Item): Media | null {
    if (!it.assetId) return null;
    let m = this.media.get(it.id);
    if (m) return m;
    const a = this.asset(it.assetId);
    if (!a || !a.url) return null;
    const el = a.kind === 'video' ? document.createElement('video') : document.createElement('audio');
    el.src = a.url; el.preload = 'auto'; el.crossOrigin = 'anonymous';
    if (el instanceof HTMLVideoElement) { el.playsInline = true; el.addEventListener('seeked', () => { if (!this.playing) this.render(); }); el.addEventListener('loadeddata', () => { if (!this.playing) this.render(); }); }
    m = { el, assetId: a.id };
    this.media.set(it.id, m);
    if (this.ac) this.wire(m, it);
    return m;
  }

  ensureAudio() {
    if (this.ac) return;
    const ac = new AudioContext();
    this.ac = ac;
    this.master = ac.createGain();
    this.analyser = ac.createAnalyser(); this.analyser.fftSize = 128;
    this.master.connect(this.analyser);
    this.master.connect(ac.destination);
    this.dest = ac.createMediaStreamDestination();
    this.master.connect(this.dest);
    for (const [id, m] of this.media) { const it = this.project.items.find((i) => i.id === id); if (it) this.wire(m, it); }
  }

  wire(m: Media, it: Item) {
    if (!this.ac || m.src) return;
    const ac = this.ac;
    m.src = ac.createMediaElementSource(m.el);
    m.gain = ac.createGain();
    m.gain.connect(this.master!);
    this.rechain(m, it);
  }

  rechain(m: Media, it: Item) {
    if (!this.ac || !m.src || !m.gain) return;
    if (m.enhance === it.voiceEnhance && m.chainIn) return;
    m.src.disconnect();
    if (it.voiceEnhance) {
      const ac = this.ac;
      const hp = ac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 90;
      const pres = ac.createBiquadFilter(); pres.type = 'peaking'; pres.frequency.value = 3200; pres.gain.value = 4; pres.Q.value = 1;
      const deEss = ac.createBiquadFilter(); deEss.type = 'peaking'; deEss.frequency.value = 7000; deEss.gain.value = -3;
      const comp = ac.createDynamicsCompressor(); comp.threshold.value = -24; comp.ratio.value = 4; comp.attack.value = 0.005; comp.release.value = 0.15;
      const make = ac.createGain(); make.gain.value = 1.5;
      m.src.connect(hp).connect(pres).connect(deEss).connect(comp).connect(make).connect(m.gain);
      m.chainIn = hp;
    } else { m.src.connect(m.gain); m.chainIn = m.gain; }
    m.enhance = it.voiceEnhance;
  }

  trackOf(it: Item) { return this.project.tracks.find((t) => t.id === it.track); }

  syncMedia(t: number) {
    for (const it of this.project.items) {
      if (it.type !== 'video' && it.type !== 'audio') continue;
      const m = this.getMedia(it);
      if (!m) continue;
      const el = m.el;
      const tr = this.trackOf(it);
      const active = t >= it.start && t < it.start + it.dur;
      const expected = it.in + (t - it.start) * it.speed;
      if (m.gain) {
        this.rechain(m, it);
        const local = t - it.start;
        let v = it.volume;
        if (it.fadeIn > 0) v *= clamp(local / it.fadeIn, 0, 1);
        if (it.fadeOut > 0) v *= clamp((it.dur - local) / it.fadeOut, 0, 1);
        if (tr?.muted) v = 0;
        m.gain.gain.value = v;
      } else el.muted = !!tr?.muted || it.volume === 0;
      el.playbackRate = it.speed;
      (el as HTMLMediaElement & { preservesPitch?: boolean }).preservesPitch = it.keepPitch;
      if (active) {
        if (this.playing) {
          if (el.paused) { el.currentTime = expected; el.play().catch(() => {}); }
          else if (Math.abs(el.currentTime - expected) > 0.3) el.currentTime = expected;
        } else {
          if (!el.paused) el.pause();
          if (Math.abs(el.currentTime - expected) > 0.04 && !el.seeking) el.currentTime = expected;
        }
      } else if (!el.paused) el.pause();
    }
  }

  async play() {
    this.ensureAudio();
    await this.ac!.resume();
    const dur = this.endAt ?? projectDuration(this.project);
    if (this.time >= dur - 0.05) this.time = this.project.markIn ?? 0;
    this.playing = true;
    this.p0 = performance.now(); this.t0 = this.time;
    this.loop();
  }
  pause() {
    this.playing = false;
    cancelAnimationFrame(this.raf);
    for (const m of this.media.values()) m.el.pause();
    this.render();
  }
  seek(t: number) {
    this.time = Math.max(0, t);
    this.p0 = performance.now(); this.t0 = this.time;
    if (!this.playing) this.render();
  }
  loop = () => {
    if (!this.playing) return;
    const t = this.t0 + (performance.now() - this.p0) / 1000;
    const end = this.endAt ?? projectDuration(this.project);
    if (t >= end) { this.time = end; this.pause(); this.onTime?.(this.time); this.onEnd?.(); return; }
    this.time = t;
    this.render();
    this.onTime?.(t);
    this.raf = requestAnimationFrame(this.loop);
  };

  render() {
    const { ctx, canvas, project: p } = this;
    const W = canvas.width, H = canvas.height;
    const t = this.time;
    if (!this.offline) this.syncMedia(t);
    if (this.layer.width !== W || this.layer.height !== H) { this.layer.width = W; this.layer.height = H; this.tmp.width = W; this.tmp.height = H; }
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = p.bgColor; ctx.fillRect(0, 0, W, H);
    this.boxes = [];
    if (this.analyser) this.analyser.getByteFrequencyData(this.freq);
    const tracks = [...p.tracks].reverse().filter((tr) => tr.kind === 'visual' && !tr.hidden);
    for (const tr of tracks) {
      const items = p.items.filter((i) => i.track === tr.id && t >= i.start && t < i.start + i.dur).sort((a, b) => a.start - b.start);
      for (const it of items) this.drawItem(it, t, W, H);
    }
    // selection outline
    if (this.selected && this.guides && !this.exporting) {
      const b = this.boxes.find((x) => x.id === this.selected);
      if (b) { ctx.strokeStyle = '#7c5cff'; ctx.lineWidth = Math.max(2, W / 400); ctx.setLineDash([8, 6]); ctx.strokeRect(b.x, b.y, b.w, b.h); ctx.setLineDash([]); }
    }
    ctx.restore();
  }
  exporting = false;

  drawItem(it: Item, t: number, W: number, H: number) {
    const local = t - it.start;
    const S = Math.min(W, H);
    let x = kfValue(it, 'x', local) * W, y = kfValue(it, 'y', local) * H;
    let scale = kfValue(it, 'scale', local), rot = kfValue(it, 'rotation', local), alpha = kfValue(it, 'opacity', local);
    // loop animations
    switch (it.loopAnim) {
      case 'wiggle': rot += Math.sin(local * 9) * 4; break;
      case 'pulse': scale *= 1 + Math.sin(local * 6) * 0.05; break;
      case 'float': y += Math.sin(local * 2.2) * S * 0.015; break;
      case 'spin': rot += local * 90; break;
      case 'kenburns': scale *= 1 + (local / Math.max(1, it.dur)) * 0.12; break;
    }
    // in / out animations
    let clipRect: [number, number, number, number] | null = null, iris = -1, blurPx = 0, glitchAmt = 0;
    const applyAnim = (name: string, k: number, dir: 1 | -1) => {
      const e = easing(dir === 1 ? 'out' : 'in', k);
      const inv = 1 - e;
      switch (name) {
        case 'fade': alpha *= e; break;
        case 'slide-left': x += inv * W * 0.6 * dir; alpha *= e; break;
        case 'slide-right': x -= inv * W * 0.6 * dir; alpha *= e; break;
        case 'slide-up': y += inv * H * 0.3; alpha *= e; break;
        case 'slide-down': y -= inv * H * 0.3; alpha *= e; break;
        case 'zoom-in': scale *= 0.3 + 0.7 * e; alpha *= e; break;
        case 'zoom-out': scale *= 1 + inv * 1.5; alpha *= e; break;
        case 'pop': scale *= easing('back', k) || 0.001; break;
        case 'spin': rot += inv * 360 * dir; scale *= e; break;
        case 'blur': blurPx = inv * 30; alpha *= e; break;
        case 'wipe-left': clipRect = [W * (1 - e), 0, W * e, H]; break;
        case 'wipe-right': clipRect = [0, 0, W * e, H]; break;
        case 'iris': iris = e; break;
        case 'glitch': glitchAmt = inv; alpha *= k > 0.2 ? 1 : 0.5; break;
        case 'whip': x += inv * W * 1.2 * dir; blurPx = inv * 20; break;
        case 'flip': scale *= Math.max(0.001, Math.abs(Math.cos(inv * Math.PI / 2))); break;
        case 'drop': y -= (1 - easing('bounce', k)) * H * 0.5; break;
      }
    };
    const ad = Math.min(it.animDur, it.dur / 2);
    if (it.animIn !== 'none' && local < ad) applyAnim(it.animIn, local / ad, 1);
    if (it.animOut !== 'none' && local > it.dur - ad) applyAnim(it.animOut, (it.dur - local) / ad, -1);
    if (alpha <= 0.001) return;

    const L = this.lctx;
    L.setTransform(1, 0, 0, 1, 0, 0);
    L.globalCompositeOperation = 'source-over';
    L.globalAlpha = 1;
    L.clearRect(0, 0, W, H);
    const adj = { ...it.adj };
    const lut = LUTS[it.lut];
    if (lut) for (const [k, v] of Object.entries(lut.adj)) {
      const kk = k as keyof typeof adj;
      if (kk === 'hue' || kk === 'blur') adj[kk] += v as number;
      else if (kk === 'grayscale' || kk === 'sepia' || kk === 'invert') adj[kk] = Math.max(adj[kk], v as number);
      else adj[kk] = (adj[kk] * (v as number)) / 100;
    }
    const f: string[] = [];
    if (adj.brightness !== 100) f.push(`brightness(${adj.brightness}%)`);
    if (adj.contrast !== 100) f.push(`contrast(${adj.contrast}%)`);
    if (adj.saturate !== 100) f.push(`saturate(${adj.saturate}%)`);
    if (adj.hue + adj.temp * -0.3) f.push(`hue-rotate(${adj.hue + adj.temp * -0.3}deg)`);
    if (adj.temp > 0) f.push(`sepia(${adj.temp * 0.6}%)`);
    if (adj.grayscale) f.push(`grayscale(${adj.grayscale}%)`);
    if (adj.sepia) f.push(`sepia(${adj.sepia}%)`);
    if (adj.invert) f.push(`invert(${adj.invert}%)`);
    const blurTotal = adj.blur + blurPx;
    if (blurTotal > 0) f.push(`blur(${(blurTotal * W) / 1080}px)`);
    L.filter = f.length ? f.join(' ') : 'none';
    L.translate(x, y);
    L.rotate((rot * Math.PI) / 180);
    L.scale(scale * (it.fx.flipH ? -1 : 1), scale);
    let bw = 0, bh = 0;
    let mediaRect: [number, number, number, number] | null = null;
    let srcEl: CanvasImageSource | null = null;
    // mask
    const drawBody = () => {
      switch (it.type) {
        case 'bg': {
          const b = it.bg!;
          const ang = ((b.angle + (b.animated ? local * 20 : 0)) * Math.PI) / 180;
          const r = Math.hypot(W, H) / 2;
          const g = L.createLinearGradient(-Math.cos(ang) * r, -Math.sin(ang) * r, Math.cos(ang) * r, Math.sin(ang) * r);
          b.colors.forEach((c, i) => g.addColorStop(i / Math.max(1, b.colors.length - 1), c));
          L.fillStyle = g; L.fillRect(-W / 2 - 2, -H / 2 - 2, W + 4, H + 4);
          bw = W; bh = H;
          break;
        }
        case 'video': case 'image': {
          let el: CanvasImageSource | null = null;
          let iw = 16, ih = 9;
          if (it.type === 'video' && this.offline) { const f = this.frameSrc.get(it.id); if (f) { el = f.img; iw = f.w; ih = f.h; } }
          else if (it.type === 'video') { const m = this.getMedia(it); const v = m?.el as HTMLVideoElement | undefined; if (v && v.readyState >= 2) { el = v; iw = v.videoWidth; ih = v.videoHeight; } }
          else { const img = this.image(it.assetId); if (img?.complete && img.naturalWidth) { el = img; iw = img.naturalWidth; ih = img.naturalHeight; } }
          const sc = it.fit === 'cover' ? Math.max(W / iw, H / ih) : Math.min(W / iw, H / ih);
          bw = iw * sc; bh = ih * sc;
          if (el) { L.drawImage(el, -bw / 2, -bh / 2, bw, bh); srcEl = el; mediaRect = [-bw / 2, -bh / 2, bw, bh]; }
          else { L.fillStyle = '#1e1c2e'; L.fillRect(-bw / 2, -bh / 2, bw, bh); }
          break;
        }
        case 'text': { const r = this.drawText(L, it, local, W, H); bw = r[0]; bh = r[1]; break; }
        case 'shape': { const r = this.drawShape(L, it, local, W, H); bw = r[0]; bh = r[1]; break; }
        case 'sticker': {
          const size = H * 0.14;
          L.font = `${size}px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif`;
          L.textAlign = 'center'; L.textBaseline = 'middle';
          L.fillText(it.sticker || '⭐', 0, size * 0.05);
          bw = size * 1.2; bh = size * 1.2;
          break;
        }
      }
    };
    if (it.mask !== 'none') {
      L.save();
      const mw = it.type === 'video' || it.type === 'image' ? Math.min(W, H) * 0.8 : W, mh = mw;
      L.beginPath();
      if (it.mask === 'circle') L.arc(0, 0, mw / 2, 0, Math.PI * 2);
      else if (it.mask === 'rounded') roundRect(L, -W * 0.45, -H * 0.3, W * 0.9, H * 0.6, W * 0.06);
      else if (it.mask === 'heart') { const s = mw / 2; L.moveTo(0, s * 0.35); L.bezierCurveTo(-s * 1.1, -s * 0.5, -s * 0.4, -s * 1.1, 0, -s * 0.45); L.bezierCurveTo(s * 0.4, -s * 1.1, s * 1.1, -s * 0.5, 0, s * 0.35); L.lineTo(0, s * 0.8); }
      void mh;
      L.clip();
      drawBody();
      L.restore();
    } else drawBody();
    L.filter = 'none';
    // AI background removal
    if (it.fx.bgRemove && srcEl && mediaRect && !this.offline) {
      if (!this.seg && !this.segLoading) { this.segLoading = true; getSegmenter().then((s) => { this.seg = s; }); }
      if (this.seg) {
        const el = srcEl as HTMLVideoElement | HTMLImageElement;
        const sw = (el as HTMLVideoElement).videoWidth || (el as HTMLImageElement).naturalWidth, sh = (el as HTMLVideoElement).videoHeight || (el as HTMLImageElement).naturalHeight;
        const mask = segmentToMask(this.seg, el, sw, sh);
        if (mask) {
          const mr = mediaRect as [number, number, number, number];
          L.globalCompositeOperation = 'destination-in';
          L.drawImage(mask, mr[0], mr[1], mr[2], mr[3]);
          if (it.fx.bgColor) { L.globalCompositeOperation = 'destination-over'; L.fillStyle = it.fx.bgColor; L.fillRect(mr[0], mr[1], mr[2], mr[3]); }
          L.globalCompositeOperation = 'source-over';
        }
      }
    }
    L.setTransform(1, 0, 0, 1, 0, 0);
    // record hit box (axis aligned, ignores rotation)
    const bws = Math.abs(bw * scale), bhs = Math.abs(bh * scale);
    this.boxes.push({ id: it.id, x: x - bws / 2, y: y - bhs / 2, w: bws, h: bhs });
    // pixel fx
    const fx = it.fx;
    if (fx.chroma) this.chromaKey(fx.chromaColor, fx.chromaTol);
    if (fx.pixelate > 0) {
      const px = Math.max(2, Math.round((fx.pixelate / 100) * 40 * (W / 1080)));
      const tw = Math.max(1, Math.floor(W / px)), th = Math.max(1, Math.floor(H / px));
      const T = this.tmp.getContext('2d')!;
      T.clearRect(0, 0, W, H); T.imageSmoothingEnabled = true; T.drawImage(this.layer, 0, 0, tw, th);
      L.clearRect(0, 0, W, H); L.imageSmoothingEnabled = false; L.drawImage(this.tmp, 0, 0, tw, th, 0, 0, W, H); L.imageSmoothingEnabled = true;
    }
    const gl = Math.max(fx.glitch / 100, glitchAmt);
    if (gl > 0 && Math.random() < 0.3 + gl * 0.7) {
      const T = this.tmp.getContext('2d')!;
      T.clearRect(0, 0, W, H); T.drawImage(this.layer, 0, 0);
      L.clearRect(0, 0, W, H);
      const strips = 14;
      for (let i = 0; i < strips; i++) {
        const sy = (H / strips) * i, sh = H / strips;
        const off = Math.random() < 0.4 ? (Math.random() - 0.5) * W * 0.08 * gl : 0;
        L.drawImage(this.tmp, 0, sy, W, sh, off, sy, W, sh);
      }
    }
    if (fx.rgbSplit > 0 || fx.vhs) {
      const d = ((fx.rgbSplit || 20) / 100) * W * 0.012;
      const T = this.tmp.getContext('2d')!;
      T.clearRect(0, 0, W, H); T.drawImage(this.layer, 0, 0);
      L.globalCompositeOperation = 'source-over';
      L.clearRect(0, 0, W, H);
      L.globalAlpha = 1; L.drawImage(this.tmp, 0, 0);
      L.globalCompositeOperation = 'lighter'; L.globalAlpha = 0.35;
      L.filter = 'sepia(1) saturate(8) hue-rotate(-50deg)'; L.drawImage(this.tmp, -d, 0);
      L.filter = 'sepia(1) saturate(8) hue-rotate(130deg)'; L.drawImage(this.tmp, d, 0);
      L.filter = 'none'; L.globalAlpha = 1; L.globalCompositeOperation = 'source-over';
    }
    if (fx.vhs) {
      L.globalCompositeOperation = 'source-atop';
      L.fillStyle = 'rgba(0,0,0,0.18)';
      for (let yy = 0; yy < H; yy += Math.max(2, H / 360)) L.fillRect(0, yy, W, Math.max(1, H / 720));
      const band = ((t * 0.3) % 1) * H;
      L.fillStyle = 'rgba(255,255,255,0.06)'; L.fillRect(0, band, W, H * 0.04);
      L.globalCompositeOperation = 'source-over';
    }
    if (fx.grain > 0) {
      L.globalCompositeOperation = 'source-atop';
      L.globalAlpha = fx.grain * 0.35;
      const ox = Math.random() * 256, oy = Math.random() * 256;
      const pat = L.createPattern(this.grain, 'repeat')!;
      L.translate(-ox, -oy); L.fillStyle = pat; L.fillRect(ox, oy, W, H); L.setTransform(1, 0, 0, 1, 0, 0);
      L.globalAlpha = 1; L.globalCompositeOperation = 'source-over';
    }
    if (fx.vignette > 0) {
      L.globalCompositeOperation = 'source-atop';
      const g = L.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.hypot(W, H) / 2);
      g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${fx.vignette})`);
      L.fillStyle = g; L.fillRect(0, 0, W, H);
      L.globalCompositeOperation = 'source-over';
    }
    if (lut?.tint) { L.globalCompositeOperation = 'source-atop'; L.fillStyle = lut.tint; L.fillRect(0, 0, W, H); L.globalCompositeOperation = 'source-over'; }

    // composite layer
    const C = this.ctx;
    C.save();
    C.globalAlpha = clamp(alpha, 0, 1);
    C.globalCompositeOperation = it.blend;
    if (clipRect) { C.beginPath(); C.rect(...(clipRect as [number, number, number, number])); C.clip(); }
    if (iris >= 0) { C.beginPath(); C.arc(W / 2, H / 2, (Math.hypot(W, H) / 2) * iris, 0, Math.PI * 2); C.clip(); }
    C.drawImage(this.layer, 0, 0);
    C.restore();
  }

  chromaKey(hex: string, tol: number) {
    const W = this.layer.width, H = this.layer.height;
    const id = this.lctx.getImageData(0, 0, W, H);
    const d = id.data;
    const kr = parseInt(hex.slice(1, 3), 16), kg = parseInt(hex.slice(3, 5), 16), kb = parseInt(hex.slice(5, 7), 16);
    const t2 = tol * 1.2, soft = tol * 0.5;
    for (let i = 0; i < d.length; i += 4) {
      if (!d[i + 3]) continue;
      const dist = Math.abs(d[i] - kr) + Math.abs(d[i + 1] - kg) + Math.abs(d[i + 2] - kb);
      if (dist < t2) d[i + 3] = 0;
      else if (dist < t2 + soft) {
        d[i + 3] = (d[i + 3] * (dist - t2)) / soft;
        // spill suppression (green)
        if (kg > kr && kg > kb) d[i + 1] = Math.min(d[i + 1], (d[i] + d[i + 2]) / 2 + 10);
      }
    }
    this.lctx.putImageData(id, 0, 0);
  }

  /** Render one frame at time t without touching media elements (used by the fast exporter). */
  renderAt(t: number) { this.time = t; this.render(); }
  /** Wait until every image and font used by the project is ready, so offline frames never draw placeholders. */
  async preload() {
    const imgs = this.project.items.filter((i) => i.type === 'image').map((i) => this.image(i.assetId)).filter(Boolean) as HTMLImageElement[];
    await Promise.all(imgs.map((im) => im.decode().catch(() => {})));
    const fonts = new Set(this.project.items.filter((i) => i.type === 'text' && i.text).map((i) => `${i.text!.weight || 700} 40px "${i.text!.font}"`));
    await Promise.all([...fonts].map((f) => document.fonts.load(f).catch(() => {})));
    await document.fonts.ready;
  }

  image(id?: string) {
    if (!id) return null;
    let img = this.images.get(id);
    if (!img) {
      const a = this.asset(id);
      if (!a) return null;
      img = new Image(); img.crossOrigin = 'anonymous'; img.src = a.url; img.onload = () => !this.playing && this.render();
      this.images.set(id, img);
    }
    return img;
  }

  drawText(L: CanvasRenderingContext2D, it: Item, local: number, W: number, H: number): [number, number] {
    const tp = it.text!;
    const size = tp.size * H;
    let content = tp.upper ? tp.content.toUpperCase() : tp.content;
    L.font = `${tp.italic ? 'italic ' : ''}${tp.weight} ${size}px "${tp.font}", Impact, sans-serif`;
    L.textBaseline = 'middle';
    L.textAlign = 'center';
    const maxW = tp.width * W;
    if (tp.anim === 'ticker') {
      const tw = L.measureText(content).width;
      const bh = size * 1.6;
      if (tp.bg) { L.fillStyle = tp.bg; L.fillRect(-W, -bh / 2, W * 2, bh); }
      L.save(); L.beginPath(); L.rect(-W / 2, -bh / 2, W, bh); L.clip();
      L.fillStyle = tp.color; L.textAlign = 'left';
      const off = (local * W * 0.12) % (tw || 1);
      for (let x = -W / 2 - off; x < W / 2; x += tw) L.fillText(content, x, 0);
      L.restore();
      return [W, bh];
    }
    let lines = wrapText(L, content, maxW);
    const lh = size * 1.18;
    // typewriter / word reveal
    if (tp.anim === 'typewriter') {
      const total = content.length;
      const shown = Math.floor(clamp(local / Math.max(0.5, Math.min(it.dur * 0.7, total * 0.05)), 0, 1) * total);
      let left = shown;
      lines = lines.map((l) => { const s = l.slice(0, Math.max(0, left)); left -= l.length + 1; return s; });
    } else if (tp.anim === 'word') {
      const words = content.split(/\s+/);
      const shown = Math.ceil(clamp(local / Math.max(0.4, it.dur * 0.6), 0, 1) * words.length);
      let left = shown;
      lines = lines.map((l) => { const ws = l.split(' '); const s = ws.slice(0, Math.max(0, left)).join(' '); left -= ws.length; return s; });
    }
    const widths = wrapText(L, content, maxW).map((l) => L.measureText(l).width);
    const bw = Math.max(...widths, 1), bh = lines.length * lh;
    let ox = 0, oy = 0;
    if (tp.anim === 'shake') { ox = (Math.random() - 0.5) * size * 0.08; oy = (Math.random() - 0.5) * size * 0.08; }
    if (tp.anim === 'bounce') { const s = 1 + Math.abs(Math.sin(local * 5)) * 0.06; L.scale(s, s); }
    const alignX = tp.align === 'left' ? -bw / 2 : tp.align === 'right' ? bw / 2 : 0;
    L.textAlign = tp.align;
    if (tp.bg) {
      L.fillStyle = tp.bg;
      const pad = size * 0.3;
      roundRect(L, -bw / 2 - pad, -bh / 2 - pad * 0.4, bw + pad * 2, bh + pad * 0.8, size * 0.2);
      L.fill();
    }
    let fill: string | CanvasGradient = tp.color;
    if (tp.gradient) { const g = L.createLinearGradient(-bw / 2, 0, bw / 2, 0); g.addColorStop(0, tp.color); g.addColorStop(1, tp.gradient); fill = g; }
    lines.forEach((line, i) => {
      const ly = -bh / 2 + lh * (i + 0.5) + oy;
      const lx = alignX + ox;
      if (tp.shadow) { L.shadowColor = 'rgba(0,0,0,.55)'; L.shadowBlur = size * 0.25; L.shadowOffsetY = size * 0.06; }
      if (tp.glow || tp.anim === 'neon') { L.shadowColor = tp.glow || tp.color; L.shadowBlur = size * (tp.anim === 'neon' ? 0.5 + 0.3 * Math.sin(local * 8) : 0.5); L.shadowOffsetY = 0; }
      if (tp.anim === 'wave') {
        // per-character wave
        const lw = L.measureText(line).width;
        let cx = tp.align === 'center' ? lx - lw / 2 : tp.align === 'right' ? lx - lw : lx;
        L.textAlign = 'left';
        for (let c = 0; c < line.length; c++) {
          const ch = line[c];
          const dy = Math.sin(local * 6 + c * 0.5) * size * 0.12;
          if (tp.strokeW > 0) { L.lineWidth = size * tp.strokeW; L.strokeStyle = tp.stroke; L.lineJoin = 'round'; L.strokeText(ch, cx, ly + dy); }
          L.fillStyle = fill; L.fillText(ch, cx, ly + dy);
          cx += L.measureText(ch).width;
        }
        L.textAlign = tp.align;
      } else {
        if (tp.strokeW > 0) { L.lineWidth = size * tp.strokeW; L.strokeStyle = tp.stroke; L.lineJoin = 'round'; L.strokeText(line, lx, ly); }
        if (tp.anim === 'glitch' && Math.random() < 0.5) {
          const j = size * 0.06;
          L.save(); L.shadowBlur = 0; L.globalCompositeOperation = 'lighter';
          L.fillStyle = 'rgba(255,0,80,.8)'; L.fillText(line, lx - j * Math.random() * 2, ly);
          L.fillStyle = 'rgba(0,255,230,.8)'; L.fillText(line, lx + j * Math.random() * 2, ly);
          L.restore();
        }
        L.fillStyle = fill; L.fillText(line, lx, ly);
      }
      L.shadowBlur = 0; L.shadowOffsetY = 0;
    });
    return [bw + size * 0.6, bh + size * 0.3];
  }

  drawShape(L: CanvasRenderingContext2D, it: Item, local: number, W: number, H: number): [number, number] {
    const s = it.shape!;
    const w = s.w * W, h = s.kind === 'circle' || s.kind === 'star' || s.kind === 'pie' ? s.w * W : s.h * H;
    const r = s.radius * Math.min(w, h) * 0.5;
    L.fillStyle = s.fill;
    L.strokeStyle = s.stroke || 'transparent';
    L.lineWidth = s.strokeW * Math.min(W, H) * 0.01;
    L.beginPath();
    switch (s.kind) {
      case 'rect': case 'frame': roundRect(L, -w / 2, -h / 2, w, h, r); break;
      case 'circle': L.arc(0, 0, w / 2, 0, Math.PI * 2); break;
      case 'triangle': L.moveTo(0, -h / 2); L.lineTo(w / 2, h / 2); L.lineTo(-w / 2, h / 2); L.closePath(); break;
      case 'star': for (let i = 0; i < 20; i++) { const a = (i / 20) * Math.PI * 2 - Math.PI / 2; const rr = i % 2 ? w * 0.36 : w / 2; L.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } L.closePath(); break;
      case 'arrow': L.moveTo(-w / 2, -h * 0.18); L.lineTo(w * 0.15, -h * 0.18); L.lineTo(w * 0.15, -h / 2); L.lineTo(w / 2, 0); L.lineTo(w * 0.15, h / 2); L.lineTo(w * 0.15, h * 0.18); L.lineTo(-w / 2, h * 0.18); L.closePath(); break;
      case 'bubble': roundRect(L, -w / 2, -h / 2, w, h * 0.8, r || h * 0.2); L.moveTo(-w * 0.2, h * 0.3); L.lineTo(-w * 0.3, h / 2); L.lineTo(-w * 0.05, h * 0.3); break;
      case 'line': L.rect(-w / 2, -Math.max(2, h * 0.05) / 2, w, Math.max(2, h * 0.05)); break;
      case 'progress': {
        L.fillStyle = 'rgba(255,255,255,.25)'; L.fillRect(-w / 2, -h / 2, w, h);
        L.fillStyle = s.fill; L.fillRect(-w / 2, -h / 2, w * clamp(local / it.dur, 0, 1), h);
        return [w, h];
      }
      case 'subscribe': {
        const clicked = local > it.dur * 0.45;
        L.fillStyle = clicked ? '#606060' : s.fill; roundRect(L, -w / 2, -h / 2, w, h, h * 0.2); L.fill();
        L.fillStyle = '#fff'; L.font = `800 ${h * 0.42}px Montserrat, sans-serif`; L.textAlign = 'center'; L.textBaseline = 'middle';
        L.fillText(clicked ? 'SUBSCRIBED 🔔' : 'SUBSCRIBE', 0, 0);
        if (local > it.dur * 0.3 && local < it.dur * 0.6) { const k = (local - it.dur * 0.3) / (it.dur * 0.3); L.font = `${h * 0.8}px sans-serif`; L.fillText('👆', w * 0.3 - k * w * 0.1, h * 0.6 - k * h * 0.2); }
        return [w, h];
      }
      case 'bars': {
        const vals = [0.45, 0.8, 0.3, 0.95, 0.6];
        const n = vals.length, gap = w * 0.04, bwid = (w - gap * (n - 1)) / n;
        vals.forEach((v, i) => {
          const k = easing('out', clamp((local - i * 0.2) / 0.8, 0, 1));
          const bhh = h * v * k;
          L.fillStyle = s.fill; L.globalAlpha = 0.55 + 0.45 * v;
          roundRect(L, -w / 2 + i * (bwid + gap), h / 2 - bhh, bwid, bhh, bwid * 0.15); L.fill();
        });
        L.globalAlpha = 1;
        return [w, h];
      }
      case 'pie': {
        const k = easing('out', clamp(local / 1.2, 0, 1));
        const parts = [[0.45, s.fill], [0.3, '#60a5fa'], [0.25, '#f472b6']] as const;
        let a0 = -Math.PI / 2;
        for (const [v, c] of parts) { const a1 = a0 + v * Math.PI * 2 * k; L.beginPath(); L.moveTo(0, 0); L.arc(0, 0, w / 2, a0, a1); L.closePath(); L.fillStyle = c; L.fill(); a0 = a1; }
        return [w, w];
      }
      case 'spectrum': {
        const n = 32, bwid = w / n;
        for (let i = 0; i < n; i++) {
          const v = this.freq[i] ? this.freq[i] / 255 : 0.15 + 0.5 * Math.abs(Math.sin(local * 4 + i * 0.6)) * (this.playing ? 1 : 0.4);
          const bhh = Math.max(2, v * h);
          L.fillStyle = s.fill; L.fillRect(-w / 2 + i * bwid + bwid * 0.15, h / 2 - bhh, bwid * 0.7, bhh);
        }
        return [w, h];
      }
    }
    if (s.kind === 'frame') { L.lineWidth = Math.max(4, s.strokeW * 10 || 10); L.strokeStyle = s.fill; L.stroke(); }
    else { L.fill(); if (s.stroke && s.strokeW) L.stroke(); }
    if (s.label) {
      L.fillStyle = s.kind === 'rect' && s.fill === '#ffffff' ? '#111' : '#fff';
      const fs = Math.min(h * 0.4, (w / Math.max(4, s.label.length)) * 1.6);
      L.font = `800 ${fs}px Montserrat, sans-serif`; L.textAlign = 'center'; L.textBaseline = 'middle';
      L.fillText(s.label, 0, s.kind === 'bubble' ? -h * 0.1 : 0);
    }
    return [w, h];
  }

  hitTest(px: number, py: number): string | null {
    for (let i = this.boxes.length - 1; i >= 0; i--) {
      const b = this.boxes[i];
      const it = this.project.items.find((x) => x.id === b.id);
      if (!it || it.type === 'bg') continue;
      const tr = this.trackOf(it);
      if (tr?.locked) continue;
      if (px >= b.x && px <= b.x + b.w && py >= b.y && py <= b.y + b.h) return b.id;
    }
    // fall back to full-frame media
    for (let i = this.boxes.length - 1; i >= 0; i--) { const b = this.boxes[i]; const it = this.project.items.find((x) => x.id === b.id); if (it && px >= b.x && px <= b.x + b.w && py >= b.y && py <= b.y + b.h) return b.id; }
    return null;
  }

  async export(scale: number, range: [number, number], onProgress: (p: number) => void, cancel: () => boolean): Promise<Blob> {
    const prevW = this.canvas.width, prevH = this.canvas.height;
    const W = Math.round((this.project.w * scale) / 2) * 2, H = Math.round((this.project.h * scale) / 2) * 2;
    this.canvas.width = W; this.canvas.height = H;
    this.exporting = true;
    this.ensureAudio();
    await this.ac!.resume();
    this.pause();
    this.seek(range[0]);
    await new Promise((r) => setTimeout(r, 400));
    const stream = this.canvas.captureStream(this.project.fps);
    this.dest!.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
    const mime = pickMime();
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: H >= 1920 || W >= 1920 ? 10_000_000 : 6_000_000 });
    const chunks: Blob[] = [];
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    const done = new Promise<Blob>((res) => (rec.onstop = () => res(new Blob(chunks, { type: mime.split(';')[0] }))));
    this.endAt = range[1];
    const prevT = this.onTime;
    const ended = new Promise<void>((res) => { this.onEnd = res; });
    this.onTime = (t) => { prevT?.(t); onProgress((t - range[0]) / (range[1] - range[0])); if (cancel()) { this.pause(); this.onEnd?.(); } };
    rec.start(250);
    await this.play();
    await ended;
    await new Promise((r) => setTimeout(r, 120));
    rec.stop();
    const blob = await done;
    this.onTime = prevT; this.onEnd = undefined; this.endAt = null;
    this.exporting = false;
    this.canvas.width = prevW; this.canvas.height = prevH;
    this.render();
    return blob;
  }

  destroy() {
    this.pause();
    for (const m of this.media.values()) { m.el.pause(); m.el.removeAttribute('src'); m.el.load(); }
    this.media.clear();
    this.ac?.close().catch(() => {});
  }
}

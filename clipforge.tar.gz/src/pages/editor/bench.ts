// Export benchmark (debug only — loaded with ?cfdebug). Builds a documentary-like project and times fastRender.
import { newItem, newProject, textProps, type Item, type Track } from './model';
import { makeAsset } from './store';
import { fastRender, type RenderSpeed } from './fastRender';
import { musicWavBlob } from '../../lib/synth';

async function photo(i: number): Promise<Blob> {
  const c = document.createElement('canvas'); c.width = 1280; c.height = 853;
  const g = c.getContext('2d')!;
  const gr = g.createLinearGradient(0, 0, 1280, 853); gr.addColorStop(0, `hsl(${i * 47},50%,40%)`); gr.addColorStop(1, `hsl(${i * 47 + 90},60%,20%)`);
  g.fillStyle = gr; g.fillRect(0, 0, 1280, 853);
  for (let k = 0; k < 400; k++) { g.fillStyle = `hsla(${(k * 13) % 360},70%,60%,0.3)`; g.fillRect((k * 97) % 1280, (k * 53) % 853, 40, 40); }
  return new Promise((r) => c.toBlob((b) => r(b!), 'image/jpeg', 0.85));
}

export async function buildBench(seconds = 60, videoUrl?: string) {
  const p = newProject(1080, 1920, 'bench');
  const mk = (name: string, kind: Track['kind']): Track => ({ id: 'tr_' + name, kind, name, muted: false, locked: false, hidden: false });
  p.tracks = [mk('Titles', 'visual'), mk('Captions', 'visual'), mk('Main', 'visual'), mk('Voice', 'audio'), mk('Music', 'audio')];
  const items: Item[] = [];
  const imgs = [];
  for (let i = 0; i < 6; i++) imgs.push(await makeAsset(await photo(i), `p${i}.jpg`));
  let vid = null;
  if (videoUrl) vid = await makeAsset(await (await fetch(videoUrl)).blob(), 'clip.webm');
  p.assets.push(...imgs); if (vid) p.assets.push(vid);
  for (let t = 0, k = 0; t < seconds; t += 4.5, k++) {
    const dur = Math.min(4.5, seconds - t);
    if (vid && k % 4 === 1) { items.push(newItem({ type: 'video', track: 'tr_Main', assetId: vid.id, start: t, dur, in: 5 + k, volume: 0 })); continue; }
    const a = imgs[k % imgs.length];
    items.push(newItem({ type: 'image', track: 'tr_Main', assetId: a.id, start: t, dur, kf: { x: [{ t: 0, v: 0.62, ease: 'linear' }, { t: dur, v: 0.38, ease: 'linear' }] } }));
  }
  for (let t = 0.4; t < seconds - 1; t += 1.3) items.push(newItem({ type: 'text', track: 'tr_Captions', start: t, dur: 1.25, y: 0.73, text: textProps({ content: 'THE SHIP WAS BUILT', size: 0.052, strokeW: 0.12, width: 0.8 }) }));
  for (let t = 10; t < seconds; t += 20) items.push(newItem({ type: 'text', track: 'tr_Titles', start: t, dur: 2.4, y: 0.45, animIn: 'slide-up', animOut: 'fade', text: textProps({ content: 'Chapter title here', font: 'Playfair Display', weight: 800, size: 0.066 }) }));
  const music = await makeAsset(await musicWavBlob('suspense', 6), 'music.wav');
  p.assets.push(music);
  for (let t = 0; t < seconds; t += music.duration) items.push(newItem({ type: 'audio', track: 'tr_Music', assetId: music.id, start: t, dur: Math.min(music.duration, seconds - t), volume: 0.12 }));
  items.push(newItem({ type: 'audio', track: 'tr_Voice', assetId: music.id, start: 0, dur: Math.min(music.duration, seconds), volume: 1 }));
  p.items = items;
  return p;
}

export async function runBench(opts: { seconds?: number; res?: number; speed?: RenderSpeed; videoUrl?: string } = {}) {
  const p = await buildBench(opts.seconds ?? 60, opts.videoUrl);
  const res = opts.res ?? 720;
  const t0 = performance.now();
  const blob = await fastRender(p, res / 1080, [0, opts.seconds ?? 60], () => {}, () => false, opts.speed ?? 'best');
  return { seconds: (performance.now() - t0) / 1000, mb: blob.size / 1e6, type: blob.type };
}

// Faster-than-real-time export for editor projects (used for AI Director documentaries that run 10–30 minutes).
// Video frames are decoded straight from each asset with WebCodecs (Mediabunny), composited with the very same
// Compositor used by the preview, and encoded as fast as the machine allows. Audio is mixed offline in short chunks
// so memory stays flat no matter how long the video is, and the file is streamed into Blob parts instead of one
// giant ArrayBuffer.
import {
  ALL_FORMATS, AudioBufferSink, AudioBufferSource, BlobSource, CanvasSource, Input, Mp4OutputFormat, Output, Quality,
  StreamTarget, VideoSampleSink, WebMOutputFormat, canEncodeAudio, canEncodeVideo,
} from 'mediabunny';
import type { InputAudioTrack, StreamTargetChunk, VideoSample } from 'mediabunny';
import { Compositor } from './renderer';
import type { Item, Project } from './model';
import { ensureAac } from '../../lib/fastExport';

const SR = 48000;
const CHUNK = 30; // seconds of audio mixed at a time

type Plan = { container: 'mp4' | 'webm'; video: 'avc' | 'vp9' | 'vp8'; audio: 'aac' | 'opus'; W: number; H: number; bitrate: number };

const even = (n: number) => Math.max(2, Math.round(n / 2) * 2);
const canV = async (c: Plan['video'], W: number, H: number, bitrate: number) => { try { return await canEncodeVideo(c, { width: W, height: H, quality: new Quality({ bitrate }) }); } catch { return false; } };
const canA = async (c: Plan['audio']) => { try { return await canEncodeAudio(c, { numberOfChannels: 2, sampleRate: SR, quality: new Quality({ bitrate: 160_000 }) }); } catch { return false; } };

/** Bitrate for a frame size; long videos get a little less so a 30-minute file stays a sensible size. */
export function editorBitrate(W: number, H: number, seconds: number) {
  const short = Math.min(W, H);
  const base = short >= 1440 ? 14e6 : short >= 1080 ? 8e6 : short >= 720 ? 5e6 : 2.5e6;
  return Math.round(seconds > 300 ? base * 0.62 : base);
}
export const estimateMB = (W: number, H: number, seconds: number) => Math.round(((editorBitrate(W, H, seconds) + 160_000) * seconds) / 8 / 1e6);

export function fastRenderSupported() {
  return typeof VideoEncoder !== 'undefined' && typeof VideoDecoder !== 'undefined' && typeof OfflineAudioContext !== 'undefined';
}

async function plansFor(W: number, H: number, seconds: number): Promise<Plan[]> {
  const aac = await ensureAac(), opus = await canA('opus');
  const sizes: [number, number][] = [[W, H]];
  if (Math.min(W, H) > 720) { const k = 720 / Math.min(W, H); sizes.push([even(W * k), even(H * k)]); }
  const out: Plan[] = [];
  for (const [w, h] of sizes) {
    const br = editorBitrate(w, h, seconds);
    if ((aac || opus) && (await canV('avc', w, h, br))) out.push({ container: 'mp4', video: 'avc', audio: aac ? 'aac' : 'opus', W: w, H: h, bitrate: br });
  }
  if (opus) for (const c of ['vp9', 'vp8'] as const) { const br = editorBitrate(W, H, seconds); if (await canV(c, W, H, br)) out.push({ container: 'webm', video: c, audio: 'opus', W, H, bitrate: br }); }
  return out;
}

/** A WritableStream that collects the muxer's positioned writes into Blob parts (patches applied by slicing). */
function blobSink() {
  const parts: Blob[] = [];
  const patches: { pos: number; data: Uint8Array }[] = [];
  let end = 0;
  const stream = new WritableStream<StreamTargetChunk>({
    write(c) {
      const { data, position } = c;
      if (position > end) { parts.push(new Blob([new Uint8Array(position - end)])); end = position; }
      if (position < end) {
        const over = Math.min(data.byteLength, end - position);
        patches.push({ pos: position, data: data.slice(0, over) });
        if (over < data.byteLength) { parts.push(new Blob([data.slice(over)])); end += data.byteLength - over; }
      } else { parts.push(new Blob([data])); end += data.byteLength; }
    },
  });
  const finish = (type: string) => {
    let b = new Blob(parts, { type });
    for (const p of patches) b = new Blob([b.slice(0, p.pos), p.data as Uint8Array<ArrayBuffer>, b.slice(p.pos + p.data.byteLength)], { type });
    return b;
  };
  return { stream, finish };
}

type AssetIO = { input: Input; audio: InputAudioTrack | null; audioSink: AudioBufferSink | null };

class Sources {
  private map = new Map<string, Promise<AssetIO | null>>();
  private project: Project;
  constructor(p: Project) { this.project = p; }
  get(assetId?: string): Promise<AssetIO | null> {
    if (!assetId) return Promise.resolve(null);
    let v = this.map.get(assetId);
    if (!v) {
      v = (async () => {
        const a = this.project.assets.find((x) => x.id === assetId);
        if (!a) return null;
        try {
          const blob = await (await fetch(a.url)).blob();
          const input = new Input({ source: new BlobSource(blob), formats: ALL_FORMATS });
          const audio = await input.getPrimaryAudioTrack().catch(() => null);
          const audioSink = audio && (await audio.canDecode().catch(() => false)) ? new AudioBufferSink(audio) : null;
          return { input, audio, audioSink };
        } catch (e) { console.warn('fast export: cannot open asset', a.name, e); return null; }
      })();
      this.map.set(assetId, v);
    }
    return v;
  }
  async dispose() { for (const v of this.map.values()) { const io = await v; io?.input.dispose?.(); } this.map.clear(); }
}

/** Mix [t0, t0+len) of the project's audio (voice, music, interview audio…) into a stereo buffer. */
async function mixChunk(p: Project, src: Sources, t0: number, len: number): Promise<AudioBuffer> {
  const n = Math.max(1, Math.round(len * SR));
  const oac = new OfflineAudioContext(2, n, SR);
  const t1 = t0 + len;
  const items = p.items.filter((it) => (it.type === 'audio' || it.type === 'video') && it.volume > 0 && it.start < t1 && it.start + it.dur > t0 && !p.tracks.find((t) => t.id === it.track)?.muted);
  for (const it of items) {
    const io = await src.get(it.assetId);
    if (!io?.audioSink) continue;
    const lo = Math.max(0, it.start - t0), hi = Math.min(len, it.start + it.dur - t0);
    if (hi - lo < 1e-3) continue;
    const g = oac.createGain();
    // volume envelope (fades) sampled across the overlap
    const steps = Math.max(2, Math.ceil((hi - lo) * 20));
    const curve = new Float32Array(steps);
    for (let i = 0; i < steps; i++) {
      const local = t0 + lo + ((hi - lo) * i) / (steps - 1) - it.start;
      let v = it.volume;
      if (it.fadeIn > 0) v *= Math.min(1, Math.max(0, local / it.fadeIn));
      if (it.fadeOut > 0) v *= Math.min(1, Math.max(0, (it.dur - local) / it.fadeOut));
      curve[i] = v;
    }
    g.gain.setValueCurveAtTime(curve, lo, hi - lo);
    let head: AudioNode = g;
    if (it.voiceEnhance) {
      const hp = oac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 90;
      const pres = oac.createBiquadFilter(); pres.type = 'peaking'; pres.frequency.value = 3200; pres.gain.value = 4; pres.Q.value = 1;
      const comp = oac.createDynamicsCompressor(); comp.threshold.value = -24; comp.ratio.value = 4;
      const make = oac.createGain(); make.gain.value = 1.5;
      hp.connect(pres).connect(comp).connect(make).connect(g);
      head = hp;
    }
    g.connect(oac.destination);
    const s0 = it.in + (t0 + lo - it.start) * it.speed, s1 = it.in + (t0 + hi - it.start) * it.speed;
    for await (const wb of io.audioSink.buffers(Math.max(0, s0 - 0.05), s1 + 0.05)) {
      let when = it.start + (wb.timestamp - it.in) / it.speed - t0, off = 0;
      if (when < lo) { off = (lo - when) * it.speed; when = lo; }
      if (off >= wb.duration || when >= hi) continue;
      const node = oac.createBufferSource();
      node.buffer = wb.buffer; node.playbackRate.value = it.speed;
      node.connect(head);
      node.start(when, off);
      node.stop(hi);
    }
  }
  return oac.startRendering();
}

type Live = { gen: AsyncGenerator<VideoSample | null, void, unknown>; last: VideoSample | null; end: number };

/**
 * Export `project` over `range` at `scale` × its size. Tries MP4 (H.264+AAC) first, then WebM.
 * Throws if this browser can't do it — callers fall back to the real-time recorder.
 */
export async function fastRender(project: Project, scale: number, range: [number, number], onProgress: (p: number) => void, cancel: () => boolean): Promise<Blob> {
  if (!fastRenderSupported()) throw new Error('no WebCodecs in this browser');
  const W = even(project.w * scale), H = even(project.h * scale);
  const total = Math.max(0.1, range[1] - range[0]);
  const plans = await plansFor(W, H, total);
  if (!plans.length) throw new Error('no usable video encoder');
  const errors: string[] = [];
  for (const plan of plans) {
    if (cancel()) throw new Error('cancelled');
    try { return await renderWith(plan, project, range, onProgress, cancel); }
    catch (e) {
      if (cancel()) throw e;
      console.warn(`fast editor export ${plan.video} ${plan.W}x${plan.H} failed`, e);
      errors.push(`${plan.video} ${plan.W}x${plan.H}: ${(e as Error).message}`);
    }
  }
  throw new Error(errors.join(' · '));
}

async function renderWith(plan: Plan, project: Project, range: [number, number], onProgress: (p: number) => void, cancel: () => boolean): Promise<Blob> {
  const fps = project.fps || 30;
  const canvas = document.createElement('canvas');
  canvas.width = plan.W; canvas.height = plan.H;
  const comp = new Compositor(canvas, project);
  comp.offline = true; comp.exporting = true; comp.selected = null; comp.guides = false;
  await comp.preload();
  const src = new Sources(project);
  const sink = blobSink();
  const output = new Output({
    format: plan.container === 'mp4' ? new Mp4OutputFormat({ fastStart: false }) : new WebMOutputFormat(),
    target: new StreamTarget(sink.stream, { chunked: true, chunkSize: 8 * 2 ** 20 }),
  });
  const vs = new CanvasSource(canvas, { codec: plan.video, quality: new Quality({ bitrate: plan.bitrate }), keyFrameInterval: 2, latencyMode: 'quality' });
  const as = new AudioBufferSource({ codec: plan.audio, quality: new Quality({ bitrate: 160_000 }) });
  output.addVideoTrack(vs, { frameRate: fps });
  output.addAudioTrack(as);
  const live = new Map<string, Live>();
  const closeLive = async (id: string) => {
    const l = live.get(id); if (!l) return;
    live.delete(id); comp.frameSrc.delete(id);
    l.last?.close();
    await l.gen.return(undefined).catch(() => {});
  };
  const visible = (it: Item) => it.type === 'video' && !project.tracks.find((t) => t.id === it.track)?.hidden;
  const vItems = project.items.filter(visible);
  const [r0, r1] = range, total = r1 - r0;
  const nFrames = Math.max(1, Math.ceil(total * fps - 1e-6));
  let ok = false;
  try {
    await output.start();
    let audioT = 0;
    const pumpAudio = async (until: number) => {
      while (audioT < Math.min(until, total) - 1e-6) {
        const len = Math.min(CHUNK, total - audioT);
        await as.add(await mixChunk(project, src, r0 + audioT, len));
        audioT += len;
      }
    };
    for (let k = 0; k < nFrames; k++) {
      if (cancel()) throw new Error('cancelled');
      const rel = k / fps, t = r0 + rel;
      if (rel + 1 > audioT) await pumpAudio(rel + CHUNK);
      for (const [id, l] of live) if (t >= l.end - 1e-6) await closeLive(id);
      for (const it of vItems) {
        if (t < it.start - 1e-6 || t >= it.start + it.dur - 1e-6) continue;
        let l = live.get(it.id);
        if (!l) {
          const io = await src.get(it.assetId);
          const vt = io ? await io.input.getPrimaryVideoTrack().catch(() => null) : null;
          if (!vt || !(await vt.canDecode().catch(() => false))) continue;
          const kEnd = Math.min(nFrames, Math.ceil((it.start + it.dur - r0) * fps - 1e-6));
          const ts: number[] = [];
          for (let j = k; j < kEnd; j++) ts.push(Math.max(0, it.in + (r0 + j / fps - it.start) * it.speed));
          if (!ts.length) continue;
          l = { gen: new VideoSampleSink(vt).samplesAtTimestamps(ts), last: null, end: it.start + it.dur };
          live.set(it.id, l);
        }
        const { value } = await l.gen.next();
        if (value) {
          l.last?.close();
          l.last = value;
          comp.frameSrc.set(it.id, { img: value.toCanvasImageSource(), w: value.displayWidth, h: value.displayHeight });
        }
      }
      comp.renderAt(t);
      await vs.add(rel, 1 / fps);
      if (k % 10 === 0) onProgress(k / nFrames);
    }
    await pumpAudio(total);
    for (const id of [...live.keys()]) await closeLive(id);
    as.close(); vs.close();
    await output.finalize();
    ok = true;
  } finally {
    for (const id of [...live.keys()]) await closeLive(id).catch(() => {});
    if (!ok) await output.cancel().catch(() => {});
    await src.dispose();
    comp.offline = false;
  }
  onProgress(1);
  return sink.finish(plan.container === 'mp4' ? 'video/mp4' : 'video/webm');
}

import { setBusy } from '../../lib/busy';
import { useIsPhone } from '../../lib/mobile';
import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type MouseEvent as RME } from 'react';
import {
  ArrowLeft, Undo2, Redo2, Download, Play, Pause, SkipBack, SkipForward, Scissors, Trash2, Copy, Magnet, ZoomIn, ZoomOut, Flag,
  FolderOpen, Type, Smile, Shapes, Palette as PaletteIcon, Music2, LayoutTemplate, Sparkles, Video, Film, History, Maximize, Grid3x3, Check, Cloud,
  Clapperboard, SlidersHorizontal, X,
} from 'lucide-react';
import { useApp } from '../../store';
import { estimateMB, fastRender, fastRenderSupported, type RenderSpeed } from './fastRender';
import { Logo } from '../../App';
import { Modal } from '../../components/ui';
import type { Asset, Item, Project, TemplateDef } from './model';
import { newItem, newProject, projectDuration, textProps, kfValue, setProp } from './model';
import { Compositor } from './renderer';
import Timeline from './Timeline';
import Assets from './Assets';
import Props from './Props';
import { hydrate, listVersions, loadProject, makeAsset, saveProject, saveVersion } from './store';
import { musicWavBlob, sfxWavBlob } from '../../lib/synth';
import { download, fmtTime, slug, uid } from '../../lib/util';
import { encodeWav } from '../../lib/audio';
import { extFor } from '../../lib/recorder';

const RAIL = [
  { id: 'media', label: 'Media', icon: FolderOpen }, { id: 'templates', label: 'Templates', icon: LayoutTemplate }, { id: 'text', label: 'Text', icon: Type },
  { id: 'stickers', label: 'Stickers', icon: Smile }, { id: 'shapes', label: 'Elements', icon: Shapes }, { id: 'bg', label: 'Backdrop', icon: PaletteIcon },
  { id: 'audio', label: 'Audio', icon: Music2 }, { id: 'ai', label: 'AI Tools', icon: Sparkles }, { id: 'record', label: 'Record', icon: Video }, { id: 'stock', label: 'Stock', icon: Film },
];
const ASPECT_SIZE: Record<string, [number, number]> = { '9:16': [1080, 1920], '16:9': [1920, 1080], '1:1': [1080, 1080], '4:5': [1080, 1350] };

type H = { p: Project; past: Project[]; future: Project[] };

export default function Editor({ projectId }: { projectId?: string }) {
  const { go, toast, pendingEditorImport, setPendingEditorImport, logHistory } = useApp();
  const [h, setH] = useState<H | null>(null);
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [sel, setSel] = useState<string | null>(null);
  const [tab, setTab] = useState('media');
  const phone = useIsPhone();
  const [sheet, setSheet] = useState<null | 'assets' | 'props'>(null);
  const openTab = (id: string) => { setTab(id); if (phone) setSheet('assets'); };
  const [zoom, setZoom] = useState(60);
  const [snapping, setSnapping] = useState(true);
  const [guides, setGuides] = useState(true);
  const [tlh, setTlh] = useState(280);
  const [saved, setSaved] = useState<'saved' | 'saving' | 'dirty'>('saved');
  const [exportOpen, setExportOpen] = useState(false);
  const [versionsOpen, setVersionsOpen] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const comp = useRef<Compositor | null>(null);
  const hRef = useRef<H | null>(null);
  hRef.current = h;
  const timeRef = useRef(0);
  timeRef.current = time;
  const p = h?.p;

  // ---------- load ----------
  useEffect(() => {
    let dead = false;
    (async () => {
      let proj: Project | null = null;
      if (projectId) proj = await loadProject(projectId);
      if (!proj && pendingEditorImport) {
        const imp = pendingEditorImport;
        setPendingEditorImport(null);
        const [w, hh] = ASPECT_SIZE[imp.aspect] || ASPECT_SIZE['9:16'];
        proj = newProject(w, hh, imp.name);
        try {
          const blob = imp.file || (await (await fetch(imp.url)).blob());
          const a = await makeAsset(blob, imp.name + '.mp4');
          proj.assets.push(a);
          const main = proj.tracks.find((t) => t.name === 'Main')!.id;
          const txt = proj.tracks.find((t) => t.name === 'Text')!.id;
          proj.items.push(newItem({ type: 'video', track: main, name: imp.name, assetId: a.id, start: 0, in: imp.start, dur: imp.end - imp.start }));
          for (const c of imp.captions) {
            const s = c.start - imp.start;
            if (s + (c.end - c.start) <= 0 || s > imp.end - imp.start) continue;
            proj.items.push(newItem({ type: 'text', track: txt, name: c.text.slice(0, 18), start: Math.max(0, s), dur: Math.max(0.2, c.end - c.start), y: 0.72, animIn: 'pop', animDur: 0.12, text: textProps({ content: c.text, upper: true, size: 0.06, stroke: '#000', strokeW: 0.16 }) }));
          }
          toast('Clip imported with captions — keep editing!', 'success');
        } catch (e) { toast('Import failed: ' + (e as Error).message, 'error'); }
      }
      if (!proj) proj = newProject();
      if (!dead) setH({ p: proj, past: [], future: [] });
    })();
    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  // ---------- compositor ----------
  const pScale = p ? Math.min(1, 960 / Math.max(p.w, p.h)) : 0.5;
  const wrapRef = useRef<HTMLDivElement>(null);
  const [wrapSize, setWrapSize] = useState({ w: 600, h: 400 });
  useEffect(() => {
    const el = wrapRef.current; if (!el) return;
    const ro = new ResizeObserver(() => setWrapSize({ w: el.clientWidth - 32, h: el.clientHeight - 32 }));
    ro.observe(el);
    return () => ro.disconnect();
  }, [!!p]);
  const fit = p ? Math.min(wrapSize.w / p.w, wrapSize.h / p.h) : 1;
  useEffect(() => {
    if (!p || !canvasRef.current || comp.current) return;
    const c = new Compositor(canvasRef.current, p);
    c.onTime = (t) => setTime(t);
    c.onEnd = () => setPlaying(false);
    comp.current = c;
    return undefined;
  }, [p]);
  useEffect(() => () => { comp.current?.destroy(); comp.current = null; }, []);
  useEffect(() => {
    const c = comp.current, cv = canvasRef.current;
    if (!c || !p || !cv || c.exporting) return;
    const W = Math.round(p.w * pScale), Hh = Math.round(p.h * pScale);
    if (cv.width !== W || cv.height !== Hh) { cv.width = W; cv.height = Hh; }
    c.setProject(p);
  }, [p, pScale]);
  useEffect(() => { if (comp.current) { comp.current.selected = sel; comp.current.guides = guides; if (!comp.current.playing) comp.current.render(); } }, [sel, guides, p]);

  // ---------- history ----------
  const update = useCallback((fn: (p: Project) => void, record = true) => {
    setH((s) => {
      if (!s) return s;
      const next = structuredClone(s.p);
      fn(next);
      next.updatedAt = Date.now();
      return { p: next, past: record ? [...s.past.slice(-80), s.p] : s.past, future: record ? [] : s.future };
    });
    setSaved('dirty');
  }, []);
  const undo = () => setH((s) => (s && s.past.length ? { p: s.past[s.past.length - 1], past: s.past.slice(0, -1), future: [s.p, ...s.future] } : s));
  const redo = () => setH((s) => (s && s.future.length ? { p: s.future[0], past: [...s.past, s.p], future: s.future.slice(1) } : s));

  // ---------- autosave ----------
  useEffect(() => {
    if (!p || saved !== 'dirty') return;
    const id = setTimeout(async () => {
      setSaved('saving');
      let thumb: string | undefined;
      try { const cv = canvasRef.current!; const t = document.createElement('canvas'); t.width = 160; t.height = Math.round((160 * cv.height) / cv.width); t.getContext('2d')!.drawImage(cv, 0, 0, t.width, t.height); thumb = t.toDataURL('image/jpeg', 0.6); } catch { /* */ }
      await saveProject(hRef.current!.p, thumb);
      setSaved('saved');
    }, 1500);
    return () => clearTimeout(id);
  }, [p, saved]);
  useEffect(() => {
    const id = setInterval(() => { const s = hRef.current; if (s && s.p.items.length) saveVersion(s.p); }, 30000);
    return () => clearInterval(id);
  }, []);

  // ---------- transport ----------
  const seek = useCallback((t: number) => { comp.current?.seek(t); setTime(t); }, []);
  const togglePlay = useCallback(async () => {
    const c = comp.current; if (!c) return;
    if (c.playing) { c.pause(); setPlaying(false); } else { await c.play(); setPlaying(true); }
  }, []);

  // ---------- placement helpers ----------
  const freeTrack = (pr: Project, kind: 'visual' | 'audio', start: number, dur: number, prefer?: string): string => {
    const tracks = pr.tracks.filter((t) => t.kind === kind && !t.locked);
    const ordered = prefer ? [...tracks.filter((t) => t.name === prefer), ...tracks.filter((t) => t.name !== prefer)] : tracks;
    for (const t of ordered) {
      const clash = pr.items.some((i) => i.track === t.id && i.start < start + dur - 0.01 && i.start + i.dur > start + 0.01);
      if (!clash) return t.id;
    }
    const nt = { id: uid('tr_'), kind, name: (kind === 'visual' ? 'Layer ' : 'Audio ') + (pr.tracks.length + 1), muted: false, locked: false, hidden: false };
    if (kind === 'visual') pr.tracks.unshift(nt); else pr.tracks.push(nt);
    return nt.id;
  };
  const placeAsset = useCallback((a: Asset, at?: number) => {
    update((pr) => {
      if (!pr.assets.some((x) => x.id === a.id)) pr.assets.push(a);
      const start = at ?? timeRef.current;
      const dur = a.kind === 'image' ? 5 : a.duration;
      if (a.kind === 'audio') {
        const track = freeTrack(pr, 'audio', start, dur, a.name.startsWith('♪') ? 'Music' : 'Voice');
        const music = pr.tracks.find((t) => t.id === track)?.name === 'Music';
        pr.items.push(newItem({ type: 'audio', track, name: a.name, assetId: a.id, start, dur: music ? Math.min(dur, Math.max(projectDuration(pr) - start, 5)) : dur, volume: music ? 0.5 : 1, fadeOut: music ? 1.5 : 0 }));
      } else {
        const mainFree = !pr.items.some((i) => { const tr = pr.tracks.find((t) => t.id === i.track); return tr?.name === 'Main' && i.start < start + dur && i.start + i.dur > start; });
        const track = freeTrack(pr, 'visual', start, dur, 'Main');
        const isMain = pr.tracks.find((t) => t.id === track)?.name === 'Main' && mainFree;
        const it = newItem({ type: a.kind, track, name: a.name, assetId: a.id, start, dur, scale: isMain ? 1 : 0.45, animIn: isMain ? 'none' : 'pop' });
        if (!isMain && a.width && a.height) it.fit = 'contain';
        pr.items.push(it);
        setSel(it.id);
      }
    });
  }, [update]);
  const addBlob = useCallback(async (b: Blob, name: string, place = false) => {
    const a = await makeAsset(b, name);
    update((pr) => { pr.assets.push(a); });
    if (place) placeAsset(a);
    else toast(`Imported ${name}`, 'success');
    return a;
  }, [update, placeAsset, toast]);
  const addItem = useCallback((part: Partial<Item> & { type: Item['type'] }, kind: 'visual' | 'audio' = 'visual', trackName?: string) => {
    update((pr) => {
      const start = timeRef.current;
      const dur = part.dur ?? 5;
      const prefer = trackName || (part.type === 'bg' ? 'Main' : part.type === 'text' ? 'Text' : 'Overlay');
      const track = freeTrack(pr, kind, start, dur, prefer);
      const it = newItem({ ...part, track, start, dur });
      pr.items.push(it);
      setSel(it.id);
    });
  }, [update]);

  const applyTemplate = useCallback(async (t: TemplateDef) => {
    const [w, hh] = ASPECT_SIZE[t.aspect];
    let fresh: Project | null = null;
    update((pr) => {
      const np = newProject(w, hh);
      pr.w = w; pr.h = hh; pr.tracks = np.tracks; pr.items = []; pr.markers = []; pr.markIn = null; pr.markOut = null;
      t.build(pr);
      fresh = pr;
    });
    seek(0);
    setSel(null);
    toast(`Template “${t.name}” applied`, 'success');
    await new Promise((r) => setTimeout(r, 30));
    const snapshot = hRef.current?.p || fresh;
    if (!snapshot) return;
    const dur = projectDuration(snapshot);
    const extra: { a: Asset; start: number; dur: number; music: boolean }[] = [];
    if (t.music) { const a = await makeAsset(await musicWavBlob(t.music, 3), `♪ ${t.music}.wav`); extra.push({ a, start: 0, dur: Math.min(a.duration, dur), music: true }); }
    for (const s of t.sfx || []) { const a = await makeAsset(await sfxWavBlob(s.id), `${s.id}.wav`); extra.push({ a, start: s.t, dur: a.duration, music: false }); }
    if (extra.length) update((pr) => {
      for (const e of extra) {
        pr.assets.push(e.a);
        const track = freeTrack(pr, 'audio', e.start, e.dur, e.music ? 'Music' : 'Voice');
        pr.items.push(newItem({ type: 'audio', track, name: e.a.name, assetId: e.a.id, start: e.start, dur: e.dur, volume: e.music ? 0.55 : 0.9, fadeOut: e.music ? 1 : 0 }));
      }
    }, false);
  }, [update, seek, toast]);

  // ---------- edit ops ----------
  const selItem = p?.items.find((i) => i.id === sel) || null;
  const splitAt = useCallback(() => {
    const s = hRef.current; if (!s) return;
    const t = timeRef.current;
    const targets = s.p.items.filter((i) => t > i.start + 0.05 && t < i.start + i.dur - 0.05 && (sel ? i.id === sel : true) && !s.p.tracks.find((tr) => tr.id === i.track)?.locked);
    if (!targets.length) { toast('Move the playhead over a clip to split', 'error'); return; }
    update((pr) => {
      for (const tg of targets) {
        const a = pr.items.find((i) => i.id === tg.id)!;
        const cut = t - a.start;
        const b: Item = structuredClone(a);
        b.id = uid('it_'); b.start = t; b.dur = a.dur - cut; b.in = a.in + cut * a.speed; b.animIn = 'none';
        for (const k of Object.keys(b.kf) as (keyof Item['kf'])[]) { b.kf[k] = (b.kf[k] || []).map((x) => ({ ...x, t: x.t - cut })).filter((x) => x.t >= 0); if (!b.kf[k]!.length) { (b as unknown as Record<string, number>)[k] = kfValue(a, k, cut); delete b.kf[k]; } }
        a.dur = cut; a.animOut = 'none';
        pr.items.push(b);
      }
    });
  }, [sel, update, toast]);
  const del = useCallback((ripple = false) => {
    if (!sel) return;
    update((pr) => {
      const it = pr.items.find((i) => i.id === sel); if (!it) return;
      pr.items = pr.items.filter((i) => i.id !== sel);
      if (ripple) for (const o of pr.items) if (o.track === it.track && o.start >= it.start) o.start -= it.dur;
    });
    setSel(null);
  }, [sel, update]);
  const duplicate = useCallback(() => {
    if (!sel) return;
    update((pr) => {
      const it = pr.items.find((i) => i.id === sel); if (!it) return;
      const c = structuredClone(it); c.id = uid('it_'); c.start = it.start + it.dur;
      c.track = freeTrack(pr, pr.tracks.find((t) => t.id === it.track)!.kind, c.start, c.dur, pr.tracks.find((t) => t.id === it.track)!.name);
      pr.items.push(c); setSel(c.id);
    });
  }, [sel, update]);

  // ---------- keyboard ----------
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tg = e.target as HTMLElement;
      if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.tagName === 'SELECT' || tg.isContentEditable)) return;
      if (useApp.getState().paletteOpen) return;
      const mod = e.ctrlKey || e.metaKey;
      const fps = hRef.current?.p.fps || 30;
      if (e.code === 'Space') { e.preventDefault(); togglePlay(); }
      else if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); }
      else if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
      else if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); duplicate(); }
      else if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); if (hRef.current) saveProject(hRef.current.p).then(() => { setSaved('saved'); toast('Saved', 'success'); }); }
      else if (e.key === 's' || e.key === 'S') splitAt();
      else if (e.key === 'Delete' || e.key === 'Backspace') del(e.shiftKey);
      else if (e.key === 'ArrowLeft') { e.preventDefault(); seek(Math.max(0, timeRef.current - (e.shiftKey ? 1 : 1 / fps))); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); seek(timeRef.current + (e.shiftKey ? 1 : 1 / fps)); }
      else if (e.key === 'Home') seek(0);
      else if (e.key === 'End' && hRef.current) seek(projectDuration(hRef.current.p));
      else if (e.key === 'i' || e.key === 'I') update((pr) => { pr.markIn = +timeRef.current.toFixed(3); if (pr.markOut !== null && pr.markOut <= pr.markIn) pr.markOut = null; });
      else if (e.key === 'o' || e.key === 'O') update((pr) => { pr.markOut = +timeRef.current.toFixed(3); if (pr.markIn === null) pr.markIn = 0; });
      else if (e.key === 'x' || e.key === 'X') update((pr) => { pr.markIn = null; pr.markOut = null; });
      else if (e.key === 'm' || e.key === 'M') update((pr) => { pr.markers = [...pr.markers, +timeRef.current.toFixed(3)].sort((a, b) => a - b); });
      else if (e.key === '+' || e.key === '=') setZoom((z) => Math.min(400, z * 1.25));
      else if (e.key === '-') setZoom((z) => Math.max(4, z / 1.25));
      else if (e.key === 'Escape') setSel(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay, duplicate, splitAt, del, seek, update, toast]);

  // ---------- canvas interaction ----------
  const canvasDown = (e: RME<HTMLCanvasElement>) => {
    const c = comp.current, cv = canvasRef.current; if (!c || !cv || !p) return;
    const r = cv.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * cv.width, py = ((e.clientY - r.top) / r.height) * cv.height;
    const id = c.hitTest(px, py);
    setSel(id);
    if (!id) return;
    const it = p.items.find((i) => i.id === id)!;
    const local = Math.max(0, timeRef.current - it.start);
    const ox = kfValue(it, 'x', local), oy = kfValue(it, 'y', local);
    let rec = false;
    const move = (ev: MouseEvent) => {
      const dx = (ev.clientX - e.clientX) / r.width, dy = (ev.clientY - e.clientY) / r.height;
      if (!rec && Math.abs(dx) + Math.abs(dy) < 0.004) return;
      let nx = ox + dx, ny = oy + dy;
      if (snapping) { if (Math.abs(nx - 0.5) < 0.015) nx = 0.5; if (Math.abs(ny - 0.5) < 0.015) ny = 0.5; }
      const first = !rec; rec = true;
      update((pr) => { const x = pr.items.find((i) => i.id === id)!; setProp(x, 'x', nx, local); setProp(x, 'y', ny, local); }, first);
    };
    const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', up);
  };
  const canvasWheel = (e: React.WheelEvent) => {
    if (!selItem) return;
    const local = Math.max(0, time - selItem.start);
    const s = kfValue(selItem, 'scale', local) * (e.deltaY < 0 ? 1.05 : 1 / 1.05);
    update((pr) => { const x = pr.items.find((i) => i.id === selItem.id)!; setProp(x, 'scale', Math.max(0.05, Math.min(8, s)), local); }, false);
  };
  const onDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    const aid = e.dataTransfer.getData('cf/asset');
    if (aid && p) { const a = p.assets.find((x) => x.id === aid); if (a) placeAsset(a); return; }
    for (const f of Array.from(e.dataTransfer.files)) await addBlob(f, f.name, true);
  };

  const snapshot = useCallback((full = true): string => {
    const c = comp.current, cv = canvasRef.current; if (!c || !cv || !p) return '';
    const pw = cv.width, ph = cv.height;
    if (full) { cv.width = p.w; cv.height = p.h; }
    const g = c.guides; c.guides = false; c.render();
    const url = cv.toDataURL('image/png');
    c.guides = g; cv.width = pw; cv.height = ph; c.render();
    return url;
  }, [p]);

  const startResize = (e: RME) => {
    const y0 = e.clientY, h0 = tlh;
    const move = (ev: MouseEvent) => setTlh(Math.max(150, Math.min(window.innerHeight - 250, h0 - (ev.clientY - y0))));
    const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
    window.addEventListener('pointermove', move); window.addEventListener('pointerup', up);
  };

  const dur = useMemo(() => (p ? projectDuration(p) : 0), [p]);
  if (!h || !p) return <div style={{ height: '100vh', display: 'grid', placeItems: 'center' }}><div className="spin" /></div>;

  return (
    <div className={'ed' + (phone ? ' ph' : '') + (phone && sheet ? ' sheet-' + sheet : '')} style={{ '--tlh': tlh + 'px' } as CSSProperties}>
      <div className="ed-top">
        <button className="btn ghost sm icon" title="Back to dashboard" onClick={() => go({ name: 'dashboard' })}><ArrowLeft size={16} /></button>
        <div className="hide-ph" onClick={() => go({ name: 'dashboard' })} style={{ cursor: 'pointer' }}><Logo /></div>
        <div className="hide-ph" style={{ width: 1, height: 24, background: 'var(--line)' }} />
        <input className="input sm ed-name" style={{ width: 220, fontWeight: 700 }} value={p.name} onChange={(e) => update((pr) => { pr.name = e.target.value; }, false)} />
        <span className="tiny dim row gap4 hide-ph" style={{ minWidth: 80 }}>{saved === 'saved' ? <><Check size={12} color="#3ddc97" /> Saved locally</> : saved === 'saving' ? <><Cloud size={12} /> Saving…</> : '● Unsaved'}</span>
        <div className="grow" />
        <button className="btn ghost sm icon" title="Undo (Ctrl+Z)" disabled={!h.past.length} onClick={undo}><Undo2 size={15} /></button>
        <button className="btn ghost sm icon" title="Redo (Ctrl+Shift+Z)" disabled={!h.future.length} onClick={redo}><Redo2 size={15} /></button>
        <button className="btn ghost sm" title="Version history" onClick={() => setVersionsOpen(true)}><History size={14} /><span className="hide-ph"> Versions</span></button>
        <span className="badge hide-ph">{p.w}×{p.h} · {p.fps}fps</span>
        <button className="btn primary sm glow" onClick={() => { comp.current?.pause(); setPlaying(false); setExportOpen(true); }}><Download size={14} /> Export</button>
      </div>

      <div className="ed-mid">
        <div className="ed-rail">
          {RAIL.map((r) => <div key={r.id} className={'rail-btn' + (tab === r.id && (!phone || sheet === 'assets') ? ' on' : '')} onClick={() => { setTab(r.id); if (phone) setSheet(sheet === 'assets' && tab === r.id ? null : 'assets'); }}><r.icon size={18} />{r.label}</div>)}
          {phone && <div className={'rail-btn' + (sheet === 'props' ? ' on' : '')} onClick={() => setSheet(sheet === 'props' ? null : 'props')}><SlidersHorizontal size={18} />Edit</div>}
        </div>
        <div className="ed-assets">
          {phone && <div className="sheet-bar" onClick={() => setSheet(null)}><span /> <b className="small">{RAIL.find((r) => r.id === tab)?.label}</b><X size={18} /></div>}
          <Assets tab={tab} project={p} time={time} selected={selItem} addBlob={addBlob} placeAsset={placeAsset} addItem={addItem} update={update} applyTemplate={applyTemplate} snapshot={() => snapshot(true)} />
        </div>
        <div className="ed-stage">
          <div className="ed-canvas-wrap" ref={wrapRef} onDragOver={(e) => e.preventDefault()} onDrop={onDrop}>
            <canvas ref={canvasRef} width={Math.round(p.w * pScale)} height={Math.round(p.h * pScale)} onPointerDown={canvasDown} onWheel={canvasWheel} style={{ cursor: selItem ? 'move' : 'default', width: Math.max(50, p.w * fit), height: Math.max(50, p.h * fit) }} />
            {!p.items.length && (
              <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', pointerEvents: 'none' }}>
                <div className="card" style={{ textAlign: 'center', maxWidth: 340, pointerEvents: 'auto' }}>
                  <div style={{ fontSize: 34 }}>🎬</div>
                  <b>Start creating</b>
                  <div className="muted small mt8">Let the AI Director make the whole video from a description, or build it yourself.</div>
                  <button className="btn glow mt16" style={{ width: '100%' }} onClick={() => go({ name: 'director' })}><Clapperboard size={15} /> AI Director — describe your video</button>
                  <div className="row gap6 center mt8 wrap">
                    <button className="btn sm primary" onClick={() => openTab('templates')}><LayoutTemplate size={13} /> Templates</button>
                    <button className="btn sm" onClick={() => openTab('media')}><FolderOpen size={13} /> Media</button>
                    <button className="btn sm" onClick={() => openTab('ai')}><Sparkles size={13} /> AI script</button>
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className="ed-transport">
            <span className="mono small" style={{ minWidth: 150 }}>{fmtTime(time, true)} / {fmtTime(dur, true)}</span>
            <div className="grow" />
            <button className="btn ghost sm icon" onClick={() => seek(p.markIn ?? 0)}><SkipBack size={15} /></button>
            <button className="btn primary icon" style={{ width: 38, height: 38, borderRadius: 99 }} onClick={togglePlay}>{playing ? <Pause size={17} /> : <Play size={17} />}</button>
            <button className="btn ghost sm icon" onClick={() => seek(dur)}><SkipForward size={15} /></button>
            <div className="grow" />
            <button className={'btn ghost sm icon' + (guides ? ' active' : '')} title="Selection guides" onClick={() => setGuides(!guides)}><Grid3x3 size={14} /></button>
            <button className="btn ghost sm icon" title="Fullscreen preview" onClick={() => canvasRef.current?.requestFullscreen?.()}><Maximize size={14} /></button>
          </div>
        </div>
        <div className="ed-props">
          {phone && <div className="sheet-bar" onClick={() => setSheet(null)}><span /> <b className="small">{selItem ? 'Edit selected' : 'Project'}</b><X size={18} /></div>}
          <Props project={p} item={selItem} time={time} update={update} onDelete={() => del(false)} onDuplicate={duplicate} />
        </div>
      </div>

      <div className="ed-resizer" onPointerDown={startResize} />

      <div className="ed-tl">
        <div className="tl-tools">
          <button className="btn ghost sm" title="Split (S)" onClick={splitAt}><Scissors size={14} /> Split</button>
          <button className="btn ghost sm icon" title="Delete (Del)" disabled={!sel} onClick={() => del(false)}><Trash2 size={14} /></button>
          <button className="btn ghost sm icon" title="Duplicate (Ctrl+D)" disabled={!sel} onClick={duplicate}><Copy size={14} /></button>
          <button className="btn ghost sm" title="Ripple delete (Shift+Del)" disabled={!sel} onClick={() => del(true)}>Ripple</button>
          <div style={{ width: 1, height: 20, background: 'var(--line)' }} />
          <button className={'btn ghost sm' + (snapping ? ' active' : '')} title="Snapping" onClick={() => setSnapping(!snapping)}><Magnet size={14} /> Snap</button>
          <button className="btn ghost sm" title="Add marker (M)" onClick={() => update((pr) => { pr.markers = [...pr.markers, +time.toFixed(3)].sort((a, b) => a - b); })}><Flag size={14} /> Marker</button>
          {p.markers.length > 0 && <button className="btn ghost sm" onClick={() => update((pr) => { pr.markers = []; })}>Clear markers</button>}
          <button className="btn ghost sm" title="Mark in (I)" onClick={() => update((pr) => { pr.markIn = +time.toFixed(3); })}>[ In</button>
          <button className="btn ghost sm" title="Mark out (O)" onClick={() => update((pr) => { pr.markOut = +time.toFixed(3); if (pr.markIn === null) pr.markIn = 0; })}>Out ]</button>
          {p.markIn !== null && <span className="badge brand">{fmtTime(p.markIn, true)} → {fmtTime(p.markOut ?? dur, true)} <span style={{ cursor: 'pointer', marginLeft: 4 }} onClick={() => update((pr) => { pr.markIn = null; pr.markOut = null; })}>×</span></span>}
          <div className="grow" />
          <span className="tiny dim">{p.items.length} clips · {p.tracks.length} tracks</span>
          <button className="btn ghost sm icon" onClick={() => setZoom((z) => Math.max(4, z / 1.25))}><ZoomOut size={14} /></button>
          <input type="range" min={4} max={400} value={zoom} onChange={(e) => setZoom(+e.target.value)} style={{ width: 110 }} />
          <button className="btn ghost sm icon" onClick={() => setZoom((z) => Math.min(400, z * 1.25))}><ZoomIn size={14} /></button>
        </div>
        <Timeline project={p} time={time} zoom={zoom} selected={sel} snapping={snapping} onSelect={setSel} onSeek={seek} update={update} />
      </div>

      <ExportModal open={exportOpen} onClose={() => setExportOpen(false)} project={p} comp={comp} snapshot={snapshot} onDone={(title) => logHistory({ title, score: 0, kind: 'editor' })} />
      <Modal open={versionsOpen} onClose={() => setVersionsOpen(false)} title="Version history" width={480}>
        <Versions id={p.id} onRestore={async (v) => { const hp = await hydrate(v); update((pr) => { Object.assign(pr, { ...hp, id: pr.id }); }); setVersionsOpen(false); toast('Version restored (Ctrl+Z to undo)', 'success'); }} />
      </Modal>
    </div>
  );
}

function Versions({ id, onRestore }: { id: string; onRestore: (p: Project) => void }) {
  const [vs, setVs] = useState<{ at: number; project: Project }[] | null>(null);
  useEffect(() => { listVersions(id).then(setVs); }, [id]);
  if (!vs) return <div className="spin" />;
  if (!vs.length) return <div className="muted small">No snapshots yet — ClipForge saves a version every 30 seconds while you edit (last 20 kept).</div>;
  return (
    <div className="col gap6">
      {vs.map((v) => (
        <div key={v.at} className="row between card tight">
          <div><b className="small">{new Date(v.at).toLocaleString()}</b><div className="dim tiny">{v.project.items.length} clips · {fmtTime(projectDuration(v.project))}</div></div>
          <button className="btn sm" onClick={() => onRestore(v.project)}>Restore</button>
        </div>
      ))}
    </div>
  );
}

function ExportModal({ open, onClose, project, comp, snapshot, onDone }: { open: boolean; onClose: () => void; project: Project; comp: React.RefObject<Compositor | null>; snapshot: (full?: boolean) => string; onDone: (t: string) => void }) {
  const toast = useApp((s) => s.toast);
  const settings = useApp((s) => s.settings);
  const [res, setRes] = useState<number>(settings.exportRes === 720 ? 720 : 1080);
  const [speed, setSpeed] = useState<RenderSpeed>((localStorage.getItem('cf-export-speed') as RenderSpeed) || 'fast');
  const outRes = speed === 'fast' ? Math.min(720, res) : res;
  const outFps = speed === 'fast' ? Math.min(24, project.fps) : project.fps;
  const [range, setRange] = useState<'all' | 'inout'>(project.markIn !== null ? 'inout' : 'all');
  const [prog, setProg] = useState<number | null>(null);
  const [result, setResult] = useState<{ url: string; blob: Blob; name: string } | null>(null);
  useEffect(() => { setBusy('export-video', prog !== null, 'exporting'); return () => setBusy('export-video', false); }, [prog]);
  const cancel = useRef(false);
  const [mode, setMode] = useState<'fast' | 'rt'>('fast');
  const t0 = useRef(0);
  const short = Math.min(project.w, project.h);
  const dur = projectDuration(project);
  const r: [number, number] = range === 'inout' && project.markIn !== null ? [project.markIn, project.markOut ?? dur] : [0, dur];
  const run = async () => {
    const c = comp.current; if (!c) return;
    cancel.current = false; setResult(null); setProg(0); t0.current = performance.now();
    try {
      let blob: Blob | null = null;
      if (fastRenderSupported() && localStorage.getItem('cf-force-realtime') !== '1') {
        setMode('fast');
        try { blob = await fastRender(project, outRes / short, r, (x) => setProg(Math.min(1, x)), () => cancel.current, speed); }
        catch (e) { if (cancel.current) { setProg(null); return; } console.warn('Fast export failed, using real-time export', e); }
      }
      if (!blob) { setMode('rt'); setProg(0); blob = await c.export(outRes / short, r, (x) => setProg(Math.min(1, x)), () => cancel.current); }
      if (cancel.current) { setProg(null); return; }
      const name = `${slug(project.name) || 'clipforge'}-${outRes}p.${extFor(blob.type)}`;
      setResult({ url: URL.createObjectURL(blob), blob, name });
      onDone(project.name);
      toast('🎉 Export complete', 'success');
    } catch (e) { toast('Export failed: ' + (e as Error).message, 'error'); }
    setProg(null);
  };
  const audioOnly = async () => {
    setProg(0);
    try {
      const sr = 44100;
      const oac = new OfflineAudioContext(2, Math.ceil((r[1] - r[0]) * sr), sr);
      const items = project.items.filter((i) => (i.type === 'audio' || i.type === 'video') && !project.tracks.find((t) => t.id === i.track)?.muted && !project.tracks.find((t) => t.id === i.track)?.hidden);
      let n = 0;
      for (const it of items) {
        const a = project.assets.find((x) => x.id === it.assetId); if (!a) continue;
        let buf: AudioBuffer;
        try { buf = await oac.decodeAudioData(await (await fetch(a.url)).arrayBuffer()); } catch { continue; }
        const src = oac.createBufferSource(); src.buffer = buf; src.playbackRate.value = it.speed;
        const g = oac.createGain();
        const s0 = it.start - r[0];
        const when = Math.max(0, s0), off = it.in + Math.max(0, -s0) * it.speed, len = it.dur - Math.max(0, -s0);
        if (len <= 0) continue;
        g.gain.setValueAtTime(it.fadeIn ? 0 : it.volume, when);
        if (it.fadeIn) g.gain.linearRampToValueAtTime(it.volume, when + it.fadeIn);
        if (it.fadeOut) { g.gain.setValueAtTime(it.volume, when + len - it.fadeOut); g.gain.linearRampToValueAtTime(0, when + len); }
        src.connect(g).connect(oac.destination);
        src.start(when, off, len * it.speed);
        setProg(++n / items.length / 2);
      }
      const out = await oac.startRendering();
      download(encodeWav(out), `${slug(project.name) || 'clipforge'}-audio.wav`);
      toast('Audio exported (WAV)', 'success');
    } catch (e) { toast('Audio export failed: ' + (e as Error).message, 'error'); }
    setProg(null);
  };
  const opts = [[480, 'SD 480p', 'Fast preview'], [720, 'HD 720p', 'Good for stories'], [1080, 'Full HD 1080p', 'Recommended'], [1440, '2K 1440p', 'Big screens'], [2160, '4K 2160p', 'Slow, huge file']] as const;
  return (
    <Modal open={open} onClose={() => { cancel.current = true; onClose(); }} title="Export video" width={560}>
      {prog !== null ? (
        <div className="col gap16" style={{ padding: '20px 0' }}>
          <div className="row between"><b>Rendering {outRes}p{speed === 'fast' ? ' · fast' : ''}…</b><span className="mono">{Math.round(prog * 100)}%</span></div>
          <div className="bar"><div style={{ width: `${prog * 100}%` }} /></div>
          <div className="dim small">{mode === 'fast' ? <>Fast render — decoding and encoding directly, usually quicker than playback ({fmtTime(r[1] - r[0])} of video{prog > 0.02 ? `, ~${fmtTime(((performance.now() - t0.current) / 1000) * (1 - prog) / prog)} left` : ''}).</> : <>Real-time render in your browser ({fmtTime(r[1] - r[0])}). Keep this tab visible.</>}</div>
          <button className="btn" onClick={() => { cancel.current = true; }}>Cancel</button>
        </div>
      ) : result ? (
        <div className="col gap16">
          <video src={result.url} controls style={{ width: '100%', maxHeight: 360, background: '#000', borderRadius: 12 }} />
          <div className="row between"><div><b>{result.name}</b><div className="dim tiny">{(result.blob.size / 1e6).toFixed(1)} MB · {result.blob.type}</div></div>
            <button className="btn primary" onClick={() => download(result.blob, result.name)}><Download size={14} /> Download</button></div>
          <button className="btn ghost sm" onClick={() => setResult(null)}>Export again</button>
        </div>
      ) : (
        <div className="col gap16">
          <div>
            <div className="section-title">Speed</div>
            <div className="grid g2">
              {([['fast', '⚡ Fast', '720p · 24 fps — about 2× quicker, great on phones'], ['best', '💎 Best quality', 'Your resolution · 30 fps · sharper encoding']] as const).map(([v, n, d]) => (
                <div key={v} className={'chip' + (speed === v ? ' on' : '')} style={{ flexDirection: 'column', alignItems: 'flex-start', padding: 12, borderRadius: 12 }} onClick={() => { setSpeed(v); localStorage.setItem('cf-export-speed', v); }}><b>{n}</b><span className="tiny dim">{d}</span></div>
              ))}
            </div>
          </div>
          <div style={speed === 'fast' ? { opacity: 0.45, pointerEvents: 'none' } : undefined}>
            <div className="section-title">Resolution{speed === 'fast' ? ' (Fast uses 720p)' : ''}</div>
            <div className="grid g3">
              {opts.map(([v, n, d]) => <div key={v} className={'chip' + (res === v ? ' on' : '')} style={{ flexDirection: 'column', alignItems: 'flex-start', padding: 10, borderRadius: 12 }} onClick={() => setRes(v)}><b>{n}</b><span className="tiny dim">{d}</span></div>)}
            </div>
                      </div>
          <div className="dim tiny" style={{ marginTop: -8 }}>Output {Math.round((project.w * outRes) / short / 2) * 2}×{Math.round((project.h * outRes) / short / 2) * 2} @ {outFps}fps · about {estimateMB(Math.round((project.w * outRes) / short), Math.round((project.h * outRes) / short), r[1] - r[0], speed)} MB{r[1] - r[0] > 600 && outRes > 720 ? ' — 720p is plenty for phones and half the size' : ''}</div>
          <div>
            <div className="section-title">Range</div>
            <div className="seg"><button className={range === 'all' ? 'on' : ''} onClick={() => setRange('all')}>Whole project ({fmtTime(dur)})</button><button className={range === 'inout' ? 'on' : ''} disabled={project.markIn === null} onClick={() => setRange('inout')}>In → Out {project.markIn === null ? '(set with I/O)' : ''}</button></div>
          </div>
          <button className="btn primary lg glow" onClick={run} disabled={!project.items.length}><Download size={16} /> Render video (MP4 / WebM)</button>
          <div className="row gap6">
            <button className="btn sm grow" onClick={audioOnly}><Music2 size={13} /> Audio only (WAV)</button>
            <button className="btn sm grow" onClick={() => { const url = snapshot(true); fetch(url).then((r) => r.blob()).then((b) => download(b, `${slug(project.name)}-frame.png`)); }}>🖼️ Current frame (PNG)</button>
            <button className="btn sm grow" onClick={() => { const b = new Blob([JSON.stringify({ ...project, assets: project.assets.map((a) => ({ ...a, url: '' })) }, null, 2)], { type: 'application/json' }); download(b, `${slug(project.name)}.clipforge.json`); }}>{'{ }'} Project file</button>
          </div>
          <div className="dim tiny">MP4 (H.264) when your browser supports it, otherwise WebM (VP9). Rendering uses your device, no upload.</div>
        </div>
      )}
    </Modal>
  );
}

import { useState } from 'react';
import ClipRow from '../components/ClipRow';
import { clipFileName, downloadBlob, formatTime } from '../lib/download';
import { reExportClip } from '../lib/pipeline';
import { captureThumb, storeThumb } from '../lib/thumb';
import { wakeAcquire, wakeRelease } from '../lib/wake';
import * as db from '../lib/db';
import { useStore } from '../store';
import type { Clip } from '../lib/types';

interface Props {
  mode: 'results' | 'editor';
}

/**
 * Results (simple list) and Editor (the advanced tabs, out of the way).
 * Both are the same data; results hides the editing controls behind "Edit".
 */
export default function EditorPage({ mode }: Props) {
  const s = useStore();
  const [playing, setPlaying] = useState<string | null>(null);
  const [busyClip, setBusyClip] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  if (!s.clips.length) {
    return (
      <>
        <h1>{mode === 'results' ? 'Results' : 'Editor'}</h1>
        <div className="empty">
          No clips in this session. Make clips first — or open a run from History.
        </div>
      </>
    );
  }

  const done = s.clips.filter((c) => c.status === 'done');

  const downloadAll = async () => {
    if (!done.length) {
      setMsg('Nothing finished yet.');
      return;
    }
    setMsg(`Downloading ${done.length} file(s), one at a time`);
    for (const c of done) {
      const blob = await db.getBlob(c.id);
      if (!blob) continue;
      await downloadBlob({ blob, fileName: c.fileName });
    }
    setMsg('All downloads handed over');
  };

  const downloadOne = async (clip: Clip) => {
    const blob = await db.getBlob(clip.id);
    if (!blob) {
      setMsg('That file is not stored on this device any more. Re-make it from the Editor.');
      return;
    }
    await downloadBlob({
      blob,
      fileName: clip.fileName || clipFileName('clip', clip.index, clip.analysis?.title ?? '', 'mp4'),
    });
    setMsg(`Downloaded ${clip.fileName}`);
  };

  const changeLayout = async (clip: Clip, layout: Clip['layout']) => {
    if (clip.layout === layout) return;
    const next: Clip = { ...clip, layout, edited: true };
    s.updateClip(next);
    await db.saveClip(next);
    setMsg(
      layout === 'face'
        ? 'Face crop selected. Press Re-make in Edit to rebuild this clip.'
        : 'Full frame selected. Press Re-make in Edit to rebuild this clip.',
    );
  };

  const reExport = async (clip: Clip) => {
    if (!s.source) {
      setMsg(
        'The source video is not loaded in this session any more. Go to Clips and run it again — ' +
          'finished clips will be skipped, only this one is rebuilt.',
      );
      return;
    }
    setBusyClip(clip.id);
    setMsg(null);
    wakeAcquire();
    const ctrl = new AbortController();
    try {
      s.updateClip({ ...clip, status: 'exporting', progress: 0, progressText: 'Re-making', error: null });
      const out = await reExportClip({
        clip,
        source: s.source,
        settings: s.ui.exportSettings,
        sourceHasAudio: s.sourceHasAudio,
        forceRealtime: s.ui.forceRealtime,
        signal: ctrl.signal,
        onProgress: (frac, message) =>
          s.updateClip({ ...clip, status: 'exporting', progress: frac, progressText: message }),
      });
      await db.putBlob(clip.id, out.blob);
      const th = await captureThumb(out.blob, [clip.duration * 0.3]);
      if (th.dataUrl) await storeThumb(clip.id, th.dataUrl);
      const updated: Clip = {
        ...clip,
        status: 'done',
        progress: 1,
        progressText: 'Done',
        sizeBytes: out.blob.size,
        mime: out.blob.type || 'video/mp4',
        verification: out.verification,
        engine: out.engine,
        exportedAt: Date.now(),
        error: null,
        thumbUrl: th.dataUrl ?? clip.thumbUrl,
        url: URL.createObjectURL(out.blob),
        fileName: clipFileName(
          s.run?.sourceName ?? 'clip',
          clip.index,
          clip.analysis?.title ?? '',
          out.blob.type.includes('webm') ? 'webm' : 'mp4',
        ),
      };
      s.updateClip(updated);
      await db.saveClip(updated);
      setMsg(
        out.verification.ok
          ? `Rebuilt and checked: ${out.verification.duration.toFixed(1)}s, motion to ${Math.round(
              out.verification.motionThrough * 100,
            )}%, audio ${out.verification.audioPresent ? 'yes' : 'no'}.`
          : `Rebuilt but the check still complains: ${out.verification.messages.join(' · ')}`,
      );
      out.blob = null as unknown as Blob;
    } catch (e) {
      s.updateClip({ ...clip, status: 'error', error: (e as Error).message, progressText: 'Failed' });
      setMsg((e as Error).message);
    } finally {
      setBusyClip(null);
      wakeRelease();
    }
  };

  return (
    <>
      <div className="spread wrap">
        <h1 style={{ margin: 0 }}>{mode === 'results' ? 'Results' : 'Editor'}</h1>
        <button className="btn btn-sm" onClick={() => void downloadAll()}>
          ⬇ Download all
        </button>
      </div>

      <p className="dim small">
        {s.run ? `${s.run.sourceName} · ${formatTime(s.run.sourceDuration)} source · ` : ''}
        {done.length}/{s.clips.length} finished
        {mode === 'editor' ? ' · editing controls are open below each clip' : ''}
      </p>

      {msg ? <p className="err">{msg}</p> : null}
      {busyClip ? <p className="small dim">Working on one clip — the rest stay untouched.</p> : null}

      {s.clips.map((c) => (
        <ClipRow
          key={c.id}
          clip={c}
          editable={mode === 'editor'}
          playing={playing}
          onPlay={(clip) => setPlaying(playing === clip.id ? null : clip.id)}
          onDownload={(clip) => void downloadOne(clip)}
          onLayout={(clip, layout) => void changeLayout(clip, layout)}
          onReExport={(clip) => void reExport(clip)}
          onDelete={async (clip) => {
            await db.deleteClipData(clip.id);
            await db.deleteClipData(`thumb:${clip.id}`);
            s.setClips(s.clips.filter((x) => x.id !== clip.id));
          }}
        />
      ))}

      {mode === 'editor' ? (
        <>
          <h2>How a clip gets rebuilt</h2>
          <div className="logbox">
            {`1. Change the layout, the start or the end.
2. Press "Re-make". Only THAT clip is rebuilt; the others keep their files.
3. The finished file is read back and checked:
     length, picture moving all the way to the end, sound present,
     video length vs audio length, frames actually written.
4. If the check fails, ClipForge rebuilds it with the other engine
     automatically and checks again.
5. Only a file that passes is offered for download.`}
          </div>
        </>
      ) : null}
    </>
  );
}

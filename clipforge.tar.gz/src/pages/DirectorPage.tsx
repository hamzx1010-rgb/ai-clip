import { useState } from 'react';
import { aiEnabled, askAiTitles, NO_AI, type AiDirectorConfig } from '../lib/title';
import { useStore } from '../store';

/**
 * AI Director — optional. ClipForge writes titles offline by default; this page
 * only upgrades them when you bring your own key. Nothing is required for the
 * app to work.
 */
export default function DirectorPage() {
  const s = useStore();
  const ai = s.ui.ai;
  const [test, setTest] = useState('');

  const set = (patch: Partial<AiDirectorConfig>) => s.setUi({ ai: { ...ai, ...patch } });

  const runTest = async () => {
    if (!aiEnabled(ai)) {
      setTest('Add a key and choose a provider first.');
      return;
    }
    setTest('Asking…');
    const got = await askAiTitles(
      ai,
      [
        {
          index: 0,
          start: 0,
          end: 25,
          hasFace: true,
          motion: 4,
          speechRatio: 0.5,
          keywords: ['testing'],
          sourceName: 'test.mp4',
        },
      ],
      'test.mp4',
      s.ui.exportSettings,
    );
    setTest(got.size ? `It worked. Sample title: ${got.get(0)?.title}` : 'No answer. Check the key, model and base URL.');
  };

  return (
    <>
      <h1>AI Director</h1>
      <p className="dim">
        Optional. Without it ClipForge still writes a title and a hook for every clip on the phone.
        With a key, the Director rewrites them for the whole run in one call.
      </p>

      <div className="rowline">
        <label htmlFor="provider">Provider</label>
        <select
          id="provider"
          value={ai.provider}
          onChange={(e) => set({ provider: e.target.value as AiDirectorConfig['provider'] })}
        >
          <option value="none">Off — write titles on the phone</option>
          <option value="openai">OpenAI-compatible API</option>
        </select>

        <label htmlFor="key">API key</label>
        <input
          id="key"
          type="password"
          autoComplete="off"
          value={ai.apiKey}
          placeholder="sk-…"
          onChange={(e) => set({ apiKey: e.target.value })}
        />
        <p className="field-note">
          Stored only in this browser. It is sent straight from your phone to the address below.
        </p>

        <label htmlFor="base">Base URL</label>
        <input
          id="base"
          type="url"
          value={ai.baseUrl}
          onChange={(e) => set({ baseUrl: e.target.value })}
        />

        <label htmlFor="model">Model</label>
        <input id="model" type="text" value={ai.model} onChange={(e) => set({ model: e.target.value })} />

        <div className="btn-row" style={{ marginTop: 12 }}>
          <button className="btn" onClick={() => void runTest()}>
            Test it
          </button>
          <button className="btn" onClick={() => s.setUi({ ai: NO_AI })}>
            Turn off
          </button>
        </div>
        {test ? <p className="small">{test}</p> : null}
      </div>

      <h2>What the Director is told</h2>
      <div className="logbox">
        {`For every clip it receives:
  start and end seconds
  whether a person is on camera in THAT clip
  how much the picture moves
  how much of the clip is speech
  your keywords

It must answer with JSON only:
  {"items":[{"index":0,"title":"…","hook":"…"}]}

Title max 60 characters. Hook max 90. No hashtags, no emoji.
If the call fails for any reason, the offline titles are kept.`}
      </div>
    </>
  );
}

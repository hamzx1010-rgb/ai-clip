/**
 * Streaming MP4 reader + MP4 writer, on top of mp4box.js.
 *
 * Why streaming and not "append the whole file":
 *   - mp4box only returns sample BYTES for tracks you called
 *     setExtractionOptions()+start() on. Reading the sample table alone gives
 *     you metadata with data === undefined, which silently starves the decoder
 *     (that is how a clip ends up with no frames).
 *   - extraction buffers every sample it hands out until you release it, so a
 *     20-minute 720p file must be appended in chunks and released as we go.
 *     Memory stays bounded instead of holding the whole video twice.
 *
 * The reader delivers video and audio samples in presentation order with a
 * bounded queue, so the export loop can pull frames at its own pace.
 */

import MP4Box from 'mp4box';
import type { ISOFile, MP4Info, MP4Sample, MP4Track } from 'mp4box';

export interface ExtractedSample {
  number: number;
  cts: number;
  dts: number;
  duration: number;
  is_sync: boolean;
  data: Uint8Array;
  seconds: number;
}

interface Queue {
  items: ExtractedSample[];
  waiters: Array<(s: ExtractedSample | null) => void>;
  closed: boolean;
}

function newQueue(): Queue {
  return { items: [], waiters: [], closed: false };
}

function push(q: Queue, s: ExtractedSample | null) {
  if (s === null) {
    q.closed = true;
    while (q.waiters.length) q.waiters.shift()!(null);
    return;
  }
  const w = q.waiters.shift();
  if (w) w(s);
  else q.items.push(s);
}

function pull(q: Queue): Promise<ExtractedSample | null> {
  if (q.items.length) return Promise.resolve(q.items.shift()!);
  if (q.closed) return Promise.resolve(null);
  return new Promise((resolve) => q.waiters.push(resolve));
}

export interface SourceTracks {
  videoId: number;
  audioId: number;
  videoTimescale: number;
  audioTimescale: number;
  width: number;
  height: number;
  videoCodec: string;
  audioCodec: string;
  audioSampleRate: number;
  audioChannels: number;
  /** Parsed avcC box object (diagnostics). */
  avcC: unknown;
  /**
   * avcC serialised WITHOUT its 8-byte box header — exactly the
   * AVCDecoderConfigurationRecord that VideoDecoderConfig.description and
   * addTrack({avcDecoderConfigRecord}) both expect.
   */
  avcCBytes: Uint8Array | null;
  /**
   * The parsed esds box object itself. mp4box's addTrack({description}) calls
   * addBox() with it, so it has to stay an object — serialising it to bytes and
   * rebuilding is both slower and easy to get wrong (esds is a FULL box, so a
   * naive "strip 8 bytes" corrupts it).
   */
  esds: unknown;
  /** esds as bytes, for diagnostics only. */
  esdsBytes: Uint8Array | null;
  durationSeconds: number;
}

export interface SampleRow {
  number: number;
  cts: number;
  duration: number;
  is_sync: boolean;
  offset: number;
  size: number;
  seconds: number;
}

export interface HeaderInfo {
  tracks: SourceTracks;
  videoTimescale: number;
  audioTimescale: number;
  videoSamples: SampleRow[];
  audioSamples: SampleRow[];
  moovFoundEarly: boolean;
  /** Every byte up to and including the mdat box header (ftyp + moov + mdat hdr). */
  headerBytes: Uint8Array | null;
  /** File offset where the mdat payload begins. */
  mdatDataStart: number;
}

/** Parse track info out of a mp4box ISOFile. Shared by the reader and readHeader. */
export function parseTracks(file: ISOFile, info: MP4Info): SourceTracks {
  const vt = (info.videoTracks?.[0] ?? info.tracks.find((t) => t.video)) as MP4Track | undefined;
  const at = (info.audioTracks?.[0] ?? info.tracks.find((t) => t.audio)) as MP4Track | undefined;
  if (!vt) throw new Error('No video track found in the file');

  const vtrak = file.getTrackById(vt.id) as unknown as TrakLike | null;
  const atrak = at ? (file.getTrackById(at.id) as unknown as TrakLike | null) : null;
  const vEntry = vtrak?.mdia?.minf?.stbl?.stsd?.entries?.[0];
  const aEntry = atrak?.mdia?.minf?.stbl?.stsd?.entries?.[0];

  return {
    videoId: vt.id,
    audioId: at?.id ?? -1,
    videoTimescale: vt.timescale || 1,
    audioTimescale: at?.timescale || 1,
    width: vt.video?.width ?? 0,
    height: vt.video?.height ?? 0,
    videoCodec: normaliseCodec(vt.codec, vEntry?.avcC),
    audioCodec: normaliseCodec(at?.codec, aEntry?.esds),
    audioSampleRate: at?.audio?.sample_rate ?? aEntry?.samplerate ?? 0,
    audioChannels: at?.audio?.channel_count ?? aEntry?.channel_count ?? 0,
    avcC: vEntry?.avcC ?? null,
    avcCBytes: serializeBox(vEntry?.avcC, true),
    esds: aEntry?.esds ?? null,
    esdsBytes: serializeBox(aEntry?.esds, false),
    durationSeconds: info.timescale ? info.duration / info.timescale : vt.duration / (vt.timescale || 1),
  };
}

export interface ReaderOptions {
  blob: Blob;
  /** Start appending at this byte offset instead of 0 (seeks into the file). */
  startByte?: number;
  /** Stop appending once this byte offset is reached. */
  endByte?: number;
  /** Stop once a sample past this presentation time has been delivered. */
  stopAtSeconds?: number;
  /**
   * Experimental: header bytes to splice in front of a mid-file slice.
   * Kept off by default — mp4box waits for the whole declared mdat before it
   * reports ready, so a spliced buffer never becomes ready. ClipForge reads
   * from byte 0 and stops early with `stopAtSeconds` instead, which is fast
   * because parsing without extraction is nearly free.
   */
  headerBytes?: Uint8Array | null;
  /** Append chunk size. 4 MB keeps memory low and parsing fast. */
  chunkBytes?: number;
  /** Pause appending when the video queue grows past this many samples. */
  highWater?: number;
  /** Resume appending under this many. */
  lowWater?: number;
  wantVideo?: boolean;
  wantAudio?: boolean;
  signal?: AbortSignal;
  onProgress?: (frac: number) => void;
}

export class SourceReader {
  private file: ISOFile;
  private opts: Required<
    Omit<ReaderOptions, 'signal' | 'onProgress' | 'startByte' | 'endByte' | 'stopAtSeconds' | 'headerBytes'>
  > &
    Pick<ReaderOptions, 'signal' | 'onProgress' | 'startByte' | 'endByte' | 'stopAtSeconds' | 'headerBytes'>;
  private vq = newQueue();
  private aq = newQueue();
  tracks: SourceTracks | null = null;
  private readyPromise: Promise<void>;
  private readyTimer: ReturnType<typeof setTimeout> | null = null;
  private pumpPromise: Promise<void> | null = null;
  private parseError: string | null = null;
  videoDelivered = 0;
  audioDelivered = 0;
  private lastDeliveredSeconds: number | null = null;

  constructor(opts: ReaderOptions) {
    this.opts = {
      blob: opts.blob,
      startByte: opts.startByte,
      endByte: opts.endByte,
      stopAtSeconds: opts.stopAtSeconds,
      headerBytes: opts.headerBytes ?? null,
      chunkBytes: opts.chunkBytes ?? 4 * 1024 * 1024,
      highWater: opts.highWater ?? 48,
      lowWater: opts.lowWater ?? 12,
      wantVideo: opts.wantVideo ?? true,
      wantAudio: opts.wantAudio ?? true,
      signal: opts.signal,
      onProgress: opts.onProgress,
    };
    this.file = MP4Box.createFile();
    this.readyPromise = new Promise<void>((resolve, reject) => {
      this.readyTimer = setTimeout(
        () => reject(new Error('Could not read the MP4 structure in time')),
        60000,
      );
      const timer = this.readyTimer;
      this.file.onReady = (info: MP4Info) => {
        try {
          this.tracks = this.readTracks(info);
        } catch (e) {
          clearTimeout(timer);
          reject(e instanceof Error ? e : new Error('Unsupported MP4'));
          return;
        }
        clearTimeout(timer);
        resolve();
      };
      this.file.onError = (e: unknown) => {
        this.parseError = `MP4 parse error: ${String((e as Error)?.message ?? e)}`;
        clearTimeout(timer);
        reject(new Error(this.parseError));
      };
      this.file.onMissingMoov = () => {
        this.parseError = 'The file has no MP4 header (moov) — it may be truncated';
      };
    });
  }

  private readTracks(info: MP4Info): SourceTracks {
    return parseTracks(this.file, info);
  }

  /** Waits until the header is parsed and tracks are known. */
  async ready(): Promise<SourceTracks> {
    await this.readyPromise;
    if (!this.tracks) throw new Error('No tracks');
    return this.tracks;
  }

  /** Starts appending chunks. Resolves when the whole file has been parsed. */
  start(): Promise<void> {
    if (!this.pumpPromise) this.pumpPromise = this.pump();
    return this.pumpPromise;
  }

  nextVideo(): Promise<ExtractedSample | null> {
    return pull(this.vq);
  }

  nextAudio(): Promise<ExtractedSample | null> {
    return pull(this.aq);
  }

  private async pump() {
    const { blob, chunkBytes, highWater, lowWater } = this.opts;
    const size = blob.size;
    const from = Math.max(0, Math.min(this.opts.startByte ?? 0, size));
    const to = Math.max(from, Math.min(this.opts.endByte ?? size, size));
    let offset = from;
    let started = false;
    let stopped = false;
    let syntheticDone = false;

    this.file.onSamples = (id: number, _user: unknown, samples: MP4Sample[]) => {
      const t = this.tracks;
      if (!t) return;
      const isVideo = id === t.videoId;
      const ts = isVideo ? t.videoTimescale : t.audioTimescale;
      const q = isVideo ? this.vq : this.aq;
      if ((isVideo && !this.opts.wantVideo) || (!isVideo && !this.opts.wantAudio)) {
        for (const s of samples) this.file.releaseUsedSamples(id, s.number);
        return;
      }
      for (const s of samples) {
        if (!s.data || s.data.byteLength === 0) continue;
        push(q, {
          number: s.number,
          cts: s.cts,
          dts: s.dts,
          duration: s.duration,
          is_sync: !!s.is_sync,
          data: s.data instanceof Uint8Array ? s.data : new Uint8Array(s.data as unknown as ArrayBuffer),
          seconds: s.cts / (ts || 1),
        });
        this.lastDeliveredSeconds = s.cts / (ts || 1);
        if (isVideo) this.videoDelivered++;
        else this.audioDelivered++;
      }
      // Free mp4box's copy immediately — this is what keeps memory bounded.
      const last = samples[samples.length - 1];
      if (last) this.file.releaseUsedSamples(id, last.number);
    };

    while (offset < to) {
      if (this.opts.signal?.aborted || stopped) break;
      const end = Math.min(offset + chunkBytes, to);

      // Splice the header in front of the first mid-file slice, padding so the
      // media bytes land at exactly the offsets the sample table expects.
      const hdr = this.opts.headerBytes;
      let part: ArrayBuffer;
      if (hdr && hdr.length && from > 0 && !syntheticDone) {
        syntheticDone = true;
        const slice = await blob.slice(offset, end).arrayBuffer();
        const pad = offset - hdr.length;
        part = new ArrayBuffer(hdr.length + Math.max(0, pad) + slice.byteLength);
        const view = new Uint8Array(part);
        view.set(hdr, 0);
        view.set(new Uint8Array(slice), hdr.length + Math.max(0, pad));
      } else {
        part = await blob.slice(offset, end).arrayBuffer();
      }
      // fileStart is the offset in the REAL file, so the synthetic header and
      // its padding put the media bytes at exactly their true offsets.
      (part as ArrayBuffer & { fileStart: number }).fileStart = offset;

      let next: number;
      try {
        next = this.file.appendBuffer(part as ArrayBuffer & { fileStart: number });
      } catch (e) {
        this.failBoth(`Could not parse the file at byte ${offset}: ${(e as Error).message}`);
        throw e instanceof Error ? e : new Error('MP4 parse failed');
      }

      if (!started && this.tracks) {
        started = true;
        try {
          if (this.opts.wantVideo) {
            this.file.setExtractionOptions(this.tracks.videoId, null, { nbSamples: 24 });
          }
          if (this.opts.wantAudio && this.tracks.audioId > 0) {
            this.file.setExtractionOptions(this.tracks.audioId, null, { nbSamples: 200 });
          }
          this.file.start();
          // Re-feed the bytes we already parsed so extraction sees them.
          // mp4box keeps them, so simply continue: samples from chunk 1 arrive
          // on the next append. To not lose the first chunk we re-append it.
        } catch {
          /* extraction unsupported — the caller will fall back */
        }
      }

      offset = typeof next === 'number' && next > offset ? next : end;
      if (offset > to) offset = to;
      this.opts.onProgress?.(Math.min(1, (offset - from) / Math.max(1, to - from)));

      // Early exit: we have everything the caller asked for.
      const limit = this.opts.stopAtSeconds;
      if (limit !== undefined) {
        const lastSec = this.lastDeliveredSeconds;
        if (lastSec !== null && lastSec > limit) stopped = true;
      }

      // Backpressure: stop reading until the consumer catches up.
      while (!stopped && this.vq.items.length > highWater) {
        await new Promise((r) => setTimeout(r, 4));
        if (this.opts.signal?.aborted) break;
        if (this.vq.items.length <= lowWater) break;
      }
      await new Promise((r) => setTimeout(r, 0));
    }

    try {
      this.file.flush();
    } catch {
      /* ignore */
    }
    push(this.vq, null);
    push(this.aq, null);
  }

  private failBoth(message: string) {
    this.parseError = message;
    push(this.vq, null);
    push(this.aq, null);
  }

  get error(): string | null {
    return this.parseError;
  }

  /** Release mp4box's internals as soon as the export is done. */
  destroy() {
    if (this.readyTimer) {
      clearTimeout(this.readyTimer);
      this.readyTimer = null;
    }
    try {
      this.file.stop();
    } catch {
      /* ignore */
    }
    push(this.vq, null);
    push(this.aq, null);
    this.tracks = null;
  }
}

/* ------------------------------------------------------------------ */

interface DataStreamLike {
  buffer: ArrayBuffer;
  getPosition(): number;
  endianness?: boolean;
}
interface BoxLike {
  size?: number;
  write?: (stream: unknown) => void;
}

/**
 * Serialise a parsed mp4box box (avcC / esds) back to bytes.
 *
 * Returns the box PAYLOAD only — the 8-byte box header (size + type) is
 * stripped. That matters: WebCodecs wants an AVCDecoderConfigurationRecord,
 * and handing it the whole box fails with "Failed to parse avcC". mp4box's own
 * addTrack({avcDecoderConfigRecord}) wants the payload too, since it runs
 * avcC.parse(new MP4BoxStream(bytes)) on it.
 *
 * Box.writeHeader() ADDS 8 to box.size, so a box written twice would grow;
 * we snapshot and restore the size to keep it idempotent.
 */
function serializeBox(box: unknown, stripHeader: boolean): Uint8Array | null {
  const b = box as BoxLike | null | undefined;
  if (!b || typeof b.write !== 'function') return null;
  const DS = (
    MP4Box as unknown as {
      DataStream?: (new (a?: ArrayBuffer, o?: number, e?: boolean) => DataStreamLike) & { BIG_ENDIAN?: boolean };
    }
  ).DataStream;
  if (!DS) return null;
  const saved = b.size;
  try {
    // BIG_ENDIAN is what every MP4 box uses; DataStream defaults to little.
    const stream = new DS(new ArrayBuffer(4096), 0, DS.BIG_ENDIAN ?? false);
    stream.endianness = DS.BIG_ENDIAN ?? false;
    b.write(stream);
    const n = stream.getPosition();
    if (!n || n <= 8) return null;
    // stream.buffer can be larger than what was written — always slice to n.
    const full = new Uint8Array(stream.buffer.slice(0, n));
    return stripHeader ? stripBoxHeader(full) : full;
  } catch {
    return null;
  } finally {
    b.size = saved;
  }
}

/** mp4box's MP4BoxStream insists on a genuine ArrayBuffer. */
function toArrayBuffer(v?: Uint8Array | ArrayBuffer | null): ArrayBuffer | undefined {
  if (!v) return undefined;
  if (v instanceof ArrayBuffer) return v;
  const u8 = v as Uint8Array;
  return u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength) as ArrayBuffer;
}

/** Drop the 8-byte size+type header when the bytes really are one box. */
function stripBoxHeader(bytes: Uint8Array): Uint8Array {
  if (bytes.length <= 8) return bytes;
  const size =
    (bytes[0] << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3];
  if (size !== bytes.length) return bytes; // not a single self-contained box
  return bytes.slice(8);
}

interface TrakLike {
  mdia?: {
    minf?: {
      stbl?: {
        stsd?: {
          entries?: Array<{
            avcC?: unknown;
            esds?: unknown;
            samplerate?: number;
            channel_count?: number;
            type?: string;
          }>;
        };
      };
    };
  };
}

function normaliseCodec(codec: string | undefined, entry: unknown): string {
  if (codec && codec.length >= 8) return codec.split('.').slice(0, 4).join('.');
  const avcC = entry as { AVCProfileIndication?: number; profile_compatibility?: number; AVCLevelIndication?: number } | undefined;
  if (avcC?.AVCProfileIndication) {
    const hex = (n: number | undefined) => (n ?? 0).toString(16).padStart(2, '0');
    return `avc1.${hex(avcC.AVCProfileIndication)}${hex(avcC.profile_compatibility)}${hex(avcC.AVCLevelIndication)}`;
  }
  return codec || '';
}

/**
 * Read only the header: tracks, codec records and the FULL sample table
 * (timestamps + byte offsets), without extracting any media data.
 *
 * With `+faststart` the moov sits at the front, so a megabyte or two is enough
 * — and the sample table is what lets the export seek straight to the byte
 * range it needs instead of reading a 20-minute file for a 28-second clip.
 */
export async function readHeader(
  blob: Blob,
  opts: { maxBytes?: number; chunkBytes?: number; signal?: AbortSignal } = {},
): Promise<HeaderInfo> {
  const maxBytes = opts.maxBytes ?? Math.min(blob.size, 8 * 1024 * 1024);
  const chunk = opts.chunkBytes ?? 1024 * 1024;
  const file = MP4Box.createFile();
  let info: MP4Info | null = null;
  file.onReady = (i: MP4Info) => {
    info = i;
  };
  file.onError = () => {
    /* keep scanning; onMissingMoov tells us if it never arrives */
  };
  let missingMoov = false;
  file.onMissingMoov = () => {
    missingMoov = true;
  };

  let offset = 0;
  const headParts: Uint8Array[] = [];
  while (offset < maxBytes && !info) {
    if (opts.signal?.aborted) break;
    const end = Math.min(offset + chunk, blob.size);
    const part = await blob.slice(offset, end).arrayBuffer();
    headParts.push(new Uint8Array(part.slice(0)));
    (part as ArrayBuffer & { fileStart: number }).fileStart = offset;
    try {
      file.appendBuffer(part as ArrayBuffer & { fileStart: number });
    } catch {
      break;
    }
    offset = end;
  }
  try {
    file.flush();
  } catch {
    /* ignore */
  }
  if (!info) {
    throw new Error(
      missingMoov
        ? 'This MP4 keeps its index at the end of the file, so the whole file has to be read'
        : 'Could not read the MP4 header',
    );
  }

  const tracks = parseTracks(file, info);

  const toRows = (trackId: number, timescale: number): SampleRow[] =>
    (file.getTrackSamplesInfo(trackId) as MP4Sample[]).map((s) => ({
      number: s.number,
      cts: s.cts,
      duration: s.duration,
      is_sync: !!s.is_sync,
      offset: s.offset ?? 0,
      size: s.size ?? 0,
      seconds: s.cts / (timescale || 1),
    }));

  const headBytes = concatU8(headParts);
  const mdatDataStart = findMdatPayloadStart(headBytes, blob.size);

  return {
    tracks,
    videoTimescale: tracks.videoTimescale,
    audioTimescale: tracks.audioTimescale,
    videoSamples: toRows(tracks.videoId, tracks.videoTimescale),
    audioSamples: tracks.audioId > 0 ? toRows(tracks.audioId, tracks.audioTimescale) : [],
    moovFoundEarly: true,
    headerBytes: mdatDataStart > 0 ? headBytes.slice(0, mdatDataStart) : null,
    mdatDataStart,
  };
}

function concatU8(parts: Uint8Array[]): Uint8Array {
  let n = 0;
  for (const p of parts) n += p.length;
  const out = new Uint8Array(n);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

/**
 * Offset of the mdat payload, found by walking the top-level boxes.
 * Returns 0 when the layout is not the simple ftyp+moov+mdat we can splice.
 */
function findMdatPayloadStart(head: Uint8Array, fileSize: number): number {
  let p = 0;
  const limit = Math.min(head.length, fileSize);
  while (p + 8 <= limit) {
    const size = (head[p] << 24) | (head[p + 1] << 16) | (head[p + 2] << 8) | head[p + 3];
    const type = String.fromCharCode(head[p + 4], head[p + 5], head[p + 6], head[p + 7]);
    if (size === 1) {
      // 64-bit size: too exotic to splice safely
      return 0;
    }
    if (size < 8) return 0;
    if (type === 'mdat') return p + 8;
    if (type === 'free' || type === 'skip' || type === 'wide') {
      p += size;
      continue;
    }
    if (p + size > limit) {
      // box continues past what we read; only acceptable for mdat
      return 0;
    }
    p += size;
  }
  return 0;
}

/** Byte offset of the key frame at or before `seconds` (0 when unknown). */
export function byteOffsetForTime(samples: SampleRow[], seconds: number): number {
  let idx = samples.findIndex((s) => s.seconds >= seconds);
  if (idx < 0) idx = samples.length - 1;
  if (idx < 0) return 0;
  let key = idx;
  while (key > 0 && !samples[key].is_sync) key--;
  const off = samples[key].offset;
  return off > 0 ? Math.max(0, off - 8) : 0;
}

/** Byte offset just past the last sample at or before `seconds`. */
export function byteEndForTime(samples: SampleRow[], seconds: number, fileSize: number): number {
  let idx = samples.findIndex((s) => s.seconds > seconds);
  if (idx < 0) idx = samples.length;
  if (idx <= 0) return fileSize;
  const prev = samples[idx - 1];
  const end = prev.offset + prev.size;
  return end > 0 ? Math.min(fileSize, end + 65536) : fileSize;
}

export function looksLikeMp4(head: Uint8Array): boolean {
  if (head.length < 12) return false;
  const s = String.fromCharCode(head[4], head[5], head[6], head[7]);
  return s === 'ftyp' || s === 'moov' || s === 'mdat';
}

export async function canDemux(blob: Blob): Promise<boolean> {
  try {
    const head = new Uint8Array(await blob.slice(0, 32).arrayBuffer());
    return looksLikeMp4(head);
  } catch {
    return false;
  }
}

/* ================================================================== */
/* Writer                                                             */
/* ================================================================== */

/**
 * Writes a plain (progressive) MP4.
 *
 * mp4box needs three things done by hand or the file is not valid:
 *   1. its init() adds "mvex", which marks the movie FRAGMENTED — ffmpeg then
 *      looks for moof/mdat and reports a broken file. We remove it.
 *   2. mvhd/tkhd/mdhd durations are not maintained by addSample, so players
 *      report a zero-length file. We set them from what we actually wrote.
 *   3. an audio track needs hdlr "soun" plus the source's esds box object.
 *
 * Video samples from the encoder are Annex-B (start codes) and must be
 * converted to length-prefixed NAL units before they go into an MP4.
 */
export class Mp4Writer {
  private file: ISOFile;
  videoTrackId = -1;
  audioTrackId = -1;
  private videoTimescale: number;
  private audioTimescale: number;
  private movieTimescale = 600;
  videoFrames = 0;
  audioFrames = 0;
  private lastVideoCts = 0;
  private lastAudioCts = 0;

  constructor(opts: {
    width: number;
    height: number;
    fps: number;
    /**
     * Raw AVCDecoderConfigurationRecord bytes.
     * mp4box runs `new MP4BoxStream(value)` on this, and MP4BoxStream throws
     * "Needs an array buffer" unless it gets a real ArrayBuffer — a Uint8Array
     * is NOT accepted, so we convert it here.
     */
    avcCBytes?: Uint8Array | ArrayBuffer | null;
    audioSampleRate: number;
    audioChannels: number;
    /** The parsed esds box object taken from the source track. */
    esds?: unknown;
  }) {
    this.file = MP4Box.createFile();
    this.videoTimescale = Math.max(1000, Math.round(opts.fps * 1000));
    this.audioTimescale = opts.audioSampleRate || 48000;

    (this.file as unknown as { init?: (o: unknown) => void }).init?.({
      timescale: this.movieTimescale,
      brands: ['isom', 'iso2', 'avc1', 'mp41'],
    });

    // CRITICAL, and it has to happen HERE rather than at the end.
    // init() creates "mvex", and mp4box's addSample() checks for it: when it is
    // present every sample is written as a moof/mdat FRAGMENT and the sample
    // tables (stts/stsc/stco/stsz) stay empty. Deleting mvex only at finalize()
    // leaves a file that is neither a valid fragmented MP4 (no mvex, and the
    // trafs do not line up) nor a progressive one (empty tables) — ffmpeg
    // reports "could not find corresponding trex" and refuses to read it.
    // Removing it up front makes addSample() fill the sample tables instead,
    // which is the plain, universally playable MP4 we want.
    this.dropMvex();

    this.videoTrackId = this.file.addTrack({
      timescale: this.videoTimescale,
      media_duration: 0,
      width: opts.width,
      height: opts.height,
      avcDecoderConfigRecord: toArrayBuffer(opts.avcCBytes),
      avc_inband: !opts.avcCBytes,
      type: 'avc1',
      hdlr: 'vide',
      name: 'ClipForge video',
      default_sample_description_index: 1,
    } as never);

    if (opts.audioSampleRate > 0) {
      this.audioTrackId = this.file.addTrack({
        timescale: this.audioTimescale,
        media_duration: 0,
        samplerate: opts.audioSampleRate,
        channel_count: opts.audioChannels,
        samplesize: 16,
        hdlr: 'soun',
        name: 'ClipForge audio',
        type: 'mp4a',
        // mp4box's addTrack does `sample_description_entry.addBox(options.description)`,
        // so this must be the parsed box object, not bytes.
        description: opts.esds,
        default_sample_description_index: 1,
      } as never);
    }
  }

  private dropMvex() {
    const moov = this.file.moov as unknown as {
      mvex?: unknown;
      boxes?: Array<{ type?: string }>;
    } | undefined;
    if (!moov) return;
    delete moov.mvex;
    if (Array.isArray(moov.boxes)) moov.boxes = moov.boxes.filter((b) => b.type !== 'mvex');
  }

  get videoSeconds(): number {
    return this.videoTimescale ? this.lastVideoCts / this.videoTimescale : 0;
  }

  get audioSeconds(): number {
    return this.audioTimescale ? this.lastAudioCts / this.audioTimescale : 0;
  }

  /**
   * Add one encoded video frame.
   * `annexB` = true when the data uses start codes (Chrome's avc encoder with
   * format 'avc' still emits them on some builds), false when already
   * length-prefixed.
   */
  addVideoFrame(data: Uint8Array, opts: { timestampUs: number; durationUs: number; key: boolean; annexB?: boolean }) {
    const payload = opts.annexB === false ? data : annexBToLengthPrefixed(data);
    const cts = Math.round((opts.timestampUs / 1e6) * this.videoTimescale);
    const dur = Math.max(1, Math.round((opts.durationUs / 1e6) * this.videoTimescale));
    this.file.addSample(this.videoTrackId, payload, {
      dts: cts,
      cts,
      duration: dur,
      is_sync: opts.key,
    } as never);
    this.videoFrames++;
    this.lastVideoCts = cts + dur;
  }

  /** Add one raw AAC access unit (audio copied from the source, no re-encode). */
  addAudioFrame(data: Uint8Array, cts: number, duration: number) {
    if (this.audioTrackId < 0) return;
    this.file.addSample(this.audioTrackId, data, {
      dts: cts,
      cts,
      duration,
      is_sync: true,
    } as never);
    this.audioFrames++;
    this.lastAudioCts = cts + duration;
  }

  finalize(): Blob {
    const moov = this.file.moov as unknown as {
      mvhd?: { duration?: number; timescale?: number };
      mvex?: unknown;
      boxes?: Array<{ type?: string }>;
      traks?: Array<{
        tkhd?: { duration?: number };
        mdia?: { mdhd?: { duration?: number; timescale?: number } };
      }>;
    };
    if (moov) {
      this.dropMvex();
      const vSec = this.videoSeconds;
      const aSec = this.audioSeconds;
      const longest = Math.max(vSec, aSec);
      const mvTs = moov.mvhd?.timescale || this.movieTimescale;
      if (moov.mvhd) moov.mvhd.duration = Math.round(longest * mvTs);
      for (const trak of moov.traks ?? []) {
        const ts = trak.mdia?.mdhd?.timescale || mvTs;
        const sec = Math.abs(ts - this.audioTimescale) < 1 && this.audioFrames > 0 ? aSec : vSec;
        if (trak.mdia?.mdhd) trak.mdia.mdhd.duration = Math.round(sec * ts);
        if (trak.tkhd) trak.tkhd.duration = Math.round(longest * mvTs);
      }
    }
    const buf = this.file.getBuffer();
    return new Blob([buf], { type: 'video/mp4' });
  }
}

/** True when the bytes start with an Annex-B start code. */
export function isAnnexB(data: Uint8Array): boolean {
  return (
    data.length > 4 &&
    data[0] === 0 &&
    data[1] === 0 &&
    (data[2] === 1 || (data[2] === 0 && data[3] === 1))
  );
}

/**
 * Annex-B (start codes) -> length-prefixed NAL units, which is what an MP4
 * sample must contain. 4-byte lengths, matching the source's avcC NALU length
 * size of 4.
 */
export function annexBToLengthPrefixed(data: Uint8Array): Uint8Array {
  if (!isAnnexB(data)) return data;
  const nalStarts: number[] = [];
  let i = 0;
  while (i < data.length) {
    if (data[i] === 0 && data[i + 1] === 0) {
      if (data[i + 2] === 1) {
        nalStarts.push(i + 3);
        i += 3;
        continue;
      }
      if (data[i + 2] === 0 && data[i + 3] === 1) {
        nalStarts.push(i + 4);
        i += 4;
        continue;
      }
    }
    i++;
  }
  if (!nalStarts.length) return data;

  // Trim trailing zero padding that belongs to no NAL unit.
  const ends: number[] = [];
  for (let k = 0; k < nalStarts.length; k++) {
    const next = k + 1 < nalStarts.length ? nalStarts[k + 1] : data.length;
    // walk back over the start code of the next NAL
    let e = next;
    if (k + 1 < nalStarts.length) {
      const s = nalStarts[k + 1];
      e = data[s - 1] === 1 ? (data[s - 4] === 0 ? s - 4 : s - 3) : s - 3;
    }
    ends.push(Math.max(nalStarts[k], e));
  }

  let total = 0;
  for (let k = 0; k < nalStarts.length; k++) total += 4 + (ends[k] - nalStarts[k]);
  const out = new Uint8Array(total);
  const view = new DataView(out.buffer);
  let o = 0;
  for (let k = 0; k < nalStarts.length; k++) {
    const len = ends[k] - nalStarts[k];
    if (len <= 0) continue;
    view.setUint32(o, len, false);
    o += 4;
    out.set(data.subarray(nalStarts[k], nalStarts[k] + len), o);
    o += len;
  }
  return out.subarray(0, o);
}

/** Pull the raw AAC units for a time range out of an already-read audio queue. */
export interface CopiedAudio {
  samples: Array<{ data: Uint8Array; cts: number; duration: number }>;
}

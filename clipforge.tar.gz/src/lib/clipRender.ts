import type { AudioAnalysis, ChatMsg, Clip, ClipRenderOptions, Transcript, VisualAnalysis, Word } from './types';
import { chunkWords, drawCaptions, getStyle } from './captions';
import { FILLERS, PROFANITY, isKeyword, norm } from './nlp';
import { buildTrack, trackAt, type TrackPoint } from './visual';
import { speakerIndexer, wordsInRange } from './engine';
import { renderMusic, renderSfx, MUSIC } from './synth';
import { clamp, easing, roundRect, waitEvent, wrapText } from './util';
import { pickMime } from './recorder';

export const GRADES: Record<string, { name: string; filter: string; overlay?: string }> = {
  none: { name: 'None', filter: 'none' },
  cinematic: { name: 'Cinematic', filter: 'contrast(1.12) saturate(0.9) brightness(0.96)', overlay: 'rgba(0,60,80,0.10)' },
  warm: { name: 'Warm', filter: 'saturate(1.15) sepia(0.18) brightness(1.03)' },
  cool: { name: 'Cool', filter: 'saturate(1.05) hue-rotate(-12deg) brightness(1.02)', overlay: 'rgba(0,80,160,0.08)' },
  vintage: { name: 'Vintage', filter: 'sepia(0.45) contrast(0.9) saturate(0.85) brightness(1.05)' },
  highcon: { name: 'High Contrast', filter: 'contrast(1.35) saturate(1.2)' },
  noir: { name: 'Noir', filter: 'grayscale(1) contrast(1.3) brightness(0.95)' },
  vivid: { name: 'Vivid Pop', filter: 'saturate(1.55) contrast(1.08)' },
  teal: { name: 'Teal & Orange', filter: 'contrast(1.1) saturate(1.25) hue-rotate(-8deg)', overlay: 'rgba(0,128,128,0.07)' },
  faded: { name: 'Faded Film', filter: 'contrast(0.82) brightness(1.1) saturate(0.8)' },
  moody: { name: 'Moody', filter: 'brightness(0.85) contrast(1.2) saturate(0.75)' },
  cyber: { name: 'Cyberpunk', filter: 'saturate(1.6) hue-rotate(35deg) contrast(1.1)', overlay: 'rgba(255,0,200,0.07)' },
};

export function aspectSize(aspect: string, res: number): [number, number] {
  switch (aspect) {
    case '16:9': return [Math.round((res * 16) / 9 / 2) * 2, res];
    case '1:1': return [res, res];
    case '4:5': return [res, Math.round((res * 5) / 4 / 2) * 2];
    default: return [res, Math.round((res * 16) / 9 / 2) * 2];
  }
}

export type Piece = { s: number; e: number; teaser?: boolean };

export function buildEdl(clip: Clip, o: ClipRenderOptions, tr: Transcript | null, audio: AudioAnalysis | null): Piece[] {
  const cuts: [number, number][] = [];
  const words = wordsInRange(tr, clip.start, clip.end);
  if (o.removeFillers) for (const w of words) if (FILLERS.includes(norm(w.w))) cuts.push([w.s - 0.03, w.e + 0.03]);
  if (o.removeSilence) {
    if (audio) for (const s of audio.silences) if (s.end > clip.start && s.start < clip.end && s.end - s.start > 0.5) cuts.push([Math.max(clip.start, s.start) + 0.15, Math.min(clip.end, s.end) - 0.15]);
    for (let i = 1; i < words.length; i++) { const g = words[i].s - words[i - 1].e; if (g > 0.8) cuts.push([words[i - 1].e + 0.2, words[i].s - 0.2]); }
  }
  cuts.sort((a, b) => a[0] - b[0]);
  const merged: [number, number][] = [];
  for (const c of cuts) { if (c[1] <= c[0]) continue; const l = merged[merged.length - 1]; if (l && c[0] <= l[1]) l[1] = Math.max(l[1], c[1]); else merged.push([...c]); }
  const pieces: Piece[] = [];
  let t = clip.start;
  for (const [a, b] of merged) { if (a - t > 0.12) pieces.push({ s: t, e: a }); t = Math.max(t, b); }
  if (clip.end - t > 0.12) pieces.push({ s: t, e: clip.end });
  if (!pieces.length) pieces.push({ s: clip.start, e: clip.end });
  if (o.teaser && clip.hookLine) pieces.unshift({ s: clip.hookLine.start, e: Math.min(clip.hookLine.end + 0.1, clip.hookLine.start + 4), teaser: true });
  return pieces;
}

type Ev = { t: number; kind: 'zoom' | 'shake' | 'flash' | 'sfx'; sfx?: string; v: number };

export type EngineCtx = {
  url: string;
  /** original file — enables fast (faster-than-real-time) export */
  file?: Blob;
  clip: Clip;
  options: ClipRenderOptions;
  transcript: Transcript | null;
  audio: AudioAnalysis | null;
  visual: VisualAnalysis | null;
  chatLog?: ChatMsg[];
  logo?: string;
  brandColor?: string;
};

export class ClipEngine {
  video: HTMLVideoElement;
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  ac: AudioContext | null = null;
  master?: GainNode; orig?: GainNode; bleep?: GainNode; musicGain?: GainNode; dest?: MediaStreamAudioDestinationNode;
  musicSrc: AudioBufferSourceNode | null = null;
  c: EngineCtx;
  pieces: Piece[] = [];
  offsets: number[] = [];
  total = 0;
  pi = 0;
  playing = false;
  raf = 0;
  track: TrackPoint[] = [];
  splitFaces: [number, number] = [0.3, 0.7];
  words: (Word & { speaker?: string })[] = [];
  events: Ev[] = [];
  lastSrc = -1;
  onTime?: (out: number, total: number) => void;
  onEnd?: () => void;
  logoImg: HTMLImageElement | null = null;
  ready: Promise<void>;
  destroyed = false;
  blurCanvas = document.createElement('canvas');

  constructor(c: EngineCtx, canvas?: HTMLCanvasElement) {
    this.c = c;
    this.video = document.createElement('video');
    this.video.src = c.url;
    this.video.playsInline = true;
    this.video.preload = 'auto';
    this.video.crossOrigin = 'anonymous';
    this.canvas = canvas || document.createElement('canvas');
    this.ctx = this.canvas.getContext('2d')!;
    this.configure(c.options, c.clip);
    this.ready = waitEvent(this.video, 'loadeddata', 20000).then(() => this.seekOut(0)).catch(() => {});
    if (c.logo) { this.logoImg = new Image(); this.logoImg.src = c.logo; }
  }

  configure(o: ClipRenderOptions, clip: Clip) {
    this.c = { ...this.c, options: o, clip };
    const [W, H] = aspectSize(o.aspect, 720);
    if (this.canvas.width !== W || this.canvas.height !== H) { this.canvas.width = W; this.canvas.height = H; }
    this.pieces = buildEdl(clip, o, this.c.transcript, this.c.audio);
    this.offsets = [];
    let acc = 0;
    for (const p of this.pieces) { this.offsets.push(acc); acc += p.e - p.s; }
    this.total = acc;
    this.track = buildTrack(this.c.visual, clip.start - 1, clip.end + 1, speakerIndexer(this.c.transcript), o.speakerFocus);
    this.words = wordsInRange(this.c.transcript, clip.start - 5, clip.end + 5).filter((w) => !(o.removeFillers && FILLERS.includes(norm(w.w))));
    // split-screen faces: average left/right face positions when 2+ faces seen
    const va = this.c.visual;
    if (va) {
      const L: number[] = [], R: number[] = [];
      va.times.forEach((t, i) => { const f = va.faces[i]; if (t >= clip.start - 3 && t <= clip.end + 3 && f && f.length >= 2) { const s = [...f].sort((a, b) => a.x - b.x); L.push(s[0].x + s[0].w / 2); R.push(s[s.length - 1].x + s[s.length - 1].w / 2); } });
      if (L.length) this.splitFaces = [L.reduce((a, b) => a + b) / L.length, R.reduce((a, b) => a + b) / R.length];
    }
    // effect events
    const ev: Ev[] = [];
    if (o.zoomPulses) {
      const kws = this.words.filter((w) => w.s >= clip.start && w.s <= clip.end && isKeyword(w.w) && w.e - w.s > 0.18);
      let last = -9;
      for (const w of kws) if (w.s - last > 2.2) { ev.push({ t: w.s, kind: 'zoom', v: 0.06 }); last = w.s; }
    }
    if (this.c.audio) for (const sp of this.c.audio.spikes) {
      if (sp.t < clip.start || sp.t > clip.end) continue;
      if (o.zoomPulses) ev.push({ t: sp.t, kind: 'zoom', v: 0.1 * sp.strength + 0.04 });
      if (o.shake && sp.strength > 0.4) ev.push({ t: sp.t, kind: 'shake', v: sp.strength });
      if (o.flash && sp.strength > 0.55) ev.push({ t: sp.t, kind: 'flash', v: 0.45 });
      if (o.sfx && sp.strength > 0.5) ev.push({ t: sp.t - 0.05, kind: 'sfx', sfx: sp.kind === 'crowd' ? 'boom' : 'pop', v: 0.5 });
    }
    if (o.sfx) ev.push({ t: this.pieces[o.teaser && clip.hookLine ? 1 : 0]?.s ?? clip.start, kind: 'sfx', sfx: 'whoosh', v: 0.5 });
    this.events = ev.sort((a, b) => a.t - b.t);
    if (o.sfx) { renderSfx('whoosh'); renderSfx('boom'); renderSfx('pop'); }
    if (o.music) renderMusic(o.music);
    if (this.musicGain) this.musicGain.gain.value = o.music ? o.musicVolume : 0;
    this.video.playbackRate = o.speed;
    if (!this.playing) this.draw();
  }

  ensureAudio() {
    if (this.ac) return;
    const ac = new AudioContext();
    this.ac = ac;
    const src = ac.createMediaElementSource(this.video);
    this.orig = ac.createGain();
    this.master = ac.createGain();
    this.bleep = ac.createGain(); this.bleep.gain.value = 0;
    const osc = ac.createOscillator(); osc.frequency.value = 1000; osc.connect(this.bleep); osc.start();
    this.musicGain = ac.createGain(); this.musicGain.gain.value = this.c.options.music ? this.c.options.musicVolume : 0;
    src.connect(this.orig).connect(this.master);
    this.bleep.connect(this.master);
    this.musicGain.connect(this.master);
    this.master.connect(ac.destination);
    this.dest = ac.createMediaStreamDestination();
    this.master.connect(this.dest);
  }

  srcToOut(src: number) {
    const p = this.pieces[this.pi];
    if (!p) return 0;
    return this.offsets[this.pi] + clamp(src - p.s, 0, p.e - p.s);
  }

  async seekOut(out: number) {
    out = clamp(out, 0, this.total - 0.01);
    let i = this.offsets.findIndex((o, k) => out >= o && out < o + (this.pieces[k].e - this.pieces[k].s));
    if (i < 0) i = this.pieces.length - 1;
    this.pi = i;
    const t = this.pieces[i].s + (out - this.offsets[i]);
    this.lastSrc = t;
    if (this.playing) this.startMusic(out);
    await new Promise<void>((res) => {
      const h = () => { this.video.removeEventListener('seeked', h); res(); };
      this.video.addEventListener('seeked', h);
      this.video.currentTime = t;
      setTimeout(res, 1500);
    });
    this.draw();
  }

  async startMusic(out: number) {
    if (!this.ac || !this.musicGain) return;
    this.stopMusic();
    if (!this.c.options.music) return;
    const ab = await renderMusic(this.c.options.music);
    if (!this.playing) return;
    const s = this.ac.createBufferSource(); s.buffer = ab; s.loop = true; s.connect(this.musicGain);
    s.start(0, out % ab.duration);
    this.musicSrc = s;
  }
  stopMusic() { try { this.musicSrc?.stop(); } catch { /* */ } this.musicSrc = null; }

  async play(silent = false) {
    if (silent) this.video.muted = true;
    else { this.ensureAudio(); await this.ac!.resume(); }
    const out = this.srcToOut(this.video.currentTime);
    if (out >= this.total - 0.05) await this.seekOut(0);
    this.playing = true;
    this.startMusic(this.srcToOut(this.video.currentTime));
    try { await this.video.play(); } catch (e) { console.warn(e); }
    this.loop();
  }

  pause() {
    this.playing = false;
    this.video.pause();
    this.stopMusic();
    cancelAnimationFrame(this.raf);
    this.draw();
  }

  loop = () => {
    if (!this.playing || this.destroyed) return;
    const v = this.video;
    const p = this.pieces[this.pi];
    if (p && v.currentTime >= p.e - 0.02) {
      if (this.pi < this.pieces.length - 1) {
        this.pi++;
        v.currentTime = this.pieces[this.pi].s;
      } else {
        this.pause();
        this.onTime?.(this.total, this.total);
        this.onEnd?.();
        return;
      }
    }
    this.tickAudio(v.currentTime);
    this.draw();
    this.raf = requestAnimationFrame(this.loop);
  };

  tickAudio(src: number) {
    if (!this.ac || !this.orig || !this.bleep || !this.musicGain) return;
    const o = this.c.options;
    const now = this.ac.currentTime;
    // bleep profanity
    let prof = false;
    if (o.censor) for (const w of this.words) if (src >= w.s && src <= w.e && PROFANITY.includes(norm(w.w))) { prof = true; break; }
    this.orig.gain.setTargetAtTime(prof ? 0 : 1, now, 0.005);
    this.bleep.gain.setTargetAtTime(prof ? 0.25 : 0, now, 0.005);
    // ducking
    if (o.music) {
      let speaking = false;
      const a = this.c.audio;
      if (a) { const i = Math.floor(src / a.hop); speaking = !!(a.speech[i] || a.speech[i + 3] || a.speech[i - 3]); }
      else speaking = this.words.some((w) => src >= w.s - 0.2 && src <= w.e + 0.2);
      const target = o.ducking && speaking ? o.musicVolume * 0.28 : o.musicVolume;
      this.musicGain.gain.setTargetAtTime(target, now, 0.12);
    }
    // sfx triggers
    if (o.sfx && this.lastSrc >= 0 && src > this.lastSrc && src - this.lastSrc < 0.5) {
      for (const e of this.events) if (e.kind === 'sfx' && e.t > this.lastSrc && e.t <= src) this.fireSfx(e.sfx!, e.v);
    }
    this.lastSrc = src;
  }

  async fireSfx(id: string, v: number) {
    if (!this.ac || !this.master) return;
    const ab = await renderSfx(id);
    const s = this.ac.createBufferSource(); s.buffer = ab;
    const g = this.ac.createGain(); g.gain.value = v;
    s.connect(g).connect(this.master); s.start();
  }

  /** Draw one output frame. `frame` lets the fast exporter pass a decoded frame instead of the <video> element. */
  draw(frame?: { img: CanvasImageSource; w: number; h: number; t: number }) {
    const { ctx, canvas, video: v } = this;
    const W = canvas.width, H = canvas.height;
    const o = this.c.options;
    const clip = this.c.clip;
    const src = frame ? frame.t : v.currentTime;
    const img: CanvasImageSource = frame ? frame.img : v;
    const out = this.srcToOut(src);
    const piece = this.pieces[this.pi];
    const inTeaser = !!piece?.teaser;
    ctx.save();
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    const vw = (frame ? frame.w : v.videoWidth) || 16, vh = (frame ? frame.h : v.videoHeight) || 9;
    // effects
    let zoom = 1, shx = 0, shy = 0, flash = 0;
    for (const e of this.events) {
      const dt = src - e.t;
      if (dt < 0 || dt > 0.8) continue;
      if (e.kind === 'zoom') zoom += e.v * Math.exp(-dt / 0.22) * easing('out', dt / 0.06);
      if (e.kind === 'shake') { const k = Math.exp(-dt / 0.15) * e.v * 14; shx += (Math.random() - 0.5) * k; shy += (Math.random() - 0.5) * k; }
      if (e.kind === 'flash') flash = Math.max(flash, e.v * Math.exp(-dt / 0.12));
    }
    if (o.beatZoom && o.music) {
      const def = MUSIC.find((m) => m.id === o.music);
      if (def) { const b = 60 / def.bpm; const ph = (out % b) / b; zoom += 0.025 * Math.exp(-ph * 6); }
    }
    if (inTeaser) zoom += 0.08;
    // main piece start after teaser → flash
    if (o.teaser && this.pieces[0]?.teaser && this.pi === 1) { const dt = src - this.pieces[1].s; if (dt < 0.3) flash = Math.max(flash, 0.7 * (1 - dt / 0.3)); }
    const g = GRADES[o.grade] || GRADES.none;
    const drawCover = (cx: number, cy: number, dx: number, dy: number, dw: number, dh: number, z: number) => {
      const sc = Math.max(dw / vw, dh / vh) * z;
      const sw = dw / sc, sh = dh / sc;
      const sx = clamp(cx * vw - sw / 2, 0, vw - sw), sy = clamp(cy * vh - sh / 2, 0, vh - sh);
      ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
    };
    ctx.filter = g.filter;
    ctx.translate(shx, shy);
    if (frame || v.readyState >= 2) {
      const tp = trackAt(this.track, src);
      if (o.reframe === 'track' || o.reframe === 'center') {
        const cx = o.reframe === 'track' ? tp.cx : 0.5;
        drawCover(cx, o.reframe === 'track' ? clamp(tp.cy + 0.05, 0.3, 0.7) : 0.5, 0, 0, W, H, zoom);
      } else if (o.reframe === 'split') {
        drawCover(this.splitFaces[0], 0.45, 0, 0, W, H / 2, 1.05 * zoom);
        drawCover(this.splitFaces[1], 0.45, 0, H / 2, W, H / 2, 1.05 * zoom);
        ctx.filter = 'none'; ctx.fillStyle = '#000'; ctx.fillRect(0, H / 2 - 2, W, 4); ctx.filter = g.filter;
      } else {
        const sc = Math.min(W / vw, H / vh) * zoom;
        const dw = vw * sc, dh = vh * sc;
        if (o.reframe === 'blur') {
          const bc = this.blurCanvas; bc.width = 90; bc.height = 160;
          const bx = bc.getContext('2d')!;
          bx.filter = 'none';
          const s2 = Math.max(90 / vw, 160 / vh); bx.drawImage(img, (90 - vw * s2) / 2, (160 - vh * s2) / 2, vw * s2, vh * s2);
          ctx.save(); ctx.filter = 'blur(18px) brightness(0.6) saturate(1.2)'; ctx.drawImage(bc, -40, -40, W + 80, H + 80); ctx.restore();
          ctx.filter = g.filter;
        }
        ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
      }
    }
    ctx.filter = 'none';
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (g.overlay) { ctx.fillStyle = g.overlay; ctx.fillRect(0, 0, W, H); }
    if (inTeaser) {
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      for (let y = 0; y < H; y += 6) ctx.fillRect(0, y, W, 2);
    }
    // captions
    const st = getStyle(o.captionStyle);
    if (o.captions && this.words.length) {
      drawCaptions(ctx, W, H, this.words, src, st, { pos: o.captionPos, scale: o.captionScale, emojis: o.emojis, keywords: o.keywordEmphasis, censor: o.censor });
    }
    const S = Math.min(W, H);
    // hook overlay (first 3s of output)
    const hookTxt = o.hookText || clip.hooks[0];
    if (o.hookOverlay && hookTxt && out < 3.2) {
      const a = easing('back', out / 0.3);
      const fade = out > 2.8 ? 1 - (out - 2.8) / 0.4 : 1;
      ctx.save();
      ctx.globalAlpha = clamp(fade, 0, 1);
      ctx.font = `800 ${S * 0.055}px Montserrat, sans-serif`;
      const lines = wrapText(ctx, hookTxt, W * 0.78);
      const lh = S * 0.07;
      const bw = Math.max(...lines.map((l) => ctx.measureText(l).width)) + S * 0.08;
      const bh = lines.length * lh + S * 0.04;
      const y = H * (H > W ? 0.13 : 0.08);
      ctx.translate(W / 2, y + bh / 2); ctx.scale(a, a); ctx.rotate(-0.02); ctx.translate(-W / 2, -(y + bh / 2));
      ctx.fillStyle = '#fff'; ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = 20;
      roundRect(ctx, W / 2 - bw / 2, y, bw, bh, S * 0.025); ctx.fill();
      ctx.shadowBlur = 0; ctx.fillStyle = '#111'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      lines.forEach((l, i) => ctx.fillText(l, W / 2, y + S * 0.02 + lh * (i + 0.5)));
      ctx.restore();
    }
    if (o.teaser && this.pieces[0]?.teaser && this.pi === 1) {
      const dt = src - this.pieces[1].s;
      if (dt < 0.9) {
        ctx.save(); ctx.globalAlpha = 1 - dt / 0.9; ctx.font = `900 ${S * 0.07}px Montserrat`; ctx.fillStyle = '#fff'; ctx.textAlign = 'center';
        ctx.strokeStyle = '#000'; ctx.lineWidth = 8; ctx.strokeText('⏪ REWIND', W / 2, H * 0.5); ctx.fillText('⏪ REWIND', W / 2, H * 0.5); ctx.restore();
      }
    }
    // chat overlay
    if (o.chatOverlay && this.c.chatLog?.length) {
      const msgs = this.c.chatLog.filter((m) => m.t <= src && m.t > src - 6).slice(-5);
      ctx.save();
      ctx.font = `600 ${S * 0.03}px Inter, sans-serif`;
      let y = H * 0.36;
      for (const m of msgs) {
        const txt = `${m.user}: ${m.text}`.slice(0, 40);
        const w = ctx.measureText(txt).width + S * 0.04;
        ctx.globalAlpha = clamp(1 - (src - m.t) / 6, 0.2, 0.95);
        ctx.fillStyle = 'rgba(15,15,25,.72)'; roundRect(ctx, S * 0.03, y, w, S * 0.05, S * 0.015); ctx.fill();
        ctx.fillStyle = '#b9a8ff'; ctx.fillText(m.user + ':', S * 0.05, y + S * 0.034);
        const uw = ctx.measureText(m.user + ': ').width;
        ctx.fillStyle = '#fff'; ctx.fillText(txt.slice(m.user.length + 2), S * 0.05 + uw, y + S * 0.034);
        y += S * 0.06;
      }
      ctx.restore();
    }
    // comment bait
    if (o.commentBait && out > this.total * 0.55 && out < this.total * 0.55 + 3) {
      const k = out - this.total * 0.55;
      ctx.save(); ctx.globalAlpha = clamp(Math.min(k / 0.2, (3 - k) / 0.3), 0, 1);
      ctx.font = `800 ${S * 0.045}px Montserrat`; const txt = 'Comment your answer below 👇';
      const w = ctx.measureText(txt).width + S * 0.06;
      ctx.fillStyle = this.c.brandColor || '#7c5cff'; roundRect(ctx, (W - w) / 2, H * 0.44, w, S * 0.08, S * 0.04); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(txt, W / 2, H * 0.44 + S * 0.04); ctx.restore();
    }
    // watermark / handle
    if (o.watermark && (o.handle || this.logoImg)) {
      ctx.save(); ctx.globalAlpha = 0.75;
      let x = W - S * 0.04;
      const y = H > W ? H * 0.05 : H * 0.07;
      ctx.font = `700 ${S * 0.032}px Montserrat, sans-serif`; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#fff'; ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 6;
      if (o.handle) { ctx.fillText(o.handle, x, y); x -= ctx.measureText(o.handle).width + S * 0.015; }
      if (this.logoImg?.complete && this.logoImg.naturalWidth) { const ls = S * 0.06; ctx.drawImage(this.logoImg, x - ls, y - ls / 2, ls, ls * (this.logoImg.naturalHeight / this.logoImg.naturalWidth)); }
      ctx.restore();
    }
    // end card
    if (o.endCard && out > this.total - 2) {
      const k = clamp((out - (this.total - 2)) / 0.3, 0, 1);
      ctx.save(); ctx.fillStyle = `rgba(10,8,20,${0.75 * k})`; ctx.fillRect(0, 0, W, H);
      ctx.globalAlpha = k; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = `900 ${S * 0.075}px Montserrat`; ctx.fillStyle = '#fff'; ctx.fillText('FOLLOW', W / 2, H * 0.45);
      ctx.font = `800 ${S * 0.055}px Montserrat`; ctx.fillStyle = this.c.brandColor || '#7c5cff'; if (o.handle) ctx.fillText(o.handle, W / 2, H * 0.52);
      ctx.font = `600 ${S * 0.035}px Inter`; ctx.fillStyle = '#ddd'; ctx.fillText('for more like this', W / 2, H * 0.57); ctx.restore();
    }
    if (o.progressBar) {
      ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(0, H - 8, W, 8);
      ctx.fillStyle = this.c.brandColor || '#7c5cff'; ctx.fillRect(0, H - 8, (W * out) / (this.total || 1), 8);
    }
    if (flash > 0.01) { ctx.fillStyle = `rgba(255,255,255,${flash})`; ctx.fillRect(0, 0, W, H); }
    ctx.restore();
    if (!frame) this.onTime?.(out, this.total);
  }

  /** Real-time render to a video file with MediaRecorder */
  async export(res: number, onProgress?: (p: number) => void): Promise<Blob> {
    const [W, H] = aspectSize(this.c.options.aspect, res);
    this.canvas.width = W; this.canvas.height = H;
    this.ensureAudio();
    await this.ac!.resume();
    await this.ready;
    await this.seekOut(0);
    const stream = this.canvas.captureStream(30);
    this.dest!.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
    const mime = pickMime();
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: res >= 1080 ? 8_000_000 : 5_000_000, audioBitsPerSecond: 160_000 });
    const chunks: Blob[] = [];
    rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    const done = new Promise<Blob>((resolve) => { rec.onstop = () => resolve(new Blob(chunks, { type: mime.split(';')[0] })); });
    const prevTime = this.onTime;
    this.onTime = (o, t) => { prevTime?.(o, t); onProgress?.(o / t); };
    // Export silently: audio goes only into the recording, not the speakers. This also keeps phones from showing a
    // media notification — pausing from there (or headphones) used to freeze the export.
    try { this.master!.disconnect(this.ac!.destination); } catch { /* already */ }
    const keepGoing = () => { if (this.playing && !this.destroyed) this.video.play().catch(() => {}); };
    this.video.addEventListener('pause', keepGoing);
    const ms = 'mediaSession' in navigator ? navigator.mediaSession : null;
    for (const a of ['pause', 'stop'] as MediaSessionAction[]) try { ms?.setActionHandler(a, () => {}); } catch { /* unsupported */ }
    let blob: Blob;
    try {
      rec.start(250);
      const ended = new Promise<void>((r) => (this.onEnd = r));
      await this.play();
      await ended;
      await new Promise((r) => setTimeout(r, 150));
      rec.stop();
      blob = await done;
    } finally {
      this.video.removeEventListener('pause', keepGoing);
      for (const a of ['pause', 'stop'] as MediaSessionAction[]) try { ms?.setActionHandler(a, null); } catch { /* unsupported */ }
      try { if (!this.destroyed) this.master!.connect(this.ac!.destination); } catch { /* closed */ }
      this.onTime = prevTime;
      this.onEnd = undefined;
    }
    const [pw, ph] = aspectSize(this.c.options.aspect, 720);
    this.canvas.width = pw; this.canvas.height = ph;
    return blob;
  }

  destroy() {
    this.destroyed = true;
    this.pause();
    this.video.removeAttribute('src'); this.video.load();
    this.ac?.close().catch(() => {});
  }
}

/** Session options merged with the clip's own layout. */
export function optsFor(o: ClipRenderOptions, clip: Clip): ClipRenderOptions {
  return { ...o, aspect: clip.aspect ?? o.aspect, reframe: clip.reframe ?? o.reframe };
}

/** Share of sampled frames in the clip that show a person big enough to be "on camera". */
export function faceShare(clip: { start: number; end: number }, visual: VisualAnalysis | null): number {
  if (!visual || visual.faceEngine === 'none' || !visual.times.length) return 0;
  let n = 0, hit = 0;
  visual.times.forEach((t, i) => {
    if (t < clip.start || t > clip.end) return;
    n++;
    // a facecam in a corner over gameplay doesn't count — only a person who is actually the subject of the shot
    const onCam = (visual.faces[i] || []).some((f) => {
      if (f.score < 0.55) return false;
      const cx = f.x + f.w / 2, cy = f.y + f.h / 2;
      const corner = (cx < 0.28 || cx > 0.72) && (cy < 0.3 || cy > 0.7);
      return f.w >= 0.18 || (f.w >= 0.08 && !corner);
    });
    if (onCam) hit++;
  });
  return n ? hit / n : 0;
}

/** Pick a layout per clip: people talking → vertical w/ face tracking; gameplay/wide shots → keep the full frame. */
export function autoLayout(clip: Clip, visual: VisualAnalysis | null, srcW: number, srcH: number): Pick<Clip, 'aspect' | 'reframe' | 'layoutWhy'> {
  if (srcH > srcW) return { aspect: '9:16', reframe: 'track', layoutWhy: 'Source is already vertical' };
  const share = faceShare(clip, visual);
  if (share >= 0.6) return { aspect: '9:16', reframe: 'track', layoutWhy: `Person on camera ${Math.round(share * 100)}% of the time → vertical with face tracking` };
  return { aspect: '16:9', reframe: 'fit', layoutWhy: share > 0 ? `Mostly gameplay / wide shot (face only ${Math.round(share * 100)}% of the time) → full frame kept` : 'Gameplay / wide shot → full frame kept, nothing cropped' };
}

export type LayoutMode = 'auto' | '16:9' | '9:16';
/** Apply the layout chosen on the setup page ('auto' keeps the per-clip smart pick). */
export function applyLayoutMode(clips: Clip[], mode: LayoutMode, visual: VisualAnalysis | null, srcW: number, srcH: number): Clip[] {
  if (mode === 'auto') return clips;
  return clips.map((c) => ({ ...c, aspect: mode, reframe: reframeFor(mode, c, visual, srcW, srcH), layoutWhy: mode === '16:9' ? 'You chose: always 16:9 full frame' : 'You chose: always 9:16' }));
}

/** Pick a sensible reframe when the user switches a clip's aspect ratio. */
export function reframeFor(aspect: string, clip: Clip, visual: VisualAnalysis | null, srcW: number, srcH: number): ClipRenderOptions['reframe'] {
  const srcWide = srcW >= srcH;
  if (aspect === '16:9') return srcWide ? 'fit' : 'blur';
  return faceShare(clip, visual) >= 0.6 ? 'track' : 'blur'; // gameplay → show the whole frame on a blurred background
}

/** Static thumbnail matching the clip's layout */
export async function clipThumb(url: string, clip: Clip, visual: VisualAnalysis | null, tr: Transcript | null, aspect = '9:16', reframe: string = 'track'): Promise<string> {
  const v = document.createElement('video');
  v.muted = true; v.src = url; v.preload = 'auto';
  await waitEvent(v, 'loadeddata', 15000).catch(() => {});
  const t = clip.hookLine ? clip.hookLine.start + 0.4 : clip.start + Math.min(2, (clip.end - clip.start) / 3);
  await new Promise<void>((res) => { v.onseeked = () => res(); v.currentTime = t; setTimeout(res, 3000); });
  const [W, H] = aspectSize(aspect, 180);
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const ctx = c.getContext('2d')!;
  const track = buildTrack(visual, clip.start, clip.end, speakerIndexer(tr));
  const tp = trackAt(track, t);
  const vw = v.videoWidth || 16, vh = v.videoHeight || 9;
  if (reframe === 'fit' || reframe === 'blur') {
    if (reframe === 'blur') { const s0 = Math.max(W / vw, H / vh); ctx.filter = 'blur(8px) brightness(0.55)'; ctx.drawImage(v, (W - vw * s0) / 2, (H - vh * s0) / 2, vw * s0, vh * s0); ctx.filter = 'none'; }
    else { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); }
    const s1 = Math.min(W / vw, H / vh);
    ctx.drawImage(v, (W - vw * s1) / 2, (H - vh * s1) / 2, vw * s1, vh * s1);
  } else {
    const sc = Math.max(W / vw, H / vh);
    const sw = W / sc, sh = H / sc;
    ctx.drawImage(v, clamp(tp.cx * vw - sw / 2, 0, vw - sw), clamp(tp.cy * vh - sh / 2, 0, vh - sh), sw, sh, 0, 0, W, H);
  }
  v.removeAttribute('src'); v.load();
  return c.toDataURL('image/jpeg', 0.75);
}

export { chunkWords };

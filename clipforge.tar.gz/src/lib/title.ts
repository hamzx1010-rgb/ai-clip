/**
 * Titles and hooks, one per clip, made on the phone.
 *
 * Offline by default: ClipForge builds them from what it measured (where the
 * clip sits in the video, how much movement and speech it has) plus the
 * keywords you type in Settings. If you add an AI Director key in Settings,
 * askAiTitles() upgrades them — but nothing here depends on the network.
 */

import type { ClipAnalysis, ExportSettings } from './types';

const HOOK_SHAPES = [
  (k: string) => `Nobody talks about ${k}`,
  (k: string) => `The part about ${k} changes everything`,
  (k: string) => `Watch this before you try ${k}`,
  (k: string) => `${cap(k)} in under 30 seconds`,
  (k: string) => `Stop doing ${k} like this`,
  (k: string) => `This is why ${k} works`,
  (k: string) => `${cap(k)}: the honest version`,
  (k: string) => `You are doing ${k} wrong`,
];

const TITLE_SHAPES = [
  (k: string, i: number) => `${cap(k)} — part ${i + 1}`,
  (k: string) => `${cap(k)}, explained`,
  (k: string) => `The truth about ${k}`,
  (k: string) => `${cap(k)} in one take`,
  (k: string) => `Why ${k} matters`,
  (k: string) => `${cap(k)}: quick cut`,
];

function cap(s: string): string {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

/** Deterministic pseudo-random from a string, so titles are stable per clip. */
function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

export interface TitleInput {
  index: number;
  start: number;
  end: number;
  hasFace: boolean;
  motion: number;
  speechRatio: number;
  keywords: string[];
  sourceName: string;
}

export function makeTitleAndHook(input: TitleInput): { title: string; hook: string; keywords: string[] } {
  const seed = hash(`${input.sourceName}|${input.index}|${input.start.toFixed(2)}|${input.end.toFixed(2)}`);
  const topic = input.keywords[seed % Math.max(1, input.keywords.length)] ?? defaultTopic(input.sourceName);
  const kw = topic.trim() || 'this moment';

  const title = TITLE_SHAPES[seed % TITLE_SHAPES.length](kw, input.index);
  let hook = HOOK_SHAPES[(seed >> 3) % HOOK_SHAPES.length](kw);

  // Describe what is actually on screen — honest, and different per clip.
  if (input.motion > 6) hook = `${hook} (lots of movement)`;
  else if (input.motion < 1.2) hook = `${hook} (calm shot)`;
  if (!input.hasFace && input.speechRatio > 0.45) hook = `${hook} — voice only`;

  return { title: title.slice(0, 72), hook: hook.slice(0, 96), keywords: [kw] };
}

function defaultTopic(sourceName: string): string {
  const base = sourceName.replace(/\.[a-z0-9]{2,5}$/i, '').replace(/[-_]+/g, ' ').trim();
  if (!base) return 'this clip';
  const words = base.split(/\s+/).filter((w) => w.length > 2);
  if (!words.length) return base.slice(0, 28);
  return words.slice(0, 3).join(' ');
}

/** Turn a free-text keyword box into a clean list. */
export function parseKeywords(raw: string): string[] {
  return raw
    .split(/[\n,;]+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 24);
}

/* ------------------------- optional AI Director ------------------------- */

export interface AiDirectorConfig {
  provider: 'none' | 'openai';
  apiKey: string;
  model: string;
  baseUrl: string;
}

export const NO_AI: AiDirectorConfig = {
  provider: 'none',
  apiKey: '',
  model: 'gpt-4o-mini',
  baseUrl: 'https://api.openai.com/v1',
};

export function aiEnabled(cfg: AiDirectorConfig): boolean {
  return cfg.provider !== 'none' && cfg.apiKey.trim().length > 10;
}

/**
 * Ask the AI Director for titles + hooks for a whole run in one call.
 * Falls back silently to the offline versions on any failure.
 */
export async function askAiTitles(
  cfg: AiDirectorConfig,
  clips: TitleInput[],
  sourceName: string,
  settings: ExportSettings,
): Promise<Map<number, { title: string; hook: string }>> {
  const out = new Map<number, { title: string; hook: string }>();
  if (!aiEnabled(cfg)) return out;
  try {
    const body = {
      model: cfg.model,
      temperature: 0.7,
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content:
            'You write vertical short-form video titles and hooks. Reply with JSON only: ' +
            '{"items":[{"index":number,"title":string,"hook":string}]}. ' +
            'Title max 60 chars, hook max 90 chars, plain language, no hashtags, no emoji.',
        },
        {
          role: 'user',
          content: JSON.stringify({
            source: sourceName,
            vertical: `${settings.width}x${settings.height}`,
            clips: clips.map((c) => ({
              index: c.index,
              start: Math.round(c.start),
              end: Math.round(c.end),
              hasFace: c.hasFace,
              motion: Number(c.motion.toFixed(1)),
              speechRatio: Number(c.speechRatio.toFixed(2)),
              keywords: c.keywords,
            })),
          }),
        },
      ],
    };
    const res = await fetch(`${cfg.baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.apiKey}` },
      body: JSON.stringify(body),
    });
    if (!res.ok) return out;
    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const text = json.choices?.[0]?.message?.content ?? '';
    const parsed = JSON.parse(text) as { items?: Array<{ index: number; title: string; hook: string }> };
    for (const it of parsed.items ?? []) {
      if (typeof it.index === 'number' && it.title) {
        out.set(it.index, { title: String(it.title).slice(0, 72), hook: String(it.hook ?? '').slice(0, 96) });
      }
    }
  } catch {
    /* offline titles already exist — ignore */
  }
  return out;
}

export function applyAiTitles(
  analysis: ClipAnalysis,
  ai: { title: string; hook: string } | undefined,
): ClipAnalysis {
  if (!ai) return analysis;
  return { ...analysis, title: ai.title, hook: ai.hook || analysis.hook };
}

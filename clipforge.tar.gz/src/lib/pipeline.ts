/**
 * The whole run: load source -> analyse -> export each clip one at a time ->
 * verify -> download the moment it is ready -> remember it.
 *
 * Memory rules that keep a phone alive on a 20-minute 720p file:
 *   - only ONE clip is being exported at any moment;
 *   - the exported blob goes straight to IndexedDB (disk), not a RAM cache;
 *   - object URLs are revoked as soon as the download has been handed over;
 *   - the source bytes are released when the run finishes.
 */

import { analyzeSource, type AnalyzeResult } from './analyze';
import {
  clipFileName,
  downloadBlob,
} from './download';
import { exportClipWithVerification, planEngines } from './export';
import { releaseSource, loadSource, plainError, probeVideo, type VideoSource } from './source';
import { captureThumb, storeThumb } from './thumb';
import { wakeAcquire, wakeRelease } from './wake';
import * as db from './db';
import type { AiDirectorConfig } from './title';
import { aiEnabled, applyAiTitles, askAiTitles } from './title';
import type { Clip, ExportSettings, RunMeta, Verification } from './types';

export interface RunCallbacks {
  onRun?: (run: RunMeta) => void;
  onClips?: (clips: Clip[]) => void;
  onClip?: (clip: Clip) => void;
  onLog?: (line: string) => void;
  /** Stage text + rough fraction, shown next to the progress bar. */
  onStatus?: (message: string, frac?: number) => void;
  onFinished?: (run: RunMeta, clips: Clip[]) => void;
}

export interface RunInput {
  input: string | File;
  settings: ExportSettings;
  keywords: string[];
  ai: AiDirectorConfig;
  downloadEach: boolean;
  forceRealtime: boolean;
  signal: AbortSignal;
  callbacks: RunCallbacks;
}

export interface RunOutcome {
  run: RunMeta;
  clips: Clip[];
  source: VideoSource;
  analysis: AnalyzeResult | null;
  failures: number;
}

/**
 * Apply the "which clips" choice from the main page:
 *   auto  - every candidate that works as a Short;
 *   best  - only clips scoring bestScore or higher;
 *   count - exactly pickCount clips, the highest scoring ones.
 * Never returns empty: a run that found anything makes at least one clip.
 */
function selectClips(all: Clip[], settings: ExportSettings, cb: RunCallbacks): Clip[] {
  const score = (c: Clip) => c.analysis?.score ?? 0;
  const mode = settings.pick ?? 'auto';
  let out = all;
  if (mode === 'count') {
    const n = Math.max(1, Math.min(all.length, Math.round(settings.pickCount || 3)));
    out = [...all].sort((a, b) => score(b) - score(a)).slice(0, n).sort((a, b) => a.index - b.index);
    log(cb, `Exact number: keeping the ${out.length} highest-scoring of ${all.length} candidates`);
  } else if (mode === 'best') {
    const min = settings.bestScore ?? 80;
    out = all.filter((c) => score(c) >= min);
    log(cb, `High-rated only (score ${min}+): ${out.length} of ${all.length} candidates qualified`);
    if (!out.length) {
      out = [...all].sort((a, b) => score(b) - score(a)).slice(0, 1);
      log(cb, `Nothing scored ${min}+, so keeping the single best one`);
    }
  } else {
    log(cb, `Automatic: keeping all ${all.length} candidate(s)`);
  }
  if (!out.length) out = all.slice(0, 1);
  return out;
}

const log = (cb: RunCallbacks, s: string) => cb.onLog?.(`[${new Date().toLocaleTimeString()}] ${s}`);

/** Fail with a plain sentence instead of hanging forever. */
function withBudget<T>(p: Promise<T>, ms: number, message: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(message)), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      },
    );
  });
}

export async function runPipeline(input: RunInput): Promise<RunOutcome> {
  const { settings, callbacks: cb, signal } = input;
  wakeAcquire();

  let source: VideoSource | null = null;
  const clips: Clip[] = [];
  let run: RunMeta | null = null;
  let analysis: AnalyzeResult | null = null;

  try {
    /* ---------- 1. get the bytes ---------- */
    log(cb, 'Getting the video');
    source = await loadSource(input.input, (frac, label) =>
      log(cb, frac > 0 ? `${label} ${Math.round(frac * 100)}%` : label),
    );
    log(cb, `Got ${source.name} (${(source.sizeBytes / 1048576).toFixed(1)} MB)`);
    if (source.viaProxy) log(cb, 'The site blocked direct download, used a public relay');

    /* ---------- 2. probe ---------- */
    const info = await probeVideo(source.url);
    if (!info.duration || info.duration < 1) throw new Error('Could not read how long the video is');
    log(cb, `Video is ${info.duration.toFixed(1)}s, ${info.width}x${info.height}`);

    run = {
      id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: Date.now(),
      sourceName: source.name,
      sourceKind: source.kind,
      sourceUrl: source.kind === 'url' ? String(input.input) : undefined,
      sourceDuration: info.duration,
      sourceWidth: info.width,
      sourceHeight: info.height,
      sourceCodec: info.codecGuess,
      clipCount: 0,
      settings: { ...settings },
      done: false,
    };
    await db.saveRun(run);
    cb.onRun?.(run);

    /* ---------- 3. analyse ---------- */
    log(cb, 'Analysing — looking for pauses, movement and people');
    // A watchdog: on a phone, one stalled decode or seek used to leave the run
    // sitting at "Loaded ..." forever with no error. Now the analysis gets a
    // generous but finite budget, and running out becomes a plain sentence.
    const analyzeBudgetMs = Math.min(600, Math.max(150, info.duration * 2.5)) * 1000;
    analysis = await withBudget(
      analyzeSource(
        source.url,
        info.duration,
        settings,
        source.name,
        input.keywords,
        source.blob,
        (p) => {
          cb.onStatus?.(p.message, 0.02 + p.frac * 0.28);
          if (p.stage === 'survey' || p.stage === 'faces' || p.stage === 'audio') log(cb, p.message);
        },
        signal,
      ),
      analyzeBudgetMs,
      `The analysis stopped answering after ${Math.round(analyzeBudgetMs / 1000)}s. ` +
        `The browser would not hand over frames or sound. Press Make clips to try again, ` +
        `or try a shorter video.`,
    );
    log(cb, `Found ${analysis.segments.length} candidate clip${analysis.segments.length === 1 ? '' : 's'}`);
    if (!analysis.segments.length) {
      throw new Error('Nothing in this video looked like a clip. Try a longer min/max length in Settings.');
    }

    /* ---------- 4. build clip records ---------- */
    for (const seg of analysis.segments) {
      const a = analysis.analyses.get(seg.index) ?? null;
      const clip: Clip = {
        id: `${run.id}-c${seg.index}`,
        runId: run.id,
        index: seg.index,
        start: seg.start,
        end: seg.end,
        duration: seg.end - seg.start,
        layout: a?.hasFace && settings.preferFace ? 'face' : 'full',
        autoLayout: a?.hasFace && settings.preferFace ? 'face' : 'full',
        status: 'ready',
        analysis: a,
        progress: 0,
        progressText: '',
        error: null,
        verification: null,
        fileName: clipFileName(source.name, seg.index, a?.title ?? '', 'mp4'),
        mime: 'video/mp4',
        sizeBytes: 0,
        edited: false,
        exportedAt: null,
        engine: null,
      };
      clips.push(clip);
    }

    // Titles: offline first, then upgrade with the AI Director if configured.
    if (aiEnabled(input.ai)) {
      log(cb, 'Asking the AI Director for titles');
      const aiTitles = await askAiTitles(
        input.ai,
        clips.map((c) => ({
          index: c.index,
          start: c.start,
          end: c.end,
          hasFace: c.analysis?.hasFace ?? false,
          motion: c.analysis?.motion ?? 0,
          speechRatio: c.analysis?.speechRatio ?? 0,
          keywords: c.analysis?.keywords ?? input.keywords,
          sourceName: source!.name,
        })),
        source.name,
        settings,
      );
      for (const c of clips) {
        if (c.analysis) c.analysis = applyAiTitles(c.analysis, aiTitles.get(c.index));
      }
      if (aiTitles.size) log(cb, `AI Director wrote ${aiTitles.size} titles`);
    }

    /* ---------- 4b. honour the picking choice from the main page ---------- */
    const picked = selectClips(clips, settings, cb);
    clips.splice(0, clips.length, ...picked);

    run.clipCount = clips.length;
    await db.saveRun(run);
    for (const c of clips) await db.saveClip(c);
    cb.onClips?.([...clips]);
    cb.onStatus?.(`Making ${clips.length} clip${clips.length === 1 ? '' : 's'}`, 0.32);

    /* ---------- 5. export ONE at a time ---------- */
    const engines = await planEngines(
      {
        srcUrl: source.url,
        srcBlob: source.blob,
        start: 0,
        end: 1,
        width: settings.width,
        height: settings.height,
        fps: settings.fps,
        layout: 'full',
        faceCenter: null,
        mode: settings.mode,
        signal,
      },
      input.forceRealtime || settings.mode === 'realtime',
    );
    log(cb, `Engine order: ${engines.join(' -> ')}`);

    let failures = 0;
    let good = 0;
    const total = clips.length;
    const baseAt = (i: number, inner: number) => 0.32 + ((i + Math.min(1, Math.max(0, inner))) / total) * 0.55;
    for (let i = 0; i < total; i++) {
      if (signal.aborted) break;
      const clip = clips[i];
      cb.onStatus?.(`Rendering clip ${i + 1} of ${total}`, baseAt(i, 0));

      // A finished clip is never made twice.
      const existing = await db.getBlob(clip.id);
      if (existing && existing.size > 2048 && clip.verification?.ok) {
        good++;
        log(cb, `Clip ${i + 1} already made — skipping`);
        clip.url = URL.createObjectURL(existing);
        clip.sizeBytes = existing.size;
        clip.status = 'done';
        await db.saveClip(clip);
        cb.onClip?.({ ...clip });
        continue;
      }

      clip.status = 'exporting';
      clip.error = null;
      clip.progress = 0;
      cb.onClip?.({ ...clip });
      log(cb, `Making clip ${i + 1} of ${clips.length} (${clip.duration.toFixed(1)}s)`);

      try {
        const out = await exportClipWithVerification({
          job: {
            srcUrl: source.url,
            srcBlob: source.blob,
            start: clip.start,
            end: clip.end,
            width: settings.width,
            height: settings.height,
            fps: settings.fps,
            layout: clip.layout,
            faceCenter: clip.analysis?.faceCenter ?? null,
            burnTitle: settings.burnTitle ? clip.analysis?.title ?? null : null,
            mode: settings.mode,
            signal,
            onProgress: (frac, message) => {
          cb.onStatus?.(
            `Rendering clip ${i + 1} of ${total} — ${Math.round(frac * 100)}%`,
            baseAt(i, frac),
          );
              clip.progress = frac;
              clip.progressText = message;
              cb.onClip?.({ ...clip });
            },
          },
          sourceHasAudio: analysis.audio.ok,
          autoRebuild: settings.autoRebuild,
          forceRealtime: input.forceRealtime || settings.mode === 'realtime',
          onAttempt: (n, engine, message) =>
            log(cb, `Clip ${i + 1} attempt ${n} (${engine}): ${message}`),
        });

        clip.status = 'verifying';
        cb.onClip?.({ ...clip });

        // Store on disk, then hand it to the download queue right away.
        await db.putBlob(clip.id, out.result.blob);
        clip.sizeBytes = out.result.blob.size;
        clip.mime = out.result.blob.type || out.result.mime;
        clip.fileName = clipFileName(source.name, clip.index, clip.analysis?.title ?? '', extFor(clip.mime));
        clip.verification = out.verification;
        clip.engine = out.result.engine;
        clip.exportedAt = Date.now();
        clip.progress = 1;
        clip.progressText = 'Done';
        clip.url = URL.createObjectURL(out.result.blob);

        log(
          cb,
          `Clip ${i + 1} OK — ${out.result.blob.size ? (out.result.blob.size / 1048576).toFixed(1) : '0'} MB, ` +
            `${out.result.framesWritten} frames, ${out.verification.duration.toFixed(1)}s, ` +
            `picture moving to ${Math.round(out.verification.motionThrough * 100)}%, ` +
            `audio ${out.verification.audioPresent ? 'yes' : 'no'}`,
        );
        if (out.attempts.length > 1) {
          log(cb, `Clip ${i + 1} was rebuilt ${out.attempts.length - 1} time(s) before it passed`);
        }

        // Thumbnail comes out of the FINISHED file — a flat thumbnail is itself
        // evidence of a frozen export, so we log it.
        try {
          const th = await captureThumb(out.result.blob, [
            clip.duration * 0.2,
            clip.duration * 0.55,
            clip.duration * 0.88,
          ]);
          if (th.dataUrl) {
            clip.thumbUrl = th.dataUrl;
            await storeThumb(clip.id, th.dataUrl);
          }
          if (th.spread < 0.4) {
            log(cb, `Clip ${i + 1} warning: the thumbnail barely changes across the file`);
          }
        } catch {
          /* a missing thumbnail is not a reason to lose the clip */
        }

        clip.status = 'done';
        good++;
        await db.saveClip(clip);
        cb.onClip?.({ ...clip });
        cb.onStatus?.(
          `Clip ${i + 1} of ${total} done — ${good} good so far`,
          baseAt(i, 1),
        );

        if (input.downloadEach) {
          // Download the moment it is ready — do not wait for the rest.
          void downloadBlob({ blob: out.result.blob, fileName: clip.fileName }).then(() => {
            log(cb, `Clip ${i + 1} downloaded`);
            // Free the bytes from RAM; they stay in IndexedDB.
            if (clip.url) {
              URL.revokeObjectURL(clip.url);
              clip.url = null;
            }
          });
        }
        out.result.blob = null as unknown as Blob; // let GC take it now it is on disk
      } catch (e) {
        const err = e as Error & { verification?: Verification };
        if (signal.aborted) {
          // Stopped by the user: what is finished stays finished, what is not
          // simply goes back to "not made yet" so it can be made later.
          clip.status = 'ready';
          clip.error = null;
          clip.progressText = 'Not made yet';
          await db.saveClip(clip);
          cb.onClip?.({ ...clip });
          break;
        }
        failures++;
        clip.status = 'error';
        clip.error = plainError(err) || 'Could not make this clip';
        clip.verification = err.verification ?? null;
        clip.progressText = 'Failed';
        log(cb, `Clip ${i + 1} FAILED — ${clip.error}`);
        await db.saveClip(clip);
        cb.onClip?.({ ...clip });
        // A failed clip does not stop the others.
        continue;
      }
    }

    if (signal.aborted) {
      run.error = good
        ? 'Stopped by you — the finished clips stay playable and downloadable.'
        : 'Stopped by you before any clip finished.';
    }
    run.done = true;
    await db.saveRun(run);
    if (!signal.aborted) cb.onFinished?.(run, clips);
    log(cb, `Run finished. ${clips.length - failures}/${clips.length} clips good.`);

    return { run, clips, source, analysis, failures };
  } catch (e) {
    const stopped = signal.aborted;
    const msg = stopped ? 'Stopped by you' : plainError(e);
    log(cb, stopped ? 'Run stopped by you' : `Run failed: ${msg}`);
    for (const c of clips) {
      if (c.status !== 'done') {
        if (stopped) {
          c.status = 'ready';
          c.error = null;
          c.progressText = 'Not made yet';
        } else {
          c.status = 'error';
          c.error = msg;
        }
        await db.saveClip(c);
      }
    }
    if (run) {
      run.done = true;
      // Remember WHY, so History can say more than "0/0 clips" next time.
      run.error = stopped
        ? clips.some((c) => c.status === 'done')
          ? 'Stopped by you — the finished clips stay playable and downloadable.'
          : 'Stopped by you before any clip finished.'
        : msg;
      await db.saveRun(run);
    }
    cb.onClips?.([...clips]);
    if (stopped && source && analysis) {
      // Stopping is not failing: hand back what exists so the screen shows it.
      return { run: run as RunMeta, clips, source, analysis, failures: 0 };
    }
    throw e instanceof Error ? e : new Error(msg);
  } finally {
    wakeRelease();
    if (source) releaseSource(source);
  }
}

export function extFor(mime: string): string {
  if (mime.includes('mp4')) return 'mp4';
  if (mime.includes('webm')) return 'webm';
  if (mime.includes('ogg')) return 'ogv';
  return 'mp4';
}

/** Re-export a single clip after an edit (layout, trim, title). */
export async function reExportClip(opts: {
  clip: Clip;
  source: VideoSource;
  settings: ExportSettings;
  sourceHasAudio: boolean;
  forceRealtime: boolean;
  signal: AbortSignal;
  onProgress: (frac: number, message: string) => void;
}): Promise<{ blob: Blob; verification: Verification; engine: string }> {
  const out = await exportClipWithVerification({
    job: {
      srcUrl: opts.source.url,
      srcBlob: opts.source.blob,
      start: opts.clip.start,
      end: opts.clip.end,
      width: opts.settings.width,
      height: opts.settings.height,
      fps: opts.settings.fps,
      layout: opts.clip.layout,
      faceCenter: opts.clip.analysis?.faceCenter ?? null,
      burnTitle: opts.settings.burnTitle ? opts.clip.analysis?.title ?? null : null,
      mode: opts.settings.mode,
      signal: opts.signal,
      onProgress: opts.onProgress,
    },
    sourceHasAudio: opts.sourceHasAudio,
    autoRebuild: opts.settings.autoRebuild,
    forceRealtime: opts.forceRealtime,
  });
  return { blob: out.result.blob, verification: out.verification, engine: out.result.engine };
}

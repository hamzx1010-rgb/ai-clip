/**
 * The whole run: load source -> analyse -> export each clip one at a time ->
 * verify -> download the moment it is ready -> remember it.
 *
 * Memory rules that keep a phone alive on a 20-minute 720p file:
 *   - only ONE clip is being exported at any moment;
 *   - the exported blob goes straight to IndexedDB (disk), not a RAM cache;
 *   - object URLs are revoked as soon as the download has been handed over;
 *   - the source bytes are released when the run finishes.
 */

import { analyzeSource, type AnalyzeResult } from './analyze';
import {
  clipFileName,
  downloadBlob,
} from './download';
import { exportClipWithVerification, planEngines } from './export';
import { releaseSource, loadSource, plainError, probeVideo, type VideoSource } from './source';
import { captureThumb, storeThumb } from './thumb';
import { wakeAcquire, wakeRelease } from './wake';
import * as db from './db';
import type { AiDirectorConfig } from './title';
import { aiEnabled, applyAiTitles, askAiTitles } from './title';
import type { Clip, ExportSettings, RunMeta, Verification } from './types';

export interface RunCallbacks {
  onRun?: (run: RunMeta) => void;
  onClips?: (clips: Clip[]) => void;
  onClip?: (clip: Clip) => void;
  onLog?: (line: string) => void;
  onFinished?: (run: RunMeta, clips: Clip[]) => void;
}

export interface RunInput {
  input: string | File;
  settings: ExportSettings;
  keywords: string[];
  ai: AiDirectorConfig;
  downloadEach: boolean;
  forceRealtime: boolean;
  signal: AbortSignal;
  callbacks: RunCallbacks;
}

export interface RunOutcome {
  run: RunMeta;
  clips: Clip[];
  source: VideoSource;
  analysis: AnalyzeResult;
  failures: number;
}

const log = (cb: RunCallbacks, s: string) => cb.onLog?.(`[${new Date().toLocaleTimeString()}] ${s}`);

export async function runPipeline(input: RunInput): Promise<RunOutcome> {
  const { settings, callbacks: cb, signal } = input;
  wakeAcquire();

  let source: VideoSource | null = null;
  const clips: Clip[] = [];
  let run: RunMeta | null = null;

  try {
    /* ---------- 1. get the bytes ---------- */
    log(cb, 'Getting the video');
    source = await loadSource(input.input, (frac, label) =>
      log(cb, frac > 0 ? `${label} ${Math.round(frac * 100)}%` : label),
    );
    log(cb, `Got ${source.name} (${(source.sizeBytes / 1048576).toFixed(1)} MB)`);
    if (source.viaProxy) log(cb, 'The site blocked direct download, used a public relay');

    /* ---------- 2. probe ---------- */
    const info = await probeVideo(source.url);
    if (!info.duration || info.duration < 1) throw new Error('Could not read how long the video is');
    log(cb, `Video is ${info.duration.toFixed(1)}s, ${info.width}x${info.height}`);

    run = {
      id: `run-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      createdAt: Date.now(),
      sourceName: source.name,
      sourceKind: source.kind,
      sourceUrl: source.kind === 'url' ? String(input.input) : undefined,
      sourceDuration: info.duration,
      sourceWidth: info.width,
      sourceHeight: info.height,
      sourceCodec: info.codecGuess,
      clipCount: 0,
      settings: { ...settings },
      done: false,
    };
    await db.saveRun(run);
    cb.onRun?.(run);

    /* ---------- 3. analyse ---------- */
    log(cb, 'Analysing — looking for pauses, movement and people');
    const analysis = await analyzeSource(
      source.url,
      info.duration,
      settings,
      source.name,
      input.keywords,
      source.blob,
      (p) => {
        if (p.stage === 'survey') log(cb, p.message);
        else if (p.stage === 'faces') log(cb, p.message);
      },
      signal,
    );
    log(cb, `Found ${analysis.segments.length} candidate clip${analysis.segments.length === 1 ? '' : 's'}`);
    if (!analysis.segments.length) {
      throw new Error('Nothing in this video looked like a clip. Try a longer min/max length in Settings.');
    }

    /* ---------- 4. build clip records ---------- */
    for (const seg of analysis.segments) {
      const a = analysis.analyses.get(seg.index) ?? null;
      const clip: Clip = {
        id: `${run.id}-c${seg.index}`,
        runId: run.id,
        index: seg.index,
        start: seg.start,
        end: seg.end,
        duration: seg.end - seg.start,
        layout: a?.hasFace && settings.preferFace ? 'face' : 'full',
        autoLayout: a?.hasFace && settings.preferFace ? 'face' : 'full',
        status: 'ready',
        analysis: a,
        progress: 0,
        progressText: '',
        error: null,
        verification: null,
        fileName: clipFileName(source.name, seg.index, a?.title ?? '', 'mp4'),
        mime: 'video/mp4',
        sizeBytes: 0,
        edited: false,
        exportedAt: null,
        engine: null,
      };
      clips.push(clip);
    }

    // Titles: offline first, then upgrade with the AI Director if configured.
    if (aiEnabled(input.ai)) {
      log(cb, 'Asking the AI Director for titles');
      const aiTitles = await askAiTitles(
        input.ai,
        clips.map((c) => ({
          index: c.index,
          start: c.start,
          end: c.end,
          hasFace: c.analysis?.hasFace ?? false,
          motion: c.analysis?.motion ?? 0,
          speechRatio: c.analysis?.speechRatio ?? 0,
          keywords: c.analysis?.keywords ?? input.keywords,
          sourceName: source!.name,
        })),
        source.name,
        settings,
      );
      for (const c of clips) {
        if (c.analysis) c.analysis = applyAiTitles(c.analysis, aiTitles.get(c.index));
      }
      if (aiTitles.size) log(cb, `AI Director wrote ${aiTitles.size} titles`);
    }

    run.clipCount = clips.length;
    await db.saveRun(run);
    for (const c of clips) await db.saveClip(c);
    cb.onClips?.([...clips]);

    /* ---------- 5. export ONE at a time ---------- */
    const engines = await planEngines(
      {
        srcUrl: source.url,
        srcBlob: source.blob,
        start: 0,
        end: 1,
        width: settings.width,
        height: settings.height,
        fps: settings.fps,
        layout: 'full',
        faceCenter: null,
        mode: settings.mode,
        signal,
      },
      input.forceRealtime || settings.mode === 'realtime',
    );
    log(cb, `Engine order: ${engines.join(' -> ')}`);

    let failures = 0;
    for (let i = 0; i < clips.length; i++) {
      if (signal.aborted) break;
      const clip = clips[i];

      // A finished clip is never made twice.
      const existing = await db.getBlob(clip.id);
      if (existing && existing.size > 2048 && clip.verification?.ok) {
        log(cb, `Clip ${i + 1} already made — skipping`);
        clip.url = URL.createObjectURL(existing);
        clip.sizeBytes = existing.size;
        clip.status = 'done';
        await db.saveClip(clip);
        cb.onClip?.({ ...clip });
        continue;
      }

      clip.status = 'exporting';
      clip.error = null;
      clip.progress = 0;
      cb.onClip?.({ ...clip });
      log(cb, `Making clip ${i + 1} of ${clips.length} (${clip.duration.toFixed(1)}s)`);

      try {
        const out = await exportClipWithVerification({
          job: {
            srcUrl: source.url,
            srcBlob: source.blob,
            start: clip.start,
            end: clip.end,
            width: settings.width,
            height: settings.height,
            fps: settings.fps,
            layout: clip.layout,
            faceCenter: clip.analysis?.faceCenter ?? null,
            burnTitle: settings.burnTitle ? clip.analysis?.title ?? null : null,
            mode: settings.mode,
            signal,
            onProgress: (frac, message) => {
              clip.progress = frac;
              clip.progressText = message;
              cb.onClip?.({ ...clip });
            },
          },
          sourceHasAudio: analysis.audio.ok,
          autoRebuild: settings.autoRebuild,
          forceRealtime: input.forceRealtime || settings.mode === 'realtime',
          onAttempt: (n, engine, message) =>
            log(cb, `Clip ${i + 1} attempt ${n} (${engine}): ${message}`),
        });

        clip.status = 'verifying';
        cb.onClip?.({ ...clip });

        // Store on disk, then hand it to the download queue right away.
        await db.putBlob(clip.id, out.result.blob);
        clip.sizeBytes = out.result.blob.size;
        clip.mime = out.result.blob.type || out.result.mime;
        clip.fileName = clipFileName(source.name, clip.index, clip.analysis?.title ?? '', extFor(clip.mime));
        clip.verification = out.verification;
        clip.engine = out.result.engine;
        clip.exportedAt = Date.now();
        clip.progress = 1;
        clip.progressText = 'Done';
        clip.url = URL.createObjectURL(out.result.blob);

        log(
          cb,
          `Clip ${i + 1} OK — ${out.result.blob.size ? (out.result.blob.size / 1048576).toFixed(1) : '0'} MB, ` +
            `${out.result.framesWritten} frames, ${out.verification.duration.toFixed(1)}s, ` +
            `picture moving to ${Math.round(out.verification.motionThrough * 100)}%, ` +
            `audio ${out.verification.audioPresent ? 'yes' : 'no'}`,
        );
        if (out.attempts.length > 1) {
          log(cb, `Clip ${i + 1} was rebuilt ${out.attempts.length - 1} time(s) before it passed`);
        }

        // Thumbnail comes out of the FINISHED file — a flat thumbnail is itself
        // evidence of a frozen export, so we log it.
        try {
          const th = await captureThumb(out.result.blob, [
            clip.duration * 0.2,
            clip.duration * 0.55,
            clip.duration * 0.88,
          ]);
          if (th.dataUrl) {
            clip.thumbUrl = th.dataUrl;
            await storeThumb(clip.id, th.dataUrl);
          }
          if (th.spread < 0.4) {
            log(cb, `Clip ${i + 1} warning: the thumbnail barely changes across the file`);
          }
        } catch {
          /* a missing thumbnail is not a reason to lose the clip */
        }

        clip.status = 'done';
        await db.saveClip(clip);
        cb.onClip?.({ ...clip });

        if (input.downloadEach) {
          // Download the moment it is ready — do not wait for the rest.
          void downloadBlob({ blob: out.result.blob, fileName: clip.fileName }).then(() => {
            log(cb, `Clip ${i + 1} downloaded`);
            // Free the bytes from RAM; they stay in IndexedDB.
            if (clip.url) {
              URL.revokeObjectURL(clip.url);
              clip.url = null;
            }
          });
        }
        out.result.blob = null as unknown as Blob; // let GC take it now it is on disk
      } catch (e) {
        failures++;
        const err = e as Error & { verification?: Verification };
        clip.status = 'error';
        clip.error = plainError(err) || 'Could not make this clip';
        clip.verification = err.verification ?? null;
        clip.progressText = 'Failed';
        log(cb, `Clip ${i + 1} FAILED — ${clip.error}`);
        await db.saveClip(clip);
        cb.onClip?.({ ...clip });
        // A failed clip does not stop the others.
        continue;
      }
    }

    run.done = true;
    await db.saveRun(run);
    cb.onFinished?.(run, clips);
    log(cb, `Run finished. ${clips.length - failures}/${clips.length} clips good.`);

    return { run, clips, source, analysis, failures };
  } catch (e) {
    const msg = plainError(e);
    log(cb, `Run failed: ${msg}`);
    for (const c of clips) {
      if (c.status !== 'done') {
        c.status = 'error';
        c.error = msg;
        await db.saveClip(c);
      }
    }
    if (run) {
      run.done = true;
      await db.saveRun(run);
    }
    cb.onClips?.([...clips]);
    throw e instanceof Error ? e : new Error(msg);
  } finally {
    wakeRelease();
    if (source) releaseSource(source);
  }
}

export function extFor(mime: string): string {
  if (mime.includes('mp4')) return 'mp4';
  if (mime.includes('webm')) return 'webm';
  if (mime.includes('ogg')) return 'ogv';
  return 'mp4';
}

/** Re-export a single clip after an edit (layout, trim, title). */
export async function reExportClip(opts: {
  clip: Clip;
  source: VideoSource;
  settings: ExportSettings;
  sourceHasAudio: boolean;
  forceRealtime: boolean;
  signal: AbortSignal;
  onProgress: (frac: number, message: string) => void;
}): Promise<{ blob: Blob; verification: Verification; engine: string }> {
  const out = await exportClipWithVerification({
    job: {
      srcUrl: opts.source.url,
      srcBlob: opts.source.blob,
      start: opts.clip.start,
      end: opts.clip.end,
      width: opts.settings.width,
      height: opts.settings.height,
      fps: opts.settings.fps,
      layout: opts.clip.layout,
      faceCenter: opts.clip.analysis?.faceCenter ?? null,
      burnTitle: opts.settings.burnTitle ? opts.clip.analysis?.title ?? null : null,
      mode: opts.settings.mode,
      signal: opts.signal,
      onProgress: opts.onProgress,
    },
    sourceHasAudio: opts.sourceHasAudio,
    autoRebuild: opts.settings.autoRebuild,
    forceRealtime: opts.forceRealtime,
  });
  return { blob: out.result.blob, verification: out.verification, engine: out.result.engine };
}

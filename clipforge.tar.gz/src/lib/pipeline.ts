import { autoLayout } from './clipRender';
import type { AudioAnalysis, ChatAnalysis, ChatMsg, Clip, Segment, Transcript, VisualAnalysis } from './types';
import { transcribeLocal, ASR_MODELS, type LocalAsrModel } from './localAsr';
import { makeTitle } from './nlp';
import { analyzeAudio, decodeToMono } from './audio';
import { analyzeVisual } from './visual';
import { findClips, type EngineSettings } from './engine';
import { freeAIDown } from './director/ai';
import { hasAI, loadSampleTranscript, refineClipsWithLLM, transcribeWhisper } from './llm';
import { analyzeChat } from './chat';
import { loadVideoMeta } from './util';

export type StepId = 'load' | 'decode' | 'audio' | 'transcript' | 'visual' | 'chat' | 'score' | 'subs' | 'llm';
export type StepState = { id: StepId; label: string; status: 'wait' | 'run' | 'done' | 'skip' | 'error'; detail?: string; progress?: number };

export type PipelineInput = {
  file: Blob;
  url: string;
  /** server endpoint that returns a small MP3 of the audio track (linked videos only) */
  audioUrl?: string;
  isSample?: boolean;
  transcript?: Transcript | null; // e.g. imported SRT
  transcribe: 'whisper' | 'none';
  language: string;
  faces: boolean;
  llm: boolean;
  chatLog?: ChatMsg[];
  markers?: { t: number; label: string; strength: number }[];
  settings: EngineSettings;
  /** free on-device subtitles when there is no transcript */
  localAsr?: LocalAsrModel;
};

export type PipelineResult = {
  duration: number; width: number; height: number;
  audio: AudioAnalysis | null; visual: VisualAnalysis | null; transcript: Transcript | null; chat: ChatAnalysis | null; clips: Clip[];
};

export async function runPipeline(inp: PipelineInput, onStep: (s: StepState[]) => void): Promise<PipelineResult> {
  const steps: StepState[] = [
    { id: 'load', label: 'Reading media & metadata', status: 'wait' },
    { id: 'decode', label: 'Decoding audio track', status: 'wait' },
    { id: 'audio', label: 'Audio intelligence — energy, silence, spikes, crowd reactions', status: 'wait' },
    { id: 'transcript', label: 'Transcription & speaker diarization', status: 'wait' },
    { id: 'visual', label: 'Visual intelligence — faces, scene cuts, motion, quality', status: 'wait' },
    { id: 'chat', label: 'Chat analysis — spam spikes, emotes, subs & donations', status: inp.chatLog?.length ? 'wait' : 'skip' },
    { id: 'score', label: 'Virality scoring & clip selection', status: 'wait' },
    { id: 'subs', label: 'Subtitles — on-device Whisper (free, no key)', status: 'wait' },
    { id: 'llm', label: 'AI polish (hooks & titles)', status: inp.llm ? 'wait' : 'skip' },
  ];
  const set = (id: StepId, p: Partial<StepState>) => { const s = steps.find((x) => x.id === id)!; Object.assign(s, p); onStep(steps.map((x) => ({ ...x }))); };
  onStep(steps.map((x) => ({ ...x })));

  set('load', { status: 'run' });
  const meta = await loadVideoMeta(inp.url);
  set('load', { status: 'done', detail: `${meta.width}×${meta.height} · ${Math.round(meta.duration)}s` });

  set('decode', { status: 'run' });
  let ab: AudioBuffer | null = null;
  const viaServer = async () => {
    set('decode', { status: 'run', detail: 'Extracting audio on the server…' });
    const r = await fetch(inp.audioUrl!);
    if (!r.ok) throw new Error('server audio ' + r.status);
    const mp3 = await r.blob();
    if (mp3.size < 1000) throw new Error('empty audio');
    return decodeToMono(mp3);
  };
  try {
    // big linked videos: let the server pull out a ~7 MB audio track instead of decoding hundreds of MB in the browser
    if (inp.audioUrl && inp.file.size > 40e6) { try { ab = await viaServer(); } catch { ab = await decodeToMono(inp.file); } }
    else { try { ab = await decodeToMono(inp.file); } catch (e) { if (inp.audioUrl) ab = await viaServer(); else throw e; } }
    set('decode', { status: 'done', detail: `${ab.sampleRate / 1000} kHz mono · ${Math.round(ab.duration)}s` });
  } catch (e) {
    set('decode', { status: 'error', detail: 'No decodable audio track — continuing with visuals only' });
  }
  const duration = meta.duration || ab?.duration || 0;

  set('audio', { status: 'run' });
  let audio: AudioAnalysis | null = null;
  if (ab) {
    await new Promise((r) => setTimeout(r, 30));
    audio = analyzeAudio(ab);
    set('audio', { status: 'done', detail: `${audio.spikes.length} spikes · ${audio.silences.length} silences · ${Math.round(audio.loudnessDb)} dBFS avg` });
  } else set('audio', { status: 'skip' });

  set('transcript', { status: 'run' });
  let transcript: Transcript | null = inp.transcript ?? null;
  try {
    if (!transcript && inp.isSample) transcript = await loadSampleTranscript();
    if (!transcript && inp.transcribe === 'whisper' && hasAI() && ab) {
      transcript = await transcribeWhisper(inp.file, inp.language, (p, label) => set('transcript', { detail: label, progress: p }), ab);
    }
  } catch (e) {
    set('transcript', { status: 'error', detail: String((e as Error).message).slice(0, 120) });
  }
  if (transcript) {
    const words = transcript.segments.reduce((a, s) => a + s.words.length, 0);
    const speakers = new Set(transcript.segments.map((s) => s.speaker).filter(Boolean));
    set('transcript', { status: 'done', detail: `${words} words · ${speakers.size || 1} speaker${speakers.size > 1 ? 's' : ''} · source: ${transcript.source}` });
  } else if (steps.find((s) => s.id === 'transcript')!.status !== 'error') set('transcript', { status: 'skip', detail: inp.localAsr === 'off' ? 'No transcript (on-device subtitles are turned off in Settings)' : 'Subtitles are made on-device for the chosen clips (next steps)' });

  set('visual', { status: 'run' });
  let visual: VisualAnalysis | null = null;
  try {
    visual = await analyzeVisual(inp.url, duration, { faces: inp.faces, maxSamples: duration > 1800 ? 360 : 200 }, (p, l) => set('visual', { progress: p, detail: l }));
    const faceFrames = visual.faces.filter((f) => f.length).length;
    set('visual', { status: 'done', detail: `${visual.times.length} frames · ${visual.sceneCuts.length} scene cuts · faces in ${Math.round((faceFrames / Math.max(1, visual.times.length)) * 100)}% (${visual.faceEngine})` });
  } catch (e) {
    set('visual', { status: 'error', detail: 'Frame sampling failed: ' + (e as Error).message });
  }

  let chat: ChatAnalysis | null = null;
  if (inp.chatLog?.length) {
    set('chat', { status: 'run' });
    chat = analyzeChat(inp.chatLog, duration);
    set('chat', { status: 'done', detail: `${inp.chatLog.length} messages · ${chat.spikes.length} chat explosions · ${chat.events.length} subs/donations` });
  }

  set('score', { status: 'run' });
  await new Promise((r) => setTimeout(r, 30));
  // No transcript yet → pass 1 picks a wider shortlist from audio; after transcribing those regions, pass 2
  // re-picks and re-cuts the clips on real words (hook-first starts, ending on the payoff).
  const asrModel = inp.localAsr ?? 'base';
  const twoPass = !transcript && !!ab && asrModel !== 'off';
  const shortlist = twoPass ? { ...inp.settings, count: Math.min(inp.settings.count * 2, inp.settings.count + 6), maxLen: inp.settings.maxLen + 12 } : inp.settings;
  let clips = findClips({ duration, audio, visual, transcript, chat, markers: inp.markers }, shortlist);
  set('score', { status: 'done', detail: twoPass ? `${clips.length} candidate moments from audio · re-cut on words after subtitles` : `${clips.length} clips · top score ${clips[0]?.score ?? 0}` });

  // free on-device subtitles: transcribe only the shortlisted moments (+ padding for better starts/ends)
  if (twoPass && ab && clips.length) {
    set('subs', { status: 'run', detail: 'Loading speech model…' });
    try {
      const data = ab.getChannelData(0), sr = ab.sampleRate;
      const ranges: { s: number; e: number }[] = [];
      for (const c of [...clips].sort((a, b) => a.start - b.start)) {
        const s = Math.max(0, c.start - 8), e = Math.min(duration, c.end + 8);
        const last = ranges[ranges.length - 1];
        if (last && s <= last.e) last.e = Math.max(last.e, e); else ranges.push({ s, e });
      }
      const segs: Segment[] = [];
      const t0 = performance.now();
      for (let i = 0; i < ranges.length; i++) {
        const r = ranges[i];
        const words = await transcribeLocal(data.subarray(Math.floor(r.s * sr), Math.floor(r.e * sr)), asrModel, inp.language, (p) => {
          if (p.phase === 'download') set('subs', { detail: `Downloading speech model ${p.total ? Math.round(((p.loaded || 0) / p.total) * 100) : 0}% (~${ASR_MODELS[asrModel].mb} MB, first time only — then it's cached)`, progress: p.total ? (p.loaded || 0) / p.total : 0 });
          else set('subs', { detail: `Transcribing clip ${i + 1} of ${ranges.length}…`, progress: i / ranges.length });
        });
        const ws = words.map((w) => ({ w: w.w, s: +(w.s + r.s).toFixed(2), e: +(w.e + r.s).toFixed(2) }));
        if (ws.length) segs.push({ start: r.s, end: r.e, text: ws.map((w) => w.w).join(' '), words: ws });
      }
      const nWords = segs.reduce((a, s) => a + s.words.length, 0);
      if (nWords) {
        transcript = { segments: segs, source: 'local', language: inp.language };
        // pass 2: words are known now → pick the final clips on sentences
        const recut = findClips({ duration, audio, visual, transcript, chat, markers: inp.markers }, inp.settings);
        if (recut.length) clips = recut;
        else {
          const all = segs.flatMap((s) => s.words);
          clips = clips.slice(0, inp.settings.count).map((c) => {
            const text = all.filter((w) => w.s >= c.start && w.s < c.end).map((w) => w.w).join(' ');
            return text ? { ...c, text, title: text.split(/\s+/).length >= 6 ? makeTitle(text) : c.title } : c;
          });
        }
      }
      if (!nWords) clips = clips.slice(0, inp.settings.count);
      set('subs', { status: 'done', detail: nWords ? `${nWords} words in ${Math.round((performance.now() - t0) / 1000)}s · Whisper ${asrModel}, on your device` : 'No speech found in the clips' });
    } catch (e) {
      console.error(e);
      clips = clips.slice(0, inp.settings.count);
      set('subs', { status: 'error', detail: 'Subtitles failed: ' + String((e as Error).message).slice(0, 120) });
    }
  } else set('subs', { status: 'skip', detail: transcript ? 'Already have a transcript' : asrModel === 'off' ? 'Turned off in Settings' : 'No audio' });

  if (inp.llm && transcript && clips.some((c) => c.text) && !freeAIDown()) {
    set('llm', { status: 'run' });
    try {
      const r = await refineClipsWithLLM(clips);
      clips = clips.map((c) => {
        const x = r[c.id];
        if (!x) return c;
        return { ...c, score: Math.round(c.score * 0.8 + x.score * 0.2), title: x.title || c.title, hooks: [x.hook, ...c.hooks.filter((h) => h !== x.hook)].slice(0, 3), reasons: [...c.reasons, x.reason].filter(Boolean) };
      }).sort((a, b) => b.score - a.score);
      set('llm', { status: 'done', detail: `AI wrote hooks & titles for ${Object.keys(r).length} clips` });
    } catch (e) {
      set('llm', { status: 'skip', detail: 'AI unavailable right now, so the built-in hooks are used (' + (e as Error).message.slice(0, 60) + ')' });
    }
  }
  if (inp.llm && !(transcript && clips.some((c) => c.text))) set('llm', { status: 'skip', detail: 'No speech, so no text hooks needed' });
  clips = clips.map((c) => ({ ...c, ...autoLayout(c, visual, meta.width, meta.height) }));
  return { duration, width: meta.width, height: meta.height, audio, visual, transcript, chat, clips };
}

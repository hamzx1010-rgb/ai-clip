import type { AudioAnalysis, ChatAnalysis, ChatMsg, Clip, Transcript, VisualAnalysis } from './types';
import { analyzeAudio, decodeToMono } from './audio';
import { analyzeVisual } from './visual';
import { findClips, type EngineSettings } from './engine';
import { hasAI, loadSampleTranscript, refineClipsWithLLM, transcribeWhisper } from './llm';
import { analyzeChat } from './chat';
import { loadVideoMeta } from './util';

export type StepId = 'load' | 'decode' | 'audio' | 'transcript' | 'visual' | 'chat' | 'score' | 'llm';
export type StepState = { id: StepId; label: string; status: 'wait' | 'run' | 'done' | 'skip' | 'error'; detail?: string; progress?: number };

export type PipelineInput = {
  file: Blob;
  url: string;
  isSample?: boolean;
  transcript?: Transcript | null; // e.g. imported SRT
  transcribe: 'whisper' | 'none';
  language: string;
  faces: boolean;
  llm: boolean;
  chatLog?: ChatMsg[];
  markers?: { t: number; label: string; strength: number }[];
  settings: EngineSettings;
};

export type PipelineResult = {
  duration: number; width: number; height: number;
  audio: AudioAnalysis | null; visual: VisualAnalysis | null; transcript: Transcript | null; chat: ChatAnalysis | null; clips: Clip[];
};

export async function runPipeline(inp: PipelineInput, onStep: (s: StepState[]) => void): Promise<PipelineResult> {
  const steps: StepState[] = [
    { id: 'load', label: 'Reading media & metadata', status: 'wait' },
    { id: 'decode', label: 'Decoding audio track', status: 'wait' },
    { id: 'audio', label: 'Audio intelligence — energy, silence, spikes, crowd reactions', status: 'wait' },
    { id: 'transcript', label: 'Transcription & speaker diarization', status: 'wait' },
    { id: 'visual', label: 'Visual intelligence — faces, scene cuts, motion, quality', status: 'wait' },
    { id: 'chat', label: 'Chat analysis — spam spikes, emotes, subs & donations', status: inp.chatLog?.length ? 'wait' : 'skip' },
    { id: 'score', label: 'Virality scoring & clip selection', status: 'wait' },
    { id: 'llm', label: 'LLM refinement (titles, hooks, re-rank)', status: inp.llm && hasAI() ? 'wait' : 'skip' },
  ];
  const set = (id: StepId, p: Partial<StepState>) => { const s = steps.find((x) => x.id === id)!; Object.assign(s, p); onStep(steps.map((x) => ({ ...x }))); };
  onStep(steps.map((x) => ({ ...x })));

  set('load', { status: 'run' });
  const meta = await loadVideoMeta(inp.url);
  set('load', { status: 'done', detail: `${meta.width}×${meta.height} · ${Math.round(meta.duration)}s` });

  set('decode', { status: 'run' });
  let ab: AudioBuffer | null = null;
  try {
    ab = await decodeToMono(inp.file);
    set('decode', { status: 'done', detail: `${ab.sampleRate / 1000} kHz mono · ${Math.round(ab.duration)}s` });
  } catch (e) {
    set('decode', { status: 'error', detail: 'No decodable audio track — continuing with visuals only' });
  }
  const duration = meta.duration || ab?.duration || 0;

  set('audio', { status: 'run' });
  let audio: AudioAnalysis | null = null;
  if (ab) {
    await new Promise((r) => setTimeout(r, 30));
    audio = analyzeAudio(ab);
    set('audio', { status: 'done', detail: `${audio.spikes.length} spikes · ${audio.silences.length} silences · ${Math.round(audio.loudnessDb)} dBFS avg` });
  } else set('audio', { status: 'skip' });

  set('transcript', { status: 'run' });
  let transcript: Transcript | null = inp.transcript ?? null;
  try {
    if (!transcript && inp.isSample) transcript = await loadSampleTranscript();
    if (!transcript && inp.transcribe === 'whisper' && hasAI() && ab) {
      transcript = await transcribeWhisper(inp.file, inp.language, (p, label) => set('transcript', { detail: label, progress: p }), ab);
    }
  } catch (e) {
    set('transcript', { status: 'error', detail: String((e as Error).message).slice(0, 120) });
  }
  if (transcript) {
    const words = transcript.segments.reduce((a, s) => a + s.words.length, 0);
    const speakers = new Set(transcript.segments.map((s) => s.speaker).filter(Boolean));
    set('transcript', { status: 'done', detail: `${words} words · ${speakers.size || 1} speaker${speakers.size > 1 ? 's' : ''} · source: ${transcript.source}` });
  } else if (steps.find((s) => s.id === 'transcript')!.status !== 'error') set('transcript', { status: 'skip', detail: 'No transcript — add an OpenAI key or import .srt for text-aware scoring & captions' });

  set('visual', { status: 'run' });
  let visual: VisualAnalysis | null = null;
  try {
    visual = await analyzeVisual(inp.url, duration, { faces: inp.faces, maxSamples: duration > 1800 ? 360 : 200 }, (p, l) => set('visual', { progress: p, detail: l }));
    const faceFrames = visual.faces.filter((f) => f.length).length;
    set('visual', { status: 'done', detail: `${visual.times.length} frames · ${visual.sceneCuts.length} scene cuts · faces in ${Math.round((faceFrames / Math.max(1, visual.times.length)) * 100)}% (${visual.faceEngine})` });
  } catch (e) {
    set('visual', { status: 'error', detail: 'Frame sampling failed: ' + (e as Error).message });
  }

  let chat: ChatAnalysis | null = null;
  if (inp.chatLog?.length) {
    set('chat', { status: 'run' });
    chat = analyzeChat(inp.chatLog, duration);
    set('chat', { status: 'done', detail: `${inp.chatLog.length} messages · ${chat.spikes.length} chat explosions · ${chat.events.length} subs/donations` });
  }

  set('score', { status: 'run' });
  await new Promise((r) => setTimeout(r, 30));
  let clips = findClips({ duration, audio, visual, transcript, chat, markers: inp.markers }, inp.settings);
  set('score', { status: 'done', detail: `${clips.length} clips · top score ${clips[0]?.score ?? 0}` });

  if (inp.llm && hasAI() && transcript) {
    set('llm', { status: 'run' });
    try {
      const r = await refineClipsWithLLM(clips);
      clips = clips.map((c) => {
        const x = r[c.id];
        if (!x) return c;
        return { ...c, score: Math.round(c.score * 0.5 + x.score * 0.5), title: x.title || c.title, hooks: [x.hook, ...c.hooks].slice(0, 3), reasons: [x.reason, ...c.reasons] };
      }).sort((a, b) => b.score - a.score);
      set('llm', { status: 'done', detail: 'Re-ranked with LLM judgement' });
    } catch (e) {
      set('llm', { status: 'error', detail: (e as Error).message.slice(0, 120) });
    }
  }
  return { duration, width: meta.width, height: meta.height, audio, visual, transcript, chat, clips };
}

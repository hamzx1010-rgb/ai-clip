import { isPhone, isTouchDevice } from './mobile';
import { autoLayout } from './clipRender';
import type { AudioAnalysis, ChatAnalysis, ChatMsg, Clip, Segment, Transcript, VisualAnalysis, Word } from './types';
import { transcribeLocal, resolveAsr, dropLoops, isLoopy, ASR_MODELS, type LocalAsrModel } from './localAsr';
import { makeTitle } from './nlp';
import { analyzeAudio, decodeToMono } from './audio';
import { analyzeVisual } from './visual';
import { findClips, type EngineSettings } from './engine';
import { freeAIDown } from './director/ai';
import { hasAI, loadSampleTranscript, refineClipsWithLLM, transcribeWhisper } from './llm';
import { analyzeChat } from './chat';
import { loadVideoMeta } from './util';

export type StepId = 'load' | 'decode' | 'audio' | 'transcript' | 'visual' | 'chat' | 'score' | 'subs' | 'llm';
export type StepState = { id: StepId; label: string; status: 'wait' | 'run' | 'done' | 'skip' | 'error'; detail?: string; progress?: number };

export type PipelineInput = {
  file: Blob;
  url: string;
  /** server endpoint that returns a small MP3 of the audio track (linked videos only) */
  audioUrl?: string;
  isSample?: boolean;
  transcript?: Transcript | null; // e.g. imported SRT
  transcribe: 'whisper' | 'none';
  language: string;
  faces: boolean;
  llm: boolean;
  chatLog?: ChatMsg[];
  markers?: { t: number; label: string; strength: number }[];
  settings: EngineSettings;
  /** free on-device subtitles when there is no transcript */
  localAsr?: LocalAsrModel;
};

export type PipelineResult = {
  duration: number; width: number; height: number;
  audio: AudioAnalysis | null; visual: VisualAnalysis | null; transcript: Transcript | null; chat: ChatAnalysis | null; clips: Clip[];
};

export async function runPipeline(inp: PipelineInput, onStep: (s: StepState[]) => void): Promise<PipelineResult> {
  const steps: StepState[] = [
    { id: 'load', label: 'Reading media & metadata', status: 'wait' },
    { id: 'decode', label: 'Decoding audio track', status: 'wait' },
    { id: 'audio', label: 'Audio intelligence — energy, silence, spikes, crowd reactions', status: 'wait' },
    { id: 'transcript', label: 'Transcription & speaker diarization', status: 'wait' },
    { id: 'visual', label: 'Visual intelligence — faces, scene cuts, motion, quality', status: 'wait' },
    { id: 'chat', label: 'Chat analysis — spam spikes, emotes, subs & donations', status: inp.chatLog?.length ? 'wait' : 'skip' },
    { id: 'score', label: 'Virality scoring & clip selection', status: 'wait' },
    { id: 'subs', label: 'Subtitles — on-device Whisper (free, no key)', status: 'wait' },
    { id: 'llm', label: 'AI polish (hooks & titles)', status: inp.llm ? 'wait' : 'skip' },
  ];
  const set = (id: StepId, p: Partial<StepState>) => { const s = steps.find((x) => x.id === id)!; Object.assign(s, p); onStep(steps.map((x) => ({ ...x }))); };
  onStep(steps.map((x) => ({ ...x })));

  set('load', { status: 'run' });
  const meta = await loadVideoMeta(inp.url);
  set('load', { status: 'done', detail: `${meta.width}×${meta.height} · ${Math.round(meta.duration)}s` });

  set('decode', { status: 'run' });
  let ab: AudioBuffer | null = null;
  const viaServer = async () => {
    set('decode', { status: 'run', detail: 'Extracting audio on the server…' });
    const r = await fetch(inp.audioUrl!);
    if (!r.ok) throw new Error('server audio ' + r.status);
    const mp3 = await r.blob();
    if (mp3.size < 1000) throw new Error('empty audio');
    return decodeToMono(mp3);
  };
  try {
    // big linked videos: let the server pull out a ~7 MB audio track instead of decoding hundreds of MB in the browser
    const local = () => decodeToMono(inp.file, undefined, (p) => set('decode', { status: 'run', detail: `Reading the sound… ${Math.round(p * 100)}%`, progress: p }));
    if (inp.audioUrl && inp.file.size > 40e6) { try { ab = await viaServer(); } catch { ab = await local(); } }
    else { try { ab = await local(); } catch (e) { if (inp.audioUrl) ab = await viaServer(); else throw e; } }
    set('decode', { status: 'done', detail: `${ab.sampleRate / 1000} kHz mono · ${Math.round(ab.duration)}s` });
  } catch (e) {
    // last resort for linked videos: let the server extract it even for small files
    if (inp.audioUrl) { try { ab = await viaServer(); set('decode', { status: 'done', detail: `${ab.sampleRate / 1000} kHz mono · ${Math.round(ab.duration)}s (via server)` }); } catch { /* fall through */ } }
    if (!ab) set('decode', { status: 'error', detail: 'This video has no sound track the phone can read, so clips are picked from the picture only. (' + String((e as Error)?.message || e).slice(0, 60) + ')' });
  }
  const duration = meta.duration || ab?.duration || 0;

  set('audio', { status: 'run' });
  let audio: AudioAnalysis | null = null;
  if (ab) {
    await new Promise((r) => setTimeout(r, 30));
    audio = analyzeAudio(ab);
    set('audio', { status: 'done', detail: `${audio.spikes.length} spikes · ${audio.silences.length} silences · ${Math.round(audio.loudnessDb)} dBFS avg` });
  } else set('audio', { status: 'skip' });

  set('transcript', { status: 'run' });
  let transcript: Transcript | null = inp.transcript ?? null;
  try {
    if (!transcript && inp.isSample) transcript = await loadSampleTranscript();
    if (!transcript && inp.transcribe === 'whisper' && hasAI() && ab) {
      transcript = await transcribeWhisper(inp.file, inp.language, (p, label) => set('transcript', { detail: label, progress: p }), ab);
    }
  } catch (e) {
    set('transcript', { status: 'error', detail: String((e as Error).message).slice(0, 120) });
  }
  if (transcript) {
    const words = transcript.segments.reduce((a, s) => a + s.words.length, 0);
    const speakers = new Set(transcript.segments.map((s) => s.speaker).filter(Boolean));
    set('transcript', { status: 'done', detail: `${words} words · ${speakers.size || 1} speaker${speakers.size > 1 ? 's' : ''} · source: ${transcript.source}` });
  } else if (steps.find((s) => s.id === 'transcript')!.status !== 'error') set('transcript', { status: 'skip', detail: inp.localAsr === 'off' ? 'No transcript (on-device subtitles are turned off in Settings)' : 'Subtitles are made on-device for the chosen clips (next steps)' });

  set('visual', { status: 'run' });
  let visual: VisualAnalysis | null = null;
  try {
    visual = await analyzeVisual(inp.url, duration, { faces: inp.faces, maxSamples: isTouchDevice() || isPhone() ? (duration > 1800 ? 180 : 110) : duration > 1800 ? 360 : 200 }, (p, l) => set('visual', { progress: p, detail: l }));
    const faceFrames = visual.faces.filter((f) => f.length).length;
    set('visual', { status: 'done', detail: `${visual.times.length} frames · ${visual.sceneCuts.length} scene cuts · faces in ${Math.round((faceFrames / Math.max(1, visual.times.length)) * 100)}% (${visual.faceEngine})` });
  } catch (e) {
    set('visual', { status: 'error', detail: 'Frame sampling failed: ' + (e as Error).message });
  }

  let chat: ChatAnalysis | null = null;
  if (inp.chatLog?.length) {
    set('chat', { status: 'run' });
    chat = analyzeChat(inp.chatLog, duration);
    set('chat', { status: 'done', detail: `${inp.chatLog.length} messages · ${chat.spikes.length} chat explosions · ${chat.events.length} subs/donations` });
  }

  set('score', { status: 'run' });
  await new Promise((r) => setTimeout(r, 30));
  // No transcript yet → pass 1 picks a wider shortlist from audio; after transcribing those regions, pass 2
  // re-picks and re-cuts the clips on real words (hook-first starts, ending on the payoff).
  const asrModel = resolveAsr(inp.localAsr ?? 'auto');
  const twoPass = !transcript && !!ab && asrModel !== 'off';
  const shortlist = twoPass ? { ...inp.settings, count: inp.settings.count + Math.min(4, Math.ceil(inp.settings.count / 2)) } : inp.settings;
  let clips = findClips({ duration, audio, visual, transcript, chat, markers: inp.markers }, shortlist);
  set('score', { status: 'done', detail: twoPass ? `${clips.length} candidate moments from audio · re-cut on words after subtitles` : `${clips.length} clips · top score ${clips[0]?.score ?? 0}` });

  // free on-device subtitles: transcribe only the shortlisted moments (+ padding for better starts/ends)
  if (twoPass && ab && clips.length) {
    set('subs', { status: 'run', detail: 'Loading speech model…' });
    try {
      const data = ab.getChannelData(0), sr = ab.sampleRate;
      // only transcribe what's needed: the best moments first, a little padding for clean starts/ends,
      // and a hard cap on total seconds (this step is the slow one on phones)
      const PAD = 4, budget = inp.settings.count * 40 + 60;
      const merge = (list: typeof clips) => {
        const rs: { s: number; e: number }[] = [];
        for (const c of [...list].sort((a, b) => a.start - b.start)) {
          const s0 = Math.max(0, c.start - PAD), e0 = Math.min(duration, c.end + PAD);
          const last = rs[rs.length - 1];
          if (last && s0 <= last.e) last.e = Math.max(last.e, e0); else rs.push({ s: s0, e: e0 });
        }
        return rs;
      };
      const total = (rs: { s: number; e: number }[]) => rs.reduce((a, r) => a + r.e - r.s, 0);
      let picked = clips.slice(0, inp.settings.count);
      for (const c of clips.slice(inp.settings.count)) if (total(merge([...picked, c])) <= budget) picked = [...picked, c];
      clips = picked;
      const ranges = merge(picked);
      // cut the audio into ≤ 28 s pieces at the quietest moment → one Whisper window each (no overlapping-window
      // overhead, never splits a word) and a real progress bar
      const pieces: { s: number; e: number; r: number }[] = [];
      ranges.forEach((r, ri) => {
        let s0 = r.s;
        while (r.e - s0 > 28) {
          let best = s0 + 28, bv = Infinity;
          if (audio) for (let t = s0 + 16; t <= s0 + 28; t += audio.hop) { const v = audio.rms[Math.floor(t / audio.hop)] ?? 1; if (v < bv) { bv = v; best = t; } }
          pieces.push({ s: s0, e: best, r: ri }); s0 = best;
        }
        pieces.push({ s: s0, e: r.e, r: ri });
      });
      const secs = pieces.reduce((a, p) => a + p.e - p.s, 0);
      const byRange: Word[][] = ranges.map(() => []);
      const t0 = performance.now();
      let done = 0, tStart = 0;
      const retry: typeof pieces = [];
      for (let i = 0; i < pieces.length; i++) {
        const pc = pieces[i];
        const words = await transcribeLocal(data.subarray(Math.floor(pc.s * sr), Math.floor(pc.e * sr)), asrModel, inp.language, (p) => {
          if (p.phase === 'download') set('subs', { detail: `Downloading speech model ${p.total ? Math.round(((p.loaded || 0) / p.total) * 100) : 0}% (~${ASR_MODELS[asrModel].mb} MB, first time only, then it's cached)`, progress: p.total ? (p.loaded || 0) / p.total : 0 });
          else {
            if (!tStart) tStart = performance.now();
            const rate = done > 0 ? (performance.now() - tStart) / 1000 / done : 0; // seconds of work per second of audio
            const left = rate ? Math.round(rate * (secs - done)) : 0;
            set('subs', { detail: `Transcribing ${Math.round(done)}s of ${Math.round(secs)}s of speech${left ? ` · about ${left >= 90 ? Math.round(left / 60) + ' min' : left + 's'} left` : ''}`, progress: done / secs });
          }
        });
        done += pc.e - pc.s;
        if (isLoopy(words)) { retry.push(pc); continue; } // the fast model got stuck in a loop → redo with the accurate one
        for (const w of dropLoops(words)) if (/[\p{L}\p{N}]/u.test(w.w)) byRange[pc.r].push({ w: w.w, s: +(w.s + pc.s).toFixed(2), e: +(w.e + pc.s).toFixed(2) });
      }
      if (retry.length && asrModel === 'tiny') {
        for (let i = 0; i < retry.length; i++) {
          const pc = retry[i];
          set('subs', { detail: `Double-checking ${retry.length - i} unclear part${retry.length - i > 1 ? 's' : ''} with the accurate model…`, progress: 0.95 });
          const words = await transcribeLocal(data.subarray(Math.floor(pc.s * sr), Math.floor(pc.e * sr)), 'base', inp.language, (p) => {
            if (p.phase === 'download') set('subs', { detail: `Getting the accurate model for ${retry.length} unclear part${retry.length > 1 ? 's' : ''} (~76 MB, once) ${p.total ? Math.round(((p.loaded || 0) / p.total) * 100) : 0}%` });
          });
          if (isLoopy(words)) continue; // still garbage → leave this bit out
          for (const w of dropLoops(words)) if (/[\p{L}\p{N}]/u.test(w.w)) byRange[pc.r].push({ w: w.w, s: +(w.s + pc.s).toFixed(2), e: +(w.e + pc.s).toFixed(2) });
        }
        byRange.forEach((ws) => ws.sort((a, b) => a.s - b.s));
      }
      const segs: Segment[] = [];
      ranges.forEach((r, ri) => { const ws = byRange[ri]; if (ws.length) segs.push({ start: r.s, end: r.e, text: ws.map((w) => w.w).join(' '), words: ws }); });
      const nWords = segs.reduce((a, s) => a + s.words.length, 0);
      if (nWords) {
        transcript = { segments: segs, source: 'local', language: inp.language };
        // pass 2: words are known now → pick the final clips on sentences
        const recut = findClips({ duration, audio, visual, transcript, chat, markers: inp.markers }, inp.settings);
        if (recut.length) clips = recut;
        else {
          const all = segs.flatMap((s) => s.words);
          clips = clips.slice(0, inp.settings.count).map((c) => {
            const text = all.filter((w) => w.s >= c.start && w.s < c.end).map((w) => w.w).join(' ');
            return text ? { ...c, text, title: text.split(/\s+/).length >= 6 ? makeTitle(text) : c.title } : c;
          });
        }
      }
      if (!nWords) clips = clips.slice(0, inp.settings.count);
      set('subs', { status: 'done', detail: nWords ? `${nWords} words in ${Math.round((performance.now() - t0) / 1000)}s · Whisper ${asrModel}, on your device` : 'No speech found in the clips' });
    } catch (e) {
      console.error(e);
      clips = clips.slice(0, inp.settings.count);
      set('subs', { status: 'error', detail: 'Subtitles failed: ' + String((e as Error).message).slice(0, 120) });
    }
  } else set('subs', { status: 'skip', detail: transcript ? 'Already have a transcript' : asrModel === 'off' ? 'Turned off in Settings' : 'No audio' });

  if (inp.llm && transcript && clips.some((c) => c.text) && !freeAIDown()) {
    set('llm', { status: 'run' });
    try {
      const r = await refineClipsWithLLM(clips);
      clips = clips.map((c) => {
        const x = r[c.id];
        if (!x) return c;
        return { ...c, score: Math.round(c.score * 0.8 + x.score * 0.2), title: x.title || c.title, hooks: [x.hook, ...c.hooks.filter((h) => h !== x.hook)].slice(0, 3), reasons: [...c.reasons, x.reason].filter(Boolean) };
      }).sort((a, b) => b.score - a.score);
      set('llm', { status: 'done', detail: `AI wrote hooks & titles for ${Object.keys(r).length} clips` });
    } catch (e) {
      set('llm', { status: 'skip', detail: 'AI unavailable right now, so the built-in hooks are used (' + (e as Error).message.slice(0, 60) + ')' });
    }
  }
  if (inp.llm && !(transcript && clips.some((c) => c.text))) set('llm', { status: 'skip', detail: 'No speech, so no text hooks needed' });
  clips = clips.map((c) => ({ ...c, ...autoLayout(c, visual, meta.width, meta.height) }));
  return { duration, width: meta.width, height: meta.height, audio, visual, transcript, chat, clips };
}

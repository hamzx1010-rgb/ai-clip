/**
 * Engine B — canvas.captureStream + MediaRecorder, in real time.
 *
 * This is the path that historically produced "no footage after second 11".
 * What actually happens on a phone:
 *
 *   1. requestVideoFrameCallback stops firing (decoder hiccup, tab throttled,
 *      or the source stalls while buffered data runs out);
 *   2. the drawing loop stops, so the canvas keeps the last picture;
 *   3. captureStream keeps producing frames AT THE WALL-CLOCK RATE anyway, so
 *      MediaRecorder happily records the frozen picture while audio marches on;
 *   4. the file looks fine in the UI and freezes at ~11s when played.
 *
 * The fixes here:
 *   - a watchdog measures how far the source has really advanced against how
 *     far the recording has advanced, and notices a stall in ~700 ms;
 *   - on a stall we pause, nudge the source forward past the stuck frame and
 *     resume — we never record the frozen picture;
 *   - if a stall cannot be recovered, the export FAILS LOUDLY so the caller can
 *     rebuild the clip with the other engine instead of shipping it;
 *   - every drawn frame is hashed, so we can report how many DISTINCT pictures
 *     really went in, and how long the longest freeze was;
 *   - page visibility changes pause cleanly and resume.
 */

import { cropRect } from './analyze';
import { framesExpectedFor, type ExportJob, type ExportResult } from './export-types';
import { grayDiff, rgbaToGray } from './frames';
import { remuxWithSourceAudio } from './remux-audio';

export function recorderSupported(): boolean {
  return typeof MediaRecorder !== 'undefined';
}

/** Pick a codec this browser can really record. */
export function pickRecorderMime(): string {
  const candidates = [
    'video/mp4;codecs="avc1.42E01E,mp4a.40.2"', // Chrome 126+ / Brave on Android
    'video/mp4;codecs=avc1.42E01E',
    'video/mp4',
    'video/webm;codecs="vp9,opus"',
    'video/webm;codecs="vp8,opus"',
    'video/webm;codecs=vp9',
    'video/webm;codecs=vp8',
    'video/webm',
  ];
  for (const c of candidates) {
    try {
      if (MediaRecorder.isTypeSupported(c)) return c;
    } catch {
      /* ignore */
    }
  }
  return '';
}

interface StallState {
  stalls: number;
  longestFreezeSec: number;
}

export async function exportRealtime(job: ExportJob): Promise<ExportResult> {
  const t0 = performance.now();
  const notes: string[] = [];
  const { width, height, fps, start, end } = job;
  const duration = Math.max(0.04, end - start);
  const wantFrames = framesExpectedFor(duration, fps);

  if (!recorderSupported()) throw new Error('This browser has no MediaRecorder');
  const mime = pickRecorderMime();
  if (!mime) throw new Error('No recordable video format in this browser');

  /* ---------------- elements ---------------- */
  const video = document.createElement('video');
  video.src = job.srcUrl;
  video.muted = false;
  video.volume = 0; // keep audio flowing to the graph without making noise
  video.playsInline = true;
  video.preload = 'auto';
  video.crossOrigin = 'anonymous';
  video.style.cssText =
    'position:fixed;left:-9999px;top:0;width:2px;height:2px;opacity:0.01;pointer-events:none;';
  document.body.appendChild(video);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) throw new Error('Could not get a drawing surface');
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, width, height);

  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('The source video did not start in time')), 25000);
    const ok = () => {
      clearTimeout(timer);
      resolve();
    };
    video.addEventListener('loadeddata', ok, { once: true });
    video.addEventListener('error', () => {
      clearTimeout(timer);
      reject(new Error('The source video failed to load'));
    }, { once: true });
  });

  const srcW = video.videoWidth || width;
  const srcH = video.videoHeight || height;
  const crop = cropRect(srcW, srcH, width, height, job.layout, job.faceCenter);

  /* ---------------- audio graph ---------------- */
  let hasAudioTrack = false;
  let audioCtx: AudioContext | null = null;
  let dest: MediaStreamAudioDestinationNode | null = null;
  // captureStream(0) = manual mode: a picture is only handed to the recorder
  // when we call requestFrame(). With captureStream(fps) Chrome samples the
  // canvas on its own clock, and on a busy phone (or in a headless test) that
  // clock lands at about half the intended rate - a 30 fps clip came out with
  // 78 pictures in 5 s. Manual mode makes the recorded frame count match the
  // number of pictures we actually drew.
  const stream = canvas.captureStream(0);
  const manualTrack = stream.getVideoTracks()[0] as
    | (MediaStreamTrack & { requestFrame?: () => void })
    | undefined;
  try {
    const Ctor: typeof AudioContext =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (Ctor) {
      audioCtx = new Ctor();
      const srcNode = audioCtx.createMediaElementSource(video);
      dest = audioCtx.createMediaStreamDestination();
      const mute = audioCtx.createGain();
      mute.gain.value = 0; // never play out loud on the phone
      srcNode.connect(dest);
      srcNode.connect(mute).connect(audioCtx.destination);
      for (const t of dest.stream.getAudioTracks()) {
        stream.addTrack(t);
        hasAudioTrack = true;
      }
      if (audioCtx.state === 'suspended') await audioCtx.resume();
    }
  } catch (e) {
    notes.push('Audio capture unavailable — the clip will be silent');
    audioCtx = null;
  }

  /* ---------------- recorder ---------------- */
  const chunks: BlobPart[] = [];
  const recorder = new MediaRecorder(stream, {
    mimeType: mime,
    videoBitsPerSecond: job.videoBitrate ?? Math.min(6_000_000, Math.max(1_200_000, width * height * fps * 0.085)),
    audioBitsPerSecond: job.audioBitrate ?? 128_000,
  });
  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size) chunks.push(e.data);
  };

  /* ---------------- frame counting + freeze detection ---------------- */
  let distinctFrames = 0;
  let drawnFrames = 0;
  let prevGray: Uint8ClampedArray | null = null;
  let freezeRunStart: number | null = null;
  const stall: StallState = { stalls: 0, longestFreezeSec: 0 };
  const probeCanvas = document.createElement('canvas');
  probeCanvas.width = 32;
  probeCanvas.height = 32;
  const probeCtx = probeCanvas.getContext('2d', { willReadFrequently: true });

  const countDraw = (mediaTime: number) => {
    drawnFrames++;
    if (!probeCtx) return;
    try {
      probeCtx.drawImage(canvas, 0, 0, 32, 32);
      const img = probeCtx.getImageData(0, 0, 32, 32);
      const gray = rgbaToGray(img.data, 32, 32);
      if (prevGray) {
        const d = grayDiff(prevGray, gray);
        if (d > 0.6) {
          distinctFrames++;
          if (freezeRunStart !== null) {
            const run = mediaTime - freezeRunStart;
            if (run > stall.longestFreezeSec) stall.longestFreezeSec = run;
            freezeRunStart = null;
          }
        } else if (freezeRunStart === null) {
          freezeRunStart = mediaTime;
        }
      } else {
        distinctFrames++;
      }
      prevGray = gray;
    } catch {
      /* ignore */
    }
  };

  /* ---------------- seek to the start ---------------- */
  await seek(video, start);

  /* ---------------- the run ---------------- */
  recorder.start();
  const recordStart = performance.now();

  let stopped = false;
  let failure: string | null = null;

  const drawLoop = () => {
    if (stopped) return;
    ctx.drawImage(video, crop.sx, crop.sy, crop.sw, crop.sh, 0, 0, width, height);
    if (job.burnTitle) drawTitle(ctx, job.burnTitle, width, height, video.currentTime - start, fps);
    // Hand this exact picture to the recorder.
    try {
      manualTrack?.requestFrame?.();
    } catch {
      /* ignore */
    }
    countDraw(video.currentTime - start);
    const frac = Math.min(1, (video.currentTime - start) / duration);
    job.onProgress?.(0.05 + frac * 0.9, `Recording ${Math.max(0, video.currentTime - start).toFixed(1)}s of ${duration.toFixed(1)}s`);
  };

  // Real frame callbacks when available — this is how we KNOW a frame arrived.
  let lastRvfc = performance.now();
  let rvfcActive = false;
  const anyVideo = video as HTMLVideoElement & {
    requestVideoFrameCallback?: (cb: (now: number, meta: { mediaTime: number }) => void) => number;
    cancelVideoFrameCallback?: (h: number) => void;
  };

  const rvfcStep = () => {
    if (stopped) return;
    lastRvfc = performance.now();
    rvfcActive = true;
    drawLoop();
    if (video.currentTime < end - 0.02) anyVideo.requestVideoFrameCallback?.(rvfcStep);
  };
  if (anyVideo.requestVideoFrameCallback) anyVideo.requestVideoFrameCallback(rvfcStep);

  // Fallback / companion timer: draws even if rvfc goes quiet, and lets the
  // watchdog tell the difference between "slow" and "frozen".
  const timer = setInterval(() => {
    if (stopped) return;
    if (!rvfcActive || performance.now() - lastRvfc > 260) drawLoop();
  }, Math.max(16, Math.round(1000 / fps)));

  /* ---------------- watchdog ---------------- */
  let stallSince: number | null = null;
  let lastMediaTime = video.currentTime;
  let pausedForHidden = false;
  let pausedAt = 0;
  let hiddenAccumMs = 0;

  const onVisibility = () => {
    if (document.visibilityState === 'hidden') {
      // Pause cleanly: we will not record a frozen picture while hidden.
      pausedForHidden = true;
      pausedAt = performance.now();
      try {
        video.pause();
        recorder.pause?.();
      } catch {
        /* ignore */
      }
    } else if (pausedForHidden) {
      pausedForHidden = false;
      hiddenAccumMs += performance.now() - pausedAt;
      try {
        recorder.resume?.();
        void video.play();
      } catch {
        /* ignore */
      }
    }
  };
  document.addEventListener('visibilitychange', onVisibility);

  const watchdog = setInterval(async () => {
    if (stopped || pausedForHidden) return;
    const media = video.currentTime;
    const advanced = media - lastMediaTime;
    lastMediaTime = media;

    if (media >= end - 0.04) return; // normal end
    if (advanced > 0.03) {
      stallSince = null;
      return;
    }

    // The source has not moved. Is it a stall, or just a slow phone?
    if (stallSince === null) {
      stallSince = performance.now();
      return;
    }
    const stuckFor = performance.now() - stallSince;
    if (stuckFor < 700) return;

    stall.stalls++;
    stallSince = null;

    // Recover: pause, step past the stuck frame, resume.
    try {
      video.pause();
      const nudged = Math.min(end, media + 0.12);
      await seek(video, nudged, 3000);
      await video.play();
      lastRvfc = performance.now();
      if (anyVideo.requestVideoFrameCallback) anyVideo.requestVideoFrameCallback(rvfcStep);
    } catch {
      // Could not recover — fail loudly rather than ship a frozen file.
      failure =
        `The video stopped moving at ${(media - start).toFixed(1)}s and could not be resumed. ` +
        `Recording was abandoned so you would not get a frozen clip.`;
      stopEverything();
    }
  }, 250);

  /* ---------------- wait for the end ---------------- */
  try {
    await video.play();
  } catch (e) {
    failure = `Playback was blocked (${(e as Error).message}). Tap the page once and try again.`;
  }

  let checkTimer: ReturnType<typeof setInterval> | null = null;
  let resolveDone: (() => void) | null = null;
  const donePromise = new Promise<void>((resolve) => {
    resolveDone = resolve;
  });

  /** Single place that stops the run — used by the watchdog AND the end check. */
  const stopEverything = () => {
    if (stopped) return;
    stopped = true;
    if (checkTimer) clearInterval(checkTimer);
    clearInterval(timer);
    clearInterval(watchdog);
    document.removeEventListener('visibilitychange', onVisibility);
    resolveDone?.();
  };

  checkTimer = setInterval(() => {
    if (stopped) return resolveDone?.();
    if (failure) return stopEverything();
    if (pausedForHidden) return;
    if (video.currentTime >= end - 0.03 || video.ended) stopEverything();
    if (job.signal?.aborted) {
      failure = 'Stopped';
      stopEverything();
    }
  }, 60);

  await donePromise;
  stopEverything();

  // Give the recorder a beat to flush the tail, then stop it.
  await new Promise((r) => setTimeout(r, 140));
  const stopped_p = new Promise<void>((resolve) => {
    recorder.onstop = () => resolve();
    setTimeout(resolve, 2500);
  });
  try {
    if (recorder.state !== 'inactive') recorder.stop();
  } catch {
    /* ignore */
  }
  await stopped_p;

  stream.getTracks().forEach((t) => t.stop());
  try {
    void audioCtx?.close();
  } catch {
    /* ignore */
  }
  video.pause();
  video.removeAttribute('src');
  video.load();
  video.remove();

  if (failure) throw new Error(failure);

  const blob = new Blob(chunks, { type: mime.split(';')[0] });
  const wallSec = (performance.now() - recordStart - hiddenAccumMs) / 1000;

  if (blob.size < 2048) throw new Error('The recorder produced an empty file');
  if (wallSec < duration * 0.75) {
    throw new Error(
      `Recording stopped early at ${wallSec.toFixed(1)}s of ${duration.toFixed(1)}s — not shipping a short clip`,
    );
  }
  if (distinctFrames < Math.max(3, wantFrames * 0.12)) {
    throw new Error(
      `Only ${distinctFrames} distinct pictures were captured in ${wallSec.toFixed(1)}s — the video was frozen, so the clip was discarded`,
    );
  }
  if (stall.longestFreezeSec > Math.min(2.0, duration * 0.25)) {
    throw new Error(
      `The picture stopped changing for ${stall.longestFreezeSec.toFixed(1)}s — the clip was discarded instead of being shipped frozen`,
    );
  }
  if (stall.stalls > 0) notes.push(`Recovered from ${stall.stalls} stall${stall.stalls > 1 ? 's' : ''}`);
  if (hiddenAccumMs > 500) notes.push(`Paused ${(hiddenAccumMs / 1000).toFixed(1)}s while the tab was hidden`);

  job.onProgress?.(1, 'Recording complete');

  /* ---------------- put the source's own sound in ----------------
     The live audio graph above is silent in several real situations (no audio
     device, an AudioContext that needs a tap, a video that is being seeked
     rather than played), so the finished recording is re-packaged with the AAC
     frames copied out of the source. If that cannot be done the recording is
     returned unchanged and the verifier will catch the silence. */
  let finalBlob = blob;
  let finalFrames = drawnFrames;
  let audioWritten = hasAudioTrack;
  try {
    const rx = await remuxWithSourceAudio(blob, job, notes);
    if (rx.ok) {
      finalBlob = rx.blob;
      finalFrames = rx.framesWritten || drawnFrames;
      audioWritten = rx.audioFrames >= 2;
    } else if (rx.note) {
      notes.push(rx.note);
    }
  } catch (e) {
    notes.push(`Could not re-package the recording: ${String((e as Error)?.message ?? e).slice(0, 140)}`);
  }

  return {
    blob: finalBlob,
    mime: finalBlob.type || mime.split(';')[0],
    engine: 'mediarecorder-webm',
    framesDecoded: drawnFrames,
    framesWritten: finalFrames,
    framesExpected: wantFrames,
    duration: wallSec,
    audioWritten,
    audioAttempted: hasAudioTrack,
    elapsedMs: Math.round(performance.now() - t0),
    stallsRecovered: stall.stalls,
    notes: [...notes, `${distinctFrames} distinct pictures over ${wallSec.toFixed(1)}s`],
  };
}

/* ------------------------------------------------------------------ */

function seek(v: HTMLVideoElement, t: number, timeoutMs = 9000): Promise<void> {
  return new Promise((resolve, reject) => {
    if (Math.abs(v.currentTime - t) < 0.01) return resolve();
    const timer = setTimeout(() => {
      v.removeEventListener('seeked', onSeeked);
      reject(new Error('Seeking took too long'));
    }, timeoutMs);
    function onSeeked() {
      clearTimeout(timer);
      v.removeEventListener('seeked', onSeeked);
      resolve();
    }
    v.addEventListener('seeked', onSeeked, { once: true });
    try {
      v.currentTime = t;
    } catch (e) {
      clearTimeout(timer);
      v.removeEventListener('seeked', onSeeked);
      reject(e instanceof Error ? e : new Error('Seek failed'));
    }
  });
}

function drawTitle(
  ctx: CanvasRenderingContext2D,
  title: string,
  w: number,
  h: number,
  elapsed: number,
  fps: number,
) {
  void fps;
  if (elapsed > 3.2) return;
  const pad = Math.round(w * 0.06);
  const size = Math.round(w * 0.072);
  ctx.font = `700 ${size}px system-ui, -apple-system, Segoe UI, Roboto, sans-serif`;
  ctx.textBaseline = 'top';
  const words = title.split(/\s+/);
  const lines: string[] = [];
  let cur = '';
  for (const word of words) {
    const test = cur ? `${cur} ${word}` : word;
    if (ctx.measureText(test).width > w - pad * 2 && cur) {
      lines.push(cur);
      cur = word;
    } else cur = test;
  }
  if (cur) lines.push(cur);
  const lineH = Math.round(size * 1.25);
  const blockH = Math.min(3, lines.length) * lineH;
  const y0 = h - pad - blockH - Math.round(h * 0.06);
  ctx.fillStyle = '#000';
  ctx.fillRect(pad - 8, y0 - 8, w - (pad - 8) * 2, blockH + 16);
  ctx.fillStyle = '#fff';
  lines.slice(0, 3).forEach((ln, i) => ctx.fillText(ln, pad, y0 + i * lineH));
}

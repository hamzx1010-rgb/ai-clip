/**
 * Does this clip actually show a person?
 *
 * Uses the browser's built-in FaceDetector when it exists (Chrome/Brave on
 * Android usually have it). If not, ClipForge says "no face" and falls back to
 * full-frame — a wrong crop is worse than no crop.
 */

import type { FaceHit } from './types';

type DetectorLike = {
  detect: (src: CanvasImageSource) => Promise<Array<{ boundingBox: DOMRectReadOnly; landmarks?: unknown[] }>>;
};

let detector: DetectorLike | null | undefined;
let detectorBroken = false;

export function faceDetectorAvailable(): boolean {
  const Ctor = (window as unknown as { FaceDetector?: new (o?: unknown) => DetectorLike }).FaceDetector;
  return typeof Ctor === 'function';
}

function getDetector(): DetectorLike | null {
  if (detector !== undefined) return detector;
  const Ctor = (window as unknown as { FaceDetector?: new (o?: unknown) => DetectorLike }).FaceDetector;
  if (!Ctor) {
    detector = null;
    return null;
  }
  try {
    detector = new Ctor({ fastMode: true, maxDetectedFaces: 4 });
  } catch {
    detector = null;
  }
  return detector;
}

/** Detect faces in the current frame of a video element. */
export async function detectFacesIn(
  v: HTMLVideoElement,
  workCanvas?: HTMLCanvasElement,
  maxSide = 480,
): Promise<FaceHit[]> {
  if (detectorBroken) return [];
  const d = getDetector();
  const w = v.videoWidth;
  const h = v.videoHeight;
  if (!d || !w || !h) return [];

  const scale = Math.min(1, maxSide / Math.max(w, h));
  const cw = Math.max(2, Math.round(w * scale));
  const ch = Math.max(2, Math.round(h * scale));
  const c = workCanvas ?? document.createElement('canvas');
  c.width = cw;
  c.height = ch;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  if (!ctx) return [];
  try {
    ctx.drawImage(v, 0, 0, cw, ch);
  } catch {
    return [];
  }

  try {
    const found = await d.detect(c);
    return (found || []).map((f) => ({
      x: f.boundingBox.x / cw,
      y: f.boundingBox.y / ch,
      w: f.boundingBox.width / cw,
      h: f.boundingBox.height / ch,
      confidence: 1,
    }));
  } catch {
    // Some builds throw when the GPU path is unavailable. Stop trying.
    detectorBroken = true;
    return [];
  }
}

/**
 * Sample a time range for faces and decide the layout for THIS clip only.
 * Returns the smoothed centre to crop around, plus how often a face appeared.
 */
export async function scanFacesForRange(
  v: HTMLVideoElement,
  from: number,
  to: number,
  opts: { samples?: number; signal?: AbortSignal } = {},
): Promise<{
  hits: FaceHit[];
  ratio: number;
  hasFace: boolean;
  center: { x: number; y: number } | null;
  framesChecked: number;
}> {
  const n = Math.max(3, opts.samples ?? 7);
  const canvas = document.createElement('canvas');
  const hits: FaceHit[] = [];
  let withFace = 0;
  let checked = 0;

  for (let i = 0; i < n; i++) {
    if (opts.signal?.aborted) break;
    const t = from + ((to - from) * (i + 0.5)) / n;
    try {
      await seekAndSettle(v, t);
    } catch {
      continue;
    }
    checked++;
    const f = await detectFacesIn(v, canvas);
    if (f.length) {
      withFace++;
      hits.push(...f);
    }
    if (i % 2 === 1) await new Promise((r) => setTimeout(r, 0));
  }

  const ratio = checked ? withFace / checked : 0;
  // Require a solid majority: a face that flickers past for one frame should not
  // force a tight crop on the whole clip.
  const hasFace = checked > 0 && ratio >= 0.5 && hits.length >= 2;

  let center: { x: number; y: number } | null = null;
  if (hasFace) {
    let sx = 0;
    let sy = 0;
    for (const h of hits) {
      sx += h.x + h.w / 2;
      sy += h.y + h.h * 0.42; // bias to the eyes, not the chin
    }
    center = { x: sx / hits.length, y: sy / hits.length };
  }

  return { hits, ratio, hasFace, center, framesChecked: checked };
}

function seekAndSettle(v: HTMLVideoElement, t: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      v.removeEventListener('seeked', onSeeked);
      reject(new Error('seek timeout'));
    }, 6000);
    function onSeeked() {
      clearTimeout(timer);
      v.removeEventListener('seeked', onSeeked);
      resolve();
    }
    v.addEventListener('seeked', onSeeked, { once: true });
    try {
      v.currentTime = Math.max(0, t);
    } catch (e) {
      clearTimeout(timer);
      reject(e instanceof Error ? e : new Error('seek failed'));
    }
  });
}

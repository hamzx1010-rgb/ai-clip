// Client for the on-device Whisper worker.
import type { Word } from './types';
import { isPhone, isTouchDevice } from './mobile';

export type LocalAsrModel = 'auto' | 'tiny' | 'base' | 'off';
/** auto = the fast model on phones (≈4× quicker on a phone CPU), the accurate one on computers */
export const resolveAsr = (m: LocalAsrModel): 'tiny' | 'base' | 'off' => (m === 'auto' ? (isTouchDevice() || isPhone() ? 'tiny' : 'base') : m);
export const ASR_MODELS: Record<'tiny' | 'base', { id: string; label: string; mb: number }> = {
  tiny: { id: 'onnx-community/whisper-tiny_timestamped', label: 'Fast (tiny)', mb: 40 },
  base: { id: 'onnx-community/whisper-base_timestamped', label: 'Accurate (base)', mb: 76 },
};

let worker: Worker | null = null;
let seq = 0;

function getWorker(): Worker {
  if (!worker) worker = new Worker(new URL('./whisper.worker.ts', import.meta.url), { type: 'module' });
  return worker;
}

export type AsrProgress = { phase: 'download' | 'transcribe'; loaded?: number; total?: number };

/** Transcribe 16 kHz mono audio. Word timestamps are relative to the start of `audio`. */
export function transcribeLocal(audio: Float32Array, model: 'tiny' | 'base', language: string, onProgress?: (p: AsrProgress) => void): Promise<Word[]> {
  const w = getWorker();
  const id = ++seq;
  return new Promise((resolve, reject) => {
    const h = (e: MessageEvent) => {
      const m = e.data;
      if (m.type === 'download') { onProgress?.({ phase: 'download', loaded: m.loaded, total: m.total }); return; }
      if (m.id !== id) return;
      if (m.type === 'ready') onProgress?.({ phase: 'transcribe' });
      else if (m.type === 'result') { w.removeEventListener('message', h); resolve(m.words as Word[]); }
      else if (m.type === 'error') { w.removeEventListener('message', h); reject(new Error(m.error)); }
    };
    w.addEventListener('message', h);
    const copy = audio.slice();
    w.postMessage({ id, type: 'transcribe', audio: copy, model: ASR_MODELS[model].id, language }, [copy.buffer]);
  });
}

/**
 * Small Whisper models sometimes get stuck in a loop ("And that's the best way to do that." ×10).
 * Keep the first occurrence of any sentence that repeats back-to-back, and drop a piece that is still
 * mostly repetition afterwards (its timings are garbage too).
 */
export function dropLoops(words: Word[]): Word[] {
  if (words.length < 8) return words;
  const norm = (w: string) => w.toLowerCase().replace(/[^a-z0-9']/g, '');
  // split into sentences
  const sents: Word[][] = [];
  let cur: Word[] = [];
  for (const w of words) { cur.push(w); if (/[.?!]["']?$/.test(w.w)) { sents.push(cur); cur = []; } }
  if (cur.length) sents.push(cur);
  const key = (s: Word[]) => s.map((w) => norm(w.w)).join(' ');
  const out: Word[][] = [];
  const seen = new Map<string, number>();
  for (const s of sents) {
    const k = key(s);
    const n = (seen.get(k) || 0) + 1;
    seen.set(k, n);
    if (k.split(' ').length >= 3 && n >= 2 && out.length && key(out[out.length - 1]) === k) continue; // back-to-back repeat
    if (k.split(' ').length >= 4 && n >= 3) continue; // same sentence a 3rd time in one window = loop
    out.push(s);
  }
  const flat = out.flat();
  // still looping inside a sentence (no punctuation)? measure repeated 4-grams
  const toks = flat.map((w) => norm(w.w));
  const grams = new Map<string, number>();
  let rep = 0;
  for (let i = 0; i + 4 <= toks.length; i++) { const g = toks.slice(i, i + 4).join(' '); const c = (grams.get(g) || 0) + 1; grams.set(g, c); if (c >= 2) rep++; }
  if (toks.length >= 16 && rep / (toks.length - 3) > 0.35) return [];
  return flat;
}

/** fuzzy loop detector: many sentences starting the same way, or lots of repeated 3-word chunks */
export function isLoopy(words: Word[]): boolean {
  const toks = words.map((w) => w.w.toLowerCase().replace(/[^a-z0-9']/g, '')).filter(Boolean);
  if (toks.length < 12) return false;
  const seen = new Set<string>();
  let rep = 0;
  for (let i = 0; i + 3 <= toks.length; i++) { const g = toks.slice(i, i + 3).join(' '); if (seen.has(g)) rep++; else seen.add(g); }
  if (rep / (toks.length - 2) > 0.3) return true;
  const sents: string[][] = [];
  let cur: string[] = [];
  words.forEach((w) => { const t = w.w.toLowerCase().replace(/[^a-z0-9']/g, ''); if (t) cur.push(t); if (/[.?!,]["']?$/.test(w.w)) { if (cur.length) sents.push(cur); cur = []; } });
  if (cur.length) sents.push(cur);
  const pre = new Map<string, number>();
  for (const s of sents) if (s.length >= 3) { const k = s.slice(0, 3).join(' '); pre.set(k, (pre.get(k) || 0) + 1); }
  const maxPre = Math.max(0, ...pre.values());
  return maxPre >= 3 && maxPre / Math.max(1, sents.length) >= 0.25;
}

// Client for the on-device Whisper worker.
import type { Word } from './types';

export type LocalAsrModel = 'tiny' | 'base' | 'off';
export const ASR_MODELS: Record<Exclude<LocalAsrModel, 'off'>, { id: string; label: string; mb: number }> = {
  tiny: { id: 'onnx-community/whisper-tiny_timestamped', label: 'Fast (tiny)', mb: 40 },
  base: { id: 'onnx-community/whisper-base_timestamped', label: 'Accurate (base)', mb: 76 },
};

let worker: Worker | null = null;
let seq = 0;

function getWorker(): Worker {
  if (!worker) worker = new Worker(new URL('./whisper.worker.ts', import.meta.url), { type: 'module' });
  return worker;
}

export type AsrProgress = { phase: 'download' | 'transcribe'; loaded?: number; total?: number };

/** Transcribe 16 kHz mono audio. Word timestamps are relative to the start of `audio`. */
export function transcribeLocal(audio: Float32Array, model: Exclude<LocalAsrModel, 'off'>, language: string, onProgress?: (p: AsrProgress) => void): Promise<Word[]> {
  const w = getWorker();
  const id = ++seq;
  return new Promise((resolve, reject) => {
    const h = (e: MessageEvent) => {
      const m = e.data;
      if (m.type === 'download') { onProgress?.({ phase: 'download', loaded: m.loaded, total: m.total }); return; }
      if (m.id !== id) return;
      if (m.type === 'ready') onProgress?.({ phase: 'transcribe' });
      else if (m.type === 'result') { w.removeEventListener('message', h); resolve(m.words as Word[]); }
      else if (m.type === 'error') { w.removeEventListener('message', h); reject(new Error(m.error)); }
    };
    w.addEventListener('message', h);
    const copy = audio.slice();
    w.postMessage({ id, type: 'transcribe', audio: copy, model: ASR_MODELS[model].id, language }, [copy.buffer]);
  });
}

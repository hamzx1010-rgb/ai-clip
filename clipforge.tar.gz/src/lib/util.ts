export const uid = (p = '') => p + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
export const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export function fmtTime(s: number, ms = false): string {
  if (!isFinite(s) || s < 0) s = 0;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  const base = (h ? h + ':' + String(m).padStart(2, '0') : String(m)) + ':' + String(sec).padStart(2, '0');
  if (!ms) return base;
  return base + '.' + String(Math.floor((s % 1) * 10));
}

export function fmtBytes(b: number): string {
  if (b < 1024) return b + ' B';
  const u = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  do { b /= 1024; i++; } while (b >= 1024 && i < u.length - 1);
  return b.toFixed(b < 10 ? 1 : 0) + ' ' + u[i];
}

export function download(blob: Blob, name: string) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
  // Keep the file alive for a long time: on Android the browser may ask "Download?" first and then copy the file
  // slowly. Freeing it after a few seconds gave broken / 0-byte downloads.
  setTimeout(() => URL.revokeObjectURL(a.href), 10 * 60_000);
}

/** Android share sheet (save to gallery / send to TikTok, YouTube…). False if not supported. */
export function canShareFile(blob: Blob, name: string): boolean {
  try { return !!navigator.canShare?.({ files: [new File([blob], name, { type: blob.type })] }); } catch { return false; }
}
export async function shareFile(blob: Blob, name: string, title?: string): Promise<void> {
  await navigator.share({ files: [new File([blob], name, { type: blob.type })], title: title || name });
}

export function smooth(arr: ArrayLike<number>, radius: number): Float32Array {
  const n = arr.length;
  const out = new Float32Array(n);
  let acc = 0;
  const pre = new Float64Array(n + 1);
  for (let i = 0; i < n; i++) { acc += arr[i]; pre[i + 1] = acc; }
  for (let i = 0; i < n; i++) {
    const a = Math.max(0, i - radius), b = Math.min(n, i + radius + 1);
    out[i] = (pre[b] - pre[a]) / (b - a);
  }
  return out;
}

export function percentile(arr: ArrayLike<number>, p: number): number {
  const a = Array.from(arr).sort((x, y) => x - y);
  if (!a.length) return 0;
  return a[Math.min(a.length - 1, Math.max(0, Math.floor(p * (a.length - 1))))];
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function slug(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'clip';
}

export function easing(name: string, t: number): number {
  t = clamp(t, 0, 1);
  switch (name) {
    case 'linear': return t;
    case 'in': return t * t * t;
    case 'out': return 1 - Math.pow(1 - t, 3);
    case 'inout': return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    case 'back': { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }
    case 'elastic': {
      if (t === 0 || t === 1) return t;
      return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * ((2 * Math.PI) / 3)) + 1;
    }
    case 'bounce': {
      const n1 = 7.5625, d1 = 2.75;
      if (t < 1 / d1) return n1 * t * t;
      if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
      if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
      return n1 * (t -= 2.625 / d1) * t + 0.984375;
    }
    default: return t;
  }
}

export function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

export function seeded(seed: number) {
  let s = seed >>> 0 || 1;
  return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 100000) / 100000; };
}

export function wrapText(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const out: string[] = [];
  for (const para of text.split('\n')) {
    const words = para.split(' ');
    let line = '';
    for (const w of words) {
      const test = line ? line + ' ' + w : w;
      if (ctx.measureText(test).width > maxW && line) { out.push(line); line = w; } else line = test;
    }
    out.push(line);
  }
  return out;
}

export function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

export function waitEvent(el: EventTarget, ev: string, timeout = 8000): Promise<void> {
  return new Promise((res, rej) => {
    const t = setTimeout(() => { el.removeEventListener(ev, h); rej(new Error('timeout ' + ev)); }, timeout);
    const h = () => { clearTimeout(t); el.removeEventListener(ev, h); res(); };
    el.addEventListener(ev, h);
  });
}

export async function seekVideo(v: HTMLVideoElement, t: number) {
  if (Math.abs(v.currentTime - t) < 0.001 && v.readyState >= 2) return;
  const p = waitEvent(v, 'seeked', 6000);
  v.currentTime = t;
  try { await p; } catch { /* ignore */ }
}

export async function loadVideoMeta(url: string): Promise<{ duration: number; width: number; height: number }> {
  const v = document.createElement('video');
  v.preload = 'metadata';
  v.muted = true;
  v.src = url;
  await waitEvent(v, 'loadedmetadata', 15000);
  let d = v.duration;
  if (!isFinite(d)) {
    // MediaRecorder webm files have no duration header: force computation
    v.currentTime = 1e101;
    await waitEvent(v, 'durationchange', 8000).catch(() => {});
    d = v.duration;
    v.currentTime = 0;
  }
  const r = { duration: isFinite(d) ? d : 0, width: v.videoWidth, height: v.videoHeight };
  v.removeAttribute('src');
  v.load();
  return r;
}

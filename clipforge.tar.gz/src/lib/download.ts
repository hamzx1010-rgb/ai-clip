/**
 * Downloads.
 *
 * Rules that matter on a phone:
 *   - one file at a time (Android drops parallel downloads silently);
 *   - each clip downloads the moment it is ready, without waiting for the rest;
 *   - no giant ZIP built in memory — a ZIP would hold every clip twice;
 *   - the object URL is revoked straight after the click so the bytes are freed.
 */

let queue: Promise<void> = Promise.resolve();

export interface DownloadRequest {
  blob: Blob;
  fileName: string;
}

/** Queue a download; resolves when the browser has been handed the file. */
export function downloadBlob(req: DownloadRequest): Promise<void> {
  const run = queue.then(() => doDownload(req));
  // Keep the chain alive even if one download throws.
  queue = run.catch(() => undefined);
  return run;
}

async function doDownload(req: DownloadRequest): Promise<void> {
  const url = URL.createObjectURL(req.blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = sanitize(req.fileName);
  a.rel = 'noopener';
  a.style.display = 'none';
  document.body.appendChild(a);
  try {
    a.click();
  } finally {
    // Give the browser a moment to take the reference, then free it.
    setTimeout(() => {
      try {
        a.remove();
      } catch {
        /* ignore */
      }
      URL.revokeObjectURL(url);
    }, 4000);
  }
  // Small gap so Android does not merge/ignore back-to-back downloads.
  await new Promise((r) => setTimeout(r, 700));
}

export function sanitize(name: string): string {
  return (
    name
      .replace(/[\\/:*?"<>|]+/g, '-')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 90) || 'clip.mp4'
  );
}

export function clipFileName(base: string, index: number, title: string, ext: string): string {
  const stem = base.replace(/\.[a-z0-9]{2,5}$/i, '').replace(/[^\p{L}\p{N} _-]/gu, '').trim();
  const t = title
    .replace(/[^\p{L}\p{N} _-]/gu, '')
    .replace(/\s+/g, '-')
    .slice(0, 34)
    .replace(/-+$/g, '');
  const n = String(index + 1).padStart(2, '0');
  return sanitize(`${stem || 'clipforge'}-${n}${t ? `-${t}` : ''}.${ext}`);
}

export function formatBytes(n: number): string {
  if (!n) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB'];
  const i = Math.min(u.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
  return `${(n / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${u[i]}`;
}

export function formatTime(sec: number): string {
  if (!Number.isFinite(sec) || sec <= 0) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

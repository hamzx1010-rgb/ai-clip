/**
 * Put the source's own sound into a finished recording.
 *
 * Why this exists: the real-time engine records a <canvas> plus an audio graph
 * taken from a playing <video>. That graph is silent in several real
 * situations - a browser with no audio device, an AudioContext that never
 * resumes without a tap, a <video> that is being seeked rather than played -
 * and a silent clip is a broken clip. So after recording, the video is
 * re-packaged with the AAC frames copied straight out of the source. Copying
 * (not re-encoding) means the sound cannot drift, cannot be lost, and works in
 * browsers that have no AAC encoder at all.
 *
 * If anything about this fails the ORIGINAL recording is returned untouched,
 * so the worst case is exactly what happened before: a clip that the verifier
 * flags as silent and the pipeline rebuilds with the other engine.
 */

import { SourceReader, annexBToLengthPrefixed, isAnnexB, readHeader } from './mp4demux';
import { Mp4Mux } from './mp4mux';
import { copyAudioRange } from './export-webcodecs';
import type { ExportJob } from './export-types';

export interface RemuxOutcome {
  blob: Blob;
  ok: boolean;
  framesWritten: number;
  audioFrames: number;
  videoSeconds: number;
  audioSeconds: number;
  note?: string;
}

export async function remuxWithSourceAudio(
  recorded: Blob,
  job: ExportJob,
  notes: string[],
): Promise<RemuxOutcome> {
  const fail = (note: string): RemuxOutcome => ({
    blob: recorded,
    ok: false,
    framesWritten: 0,
    audioFrames: 0,
    videoSeconds: 0,
    audioSeconds: 0,
    note,
  });

  // Only MP4 can be re-packaged here; a WebM/VP9 recording is left alone.
  const type = (recorded.type || '').toLowerCase();
  if (!type.includes('mp4')) return fail(`Recording is ${type || 'unknown'}, not MP4 - left as it is`);

  const head = new Uint8Array(await recorded.slice(0, 16).arrayBuffer());
  let isMp4 = false;
  for (let i = 4; i < 8; i++) if (head[i] === 0x66 && head[i + 1] === 0x74 && head[i + 2] === 0x79 && head[i + 3] === 0x70) isMp4 = true;
  if (!isMp4) return fail('The recording has no MP4 header');

  const reader = new SourceReader({
    blob: recorded,
    wantVideo: true,
    wantAudio: false,
    signal: job.signal,
  });

  try {
    const loop = reader.start();
    const t = await reader.ready();
    if (t.videoId < 0 || !t.width || !t.height) {
      reader.destroy();
      return fail('The recording has no readable video track');
    }

    /* The sound: copied from the source for exactly this time range.
       Reading the source index costs only the header (no sample extraction). */
    let audio: Awaited<ReturnType<typeof copyAudioRange>> = { rate: 0, channels: 0, samples: [] };
    try {
      const srcHeader = await readHeader(job.srcBlob, { signal: job.signal });
      audio = await copyAudioRange(job, srcHeader.tracks, job.start, job.end, notes);
    } catch (e) {
      notes.push(`Could not copy the sound from the source: ${String((e as Error)?.message ?? e).slice(0, 140)}`);
    }

    const vts = t.videoTimescale || 1;
    const mux = new Mp4Mux({
      width: t.width,
      height: t.height,
      videoTimescale: 600,
      avcC: t.avcCBytes ?? new Uint8Array(0),
      audioSampleRate: audio.rate,
      audioChannels: audio.channels,
      audioFrameDuration: audio.rate ? 1024 / audio.rate : 0,
    });
    const ats = t.audioTimescale || audio.rate || 48000;
    mux.addRawAacFrames(audio.samples, ats);
    audio.samples.length = 0;

    let sawAnnexB: boolean | null = null;
    let count = 0;
    let base = -1;
    let lastTime = -1;
    const uniform = job.fps > 0 ? 1 / job.fps : 0;
    for (;;) {
      const s = await reader.nextVideo();
      if (!s) break;
      if (base < 0) base = s.cts;
      let time = Math.max(0, (s.cts - base) / vts);
      let duration = Math.max(1 / 240, (s.duration || 0) / vts);
      if (uniform > 0) {
        // This engine records in wall-clock time, so the pictures it captured
        // are evenly spaced in REALITY but not in the timestamps the recorder
        // wrote (they follow the video element's frame callbacks, which land
        // at 16.7 ms and 50 ms alternately). Putting them on an exact 1/fps
        // grid removes the judder and the duplicate-DTS warnings ffmpeg gives,
        // and keeps the total length because the recorder really did run for
        // this long.
        time = count * uniform;
        duration = uniform;
      } else if (time <= lastTime) {
        // Never let two samples share a timestamp: that is what makes ffmpeg
        // report "non monotonically increasing dts".
        time = lastTime + duration;
      }
      lastTime = time;
      if (sawAnnexB === null) sawAnnexB = isAnnexB(s.data);
      mux.addVideoFrame({
        data: sawAnnexB ? annexBToLengthPrefixed(s.data) : s.data.slice(),
        time,
        duration,
        key: s.is_sync,
      });
      count++;
    }
    await loop.catch(() => undefined);
    reader.destroy();

    if (count < 2) return fail('The recording had no video samples to copy');
    if (!mux.videoSeconds || mux.videoSeconds < (job.end - job.start) * 0.8) {
      return fail(`Re-packaged video was only ${mux.videoSeconds.toFixed(1)}s`);
    }

    const blob = mux.build();
    const note = audio.rate
      ? `Re-packaged with ${count} pictures and ${mux.audioFrames} sound frames copied from the source`
      : `Re-packaged with ${count} pictures (the source has no copyable sound)`;
    notes.push(note);
    return {
      blob,
      ok: true,
      framesWritten: count,
      audioFrames: mux.audioFrames,
      videoSeconds: mux.videoSeconds,
      audioSeconds: mux.audioSeconds,
      note,
    };
  } catch (e) {
    try {
      reader.destroy();
    } catch {
      /* ignore */
    }
    const msg = `Could not re-package the recording (${String((e as Error)?.message ?? e).slice(0, 160)})`;
    notes.push(msg);
    return fail(msg);
  }
}

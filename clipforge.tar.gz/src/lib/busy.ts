// Tracks long jobs running in this tab (clipping, downloading, making a documentary) so the app can warn
// before the tab is closed or reloaded, and show a "working" dot next to that tool in the sidebar.
import { useSyncExternalStore } from 'react';

const jobs = new Map<string, string>(); // key → label
const subs = new Set<() => void>();
let snap: string[] = [];
const emit = () => { snap = [...jobs.keys()]; subs.forEach((f) => f()); };

export function setBusy(key: string, on: boolean, label = key) {
  if (on === jobs.has(key)) return;
  if (on) jobs.set(key, label); else jobs.delete(key);
  emit();
}
export const busyLabels = () => [...jobs.values()];
export function useBusy(): string[] {
  return useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, () => snap);
}

if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', (e) => {
    if (!jobs.size) return;
    e.preventDefault();
    e.returnValue = `Still working: ${busyLabels().join(', ')}. Leaving now will lose it.`;
    return e.returnValue;
  });
}

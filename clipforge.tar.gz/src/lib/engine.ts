import type { AudioAnalysis, ChatAnalysis, Clip, ScoreBreakdown, Transcript, VisualAnalysis, Word } from './types';
import { maxRange, meanRange } from './audio';
import { buildPhrases, cutInForGap, cutOutForGap, findGap, gapBetween } from './boundaries';
import { makeHashtags, makeHooks, makeTitle, textFeatures, CATEGORIES, FILLERS, norm } from './nlp';
import { clamp, fmtTime, hashStr, uid } from './util';

export type EngineSettings = {
  count: number;
  minLen: number;
  maxLen: number;
  categories: string[];
  keywords: string[];
  platform: string;
  speakerPriority: string; // 'all' or speaker name
  stream?: boolean;
};

export type EngineInput = {
  duration: number;
  audio: AudioAnalysis | null;
  visual: VisualAnalysis | null;
  transcript: Transcript | null;
  chat?: ChatAnalysis | null;
  markers?: { t: number; label: string; strength: number }[];
};

type Unit = { start: number; end: number; text: string; speaker?: string; words: Word[]; startOk?: boolean; endOk?: boolean; startCut?: number | null; endCut?: number | null; startGap?: number; endGap?: number; prevEnd?: number; nextStart?: number; score: number; f?: ReturnType<typeof textFeatures>; reaction: number; reactionT: number; reactionKind: string; energy: number; pace: number; chat: number; chatLabel: string };

// Sweet spots from Shorts/TikTok retention data: 15–35 s holds the highest % viewed; longer only when it keeps holding.
export const PLATFORM_IDEAL: Record<string, [number, number]> = {
  tiktok: [18, 38], shorts: [18, 42], reels: [15, 40], youtube: [45, 150], facebook: [20, 60], x: [20, 60], snapchat: [10, 30], linkedin: [30, 90], pinterest: [10, 30], all: [18, 40],
};

export function buildUnits(input: EngineInput): Unit[] {
  const { transcript, audio, duration } = input;
  const units: Unit[] = [];
  const blank = { score: 0, reaction: 0, reactionT: 0, reactionKind: '', energy: 0, pace: 0, chat: 0, chatLabel: '' };
  if (transcript && transcript.segments.length) {
    for (const seg of transcript.segments) {
      // phrases split at sentence ends and real pauses, each marked with whether a clip may start/end there
      for (const ph of buildPhrases(seg.words, audio, seg.start, seg.end)) {
        units.push({ ...blank, start: ph.start, end: ph.end, text: ph.words.map((w) => w.w).join(' '), speaker: seg.speaker, words: ph.words, startOk: ph.startOk, endOk: ph.endOk, startCut: ph.startCut, endCut: ph.endCut, startGap: ph.startGap, endGap: ph.endGap, prevEnd: ph.prevEnd, nextStart: ph.nextStart });
      }
    }
  } else if (audio) {
    // speech regions separated by silences
    let t = 0;
    const regions: [number, number][] = [];
    for (const s of audio.silences) { if (s.start - t > 0.4) regions.push([t, s.start]); t = s.end; }
    if (duration - t > 0.4) regions.push([t, duration]);
    for (const [a, b] of regions) {
      // no words: clips may only start right after a silence and end right before one
      for (let x = a; x < b; x += 7) units.push({ ...blank, start: x, end: Math.min(b, x + 7), text: '', words: [], startOk: x === a, endOk: x + 7 >= b });
    }
  } else {
    for (let x = 0; x < duration; x += 6) units.push({ ...blank, start: x, end: Math.min(duration, x + 6), text: '', words: [] });
  }
  return units;
}

export function scoreUnits(units: Unit[], input: EngineInput, s: EngineSettings) {
  const { audio, chat } = input;
  const sel = new Set(s.categories);
  const avgEnergy = audio ? meanRange(audio.rms, audio.hop, 0, audio.duration) || 0.2 : 0.2;
  for (const u of units) {
    let sc = 0;
    if (u.text) {
      const f = textFeatures(u.text, s.keywords);
      u.f = f;
      for (const [k, c] of Object.entries(f.cats)) sc += Math.min(c, 3) * (sel.size === 0 || sel.has(k) ? 1.6 : 0.55);
      sc += (f.question ? 1.3 : 0) + (f.exclaim ? 0.5 : 0) + Math.min(f.numbers, 3) * 0.45 + f.quotable * 0.6 - f.fillers * 0.7 + f.keywordHits.length * 5;
      u.pace = u.words.length / Math.max(0.5, u.end - u.start);
    }
    if (audio) {
      u.energy = meanRange(audio.rms, audio.hop, u.start, u.end) / (avgEnergy || 0.2);
      sc += clamp(u.energy - 1, -0.5, 1) * 1.2;
      if (!u.text) {
        const on = meanRange(audio.onset, audio.hop, u.start, u.end) * 60;
        u.pace = on;
        sc += clamp(on - 0.5, -0.5, 1.5);
      }
      const react = audio.spikes.filter((sp) => sp.t >= u.end - 0.6 && sp.t <= u.end + 3);
      for (const r of react) {
        const v = r.strength * (r.kind === 'crowd' ? 1.6 : 1);
        if (v > u.reaction) { u.reaction = v; u.reactionT = r.t; u.reactionKind = r.kind; }
      }
      const inside = audio.spikes.filter((sp) => sp.t >= u.start && sp.t < u.end - 0.6);
      for (const r of inside) sc += r.strength * 0.8;
      sc += u.reaction * 2.2;
    }
    if (chat) {
      for (const sp of chat.spikes) if (sp.t >= u.start && sp.t <= u.end + 12 && sp.strength > u.chat) { u.chat = sp.strength; u.chatLabel = sp.label; }
      sc += u.chat * 3;
    }
    if (input.markers) for (const m of input.markers) if (m.t >= u.start - 1 && m.t <= u.end + 4) sc += m.strength * 3;
    if (s.speakerPriority !== 'all' && u.speaker) sc += u.speaker === s.speakerPriority ? 1.2 : -0.6;
    u.score = sc;
  }
}

// ── What makes the first 1–1.5 s stop the scroll ("viewed vs. swiped away") and the ending loop ──────────────
/** words that make a weak first word: connectives, fillers, throat-clearing */
const WEAK_OPEN = /^(and|so|but|because|or|then|also|um+|uh+|like|yeah|yes|okay|ok|right|well|anyway|alright|i mean|you know|basically|actually,)\b/i;
/** greetings / channel intros: the #1 reason people swipe in the first second */
const GREETING = /^(welcome( back)?|hey|hi|hello|what'?s up|yo|good (morning|evening)|today (we|i)('re| are| am|'m)?|in this (video|episode)|before we (start|begin)|don'?t forget to|make sure (to|you) (like|subscribe))\b/i;
/** openers that only make sense with earlier context ("he said…", "that's why…") */
const DANGLING_OPEN = /^(he|she|it|they|that|this|those|these|him|her|them|which|who|there)\b(?!'s (the|a|how|why|what))/i;
/** openers that create an instant question/claim in the viewer's head */
const STRONG_OPEN = /^(why|how|what|stop|never|nobody|no one|everyone|everybody|the (truth|secret|problem|reason|biggest|worst|best|only|one thing)|here'?s|if you|you('re| are| need| have| should| won'?t)?|imagine|i (lost|made|quit|got fired|almost|never|was|spent|tried)|most people|this is (why|how|what)|there'?s no|\$?\d)/i;
const SKIP_LEAD = new Set(['so', 'and', 'but', 'um', 'uh', 'umm', 'uhh', 'like', 'yeah', 'yes', 'okay', 'ok', 'well', 'right', 'alright', 'anyway', 'basically', 'also', 'then', 'sure', 'exactly', 'oh']);

/** Drop leading "so / and / um / like…" so the clip starts on the first real word. */
function leadSkip(words: Word[]): number {
  let k = 0;
  // a one-word "sentence" glued to the front ("Year. Honestly, here's…") is a leftover of the previous thought
  if (words.length > 4 && /\.["']?$/.test(words[0].w)) k = 1;
  while (k < words.length - 3 && k < 4 && SKIP_LEAD.has(words[k].w.toLowerCase().replace(/[^a-z']/g, ''))) k++;
  return k;
}
const contentSet = (t: string) => new Set(t.toLowerCase().replace(/[^a-z0-9\s']/g, ' ').split(/\s+/).filter((w) => w.length > 3 && !STOP_EN.has(w)));
const STOP_EN = new Set('that this with have from they what when your just like about there their would could should because really which think going know been were into them then than also only some very much more most even back over well said says things thing people want make made kind sort yeah okay right'.split(' '));

/** Scroll-stopping power of a clip's opening (0..~1.2). */
function openerScore(first: Unit, text: string, maxU: number, energyBoost: number): number {
  const head = text.split(/\s+/).slice(0, 8).join(' ');
  let h = (first.score / maxU) * 0.5;
  if (first.f?.question || /\?/.test(head)) h += 0.2;
  if (STRONG_OPEN.test(head)) h += 0.22;
  if (first.f && (first.f.cats.hot > 0 || first.f.cats.shocking > 0)) h += 0.1;
  if (first.f && first.f.numbers > 0) h += 0.06;
  if (WEAK_OPEN.test(head)) h -= 0.3;
  if (DANGLING_OPEN.test(head)) h -= 0.2;
  if (GREETING.test(head)) h -= 0.4;
  if (/^(for sure|sure|yeah|yes|yep|yup|right|exactly|okay|ok|totally|absolutely|definitely|true|mm+|uh+ huh|oh)[.,!?]*(\s|$)/i.test(head)) h -= 0.3;
  if (/\b(um+|uh+)\b/i.test(head)) h -= 0.12;
  return h + energyBoost;
}

function overlap(a: { start: number; end: number }, b: { start: number; end: number }) {
  const o = Math.max(0, Math.min(a.end, b.end) - Math.max(a.start, b.start));
  return o / Math.min(a.end - a.start, b.end - b.start);
}

export function findClips(input: EngineInput, s: EngineSettings): Clip[] {
  const units = buildUnits(input);
  scoreUnits(units, input, s);
  const { audio, visual } = input;
  const ideal = s.stream ? [15, 30] : PLATFORM_IDEAL[s.platform] || [20, 40];
  const maxU = Math.max(...units.map((u) => u.score), 1);

  type Cand = { start: number; end: number; i: number; j: number; raw: number; parts: Record<string, number> };
  const cands: Cand[] = [];
  const avgE = audio ? meanRange(audio.rms, audio.hop, 0, audio.duration) || 0.2 : 0.2;
  // pass 1: only clean sentence boundaries. pass 2 (only if too few): allow imperfect ones, heavily penalised
  for (const strict of [true, false]) {
  if (!strict && cands.length >= s.count * 2) break;
  for (let i = 0; i < units.length; i++) {
    const first = units[i];
    if (first.f && first.f.fillers > 0 && first.words.length < 4) continue;
    // only start where a sentence really begins (never mid-thought)
    if (strict && first.startOk === false) continue;
    // a one-word leftover ("Year." from a mis-punctuated sentence) never opens a clip — unless it's a question/exclamation
    if (first.words.length === 1 && !/[?!]["']?$/.test(first.text)) continue;
    // drop a lead-in "so / and / um" only if the speaker actually pauses after it — otherwise the cut would land mid-speech
    let skip = first.words.length ? leadSkip(first.words) : 0;
    const skipGap = skip ? gapBetween(audio, first.words[skip - 1], first.words[skip]) : null;
    if (!skipGap || skipGap.e - skipGap.s < 0.12) skip = 0; // only drop "so/and" when he actually pauses after it
    const w0 = first.words[skip];
    // cut inside the measured silence right before the first word
    const start = !first.words.length ? Math.max(0, first.start) : skipGap ? cutInForGap(skipGap) : first.startCut ?? Math.max(0, w0.s - 0.1);
    const gapIn = skip && skipGap && skipGap.e - skipGap.s >= 0.12 ? skipGap.e - skipGap.s : first.startGap ?? 1;
    // a bare "Yeah." / "Sure." / "Right." as the first line wastes the most important second
    const ackOpen = first.words.length <= 3 && /^(for sure|sure|yeah|yes|yep|right|exactly|okay|ok|totally|absolutely|definitely|true|oh|mm+|uh+ huh)[.,!?]*$/i.test(first.text.trim());
    const startPen = (first.startOk === false ? (skipGap || first.startCut != null ? 0.25 : 0.5) : 0) + (first.words.length && gapIn < 0.12 ? 0.08 : 0) + (ackOpen ? 0.15 : 0);
    const firstText = first.words.length ? first.words.slice(skip).map((w) => w.w).join(' ') : first.text;
    for (let j = i; j < units.length; j++) {
      const last = units[j];
      // never bridge a long gap (different part of the video / untranscribed region)
      if (j > i && last.start - units[j - 1].end > 2.5) break;
      // only end where a sentence really ends and the speaker pauses
      if (strict && last.endOk === false) continue;
      if (!strict && first.startOk !== false && last.endOk !== false) continue; // already added in pass 1
      // end inside the measured silence right after the last word (+ a short breath, never into the next word)
      let end = last.words.length ? last.endCut ?? last.end + 0.1 : last.end;
      const endPen = (last.endOk === false ? (last.endCut != null ? 0.25 : 0.5) : 0) + (last.words.length && (last.endGap ?? 1) < 0.12 ? 0.08 : 0);
      // laughter / applause right after the line: keep it (up to ~1.5 s), ending in a quiet moment before anyone speaks again
      if (last.reaction > 0.3 && last.reactionKind === 'crowd' && last.reactionT > end - 0.5) {
        const lim = Math.min(last.reactionT + 1.6, (last.nextStart ?? Infinity) - 0.15, input.duration);
        const g = lim > last.reactionT + 0.4 ? findGap(audio, last.reactionT + 0.4, lim) : null;
        if (g) end = Math.max(end, cutOutForGap(g));
      }
      const len = end - start;
      if (len > s.maxLen) break;
      if (len < s.minLen) continue;
      const span = units.slice(i, j + 1);
      const scores = span.map((u) => u.score);
      const density = scores.reduce((a, b) => a + b, 0) / span.length / maxU;
      const lateStart = Math.floor(span.length * 0.5);
      const payoff = Math.max(...scores.slice(lateStart)) / maxU;
      // ends ON the peak (punchline / reveal / reaction) → completion + replays
      const endPeak = Math.max(last.score, span[span.length - 2]?.score ?? -1) / maxU;
      const reaction = Math.max(...span.map((u) => u.reaction));
      // hook: the first ~1.5–3 s
      const eBoost = audio ? clamp(meanRange(audio.rms, audio.hop, start, start + 2) / avgE - 1, -0.3, 0.4) * 0.3 : 0;
      const hook = openerScore(first, firstText, maxU, eBoost);
      // middle: a micro-payoff keeps people past the midpoint; long flat stretches lose them
      const third = Math.max(1, Math.floor(span.length / 3));
      const midPayoff = span.length >= 3 ? Math.max(...scores.slice(third, span.length - third || third + 1)) / maxU : density;
      let lull = 0, run = 0;
      for (const u of span) { if (u.score < maxU * 0.2) { run += u.end - u.start; lull = Math.max(lull, run); } else run = 0; }
      const lullPen = clamp((lull - 5) / 10, 0, 1);
      let dead = 0;
      if (audio) for (const si of audio.silences) dead += Math.max(0, Math.min(end, si.end) - Math.max(start, si.start));
      const deadRatio = dead / len;
      const fit = Math.exp(-Math.pow(Math.max(0, ideal[0] - len, len - ideal[1]) / 12, 2));
      let vis = 0.5;
      if (visual && visual.times.length) {
        const idx = visual.times.map((t, k) => (t >= start && t <= end ? k : -1)).filter((k) => k >= 0);
        if (idx.length) {
          const faceFrac = idx.filter((k) => visual.faces[k]?.length).length / idx.length;
          const bright = idx.reduce((a, k) => a + visual.brightness[k], 0) / idx.length;
          vis = (visual.faceEngine === 'mediapipe' ? faceFrac * 0.6 : 0.35) + clamp((bright - 0.12) * 2, 0, 0.4);
        }
      }
      const chat = Math.max(0, ...span.map((u) => u.chat));
      const complete = /[.?!]["']?$/.test(last.text) || !last.text ? 1 : 0.5;
      // loop: a short punchy last line, or an ending that echoes the opening, makes the replay feel seamless
      let loop = 0;
      if (last.text) {
        const lw = last.words.length;
        if (lw <= 12) loop += 0.35;
        if (/[?!]["']?$/.test(last.text)) loop += 0.15;
        const a0 = contentSet(firstText), a1 = contentSet(last.text);
        let common = 0; a1.forEach((w) => { if (a0.has(w)) common++; });
        if (j > i && common) loop += Math.min(0.4, common * 0.2);
      } else loop = reaction > 0.3 ? 0.5 : 0.2;
      // a complete arc: a question/claim early that the clip pays off later
      const arc = j > i && (first.f?.question || STRONG_OPEN.test(firstText)) && payoff > 0.45 ? 1 : 0;
      const raw = hook * 0.3 + payoff * 0.12 + endPeak * 0.12 + density * 0.14 + midPayoff * 0.06 + loop * 0.07 + arc * 0.05
        + reaction * 0.08 + chat * 0.1 + fit * 0.1 + vis * 0.04 + complete * 0.05 - deadRatio * 0.4 - lullPen * 0.12
        - startPen - endPen;
      cands.push({ start, end, i, j, raw, parts: { hook, payoff: Math.max(payoff, endPeak), density, reaction, fit, vis, deadRatio, chat, loop, endPeak, lull, midPayoff, arc, skip } });
    }
  }
  }
  if (!cands.length) {
    // fallback fixed windows
    const L = clamp((s.minLen + s.maxLen) / 2, 5, input.duration);
    for (let t = 0; t + L <= input.duration + 0.01; t += L / 2) cands.push({ start: t, end: Math.min(input.duration, t + L), i: 0, j: 0, raw: 0.1 + (audio ? meanRange(audio.rms, audio.hop, t, t + L) : 0), parts: { hook: 0.3, payoff: 0.3, density: 0.3, reaction: 0, fit: 1, vis: 0.5, deadRatio: 0, chat: 0 } });
  }
  cands.sort((a, b) => b.raw - a.raw);
  const chosen: Cand[] = [];
  for (const thr of [0.2, 0.5]) {
    for (const c of cands) {
      if (chosen.length >= s.count) break;
      if (chosen.includes(c)) continue;
      if (chosen.every((x) => overlap(x, c) <= thr)) chosen.push(c);
    }
    if (chosen.length >= s.count) break;
  }
  const raws = cands.map((c) => c.raw);
  const hi = Math.max(...raws), lo = raws[Math.floor(raws.length * 0.85)] ?? Math.min(...raws);

  const clips: Clip[] = chosen.map((c) => {
    const span = units.slice(c.i, c.j + 1);
    const skip = c.parts.skip || 0;
    const text = [span[0].words.length ? span[0].words.slice(skip).map((w) => w.w).join(' ') : span[0].text, ...span.slice(1).map((u) => u.text)].join(' ').trim();
    const n01 = clamp((c.raw - lo) / (hi - lo || 1), 0, 1);
    const jitter = (hashStr(text + c.start) % 5) - 2;
    const score = Math.round(clamp(48 + 46 * Math.pow(n01, 0.85) + jitter, 12, 99));
    const f = textFeatures(text, s.keywords);
    const catScores = CATEGORIES.map((k) => ({ id: k.id, v: f.cats[k.id] || 0 })).filter((x) => x.v > 0).sort((a, b) => b.v - a.v);
    let cats = catScores.slice(0, 3).map((x) => x.id);
    if (!cats.length && c.parts.reaction > 0.3) cats = ['funny'];
    if (!cats.length && c.parts.chat > 0.3) cats = ['hype'];
    const P = c.parts;
    const sat = (v?: number) => Math.min(1, (v || 0) / 4);
    const raw: ScoreBreakdown = {
      hook: pct(P.hook, 0.15, 1.0),
      retention: pct(P.payoff * 0.5 + P.density * 0.3 + (1 - P.deadRatio) * 0.2 + P.fit * 0.15, 0.25, 0.95),
      comments: pct((f.question ? 0.35 : 0) + sat(f.cats.hot) * 0.25 + sat(f.cats.drama) * 0.25 + (f.cta ? 0.2 : 0) + P.chat * 0.3, 0, 0.9),
      shares: pct(sat(f.cats.funny) * 0.25 + sat(f.cats.shocking) * 0.25 + sat(f.cats.emotional) * 0.2 + P.reaction * 0.35 + f.quotable * 0.1, 0, 0.8),
      saves: pct(sat(f.cats.educational) * 0.35 + Math.min(f.numbers, 4) * 0.08 + sat(f.cats.motivational) * 0.25, 0, 0.7),
      replay: pct((P.loop || 0) * 0.45 + P.reaction * 0.3 + (P.endPeak || 0) * 0.2 + (c.end - c.start < 30 ? 0.15 : 0), 0, 0.9),
    };
    const b = Object.fromEntries(Object.entries(raw).map(([k, v]) => [k, Math.round(clamp(0.55 * (v as number) + 0.45 * score, 5, 99))])) as ScoreBreakdown;
    const reasons = buildReasons(c, span, f, input, s);
    // cold-open teaser = "show the result first": the strongest line from the second half, 1.2–4 s
    let hookLine: Clip['hookLine'];
    const late = span.slice(Math.max(1, Math.floor(span.length * 0.4)));
    const hl = late.filter((u) => u.text && u.end - u.start <= 4.5 && u.end - u.start >= 1.2).sort((a, b) => (b.score + b.reaction * 2) - (a.score + a.reaction * 2))[0];
    if (hl) hookLine = { start: hl.start, end: hl.end, text: hl.text };
    // use it automatically only when the natural opening is weak and the payoff is strong
    // (no automatic cold open — jumping to a later line first reads as a random cut; it stays a manual option)
    const teaser = undefined;
    const title = text ? makeTitle(text) : audioTitle(c, cats, Math.round(c.start * 7));
    return {
      id: uid('clip_'),
      start: +c.start.toFixed(2),
      end: +c.end.toFixed(2),
      score,
      breakdown: b,
      reasons,
      categories: cats,
      title,
      hooks: makeHooks(text, cats, hashStr(text), span.map((u) => ({ text: u.text, score: u.score }))),
      teaser,
      hookLine,
      text,
      keywordHits: f.keywordHits,
      hashtags: makeHashtags(text, cats, s.platform === 'all' ? 'tiktok' : s.platform),
    };
  });
  clips.sort((a, b) => b.score - a.score);
  // multi-part series detection: consecutive clips with small gaps
  const byTime = [...clips].sort((a, b) => a.start - b.start);
  let series: Clip[] = [];
  const flushSeries = () => {
    if (series.length > 1) series.forEach((c, k) => (c.part = { n: k + 1, of: series.length, series: series[0].title }));
    series = [];
  };
  for (const c of byTime) {
    const prev = series[series.length - 1];
    if (prev && c.start - prev.end < 2.5) series.push(c);
    else { flushSeries(); series = [c]; }
  }
  flushSeries();
  return clips;
}

function pct(v: number, lo: number, hi: number) {
  return Math.round(clamp(((v - lo) / (hi - lo)) * 100, 3, 99));
}

function buildReasons(c: { start: number; end: number; parts: Record<string, number> }, span: Unit[], f: ReturnType<typeof textFeatures>, input: EngineInput, s: EngineSettings): string[] {
  const r: string[] = [];
  const rel = (t: number) => { const d = Math.max(0, t - c.start); return d < 1 ? 'in the very first second' : `${Math.round(d)}s in`; };
  const first = span[0];
  const opener = first.words.length ? first.words.slice(c.parts.skip || 0).map((w) => w.w).join(' ') : first.text;
  if (first.f?.question) r.push(`Opens with a question ("${trim(opener, 48)}"): viewers stay to hear the answer`);
  else if (STRONG_OPEN.test(opener)) r.push(`Scroll-stopping first line: "${trim(opener, 48)}"`);
  else if (first.f && (first.f.cats.hot || first.f.cats.shocking)) r.push(`Strong hook in the first 2s: "${trim(opener, 48)}"`);
  if (c.parts.skip) r.push('Starts straight on the first real word (lead-in “so / um / and” trimmed)');
  if ((c.parts.endPeak || 0) > 0.6) r.push('Ends right on the payoff, with no trailing tail, so more people finish it');
  if ((c.parts.loop || 0) >= 0.5) r.push('The ending flows back into the start, which encourages replays (each loop counts as a view)');
  if (c.parts.arc) r.push('Complete arc: a question/claim up front, paid off before the end');
  if ((c.parts.lull || 0) > 6) r.push(`Has a ${Math.round(c.parts.lull)}s slow stretch, so jump cuts matter here`);
  const hotTerms = f.terms.filter((t) => t.length > 3).slice(0, 3);
  if (hotTerms.length) r.push(`High-signal language detected: ${hotTerms.map((t) => `"${t}"`).join(', ')}`);
  const react = span.filter((u) => u.reaction > 0.3).sort((a, b) => b.reaction - a.reaction)[0];
  if (react) r.push(`${react.reactionKind === 'crowd' ? 'Audience reaction (laughter/applause)' : 'Volume spike / loud reaction'} ${rel(react.reactionT)}${first.text ? ' right after the punchline' : ''}`);
  const energetic = span.filter((u) => u.energy > 1.25).sort((a, b) => b.energy - a.energy)[0];
  if (energetic) r.push(`Energy peaks ${rel(energetic.start)} (+${Math.round((energetic.energy - 1) * 100)}% vs. video average)`);
  if (f.numbers >= 2) r.push('Concrete numbers & specifics boost credibility and saves');
  if (f.keywordHits.length) r.push(`Contains your keyword${f.keywordHits.length > 1 ? 's' : ''}: ${f.keywordHits.map((k) => `"${k}"`).join(', ')}`);
  const chatU = span.filter((u) => u.chat > 0.3).sort((a, b) => b.chat - a.chat)[0];
  if (chatU) r.push(`Chat exploded: ${chatU.chatLabel}`);
  if (input.markers?.some((m) => m.t >= c.start && m.t <= c.end)) r.push('Live-monitor marker fired during this moment');
  const pace = span.reduce((a, u) => a + u.pace, 0) / span.length;
  if (span[0].text && pace > 2.9) r.push(`Fast delivery (${pace.toFixed(1)} words/s) keeps retention high`);
  if (c.parts.deadRatio < 0.05) r.push(`Tight pacing — only ${Math.round(c.parts.deadRatio * 100)}% dead air`);
  else if (c.parts.deadRatio > 0.12) r.push(`${Math.round(c.parts.deadRatio * 100)}% dead air — auto jump-cuts recommended`);
  if (input.visual?.faceEngine === 'mediapipe' && c.parts.vis > 0.45) r.push('Faces visible throughout');
  const len = c.end - c.start;
  const ideal = s.stream ? [15, 30] : PLATFORM_IDEAL[s.platform] || [20, 40];
  if (len >= ideal[0] && len <= ideal[1]) r.push(`${Math.round(len)}s is in the sweet spot for ${s.stream ? 'stream clips' : s.platform}`);
  const fillerCount = span.reduce((a, u) => a + u.words.filter((w) => FILLERS.includes(norm(w.w))).length, 0);
  if (fillerCount) r.push(`${fillerCount} filler word${fillerCount > 1 ? 's' : ''} will be auto-removed`);
  if (!r.length) r.push('Consistent speech energy and a complete thought');
  return r;
}

function trim(s: string, n: number) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }

export function reasoningSentence(c: Clip): string {
  const top = c.reasons.slice(0, 4).map((x) => x.charAt(0).toLowerCase() + x.slice(1));
  return `This clip scored ${c.score} because: ${top.join(' + ')}.`;
}

export function speakerIndexer(tr: Transcript | null): ((t: number) => number) | undefined {
  if (!tr || !tr.segments.some((s) => s.speaker)) return undefined;
  const order: string[] = [];
  for (const s of tr.segments) if (s.speaker && !order.includes(s.speaker)) order.push(s.speaker);
  if (order.length < 2) return undefined;
  return (t: number) => {
    const seg = tr.segments.find((s) => t >= s.start - 0.2 && t <= s.end + 0.6) || [...tr.segments].reverse().find((s) => s.start <= t);
    return seg?.speaker ? order.indexOf(seg.speaker) : 0;
  };
}

export function wordsInRange(tr: Transcript | null, a: number, b: number): (Word & { speaker?: string })[] {
  if (!tr) return [];
  const out: (Word & { speaker?: string })[] = [];
  for (const s of tr.segments) {
    if (s.end < a || s.start > b) continue;
    for (const w of s.words) { const m = (w.s + w.e) / 2; if (m >= a && m < b) out.push({ ...w, speaker: s.speaker }); } // by midpoint: a trimmed lead-in word never shows up
  }
  return out;
}

export { maxRange };

const AUDIO_TITLES: Record<string, string[]> = {
  funny: ['I can\'t stop laughing at this 😂', 'This went so wrong 💀', 'Nobody expected this ending', 'The reaction says it all 😭'],
  hype: ['WAIT… WHAT JUST HAPPENED?! 😳', 'This moment went crazy 🔥', 'The clutch nobody saw coming', 'Absolute chaos in 10 seconds'],
  shocking: ['I was NOT ready for this 😱', 'This changes everything…', 'You won\'t believe what I found', 'Wait for it… 👀'],
  default: ['The best moment of the whole video 🔥', 'Wait for it… 👀', 'This part had me screaming', 'Peak moment right here ⚡', 'Rewatch this twice 🔁'],
};
function audioTitle(c: { parts: Record<string, number> }, cats: string[], seed: number): string {
  const key = cats.find((k) => AUDIO_TITLES[k]) || ((c.parts.reaction || 0) > 0.5 ? 'hype' : 'default');
  const list = AUDIO_TITLES[key];
  return list[seed % list.length];
}

export type Word = { w: string; s: number; e: number };
export type Segment = { speaker?: string; start: number; end: number; text: string; words: Word[] };
export type Transcript = {
  segments: Segment[];
  source: 'whisper' | 'sample' | 'srt' | 'local' | 'none';
  language?: string;
};

export type AudioAnalysis = {
  duration: number;
  hop: number; // seconds per frame
  rms: Float32Array; // normalized 0..1
  zcr: Float32Array; // zero crossing rate 0..1
  onset: Float32Array; // onset strength
  speech: Uint8Array; // 1 = voice-like activity
  crowd: Uint8Array; // 1 = broadband noise burst (applause/laughter/cheer)
  spikes: { t: number; strength: number; kind: 'loud' | 'crowd' }[];
  silences: { start: number; end: number }[];
  peaks: Float32Array; // downsampled waveform peaks for display (~1000)
  loudnessDb: number;
};

export type FaceBox = { x: number; y: number; w: number; h: number; score: number }; // normalized 0..1
export type VisualAnalysis = {
  times: number[];
  brightness: number[];
  sharpness: number[];
  motion: number[];
  motionCx: number[]; // horizontal centre of motion 0..1
  sceneCuts: number[];
  faces: FaceBox[][];
  faceEngine: 'mediapipe' | 'none';
};

export type ChatMsg = { t: number; user: string; text: string; kind?: 'msg' | 'sub' | 'donation' | 'raid' | 'bits' };
export type ChatAnalysis = {
  bucket: number;
  rate: number[]; // msgs per bucket
  hype: number[]; // emote-spam score per bucket
  spikes: { t: number; strength: number; label: string; top: string[] }[];
  events: ChatMsg[];
};

export type ScoreBreakdown = {
  hook: number;
  retention: number;
  comments: number;
  shares: number;
  saves: number;
  replay: number;
};

export type Clip = {
  id: string;
  start: number;
  end: number;
  score: number;
  breakdown: ScoreBreakdown;
  reasons: string[];
  categories: string[];
  title: string;
  hooks: string[];
  hookLine?: { start: number; end: number; text: string };
  text: string;
  keywordHits: string[];
  hashtags: string[];
  part?: { n: number; of: number; series: string };
  approved?: boolean;
  /** per-clip layout (overrides session options) */
  aspect?: '9:16' | '16:9' | '1:1' | '4:5';
  reframe?: 'track' | 'center' | 'blur' | 'split' | 'fit';
  layoutWhy?: string;
};

export type Platform = {
  id: string;
  name: string;
  aspect: '9:16' | '16:9' | '1:1' | '4:5';
  maxLen: number;
  color: string;
};

export type CaptionStyleId = string;

export type ClipRenderOptions = {
  aspect: '9:16' | '16:9' | '1:1' | '4:5';
  reframe: 'track' | 'center' | 'blur' | 'split' | 'fit';
  speakerFocus: 'auto' | 'left' | 'right';
  captionStyle: CaptionStyleId;
  captionPos: 'top' | 'middle' | 'bottom';
  captionScale: number;
  captions: boolean;
  emojis: boolean;
  keywordEmphasis: boolean;
  censor: boolean;
  hookText: string;
  hookOverlay: boolean;
  teaser: boolean;
  removeSilence: boolean;
  removeFillers: boolean;
  speed: number;
  zoomPulses: boolean;
  shake: boolean;
  flash: boolean;
  progressBar: boolean;
  grade: string;
  music: string; // track id or '' none
  musicVolume: number;
  ducking: boolean;
  sfx: boolean;
  beatZoom: boolean;
  handle: string;
  watermark: boolean;
  endCard: boolean;
  commentBait: boolean;
  chatOverlay: boolean;
};

export type ScheduledPost = {
  id: string;
  clipTitle: string;
  platform: string;
  when: string; // ISO
  caption: string;
  status: 'scheduled' | 'posted' | 'draft';
  score?: number;
};

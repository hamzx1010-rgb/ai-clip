/** Shared shapes used across ClipForge. */

export type LayoutMode = 'face' | 'full';

export type ClipStatus =
  | 'pending'
  | 'analysing'
  | 'ready'
  | 'exporting'
  | 'verifying'
  | 'done'
  | 'error';

export interface FaceHit {
  /** 0..1 normalised box in source frame coordinates. */
  x: number;
  y: number;
  w: number;
  h: number;
  confidence: number;
}

export interface ClipAnalysis {
  /** Detected faces inside this clip's time range (sampled). */
  faces: FaceHit[];
  /** Fraction of sampled frames that contained a face. */
  faceRatio: number;
  /** True when this specific clip really shows a person. */
  hasFace: boolean;
  /** Smoothed face centre used for the crop, normalised 0..1. */
  faceCenter: { x: number; y: number } | null;
  /** Mean absolute frame difference — is there movement? */
  motion: number;
  /** Speech ratio from this clip's own audio. */
  speechRatio: number;
  /** True when the cut starts inside a real pause. */
  startsInPause: boolean;
  /** True when the cut ends inside a real pause. */
  endsInPause: boolean;
  /** 0..100 */
  score: number;
  title: string;
  hook: string;
  keywords: string[];
  /** Why the score is what it is — shown in plain words. */
  scoreNotes: string[];
}

export interface Verification {
  ok: boolean;
  /** Seconds of video actually present in the finished file. */
  duration: number;
  expectedDuration: number;
  /** Seconds of audio present (0 when there is no audio). */
  audioDuration: number;
  /** True when an audio track exists and is audible somewhere. */
  audioPresent: boolean;
  /** Total frames the decoder handed back for the finished file. */
  framesDecoded: number;
  /** Frames expected for the duration at the clip frame rate. */
  framesExpected: number;
  /** How far into the clip the picture is still changing (0..1). */
  motionThrough: number;
  /** Per-window motion samples across the whole clip. */
  motionSamples: number[];
  /** Longest stretch with no picture change, in seconds. */
  longestFreeze: number;
  attempts: number;
  engine: string;
  /** Non-failing remarks, e.g. a sound check this device could not perform. */
  notes?: string[];
  messages: string[];
  checkedAt: number;
}

export interface Clip {
  id: string;
  runId: string;
  index: number;
  start: number;
  end: number;
  duration: number;
  layout: LayoutMode;
  autoLayout: LayoutMode;
  status: ClipStatus;
  analysis: ClipAnalysis | null;
  progress: number;
  progressText: string;
  error: string | null;
  verification: Verification | null;
  fileName: string;
  mime: string;
  sizeBytes: number;
  /** Object URL for the exported blob — transient, never persisted. */
  url?: string | null;
  /** Object URL for the thumbnail — transient. */
  thumbUrl?: string | null;
  edited: boolean;
  exportedAt: number | null;
  engine: string | null;
}

export interface RunMeta {
  id: string;
  createdAt: number;
  sourceName: string;
  sourceKind: 'url' | 'file';
  sourceUrl?: string;
  sourceDuration: number;
  sourceWidth: number;
  sourceHeight: number;
  sourceCodec: string;
  clipCount: number;
  settings: ExportSettings;
  done: boolean;
  /** Plain-word reason when the whole run could not finish. */
  error?: string | null;
}

export interface ExportSettings {
  minSeconds: number;
  maxSeconds: number;
  targetSeconds: number;
  width: number;
  height: number;
  fps: number;
  /** 'fast' = WebCodecs offline, 'realtime' = captureStream+MediaRecorder. */
  mode: 'fast' | 'realtime';
  /** Which candidates become clips: all of them, only high scores, or exactly N. */
  pick: 'auto' | 'best' | 'count';
  pickCount: number;
  bestScore: number;
  /** Keep the clip after a failed verification and retry with the other engine. */
  autoRebuild: boolean;
  burnTitle: boolean;
  faceBoost: number;
  preferFace: boolean;
}

export const DEFAULT_SETTINGS: ExportSettings = {
  minSeconds: 12,
  maxSeconds: 45,
  targetSeconds: 28,
  width: 720,
  height: 1280,
  fps: 30,
  mode: 'fast',
  pick: 'auto',
  pickCount: 3,
  bestScore: 80,
  autoRebuild: true,
  burnTitle: false,
  faceBoost: 1.35,
  preferFace: true,
};

export const APP_VERSION = '2.0.0';

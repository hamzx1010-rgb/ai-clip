/**
 * Post-export verification.
 *
 * The finished file is read BACK and checked on its own:
 *   - is it as long as it should be?
 *   - does the picture keep changing all the way to the end (not just at the
 *     start)?
 *   - is the video track as long as the audio track?
 *   - is there sound?
 *   - how many frames did the decoder really hand back?
 *
 * Two independent readers are used so a container quirk cannot hide a freeze:
 *   1. a WebCodecs/frame-accurate pass when the file is an MP4 we can demux;
 *   2. a playback pass that seeks through the file in a <video> element and
 *      compares small grey thumbnails window by window.
 * The playback pass works for ANY container (MP4 or WebM), so it always runs.
 */

import { measureAudioInBlob } from './audio';
import { grabGray, grayDiff, makeVideoEl } from './frames';
import type { ExportResult } from './export-types';
import type { Verification } from './types';

export interface VerifyOptions {
  /** Expected clip length in seconds. */
  expectedDuration: number;
  fps: number;
  /** True when the source itself had an audio track. */
  sourceHasAudio: boolean;
  /** Longest acceptable stretch with no picture change, in seconds. */
  maxFreezeSeconds?: number;
  /** How many windows to compare across the clip. */
  windows?: number;
  signal?: AbortSignal;
}

export async function verifyExport(
  blob: Blob,
  result: Pick<ExportResult, 'engine' | 'framesWritten' | 'framesExpected'>,
  opts: VerifyOptions,
): Promise<Verification> {
  const maxFreeze = opts.maxFreezeSeconds ?? Math.min(1.6, Math.max(0.6, opts.expectedDuration * 0.15));
  const windows = Math.max(6, Math.min(28, opts.windows ?? Math.round(opts.expectedDuration / 1.2)));
  const messages: string[] = [];
  let attempts = 1;

  const url = URL.createObjectURL(blob);
  const video = makeVideoEl(url);

  try {
    /* ---------- duration ---------- */
    let duration = 0;
    try {
      duration = await loadDuration(video, opts.expectedDuration);
    } catch (e) {
      messages.push(`Could not open the finished file: ${(e as Error).message}`);
    }

    /* ---------- audio ---------- */
    const audio = await measureAudioInBlob(blob);
    const audioPresent = audio.audible && audio.duration > 0.2;
    if (opts.sourceHasAudio && !audioPresent) {
      messages.push('The source has sound but the finished clip is silent');
    }
    if (audio.duration > 0 && duration > 0 && Math.abs(audio.duration - duration) > 1.2) {
      messages.push(
        `Video is ${duration.toFixed(1)}s but audio is ${audio.duration.toFixed(1)}s — they do not match`,
      );
    }

    /* ---------- motion across the whole clip ---------- */
    const scan = await scanMotion(video, duration || opts.expectedDuration, windows, opts.signal);
    if (scan.framesRead < windows * 0.6) {
      messages.push(`Only ${scan.framesRead} of ${windows} checks could read the picture back`);
    }

    const freeze = scan.longestFreeze;
    if (freeze > maxFreeze && scan.framesRead >= windows * 0.6) {
      messages.push(
        `The picture stops changing for ${freeze.toFixed(1)}s (at about ${scan.freezeAt.toFixed(1)}s in)`,
      );
    }
    if (scan.movingWindows < Math.max(2, Math.floor(scan.compared * 0.35))) {
      messages.push('Almost no movement anywhere in the clip');
    }

    /* ---------- length ---------- */
    if (duration > 0) {
      const short = opts.expectedDuration - duration;
      if (short > 1.2) messages.push(`The clip is ${short.toFixed(1)}s shorter than it should be`);
    } else {
      messages.push('The finished file reports no duration');
    }

    /* ---------- frame count ---------- */
    const framesExpected = result.framesExpected || Math.max(1, Math.round(opts.expectedDuration * opts.fps));
    let framesDecoded = result.framesWritten;
    if (scan.framesRead > 0) {
      // trust the read-back too: it proves the file itself is playable throughout
      framesDecoded = Math.max(framesDecoded, Math.round(scan.framesRead / windows * framesExpected));
    }
    if (framesDecoded < framesExpected * 0.6) {
      messages.push(`Only about ${framesDecoded} frames are in the file, expected about ${framesExpected}`);
    }

    const ok = messages.length === 0 && duration > 0 && (!opts.sourceHasAudio || audioPresent);

    return {
      ok,
      duration,
      expectedDuration: opts.expectedDuration,
      audioDuration: audio.duration,
      audioPresent,
      framesDecoded,
      framesExpected,
      motionThrough: scan.motionThrough,
      motionSamples: scan.samples,
      longestFreeze: freeze,
      attempts,
      engine: result.engine,
      messages,
      checkedAt: Date.now(),
    };
  } finally {
    attempts = 1;
    video.pause();
    video.removeAttribute('src');
    video.load();
    video.remove();
    URL.revokeObjectURL(url);
  }
}

/* ------------------------------------------------------------------ */

async function loadDuration(video: HTMLVideoElement, expected: number): Promise<number> {
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('the file did not open in time')), 20000);
    const ok = () => {
      clearTimeout(timer);
      resolve();
    };
    video.addEventListener('loadedmetadata', ok, { once: true });
    video.addEventListener('error', () => {
      clearTimeout(timer);
      reject(new Error('the browser could not play the finished file'));
    }, { once: true });
    if (video.readyState >= 1) ok();
  });

  let d = video.duration;
  if (!Number.isFinite(d) || d <= 0) {
    // Some encoders write an open-ended duration; nudge it.
    await new Promise<void>((resolve) => {
      const timer = setTimeout(resolve, 2500);
      const onTime = () => {
        if (Number.isFinite(video.duration) && video.duration > 0) {
          clearTimeout(timer);
          video.removeEventListener('timeupdate', onTime);
          resolve();
        }
      };
      video.addEventListener('timeupdate', onTime);
      try {
        video.currentTime = Math.max(0.1, expected * 0.5);
      } catch {
        /* ignore */
      }
    });
    d = video.duration;
  }
  return Number.isFinite(d) && d > 0 ? d : 0;
}

interface MotionScan {
  samples: number[];
  longestFreeze: number;
  freezeAt: number;
  motionThrough: number;
  movingWindows: number;
  compared: number;
  framesRead: number;
}

/**
 * Walk the finished file and compare neighbouring windows.
 * Each window is ~1/fps apart in time; we read a 48x48 grey thumbnail and
 * measure how much it changed. A frozen clip shows ~0 change everywhere after
 * the freeze point, which is exactly what we are looking for.
 */
async function scanMotion(
  video: HTMLVideoElement,
  duration: number,
  windows: number,
  signal?: AbortSignal,
): Promise<MotionScan> {
  const empty: MotionScan = {
    samples: [],
    longestFreeze: 0,
    freezeAt: 0,
    motionThrough: 0,
    movingWindows: 0,
    compared: 0,
    framesRead: 0,
  };
  if (!(duration > 0)) return empty;

  // Sample the full span, but keep the step small enough to catch a freeze.
  const step = Math.min(0.45, duration / windows);
  const points: number[] = [];
  for (let t = step * 0.5; t < duration - step * 0.25; t += step) points.push(t);
  if (points.length < 4) {
    for (let i = 0; i < 8; i++) points.push((duration * (i + 0.5)) / 8);
  }

  const samples: number[] = [];
  const canvas = document.createElement('canvas');
  let prev: Uint8ClampedArray | null = null;
  let framesRead = 0;
  let movingWindows = 0;
  let compared = 0;
  let longestFreeze = 0;
  let freezeStart: number | null = null;
  let freezeAt = 0;
  let lastMovingT = 0;

  for (let i = 0; i < points.length; i++) {
    if (signal?.aborted) break;
    const g = await grabGray(video, points[i], 48, canvas);
    if (!g) {
      samples.push(0);
      continue;
    }
    framesRead++;
    if (prev) {
      const d = grayDiff(prev, g.gray);
      samples.push(Number(d.toFixed(3)));
      compared++;
      const moving = d > 0.6 || g.empty === false && d > 0.25;
      if (moving) {
        movingWindows++;
        if (freezeStart !== null) {
          const run = points[i] - freezeStart;
          if (run > longestFreeze) {
            longestFreeze = run;
            freezeAt = freezeStart;
          }
          freezeStart = null;
        }
        lastMovingT = points[i];
      } else if (freezeStart === null) {
        freezeStart = points[i - 1] ?? points[i];
      }
    }
    prev = g.gray;
    if (i % 4 === 3) await new Promise((r) => setTimeout(r, 0));
  }

  if (freezeStart !== null) {
    const run = (points[points.length - 1] ?? duration) - freezeStart;
    if (run > longestFreeze) {
      longestFreeze = run;
      freezeAt = freezeStart;
    }
  }

  // "Motion through" = how far into the clip the picture was still changing.
  const motionThrough = duration > 0 ? Math.min(1, lastMovingT / duration) : 0;

  return {
    samples,
    longestFreeze,
    freezeAt,
    motionThrough,
    movingWindows,
    compared,
    framesRead,
  };
}

/** Human-readable verdict for the UI. */
export function verificationSummary(v: Verification | null): string {
  if (!v) return 'Not checked yet';
  if (v.ok) {
    return `Checked: ${v.duration.toFixed(1)}s long, picture moves to ${Math.round(
      v.motionThrough * 100,
    )}%, sound ${v.audioPresent ? 'present' : 'absent'}`;
  }
  return v.messages.join(' · ') || 'Failed the check';
}

/**
 * Pulling frames out of a <video> element.
 *
 * This module is also where ClipForge counts the frames it actually received,
 * because "the decoder quietly returned nothing" is exactly how a clip ends up
 * frozen on one picture. Every consumer gets a real count, never a guess.
 */

export interface FrameSample {
  t: number;
  /** 8-bit grey thumbnail, side `size`. */
  gray: Uint8ClampedArray;
  size: number;
  /** True when this frame differs from the previous sampled frame. */
  distinct: boolean;
}

export interface SamplerHandle {
  video: HTMLVideoElement;
  close(): void;
}

/** Mean absolute difference between two same-size grey buffers, 0..255. */
export function grayDiff(a: Uint8ClampedArray, b: Uint8ClampedArray): number {
  const n = Math.min(a.length, b.length);
  if (!n) return 0;
  let sum = 0;
  // stride to keep it cheap on a phone
  const step = n > 4096 ? 4 : 1;
  let count = 0;
  for (let i = 0; i < n; i += step) {
    sum += Math.abs(a[i] - b[i]);
    count++;
  }
  return count ? sum / count : 0;
}

export function rgbaToGray(data: Uint8ClampedArray, w: number, h: number): Uint8ClampedArray {
  const out = new Uint8ClampedArray(w * h);
  for (let i = 0, p = 0; i < out.length; i++, p += 4) {
    out[i] = (data[p] * 77 + data[p + 1] * 150 + data[p + 2] * 29) >> 8;
  }
  return out;
}

export function makeVideoEl(src: string): HTMLVideoElement {
  const v = document.createElement('video');
  v.src = src;
  v.muted = true;
  v.playsInline = true;
  v.preload = 'auto';
  v.crossOrigin = 'anonymous';
  v.disablePictureInPicture = true;
  // Keep it off-screen but rendered — display:none can stop frame delivery.
  v.style.cssText =
    'position:fixed;left:-9999px;top:0;width:2px;height:2px;opacity:0.01;pointer-events:none;';
  document.body.appendChild(v);
  return v;
}

export function waitForEvent(
  el: HTMLVideoElement,
  ev: string,
  timeoutMs = 15000,
): Promise<void> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => {
      cleanup();
      reject(new Error(`Timed out waiting for ${ev}`));
    }, timeoutMs);
    const ok = () => {
      cleanup();
      resolve();
    };
    const bad = () => {
      cleanup();
      reject(new Error('The video element failed'));
    };
    function cleanup() {
      clearTimeout(t);
      el.removeEventListener(ev, ok);
      el.removeEventListener('error', bad);
    }
    el.addEventListener(ev, ok, { once: true });
    el.addEventListener('error', bad, { once: true });
  });
}

export async function readyVideo(src: string): Promise<HTMLVideoElement> {
  const v = makeVideoEl(src);
  if (v.readyState >= 2) return v;
  await waitForEvent(v, 'loadeddata', 25000);
  return v;
}

/** Seek and wait until the frame for `t` is actually available to draw. */
export function seekTo(v: HTMLVideoElement, t: number, timeoutMs = 8000): Promise<void> {
  return new Promise((resolve, reject) => {
    const target = Math.max(0, t);
    if (Math.abs(v.currentTime - target) < 0.004 && v.readyState >= 2) return resolve();
    const timer = setTimeout(() => {
      v.removeEventListener('seeked', onSeeked);
      reject(new Error('Seeking took too long'));
    }, timeoutMs);
    function onSeeked() {
      clearTimeout(timer);
      v.removeEventListener('seeked', onSeeked);
      resolve();
    }
    v.addEventListener('seeked', onSeeked, { once: true });
    try {
      v.currentTime = target;
    } catch (e) {
      clearTimeout(timer);
      v.removeEventListener('seeked', onSeeked);
      reject(e instanceof Error ? e : new Error('Seek failed'));
    }
  });
}

/**
 * Grab one frame at time t as a small grey thumbnail.
 * Returns null when the decoder gave us nothing usable (black/empty), which the
 * caller must treat as "do not trust this clip".
 */
export async function grabGray(
  v: HTMLVideoElement,
  t: number,
  size = 48,
  canvas?: HTMLCanvasElement,
): Promise<{ gray: Uint8ClampedArray; size: number; empty: boolean } | null> {
  try {
    await seekTo(v, t);
  } catch {
    return null;
  }
  const w = v.videoWidth;
  const h = v.videoHeight;
  if (!w || !h) return null;

  const c = canvas ?? document.createElement('canvas');
  const side = size;
  c.width = side;
  c.height = side;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  if (!ctx) return null;
  ctx.clearRect(0, 0, side, side);
  // cover-fit so aspect does not matter for the comparison
  const scale = Math.max(side / w, side / h);
  const dw = w * scale;
  const dh = h * scale;
  try {
    ctx.drawImage(v, (side - dw) / 2, (side - dh) / 2, dw, dh);
  } catch {
    return null;
  }
  let img: ImageData;
  try {
    img = ctx.getImageData(0, 0, side, side);
  } catch {
    return null; // tainted canvas — cannot verify
  }
  const gray = rgbaToGray(img.data, side, side);
  let sum = 0;
  for (let i = 0; i < gray.length; i++) sum += gray[i];
  const mean = sum / gray.length;
  // Fully black or fully white and perfectly flat = decoder gave nothing.
  let varSum = 0;
  for (let i = 0; i < gray.length; i++) varSum += Math.abs(gray[i] - mean);
  const empty = varSum / gray.length < 0.35;
  return { gray, size: side, empty };
}

/**
 * Sample motion + face evidence across a time range.
 * Uses requestVideoFrameCallback when available (real decoded frames) and
 * falls back to seek-stepping. Always reports how many frames it really got.
 */
export async function sampleRange(
  v: HTMLVideoElement,
  from: number,
  to: number,
  opts: {
    samples?: number;
    size?: number;
    onFrame?: (t: number, gray: Uint8ClampedArray, size: number) => void;
    signal?: AbortSignal;
  } = {},
): Promise<{ frames: number; motion: number; samples: number[]; lastGray: Uint8ClampedArray | null }> {
  const n = Math.max(2, opts.samples ?? 14);
  const size = opts.size ?? 48;
  const canvas = document.createElement('canvas');
  const out: number[] = [];
  let prev: Uint8ClampedArray | null = null;
  let frames = 0;
  let lastGray: Uint8ClampedArray | null = null;

  for (let i = 0; i < n; i++) {
    if (opts.signal?.aborted) break;
    const t = from + ((to - from) * i) / (n - 1 || 1);
    const g = await grabGray(v, t, size, canvas);
    if (!g) {
      out.push(0);
      continue;
    }
    frames++;
    lastGray = g.gray;
    const d = prev ? grayDiff(prev, g.gray) : 0;
    out.push(d);
    opts.onFrame?.(t, g.gray, size);
    prev = g.gray;
    // yield to the main thread so the UI stays alive on a phone
    if (i % 3 === 2) await new Promise((r) => setTimeout(r, 0));
  }

  const motionSamples = out.slice(1);
  const motion = motionSamples.length
    ? motionSamples.reduce((a, b) => a + b, 0) / motionSamples.length
    : 0;
  return { frames, motion, samples: out, lastGray };
}

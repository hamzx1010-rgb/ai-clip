/**
 * Keep the screen on while clips are analysed or exported.
 *
 * navigator.wakeLock is the real fix, but Brave/Chrome drop it the moment the
 * tab is hidden and never give it back on their own — so we re-acquire on
 * visibilitychange. As a second net we also run a silent WebAudio loop, which
 * stops Android from freezing a backgrounded tab's timers outright.
 */

let lock: WakeLockSentinel | null = null;
let wanted = false;
let audioCtx: AudioContext | null = null;
let silentNode: AudioNode | null = null;
let holders = 0;

export function wakeSupported(): boolean {
  return typeof navigator !== 'undefined' && 'wakeLock' in navigator;
}

export function wakeActive(): boolean {
  return lock !== null && !lock.released;
}

async function acquire() {
  if (!wanted) return;
  try {
    if ('wakeLock' in navigator) {
      lock = await navigator.wakeLock.request('screen');
      lock.addEventListener('release', () => {
        lock = null;
        // Re-acquire when we come back to the foreground.
        if (wanted) setTimeout(acquire, 400);
      });
    }
  } catch {
    lock = null;
  }
  startSilentAudio();
}

function startSilentAudio() {
  try {
    if (!audioCtx) {
      const Ctor: typeof AudioContext =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      audioCtx = new Ctor();
    }
    if (!silentNode && audioCtx) {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      gain.gain.value = 0.0001; // inaudible, but keeps the tab "playing"
      osc.connect(gain).connect(audioCtx.destination);
      osc.start();
      silentNode = gain;
    }
    if (audioCtx && audioCtx.state === 'suspended') void audioCtx.resume();
  } catch {
    /* ignore — wake lock alone is still useful */
  }
}

function stopSilentAudio() {
  try {
    if (silentNode) {
      silentNode.disconnect();
      silentNode = null;
    }
    if (audioCtx && audioCtx.state !== 'closed') void audioCtx.close();
    audioCtx = null;
  } catch {
    /* ignore */
  }
}

/** Call once when work starts; safe to call repeatedly. */
export function wakeAcquire() {
  holders += 1;
  if (!wanted) {
    wanted = true;
    void acquire();
    document.addEventListener('visibilitychange', onVis);
  }
}

/** Call when all work is finished. */
export function wakeRelease() {
  holders = Math.max(0, holders - 1);
  if (holders === 0 && wanted) {
    wanted = false;
    document.removeEventListener('visibilitychange', onVis);
    try {
      void lock?.release();
    } catch {
      /* ignore */
    }
    lock = null;
    stopSilentAudio();
  }
}

function onVis() {
  if (document.visibilityState === 'visible' && wanted) void acquire();
}

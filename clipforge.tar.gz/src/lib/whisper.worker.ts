/// <reference lib="webworker" />
// On-device speech-to-text (Whisper via Transformers.js). Free, no API key. The model is downloaded once and cached by the browser.
import { pipeline, env } from '@huggingface/transformers';

env.allowLocalModels = false;
env.useBrowserCache = true;

type Req = { id: number; type: 'transcribe'; audio: Float32Array; model: string; language: string };
type Chunk = { text: string; timestamp: [number, number | null] };

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let asr: any = null;
let asrModel = '';

async function load(model: string) {
  if (asr && asrModel === model) return asr;
  const files: Record<string, { loaded: number; total: number }> = {};
  asr = await pipeline('automatic-speech-recognition', model, {
    device: 'wasm',
    dtype: { encoder_model: 'q8', decoder_model_merged: 'q8' },
    progress_callback: (p: { status: string; file?: string; loaded?: number; total?: number }) => {
      if (p.status === 'progress' && p.file) {
        files[p.file] = { loaded: p.loaded || 0, total: p.total || 0 };
        const loaded = Object.values(files).reduce((a, f) => a + f.loaded, 0);
        const total = Object.values(files).reduce((a, f) => a + f.total, 0);
        postMessage({ type: 'download', loaded, total });
      }
    },
  } as never);
  asrModel = model;
  return asr;
}

self.onmessage = async (e: MessageEvent<Req>) => {
  const { id, audio, model, language } = e.data;
  try {
    const t = await load(model);
    postMessage({ type: 'ready', id });
    const multilingual = !model.includes('.en');
    const out = await t(audio, {
      return_timestamps: 'word',
      chunk_length_s: 30,
      stride_length_s: 5,
      ...(multilingual ? { task: 'transcribe', ...(language && language !== 'auto' ? { language } : {}) } : {}),
    });
    const chunks: Chunk[] = (out?.chunks || []) as Chunk[];
    postMessage({ type: 'result', id, words: chunks.map((c) => ({ w: String(c.text).trim(), s: c.timestamp[0] ?? 0, e: c.timestamp[1] ?? (c.timestamp[0] ?? 0) + 0.3 })).filter((w) => w.w) });
  } catch (err) {
    postMessage({ type: 'error', id, error: String((err as Error)?.message || err) });
  }
};

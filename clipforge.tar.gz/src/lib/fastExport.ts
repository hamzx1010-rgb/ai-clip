// Faster-than-real-time clip export.
// Frames are decoded straight from the source file with WebCodecs (via Mediabunny), drawn with the exact same
// renderer used by the preview (reframe, captions, effects), and encoded as fast as the machine allows.
// The audio mix (original audio + music + SFX + bleeps) is rendered offline with an OfflineAudioContext.
import {
  ALL_FORMATS, AudioBufferSink, Conversion, AudioBufferSource, BlobSource, BufferTarget, CanvasSource, Input, Mp4OutputFormat,
  Output, Quality, VideoSampleSink, WebMOutputFormat, canEncodeAudio, canEncodeVideo,
} from 'mediabunny';
import type { InputVideoTrack } from 'mediabunny';
import type { ClipEngine } from './clipRender';
import { aspectSize } from './clipRender';
import { renderMusic, renderSfx } from './synth';
import { PROFANITY, norm } from './nlp';
import type { Word } from './types';

const FPS = 30;
const SR = 48000;

type Plan = { container: 'mp4' | 'webm'; video: 'avc' | 'vp9' | 'vp8'; audio: 'aac' | 'opus'; W: number; H: number; bitrate: number };

const bitrateFor = (res: number) => (res >= 1080 ? 8_000_000 : res >= 720 ? 5_000_000 : 2_500_000);
const canV = async (c: 'avc' | 'vp9' | 'vp8', W: number, H: number, bitrate: number) => { try { return await canEncodeVideo(c, { width: W, height: H, quality: new Quality({ bitrate }) }); } catch { return false; } };
const canA = async (c: 'aac' | 'opus') => { try { return await canEncodeAudio(c, { numberOfChannels: 2, sampleRate: SR, quality: new Quality({ bitrate: 160_000 }) }); } catch { return false; } };

// Many browsers (Chrome on Linux, Firefox, older Safari) can't encode AAC natively. Opus-in-MP4 plays in Chrome/VLC but
// breaks in phone galleries, QuickTime and social apps — so we load a small WASM AAC encoder when needed.
let aacReady: Promise<boolean> | null = null;
export function ensureAac(): Promise<boolean> {
  return (aacReady ??= (async () => {
    if (await canA('aac')) return true;
    try { const m = await import('@mediabunny/aac-encoder'); m.registerAacEncoder(); } catch (e) { console.warn('AAC encoder failed to load', e); }
    return canA('aac');
  })());
}

const planCache: Record<string, Plan[]> = {};
/** Encoder setups to try, best first: MP4 (H.264 + AAC) at the requested size, then 720p MP4, then WebM as a last resort. */
async function candidatePlans(aspect: Parameters<typeof aspectSize>[0], res: number): Promise<Plan[]> {
  const key = `${aspect}@${res}`;
  if (planCache[key]) return planCache[key];
  const aac = await ensureAac(), opus = await canA('opus');
  const out: Plan[] = [];
  for (const r of res > 720 ? [res, 720] : [res]) {
    const [W, H] = aspectSize(aspect, r), br = bitrateFor(r);
    if ((aac || opus) && (await canV('avc', W, H, br))) out.push({ container: 'mp4', video: 'avc', audio: aac ? 'aac' : 'opus', W, H, bitrate: br });
  }
  if (opus) {
    const [W, H] = aspectSize(aspect, res), br = bitrateFor(res);
    for (const c of ['vp9', 'vp8'] as const) if (await canV(c, W, H, br)) out.push({ container: 'webm', video: c, audio: 'opus', W, H, bitrate: br });
  }
  return (planCache[key] = out);
}

/** Is fast export possible in this browser at all? */
export function fastExportSupported(): boolean {
  return typeof VideoEncoder !== 'undefined' && typeof VideoDecoder !== 'undefined' && typeof OfflineAudioContext !== 'undefined';
}

function outTime(eng: ClipEngine, src: number): number | null {
  for (let i = 0; i < eng.pieces.length; i++) {
    const p = eng.pieces[i];
    if (src >= p.s && src < p.e) return eng.offsets[i] + (src - p.s);
  }
  return null;
}
function srcTime(eng: ClipEngine, out: number): number {
  for (let i = 0; i < eng.pieces.length; i++) {
    const p = eng.pieces[i];
    if (out >= eng.offsets[i] && out < eng.offsets[i] + (p.e - p.s)) return p.s + (out - eng.offsets[i]);
  }
  const last = eng.pieces[eng.pieces.length - 1];
  return last ? last.e : 0;
}

async function mixAudio(eng: ClipEngine, input: Input): Promise<AudioBuffer> {
  const o = eng.c.options;
  const total = Math.max(0.1, eng.total);
  const oac = new OfflineAudioContext(2, Math.ceil(total * SR), SR);
  const orig = oac.createGain(); orig.connect(oac.destination);

  // 1) original audio, piece by piece
  const at = await input.getPrimaryAudioTrack();
  if (at && (await at.canDecode())) {
    const sink = new AudioBufferSink(at);
    for (let i = 0; i < eng.pieces.length; i++) {
      const p = eng.pieces[i];
      const chunks: { buffer: AudioBuffer; timestamp: number }[] = [];
      for await (const wb of sink.buffers(Math.max(0, p.s - 0.05), p.e + 0.05)) chunks.push(wb);
      if (!chunks.length) continue;
      const rate = chunks[0].buffer.sampleRate, ch = Math.min(2, chunks[0].buffer.numberOfChannels);
      const n = Math.max(1, Math.ceil((p.e - p.s) * rate));
      const pb = new AudioBuffer({ length: n, sampleRate: rate, numberOfChannels: ch });
      for (const wb of chunks) {
        const off = Math.round((wb.timestamp - p.s) * rate);
        for (let c = 0; c < ch; c++) {
          const data = wb.buffer.getChannelData(Math.min(c, wb.buffer.numberOfChannels - 1));
          const s0 = Math.max(0, -off), d0 = Math.max(0, off);
          const count = Math.min(data.length - s0, n - d0);
          if (count > 0) pb.getChannelData(c).set(data.subarray(s0, s0 + count), d0);
        }
      }
      // 12 ms fade in/out on every piece: removes the click of a hard splice (inaudible as a fade)
      const fl = Math.min(Math.floor(rate * 0.012), Math.floor(n / 4));
      for (let c = 0; c < ch; c++) { const d = pb.getChannelData(c); for (let k = 0; k < fl; k++) { const g = k / fl; d[k] *= g; d[n - 1 - k] *= g; } }
      const s = oac.createBufferSource(); s.buffer = pb; s.connect(orig); s.start(eng.offsets[i]);
    }
  }

  // 2) profanity bleeps
  if (o.censor) {
    const bleep = oac.createGain(); bleep.gain.value = 0; bleep.connect(oac.destination);
    const osc = oac.createOscillator(); osc.frequency.value = 1000; osc.connect(bleep); osc.start();
    for (const w of eng.words as Word[]) {
      if (!PROFANITY.includes(norm(w.w))) continue;
      const a = outTime(eng, w.s), b = outTime(eng, w.e - 0.001);
      if (a === null || b === null) continue;
      orig.gain.setValueAtTime(0, a); orig.gain.setValueAtTime(1, b);
      bleep.gain.setValueAtTime(0.25, a); bleep.gain.setValueAtTime(0, b);
    }
  }

  // 3) music bed with ducking
  if (o.music) {
    const mb = await renderMusic(o.music);
    const mg = oac.createGain(); mg.gain.value = o.musicVolume; mg.connect(oac.destination);
    const ms = oac.createBufferSource(); ms.buffer = mb; ms.loop = true; ms.connect(mg); ms.start(0);
    if (o.ducking) {
      const a = eng.c.audio;
      for (let t = 0; t < total; t += 0.1) {
        const src = srcTime(eng, t);
        let speaking = false;
        if (a) { const i = Math.floor(src / a.hop); speaking = !!(a.speech[i] || a.speech[i + 3] || a.speech[i - 3]); }
        else speaking = eng.words.some((w) => src >= w.s - 0.2 && src <= w.e + 0.2);
        mg.gain.setTargetAtTime(speaking ? o.musicVolume * 0.28 : o.musicVolume, t, 0.12);
      }
    }
  }

  // 4) sound effects
  if (o.sfx) {
    for (const e of eng.events) {
      if (e.kind !== 'sfx' || !e.sfx) continue;
      const t = outTime(eng, Math.max(e.t, eng.pieces[0]?.s ?? 0));
      if (t === null) continue;
      const buf = await renderSfx(e.sfx);
      const g = oac.createGain(); g.gain.value = e.v; g.connect(oac.destination);
      const s = oac.createBufferSource(); s.buffer = buf; s.connect(g); s.start(t);
    }
  }
  return oac.startRendering();
}

/**
 * Render one clip to a file, much faster than real time.
 * Tries several encoder setups; throws only if none works — callers then fall back to real-time export.
 */
export async function exportClipFast(eng: ClipEngine, file: Blob, res: number, onProgress?: (p: number) => void, shouldCancel?: () => boolean): Promise<Blob> {
  if (!fastExportSupported()) throw new Error('this browser has no WebCodecs');
  if (Math.abs(eng.c.options.speed - 1) > 0.01) throw new Error('speed change needs real-time export');
  const plans = await candidatePlans(eng.c.options.aspect, res);
  if (!plans.length) throw new Error('no usable video encoder');

  const input = new Input({ source: new BlobSource(file), formats: ALL_FORMATS });
  try {
    const vt = await input.getPrimaryVideoTrack();
    if (!vt || !(await vt.canDecode())) throw new Error(`can't decode ${vt?.codec ?? 'this'} video here`);
    eng.configure(eng.c.options, eng.c.clip);
    onProgress?.(0.01);
    const audio = await mixAudio(eng, input);
    onProgress?.(0.06);
    const errors: string[] = [];
    for (const plan of plans) {
      if (shouldCancel?.()) throw new Error('cancelled');
      try {
        return await encodeWith(plan, eng, vt, audio, onProgress, shouldCancel);
      } catch (e) {
        if (shouldCancel?.()) throw e;
        console.warn(`Fast export with ${plan.video}/${plan.audio} ${plan.W}x${plan.H} failed`, e);
        errors.push(`${plan.video} ${plan.W}x${plan.H}: ${(e as Error).message}`);
      }
    }
    throw new Error(errors.join(' · '));
  } finally {
    input.dispose?.();
    const [pw, ph] = aspectSize(eng.c.options.aspect, 720);
    eng.canvas.width = pw; eng.canvas.height = ph;
  }
}

async function encodeWith(plan: Plan, eng: ClipEngine, vt: InputVideoTrack, audio: AudioBuffer, onProgress?: (p: number) => void, shouldCancel?: () => boolean): Promise<Blob> {
  eng.canvas.width = plan.W; eng.canvas.height = plan.H;
  const output = new Output({
    format: plan.container === 'mp4' ? new Mp4OutputFormat({ fastStart: 'in-memory' }) : new WebMOutputFormat(),
    target: new BufferTarget(),
  });
  const vs = new CanvasSource(eng.canvas, { codec: plan.video, quality: new Quality({ bitrate: plan.bitrate }), keyFrameInterval: 2, latencyMode: 'quality' });
  const as = new AudioBufferSource({ codec: plan.audio, quality: new Quality({ bitrate: 160_000 }) });
  output.addVideoTrack(vs, { frameRate: FPS });
  output.addAudioTrack(as);
  let ok = false;
  try {
    await output.start();
    await as.add(audio);
    as.close();
    const sink = new VideoSampleSink(vt);
    const nTotal = Math.max(1, Math.ceil(eng.total * FPS));
    let done = 0;
    for (let i = 0; i < eng.pieces.length; i++) {
      const p = eng.pieces[i];
      const ks: number[] = [];
      for (let k = Math.ceil(eng.offsets[i] * FPS - 1e-6); k < nTotal && k / FPS < eng.offsets[i] + (p.e - p.s) - 1e-6; k++) ks.push(k);
      if (!ks.length) continue;
      const ts = ks.map((k) => p.s + (k / FPS - eng.offsets[i]));
      let j = 0;
      for await (const sample of sink.samplesAtTimestamps(ts)) {
        if (shouldCancel?.()) { sample?.close(); throw new Error('cancelled'); }
        const k = ks[j], t = ts[j]; j++;
        eng.pi = i;
        if (sample) eng.draw({ img: sample.toCanvasImageSource(), w: sample.displayWidth, h: sample.displayHeight, t });
        await vs.add(k / FPS, 1 / FPS);
        sample?.close();
        done++;
        if (done % 5 === 0) onProgress?.(0.06 + 0.93 * (done / nTotal));
      }
    }
    vs.close();
    await output.finalize();
    ok = true;
  } finally {
    if (!ok) await output.cancel().catch(() => {});
  }
  onProgress?.(1);
  const buf = (output.target as BufferTarget).buffer!;
  return new Blob([buf], { type: plan.container === 'mp4' ? 'video/mp4' : 'video/webm' });
}

/**
 * Real-time recordings (MediaRecorder) come out as streamed files with no duration/seek index, which many players
 * show as broken. Rewrite them into a normal file (no re-encode for video; audio → AAC for MP4 compatibility).
 */
export async function finalizeRecording(blob: Blob): Promise<Blob> {
  const attempt = async (toMp4: boolean, transcodeVideo: boolean): Promise<Blob | null> => {
    const input = new Input({ source: new BlobSource(blob), formats: ALL_FORMATS });
    try {
      const aac = toMp4 && (await ensureAac());
      const output = new Output({ format: toMp4 ? new Mp4OutputFormat({ fastStart: 'in-memory' }) : new WebMOutputFormat(), target: new BufferTarget() });
      const conv = await Conversion.init({
        input, output,
        video: transcodeVideo ? { codec: 'avc', bitrate: 5_000_000, frameRate: FPS } : undefined,
        audio: aac ? { codec: 'aac', bitrate: 160_000 } : undefined,
      });
      if (!conv.isValid || conv.discardedTracks.some((d) => d.track.type === 'video')) {
        console.warn('conversion not possible', conv.discardedTracks.map((d) => `${d.track.type}:${d.reason}`).join(', '));
        return null;
      }
      await conv.execute();
      return new Blob([(output.target as BufferTarget).buffer!], { type: toMp4 ? 'video/mp4' : 'video/webm' });
    } catch (e) {
      console.warn('finalizeRecording attempt failed', { toMp4, transcodeVideo }, e);
      return null;
    } finally {
      input.dispose?.();
    }
  };
  let codec: string | null = null, W = 720, H = 1280;
  try {
    const input = new Input({ source: new BlobSource(blob), formats: ALL_FORMATS });
    const vt = await input.getPrimaryVideoTrack();
    codec = vt?.codec ?? null; W = vt?.displayWidth ?? W; H = vt?.displayHeight ?? H;
    input.dispose?.();
  } catch { /* unreadable → keep raw */ }
  if (codec === 'avc' || codec === 'hevc') return (await attempt(true, false)) ?? blob;
  // recorder made VP8/VP9 → convert to H.264 MP4 if this device can (phone galleries & social apps want MP4)
  if (await canV('avc', W, H, 5_000_000)) { const r = await attempt(true, true); if (r) return r; }
  return (await attempt(false, false)) ?? blob;
}

/** SRT subtitles for a rendered clip (times follow the edited output timeline). */
export function clipSrt(eng: ClipEngine): string {
  const words = (eng.words as Word[]).map((w) => ({ w: w.w, s: outTime(eng, w.s), e: outTime(eng, Math.max(w.s, w.e - 0.001)) })).filter((w) => w.s !== null && w.e !== null) as { w: string; s: number; e: number }[];
  if (!words.length) return '';
  const lines: { s: number; e: number; text: string }[] = [];
  let cur: typeof words = [];
  const flush = () => { if (cur.length) lines.push({ s: cur[0].s, e: cur[cur.length - 1].e, text: cur.map((x) => x.w).join(' ') }); cur = []; };
  for (const w of words) {
    if (cur.length && (cur.length >= 7 || w.s - cur[cur.length - 1].e > 0.7 || /[.?!]$/.test(cur[cur.length - 1].w))) flush();
    cur.push(w);
  }
  flush();
  const ts = (t: number) => { const ms = Math.round(t * 1000); const h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60; return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(ms % 1000).padStart(3, '0')}`; };
  return lines.map((l, i) => `${i + 1}\n${ts(l.s)} --> ${ts(Math.max(l.e, l.s + 0.3))}\n${l.text}\n`).join('\n');
}

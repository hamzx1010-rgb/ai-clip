// Faster-than-real-time clip export.
// Frames are decoded straight from the source file with WebCodecs (via Mediabunny), drawn with the exact same
// renderer used by the preview (reframe, captions, effects), and encoded as fast as the machine allows.
// The audio mix (original audio + music + SFX + bleeps) is rendered offline with an OfflineAudioContext.
import {
  ALL_FORMATS, AudioBufferSink, AudioBufferSource, BlobSource, BufferTarget, CanvasSource, Input, Mp4OutputFormat,
  Output, Quality, VideoSampleSink, WebMOutputFormat, canEncodeAudio, canEncodeVideo,
} from 'mediabunny';
import type { ClipEngine } from './clipRender';
import { aspectSize } from './clipRender';
import { renderMusic, renderSfx } from './synth';
import { PROFANITY, norm } from './nlp';
import type { Word } from './types';

const FPS = 30;
const SR = 48000;

type Plan = { container: 'mp4' | 'webm'; video: 'avc' | 'vp9' | 'vp8'; audio: 'aac' | 'opus' };
let planCache: Record<string, Plan | null> = {};

async function pickPlan(W: number, H: number, bitrate: number): Promise<Plan | null> {
  const key = `${W}x${H}@${bitrate}`;
  if (key in planCache) return planCache[key];
  const q = new Quality({ bitrate: bitrate });
  const v = async (c: 'avc' | 'vp9' | 'vp8') => { try { return await canEncodeVideo(c, { width: W, height: H, quality: q }); } catch { return false; } };
  const a = async (c: 'aac' | 'opus') => { try { return await canEncodeAudio(c, { numberOfChannels: 2, sampleRate: SR, quality: new Quality({ bitrate: 160_000 }) }); } catch { return false; } };
  let plan: Plan | null = null;
  if (await v('avc')) plan = { container: 'mp4', video: 'avc', audio: (await a('aac')) ? 'aac' : 'opus' };
  else if ((await v('vp9')) && (await a('opus'))) plan = { container: 'webm', video: 'vp9', audio: 'opus' };
  else if ((await v('vp8')) && (await a('opus'))) plan = { container: 'webm', video: 'vp8', audio: 'opus' };
  planCache[key] = plan;
  return plan;
}

/** Is fast export possible in this browser at all? */
export function fastExportSupported(): boolean {
  return typeof VideoEncoder !== 'undefined' && typeof VideoDecoder !== 'undefined' && typeof OfflineAudioContext !== 'undefined';
}

function outTime(eng: ClipEngine, src: number): number | null {
  for (let i = 0; i < eng.pieces.length; i++) {
    const p = eng.pieces[i];
    if (src >= p.s && src < p.e) return eng.offsets[i] + (src - p.s);
  }
  return null;
}
function srcTime(eng: ClipEngine, out: number): number {
  for (let i = 0; i < eng.pieces.length; i++) {
    const p = eng.pieces[i];
    if (out >= eng.offsets[i] && out < eng.offsets[i] + (p.e - p.s)) return p.s + (out - eng.offsets[i]);
  }
  const last = eng.pieces[eng.pieces.length - 1];
  return last ? last.e : 0;
}

async function mixAudio(eng: ClipEngine, input: Input): Promise<AudioBuffer> {
  const o = eng.c.options;
  const total = Math.max(0.1, eng.total);
  const oac = new OfflineAudioContext(2, Math.ceil(total * SR), SR);
  const orig = oac.createGain(); orig.connect(oac.destination);

  // 1) original audio, piece by piece
  const at = await input.getPrimaryAudioTrack();
  if (at && (await at.canDecode())) {
    const sink = new AudioBufferSink(at);
    for (let i = 0; i < eng.pieces.length; i++) {
      const p = eng.pieces[i];
      const chunks: { buffer: AudioBuffer; timestamp: number }[] = [];
      for await (const wb of sink.buffers(Math.max(0, p.s - 0.05), p.e + 0.05)) chunks.push(wb);
      if (!chunks.length) continue;
      const rate = chunks[0].buffer.sampleRate, ch = Math.min(2, chunks[0].buffer.numberOfChannels);
      const n = Math.max(1, Math.ceil((p.e - p.s) * rate));
      const pb = new AudioBuffer({ length: n, sampleRate: rate, numberOfChannels: ch });
      for (const wb of chunks) {
        const off = Math.round((wb.timestamp - p.s) * rate);
        for (let c = 0; c < ch; c++) {
          const data = wb.buffer.getChannelData(Math.min(c, wb.buffer.numberOfChannels - 1));
          const s0 = Math.max(0, -off), d0 = Math.max(0, off);
          const count = Math.min(data.length - s0, n - d0);
          if (count > 0) pb.getChannelData(c).set(data.subarray(s0, s0 + count), d0);
        }
      }
      const s = oac.createBufferSource(); s.buffer = pb; s.connect(orig); s.start(eng.offsets[i]);
    }
  }

  // 2) profanity bleeps
  if (o.censor) {
    const bleep = oac.createGain(); bleep.gain.value = 0; bleep.connect(oac.destination);
    const osc = oac.createOscillator(); osc.frequency.value = 1000; osc.connect(bleep); osc.start();
    for (const w of eng.words as Word[]) {
      if (!PROFANITY.includes(norm(w.w))) continue;
      const a = outTime(eng, w.s), b = outTime(eng, w.e - 0.001);
      if (a === null || b === null) continue;
      orig.gain.setValueAtTime(0, a); orig.gain.setValueAtTime(1, b);
      bleep.gain.setValueAtTime(0.25, a); bleep.gain.setValueAtTime(0, b);
    }
  }

  // 3) music bed with ducking
  if (o.music) {
    const mb = await renderMusic(o.music);
    const mg = oac.createGain(); mg.gain.value = o.musicVolume; mg.connect(oac.destination);
    const ms = oac.createBufferSource(); ms.buffer = mb; ms.loop = true; ms.connect(mg); ms.start(0);
    if (o.ducking) {
      const a = eng.c.audio;
      for (let t = 0; t < total; t += 0.1) {
        const src = srcTime(eng, t);
        let speaking = false;
        if (a) { const i = Math.floor(src / a.hop); speaking = !!(a.speech[i] || a.speech[i + 3] || a.speech[i - 3]); }
        else speaking = eng.words.some((w) => src >= w.s - 0.2 && src <= w.e + 0.2);
        mg.gain.setTargetAtTime(speaking ? o.musicVolume * 0.28 : o.musicVolume, t, 0.12);
      }
    }
  }

  // 4) sound effects
  if (o.sfx) {
    for (const e of eng.events) {
      if (e.kind !== 'sfx' || !e.sfx) continue;
      const t = outTime(eng, Math.max(e.t, eng.pieces[0]?.s ?? 0));
      if (t === null) continue;
      const buf = await renderSfx(e.sfx);
      const g = oac.createGain(); g.gain.value = e.v; g.connect(oac.destination);
      const s = oac.createBufferSource(); s.buffer = buf; s.connect(g); s.start(t);
    }
  }
  return oac.startRendering();
}

/**
 * Render one clip to a file, much faster than real time.
 * Throws if the browser can't decode the source or encode the output — callers fall back to real-time export.
 */
export async function exportClipFast(eng: ClipEngine, file: Blob, res: number, onProgress?: (p: number) => void, shouldCancel?: () => boolean): Promise<Blob> {
  if (!fastExportSupported()) throw new Error('WebCodecs not available');
  if (Math.abs(eng.c.options.speed - 1) > 0.01) throw new Error('speed change needs real-time export');
  const [W, H] = aspectSize(eng.c.options.aspect, res);
  const bitrate = res >= 1080 ? 8_000_000 : res >= 720 ? 5_000_000 : 2_500_000;
  const plan = await pickPlan(W, H, bitrate);
  if (!plan) throw new Error('No supported encoder');

  const input = new Input({ source: new BlobSource(file), formats: ALL_FORMATS });
  try {
    const vt = await input.getPrimaryVideoTrack();
    if (!vt || !(await vt.canDecode())) throw new Error('Cannot decode this video in the browser');

    // make sure the engine's timeline is built for this clip
    eng.configure(eng.c.options, eng.c.clip);
    eng.canvas.width = W; eng.canvas.height = H;
    onProgress?.(0.01);

    const audio = await mixAudio(eng, input);
    onProgress?.(0.06);

    const output = new Output({
      format: plan.container === 'mp4' ? new Mp4OutputFormat({ fastStart: 'in-memory' }) : new WebMOutputFormat(),
      target: new BufferTarget(),
    });
    const vs = new CanvasSource(eng.canvas, { codec: plan.video, quality: new Quality({ bitrate: bitrate }), keyFrameInterval: 2, latencyMode: 'quality' });
    const as = new AudioBufferSource({ codec: plan.audio, quality: new Quality({ bitrate: 160_000 }) });
    output.addVideoTrack(vs, { frameRate: FPS });
    output.addAudioTrack(as);
    await output.start();
    await as.add(audio);
    as.close();

    const sink = new VideoSampleSink(vt);
    const nTotal = Math.max(1, Math.ceil(eng.total * FPS));
    let done = 0;
    for (let i = 0; i < eng.pieces.length; i++) {
      const p = eng.pieces[i];
      const ks: number[] = [];
      for (let k = Math.ceil(eng.offsets[i] * FPS - 1e-6); k < nTotal && k / FPS < eng.offsets[i] + (p.e - p.s) - 1e-6; k++) ks.push(k);
      if (!ks.length) continue;
      const ts = ks.map((k) => p.s + (k / FPS - eng.offsets[i]));
      let j = 0;
      for await (const sample of sink.samplesAtTimestamps(ts)) {
        if (shouldCancel?.()) { sample?.close(); throw new Error('cancelled'); }
        const k = ks[j], t = ts[j]; j++;
        eng.pi = i;
        if (sample) eng.draw({ img: sample.toCanvasImageSource(), w: sample.displayWidth, h: sample.displayHeight, t });
        await vs.add(k / FPS, 1 / FPS);
        sample?.close();
        done++;
        if (done % 5 === 0) onProgress?.(0.06 + 0.93 * (done / nTotal));
      }
    }
    vs.close();
    await output.finalize();
    onProgress?.(1);
    const buf = (output.target as BufferTarget).buffer!;
    return new Blob([buf], { type: plan.container === 'mp4' ? 'video/mp4' : 'video/webm' });
  } finally {
    input.dispose?.();
    const [pw, ph] = aspectSize(eng.c.options.aspect, 720);
    eng.canvas.width = pw; eng.canvas.height = ph;
  }
}

/** SRT subtitles for a rendered clip (times follow the edited output timeline). */
export function clipSrt(eng: ClipEngine): string {
  const words = (eng.words as Word[]).map((w) => ({ w: w.w, s: outTime(eng, w.s), e: outTime(eng, Math.max(w.s, w.e - 0.001)) })).filter((w) => w.s !== null && w.e !== null) as { w: string; s: number; e: number }[];
  if (!words.length) return '';
  const lines: { s: number; e: number; text: string }[] = [];
  let cur: typeof words = [];
  const flush = () => { if (cur.length) lines.push({ s: cur[0].s, e: cur[cur.length - 1].e, text: cur.map((x) => x.w).join(' ') }); cur = []; };
  for (const w of words) {
    if (cur.length && (cur.length >= 7 || w.s - cur[cur.length - 1].e > 0.7 || /[.?!]$/.test(cur[cur.length - 1].w))) flush();
    cur.push(w);
  }
  flush();
  const ts = (t: number) => { const ms = Math.round(t * 1000); const h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60; return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(ms % 1000).padStart(3, '0')}`; };
  return lines.map((l, i) => `${i + 1}\n${ts(l.s)} --> ${ts(Math.max(l.e, l.s + 0.3))}\n${l.text}\n`).join('\n');
}

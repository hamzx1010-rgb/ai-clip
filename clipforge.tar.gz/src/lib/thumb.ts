/**
 * Thumbnails.
 *
 * Taken from the FINISHED file, not from the source — so the picture you see in
 * the list is proof the export really produced frames at that moment. If the
 * thumbnail comes back flat/empty, that is itself a warning sign.
 */

import * as db from './db';
import { grabGray, grayDiff, makeVideoEl } from './frames';

export interface ThumbResult {
  dataUrl: string | null;
  /** How much the picture changed between the 3 samples (0 = suspicious). */
  spread: number;
}

export async function captureThumb(blob: Blob, atSeconds: number[]): Promise<ThumbResult> {
  const url = URL.createObjectURL(blob);
  const v = makeVideoEl(url);
  const canvas = document.createElement('canvas');
  try {
    await new Promise<void>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('thumb timeout')), 12000);
      v.addEventListener('loadeddata', () => {
        clearTimeout(t);
        resolve();
      }, { once: true });
      v.addEventListener('error', () => {
        clearTimeout(t);
        reject(new Error('thumb decode error'));
      }, { once: true });
    });

    canvas.width = 270;
    canvas.height = 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return { dataUrl: null, spread: 0 };

    const dur = Number.isFinite(v.duration) && v.duration > 0 ? v.duration : Math.max(...atSeconds) + 0.2;
    const main = Math.min(dur * 0.25, Math.max(0.2, dur - 0.4));
    await seek(v, main);
    drawCover(ctx, v, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.62);

    // Cheap freeze sniffing: compare three points across the clip.
    const pts = [dur * 0.2, dur * 0.55, dur * 0.88].map((x) => Math.min(Math.max(0.05, x), dur - 0.05));
    let prev: Uint8ClampedArray | null = null;
    let spread = 0;
    for (const p of pts) {
      const g = await grabGray(v, p, 32);
      if (!g) continue;
      if (prev) spread = Math.max(spread, grayDiff(prev, g.gray));
      prev = g.gray;
    }
    void atSeconds;
    return { dataUrl, spread };
  } catch {
    return { dataUrl: null, spread: 0 };
  } finally {
    v.pause();
    v.removeAttribute('src');
    v.load();
    v.remove();
    URL.revokeObjectURL(url);
  }
}

export async function storeThumb(clipId: string, dataUrl: string): Promise<void> {
  await db.putBlob(`thumb:${clipId}`, new Blob([dataUrl], { type: 'text/plain' }));
}

function drawCover(ctx: CanvasRenderingContext2D, v: HTMLVideoElement, w: number, h: number) {
  const vw = v.videoWidth || w;
  const vh = v.videoHeight || h;
  const scale = Math.max(w / vw, h / vh);
  const dw = vw * scale;
  const dh = vh * scale;
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, w, h);
  ctx.drawImage(v, (w - dw) / 2, (h - dh) / 2, dw, dh);
}

function seek(v: HTMLVideoElement, t: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      v.removeEventListener('seeked', ok);
      reject(new Error('seek timeout'));
    }, 8000);
    function ok() {
      clearTimeout(timer);
      v.removeEventListener('seeked', ok);
      resolve();
    }
    v.addEventListener('seeked', ok, { once: true });
    try {
      v.currentTime = Math.max(0, t);
    } catch (e) {
      clearTimeout(timer);
      reject(e instanceof Error ? e : new Error('seek failed'));
    }
  });
}

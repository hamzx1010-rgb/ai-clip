// Where a human editor would cut: only at the start of a sentence, only after the end of one, and
// exactly inside the silent gap between two words, measured on the waveform (10 ms voice envelope).
// On-device Whisper word times are regularly 0.2–0.4 s early or late, so they are only used to know
// roughly *where* to look; the cut itself goes in the real gap. No real gap = not a cut point.
import type { AudioAnalysis, Word } from './types';

const SENT_END = /[.?!…]["'”)]*$/;
const CAP = /^["'“(]*[A-Z0-9]/;

export type Gap = { s: number; e: number };

export type Phrase = {
  words: Word[];
  start: number;
  end: number;
  /** a clip may start here: a sentence begins and there is a real gap before it */
  startOk: boolean;
  /** a clip may end here: a sentence ends and there is a real gap after it */
  endOk: boolean;
  /** where exactly to cut (inside the measured gap), or null if the speech runs straight on */
  startCut: number | null;
  endCut: number | null;
  /** length of the silent gap at each boundary (s) — short gaps are tight to cut in */
  startGap: number;
  endGap: number;
  prevEnd: number;
  nextStart: number;
};

function envOf(a: AudioAnalysis): { v: ArrayLike<number>; hop: number } {
  return a.env && a.envHop ? { v: a.env, hop: a.envHop } : { v: a.rms, hop: a.hop };
}
function lv(a: AudioAnalysis, t0: number, t1: number) {
  const { v, hop } = envOf(a);
  const i0 = Math.max(0, Math.floor(t0 / hop)), i1 = Math.min(v.length - 1, Math.ceil(t1 / hop));
  const arr: number[] = [];
  for (let i = i0; i <= i1; i += 1) arr.push(v[i]);
  if (!arr.length) return { lo: 0, hi: 1 };
  arr.sort((x, y) => x - y);
  return { lo: arr[Math.floor(arr.length * 0.08)], hi: arr[Math.floor(arr.length * 0.92)] };
}

/**
 * The real silent gap in [t0, t1]: the longest run of low-energy frames (≥ 40 ms, or ≥ 20 ms when very quiet).
 * Threshold is relative to the local speech level, so it works over game audio / music beds too.
 */
export function findGap(a: AudioAnalysis | null, t0: number, t1: number, center?: number): Gap | null {
  if (!a || t1 <= t0) return null;
  const { v, hop } = envOf(a);
  const { lo, hi } = lv(a, t0 - 2, t1 + 2);
  if (hi <= lo) return null;
  const thr = lo + (hi - lo) * 0.18, deep = lo + (hi - lo) * 0.08;
  const i0 = Math.max(0, Math.floor(t0 / hop)), i1 = Math.min(v.length - 1, Math.ceil(t1 / hop));
  let best: Gap | null = null, bestScore = -1;
  let run = -1, deepCount = 0;
  const minRun = Math.max(1, Math.round(0.04 / hop)), minDeep = Math.max(1, Math.round(0.02 / hop));
  for (let i = i0; i <= i1 + 1; i++) {
    const q = i <= i1 && v[i] <= thr;
    if (q) { if (run < 0) { run = i; deepCount = 0; } if (v[i] <= deep) deepCount++; continue; }
    if (run >= 0) {
      const len = i - run;
      if (len >= minRun || deepCount >= minDeep) {
        const g = { s: run * hop, e: i * hop };
        const mid = (g.s + g.e) / 2;
        // prefer long gaps, then gaps near where the ASR says the boundary is
        const sc = (g.e - g.s) - (center !== undefined ? Math.abs(mid - center) * 0.15 : 0);
        if (sc > bestScore) { bestScore = sc; best = g; }
      }
      run = -1;
    }
  }
  return best;
}

/** start a clip just before the voice comes in (inside the gap) */
export const cutInForGap = (g: Gap) => g.e - Math.min(0.1, (g.e - g.s) / 2); // short gap → its middle
/** end a clip just after the voice stops (a short breath, never reaching the next word) */
export const cutOutForGap = (g: Gap) => g.s + Math.min(0.22, (g.e - g.s) / 2);

/** the gap between word A and word B (either may be missing at the edge of a transcribed region) */
export function gapBetween(a: AudioAnalysis | null, A: Word | null, B: Word | null): Gap | null {
  if (!a) {
    if (A && B && B.s - A.e >= 0.2) return { s: A.e, e: B.s };
    return null;
  }
  if (A && B) {
    const lo = Math.max(A.s + (A.e - A.s) * 0.5, A.e - 0.4), hi = Math.min(B.e - 0.05, B.s + 0.4);
    return findGap(a, lo, Math.max(lo + 0.05, hi), (A.e + B.s) / 2);
  }
  if (B) return findGap(a, B.s - 0.9, B.s + 0.3, B.s - 0.1);
  if (A) return findGap(a, A.e - 0.35, A.e + 0.9, A.e + 0.1);
  return null;
}

/** is there any real pause between two words? */
export function hasDip(a: AudioAnalysis | null, t0: number, t1: number): boolean {
  if (!a) return t1 - t0 >= 0.2;
  return !!findGap(a, t0, t1);
}

/**
 * Split words into phrases at sentence ends and at real pauses; mark which phrase starts/ends are
 * safe cut points and exactly where to cut. Works for unpunctuated casual speech too.
 */
export function buildPhrases(words: Word[], audio: AudioAnalysis | null, segStart: number, segEnd: number): Phrase[] {
  const out: Phrase[] = [];
  if (!words.length) return out;
  const gapAfter = (k: number) => (k + 1 < words.length ? words[k + 1].s - words[k].e : Infinity);
  let cur: Word[] = [];
  let curStartK = 0;
  const flush = (k: number) => {
    if (!cur.length) return;
    const prev = curStartK > 0 ? words[curStartK - 1] : null;
    const next = k + 1 < words.length ? words[k + 1] : null;
    const first = cur[0], last = cur[cur.length - 1];
    // first words of a transcribed region: the region may have started mid-sentence → need room before it
    const gIn = prev || first.s - segStart >= 0.4 ? gapBetween(audio, prev, first) : null;
    const gOut = next || segEnd - last.e >= 0.4 ? gapBetween(audio, last, next) : null;
    const sentenceStart = prev ? SENT_END.test(prev.w) || (first.s - prev.e >= 0.6 && CAP.test(first.w)) : CAP.test(first.w);
    const sentenceEnd = SENT_END.test(last.w) || (next ? next.s - last.e >= 0.9 : false);
    out.push({
      words: cur, start: first.s, end: last.e,
      startOk: sentenceStart && !!gIn, endOk: sentenceEnd && !!gOut,
      startCut: gIn ? cutInForGap(gIn) : null, endCut: gOut ? cutOutForGap(gOut) : null,
      startGap: gIn ? gIn.e - gIn.s : 0, endGap: gOut ? gOut.e - gOut.s : 0,
      prevEnd: prev ? prev.e : -1, nextStart: next ? next.s : Infinity,
    });
    cur = [];
    curStartK = k + 1;
  };
  for (let k = 0; k < words.length; k++) {
    cur.push(words[k]);
    const g = gapAfter(k);
    if (SENT_END.test(words[k].w) && cur.length >= 2) flush(k);
    else if (g >= 0.55 && cur.length >= 4) flush(k); // natural pause = phrase boundary (unpunctuated speech)
    else if (cur.length >= 30) {
      // run-on: break at the biggest pause in the back half instead of an arbitrary word
      let best = -1, bg = -1;
      for (let m = Math.floor(cur.length / 2); m < cur.length - 1; m++) { const gg = cur[m + 1].s - cur[m].e; if (gg > bg) { bg = gg; best = m; } }
      const keep = cur.slice(best + 1);
      cur = cur.slice(0, best + 1);
      flush(k - keep.length);
      cur = keep;
    }
  }
  flush(words.length - 1);
  return out;
}

/** is the whole span [t0, t1] actually quiet (safe to cut out without chopping a word)? */
export function isQuiet(a: AudioAnalysis | null, t0: number, t1: number): boolean {
  if (!a) return true;
  if (t1 <= t0) return false;
  const { v, hop } = envOf(a);
  const { lo, hi } = lv(a, t0 - 2, t1 + 2);
  const thr = lo + (hi - lo) * 0.2;
  const i0 = Math.max(0, Math.floor(t0 / hop)), i1 = Math.min(v.length - 1, Math.ceil(t1 / hop));
  for (let i = i0; i <= i1; i++) if (v[i] > thr) return false;
  return true;
}

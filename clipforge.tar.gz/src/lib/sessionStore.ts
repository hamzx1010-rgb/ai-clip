// Clip sessions (clips + analysis + the source video) saved in the browser (IndexedDB), so your clip history
// survives reloads and is visible from every tab. The big video file is stored separately from the small record.
import { del, get, set } from 'idb-keyval';
import type { ClipSession } from '../store';

export type SessionMeta = {
  id: string; name: string; mode: 'video' | 'stream'; createdAt: number; duration: number;
  clips: number; top: number; bytes: number; hasFile: boolean; thumb?: string; titles: string[];
};

const INDEX = 'cf:sess-index';
const REC = (id: string) => 'cf:sess:' + id;
const FILE = (id: string) => 'cf:sessfile:' + id;
const chan = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('cf-sessions') : null;

/** Called when sessions change in this or another tab. */
export function onSessionsChanged(fn: () => void): () => void {
  const h = () => fn();
  chan?.addEventListener('message', h);
  window.addEventListener('cf-sessions', h);
  return () => { chan?.removeEventListener('message', h); window.removeEventListener('cf-sessions', h); };
}
const changed = () => { chan?.postMessage('changed'); window.dispatchEvent(new Event('cf-sessions')); };

export async function listSessions(): Promise<SessionMeta[]> {
  return ((await get<SessionMeta[]>(INDEX)) || []).sort((a, b) => b.createdAt - a.createdAt);
}

// index writes are serialized so two quick saves can't overwrite each other
let q: Promise<unknown> = Promise.resolve();
const withIndex = (fn: (list: SessionMeta[]) => SessionMeta[]) => (q = q.then(async () => { await set(INDEX, fn((await get<SessionMeta[]>(INDEX)) || [])); }).catch((e) => console.warn('session index', e)));

function metaOf(s: ClipSession, prev?: SessionMeta, hasFile?: boolean, thumb?: string): SessionMeta {
  return {
    id: s.id, name: s.name, mode: s.mode, createdAt: s.createdAt, duration: s.duration,
    clips: s.clips.length, top: s.clips.reduce((a, c) => Math.max(a, c.score), 0),
    bytes: (hasFile ?? prev?.hasFile) ? (s.file?.size ?? prev?.bytes ?? 0) : 0, hasFile: hasFile ?? prev?.hasFile ?? false,
    thumb: thumb ?? prev?.thumb, titles: [...s.clips].sort((a, b) => b.score - a.score).slice(0, 3).map((c) => c.title),
  };
}
const record = (s: ClipSession) => { const { url: _u, file: _f, ...rest } = s; void _u; void _f; return rest; };

/** First save: the record, the source video and a thumbnail. */
export async function saveSession(s: ClipSession, thumb?: string): Promise<void> {
  navigator.storage?.persist?.().catch(() => {}); // ask the browser not to evict it when space is low
  await set(REC(s.id), record(s));
  let hasFile = false;
  if (s.file) {
    try { await set(FILE(s.id), s.file); hasFile = true; }
    catch (e) { console.warn('Could not store the source video (storage full?)', e); }
  }
  await withIndex((l) => [metaOf(s, undefined, hasFile, thumb), ...l.filter((x) => x.id !== s.id)]);
  changed();
}

/** Later edits (clip titles, options, exports) — the video isn't rewritten. */
const timers = new Map<string, ReturnType<typeof setTimeout>>();
export function updateSessionSoon(s: ClipSession) {
  clearTimeout(timers.get(s.id));
  timers.set(s.id, setTimeout(async () => {
    timers.delete(s.id);
    if (!(await get(REC(s.id)))) return; // deleted meanwhile
    await set(REC(s.id), record(s));
    await withIndex((l) => l.map((x) => (x.id === s.id ? metaOf(s, x) : x)));
    changed();
  }, 800));
}

export async function loadSession(id: string): Promise<ClipSession | null> {
  const r = await get<Omit<ClipSession, 'url' | 'file'>>(REC(id));
  if (!r) return null;
  const file = await get<Blob>(FILE(id)).catch(() => undefined);
  return { ...r, file, url: file ? URL.createObjectURL(file) : '' } as ClipSession;
}

export async function deleteSession(id: string) {
  clearTimeout(timers.get(id));
  await del(REC(id)); await del(FILE(id)).catch(() => {});
  await withIndex((l) => l.filter((x) => x.id !== id));
  changed();
}

/** Settings → "Auto-delete processed sources after N days" (0 = never). Only the source video is removed if it's old;
 *  the clip list stays so you can still see what was made. */
export async function autoClean(days: number) {
  if (!days) return;
  const cut = Date.now() - days * 864e5;
  const old = (await listSessions()).filter((m) => m.createdAt < cut && m.hasFile);
  for (const m of old) await del(FILE(m.id)).catch(() => {});
  if (old.length) { await withIndex((l) => l.map((x) => (old.some((o) => o.id === x.id) ? { ...x, hasFile: false, bytes: 0 } : x))); changed(); }
}

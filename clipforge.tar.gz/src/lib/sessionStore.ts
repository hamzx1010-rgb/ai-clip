// Clip sessions (clips + analysis + the source video) saved in the browser (IndexedDB), so your clip history
// survives reloads and is visible from every tab. The big video file is stored separately from the small record.
import { del, get, keys, set } from 'idb-keyval';
import type { ClipSession } from '../store';

export type SessionMeta = {
  id: string; name: string; mode: 'video' | 'stream'; createdAt: number; duration: number;
  clips: number; top: number; bytes: number; hasFile: boolean; thumb?: string; titles: string[];
  /** link it came from (re-downloadable) */
  src?: string;
};

const INDEX = 'cf:sess-index';
const REC = (id: string) => 'cf:sess:' + id;
const FILE = (id: string) => 'cf:sessfile:' + id;
const chan = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('cf-sessions') : null;

/** Called when sessions change in this or another tab. */
export function onSessionsChanged(fn: () => void): () => void {
  const h = () => fn();
  chan?.addEventListener('message', h);
  window.addEventListener('cf-sessions', h);
  return () => { chan?.removeEventListener('message', h); window.removeEventListener('cf-sessions', h); };
}
const changed = () => { chan?.postMessage('changed'); window.dispatchEvent(new Event('cf-sessions')); };

export async function listSessions(): Promise<SessionMeta[]> {
  if (!healed) { healed = true; await heal().catch((e) => console.warn('history repair', e)); }
  return ((await get<SessionMeta[]>(INDEX)) || []).sort((a, b) => b.createdAt - a.createdAt);
}

/** Once per page load: put back any saved clip session that is missing from the list (e.g. a save that was
 *  interrupted), and delete video copies that no longer belong to anything (they only waste space). */
let healed = false;
async function heal() {
  const all = (await keys()).map(String);
  const recs = new Set(all.filter((k) => k.startsWith('cf:sess:')).map((k) => k.slice(8)));
  const files = new Set(all.filter((k) => k.startsWith('cf:sessfile:')).map((k) => k.slice(12)));
  const idx = (await get<SessionMeta[]>(INDEX)) || [];
  const known = new Set(idx.map((m) => m.id));
  const add: SessionMeta[] = [];
  for (const id of recs) {
    if (known.has(id)) continue;
    const r = await get<ClipSession>(REC(id)).catch(() => undefined);
    if (!r || !Array.isArray(r.clips)) continue;
    const f = files.has(id) ? await get<Blob>(FILE(id)).catch(() => undefined) : undefined;
    add.push(metaOf({ ...r, file: f } as ClipSession, undefined, !!f));
  }
  for (const id of files) if (!recs.has(id)) await del(FILE(id)).catch(() => {});
  const stale = idx.filter((m) => !recs.has(m.id)).map((m) => m.id); // record gone → drop the row
  const wrongFile = idx.filter((m) => m.hasFile && !files.has(m.id)).map((m) => m.id);
  if (add.length || stale.length || wrongFile.length) {
    await withIndex((l) => [...add, ...l.filter((m) => !stale.includes(m.id)).map((m) => (wrongFile.includes(m.id) ? { ...m, hasFile: false, bytes: 0 } : m))]);
  }
}

/** Your clip history is unlimited: the clip lists are tiny and are never deleted automatically. Only the big
 *  source-video copies are, oldest first, when the browser runs out of room (link videos can be re-downloaded). */
async function makeRoom(bytes: number, keepId?: string, force = false): Promise<number> {
  let freed = 0;
  const est = await navigator.storage?.estimate?.().catch(() => undefined);
  let free = est?.quota ? est.quota - (est.usage || 0) : Infinity;
  const need = bytes + 80e6; // leave some headroom for models, thumbnails…
  if (!force && free >= need) return 0;
  const old = (await listSessions()).filter((m) => m.hasFile && m.id !== keepId).sort((a, b) => a.createdAt - b.createdAt);
  for (const m of old) {
    if (!force && free >= need) break;
    await del(FILE(m.id)).catch(() => {});
    free += m.bytes; freed += m.bytes;
    await withIndex((l) => l.map((x) => (x.id === m.id ? { ...x, hasFile: false, bytes: 0 } : x)));
  }
  if (freed) changed();
  return freed;
}

/** Store (or re-store) the source video of a session, freeing old copies if needed. Returns false if it didn't fit. */
export async function attachFile(id: string, file: Blob): Promise<boolean> {
  await makeRoom(file.size, id);
  try { await set(FILE(id), file); }
  catch (e) {
    console.warn('storage full, freeing old videos', e);
    await makeRoom(file.size, id, true);
    try { await set(FILE(id), file); } catch { return false; }
  }
  await withIndex((l) => l.map((x) => (x.id === id ? { ...x, hasFile: true, bytes: file.size } : x)));
  changed();
  return true;
}

/** Settings → "Free up space": remove stored video copies (clip lists stay). */
export async function freeSpace(): Promise<number> {
  const newest = (await listSessions())[0]?.id;
  return makeRoom(0, newest, true);
}

// index writes are serialized so two quick saves can't overwrite each other
let q: Promise<unknown> = Promise.resolve();
const withIndex = (fn: (list: SessionMeta[]) => SessionMeta[]) => (q = q.then(async () => { await set(INDEX, fn((await get<SessionMeta[]>(INDEX)) || [])); }).catch((e) => console.warn('session index', e)));

function metaOf(s: ClipSession, prev?: SessionMeta, hasFile?: boolean, thumb?: string): SessionMeta {
  return {
    id: s.id, name: s.name, mode: s.mode, createdAt: s.createdAt, duration: s.duration,
    clips: s.clips.length, top: s.clips.reduce((a, c) => Math.max(a, c.score), 0),
    bytes: (hasFile ?? prev?.hasFile) ? (s.file?.size ?? prev?.bytes ?? 0) : 0, hasFile: hasFile ?? prev?.hasFile ?? false,
    src: s.sourceUrl ?? prev?.src, thumb: thumb ?? prev?.thumb, titles: [...s.clips].sort((a, b) => b.score - a.score).slice(0, 3).map((c) => c.title),
  };
}
const record = (s: ClipSession) => { const { url: _u, file: _f, ...rest } = s; void _u; void _f; return rest; };

/** First save: the record, the source video and a thumbnail. */
export async function saveSession(s: ClipSession, thumb?: string): Promise<void> {
  navigator.storage?.persist?.().catch(() => {}); // ask the browser not to evict it when space is low
  // the small clip list goes in first, so it's in your history even if the big video doesn't fit
  await set(REC(s.id), record(s));
  await withIndex((l) => [metaOf(s, undefined, false, thumb), ...l.filter((x) => x.id !== s.id)]);
  changed();
  if (s.file) await attachFile(s.id, s.file).catch((e) => console.warn('Could not store the source video', e));
}

/** Later edits (clip titles, options, exports) — the video isn't rewritten. */
const timers = new Map<string, ReturnType<typeof setTimeout>>();
export function updateSessionSoon(s: ClipSession) {
  clearTimeout(timers.get(s.id));
  timers.set(s.id, setTimeout(async () => {
    timers.delete(s.id);
    if (!(await get(REC(s.id)))) return; // deleted meanwhile
    await set(REC(s.id), record(s));
    await withIndex((l) => l.map((x) => (x.id === s.id ? metaOf(s, x) : x)));
    changed();
  }, 800));
}

export async function loadSession(id: string): Promise<ClipSession | null> {
  const r = await get<Omit<ClipSession, 'url' | 'file'>>(REC(id));
  if (!r) return null;
  const file = await get<Blob>(FILE(id)).catch(() => undefined);
  return { ...r, file, url: file ? URL.createObjectURL(file) : '' } as ClipSession;
}

export async function deleteSession(id: string) {
  clearTimeout(timers.get(id));
  await del(REC(id)); await del(FILE(id)).catch(() => {});
  await withIndex((l) => l.filter((x) => x.id !== id));
  changed();
}

/** Settings → "Auto-delete processed sources after N days" (0 = never). Only the source video is removed if it's old;
 *  the clip list stays so you can still see what was made. */
export async function autoClean(days: number) {
  if (!days) return;
  const cut = Date.now() - days * 864e5;
  const old = (await listSessions()).filter((m) => m.createdAt < cut && m.hasFile);
  for (const m of old) await del(FILE(m.id)).catch(() => {});
  if (old.length) { await withIndex((l) => l.map((x) => (old.some((o) => o.id === x.id) ? { ...x, hasFile: false, bytes: 0 } : x))); changed(); }
}

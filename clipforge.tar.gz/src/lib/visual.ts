import type { VisualAnalysis, FaceBox } from './types';
import { detectFaces, getFaceDetector } from './faces';
import { seekVideo, waitEvent } from './util';

/** Sample frames across the video: brightness, sharpness, motion, scene cuts, faces */
export async function analyzeVisual(
  url: string,
  duration: number,
  opts: { faces: boolean; maxSamples?: number },
  onProgress?: (p: number, label?: string) => void,
): Promise<VisualAnalysis> {
  const v = document.createElement('video');
  v.muted = true; v.preload = 'auto'; v.playsInline = true; v.crossOrigin = 'anonymous';
  v.src = url;
  // Android (Chrome/Brave) often won't load data for a detached video that never plays → attach it
  // invisibly and give it a muted play/pause nudge if it hasn't loaded after a moment
  Object.assign(v.style, { position: 'fixed', left: '0', top: '0', width: '2px', height: '2px', opacity: '0', pointerEvents: 'none', zIndex: '-1' });
  document.body.appendChild(v);
  v.load();
  const nudge = setTimeout(() => { v.play().then(() => v.pause()).catch(() => {}); }, 1500);
  try { if (v.readyState < 2) await waitEvent(v, 'loadeddata', 15000); }
  catch (e) { v.remove(); throw e; }
  finally { clearTimeout(nudge); }
  const maxS = opts.maxSamples ?? 240;
  const step = Math.max(0.5, duration / maxS);
  const times: number[] = [];
  for (let t = 0.05; t < duration - 0.05; t += step) times.push(t);

  const W = 96, H = Math.max(2, Math.round((96 * (v.videoHeight || 9)) / (v.videoWidth || 16)));
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  const fc = document.createElement('canvas');
  const fw = 384; fc.width = fw; fc.height = Math.round((fw * (v.videoHeight || 9)) / (v.videoWidth || 16));
  const fctx = fc.getContext('2d')!;
  const useFaces = opts.faces && !!(await getFaceDetector());

  const res: VisualAnalysis = { times, brightness: [], sharpness: [], motion: [], motionCx: [], sceneCuts: [], faces: [], faceEngine: useFaces ? 'mediapipe' : 'none' };
  let prev: Uint8ClampedArray | null = null;
  let prevHist: number[] | null = null;
  for (let k = 0; k < times.length; k++) {
    await seekVideo(v, times[k]);
    ctx.drawImage(v, 0, 0, W, H);
    const d = ctx.getImageData(0, 0, W, H).data;
    let bs = 0, sharp = 0, mot = 0, mx = 0, mw = 0;
    const hist = new Array(64).fill(0);
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = (y * W + x) * 4;
        const l = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
        bs += l;
        hist[(d[i] >> 6) * 16 + (d[i + 1] >> 6) * 4 + (d[i + 2] >> 6)]++;
        if (x > 0) {
          const j = i - 4;
          sharp += Math.abs(l - (0.299 * d[j] + 0.587 * d[j + 1] + 0.114 * d[j + 2]));
        }
        if (prev) {
          const df = Math.abs(d[i] - prev[i]) + Math.abs(d[i + 1] - prev[i + 1]) + Math.abs(d[i + 2] - prev[i + 2]);
          mot += df; mx += df * (x / W); mw += df;
        }
      }
    }
    const N = W * H;
    res.brightness.push(bs / N / 255);
    res.sharpness.push(sharp / N / 40);
    res.motion.push(prev ? mot / N / 255 / 3 : 0);
    res.motionCx.push(mw > 0 ? mx / mw : 0.5);
    if (prevHist) {
      let diff = 0; for (let i = 0; i < 64; i++) diff += Math.abs(hist[i] - prevHist[i]);
      if (diff / N > 0.55) res.sceneCuts.push(times[k]);
    }
    prevHist = hist;
    prev = new Uint8ClampedArray(d);

    let faces: FaceBox[] = [];
    if (useFaces) {
      fctx.drawImage(v, 0, 0, fc.width, fc.height);
      faces = await detectFaces(fc, fc.width, fc.height);
    }
    res.faces.push(faces);
    if (onProgress && k % 3 === 0) onProgress(k / times.length, `Frame ${k + 1}/${times.length}`);
  }
  v.removeAttribute('src'); v.load();
  v.pause(); v.removeAttribute('src'); v.load(); v.remove();
  return res;
}

/** Face-track for a time window: returns smoothed crop centres */
export type TrackPoint = { t: number; cx: number; cy: number; faces: number };
export function buildTrack(
  va: VisualAnalysis | null,
  start: number,
  end: number,
  speakerAt?: (t: number) => number, // speaker index 0/1/..
  focus: 'auto' | 'left' | 'right' = 'auto',
): TrackPoint[] {
  if (!va || !va.times.length) return [{ t: start, cx: 0.5, cy: 0.45, faces: 0 }];
  const pts: TrackPoint[] = [];
  let last = { cx: 0.5, cy: 0.42 };
  for (let i = 0; i < va.times.length; i++) {
    const t = va.times[i];
    if (t < start - 2 || t > end + 2) continue;
    const faces = [...(va.faces[i] || [])].sort((a, b) => a.x - b.x);
    let target: FaceBox | null = null;
    if (faces.length === 1) target = faces[0];
    else if (faces.length > 1) {
      if (focus === 'left') target = faces[0];
      else if (focus === 'right') target = faces[faces.length - 1];
      else if (speakerAt) {
        const sp = speakerAt(t);
        target = faces[Math.min(faces.length - 1, Math.max(0, sp))];
      } else target = faces.reduce((a, b) => (a.w * a.h > b.w * b.h ? a : b));
    }
    if (target) last = { cx: target.x + target.w / 2, cy: target.y + target.h / 2 };
    else if (va.faceEngine === 'none') last = { cx: 0.5 * 0.6 + va.motionCx[i] * 0.4, cy: 0.45 };
    pts.push({ t, cx: last.cx, cy: last.cy, faces: faces.length });
  }
  if (!pts.length) pts.push({ t: start, cx: 0.5, cy: 0.45, faces: 0 });
  // smooth (moving average of 3) — keeps hard switches on speaker change reasonably quick
  return pts.map((p, i) => {
    const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
    const jump = Math.abs(a.cx - b.cx) > 0.25;
    return jump ? p : { ...p, cx: (a.cx + p.cx * 2 + b.cx) / 4, cy: (a.cy + p.cy * 2 + b.cy) / 4 };
  });
}

export function trackAt(track: TrackPoint[], t: number): { cx: number; cy: number } {
  if (track.length === 1 || t <= track[0].t) return track[0];
  for (let i = 1; i < track.length; i++) {
    if (track[i].t >= t) {
      const a = track[i - 1], b = track[i];
      if (Math.abs(a.cx - b.cx) > 0.25) return t - a.t < (b.t - a.t) / 2 ? a : b; // hard cut to new speaker
      const k = (t - a.t) / (b.t - a.t || 1);
      return { cx: a.cx + (b.cx - a.cx) * k, cy: a.cy + (b.cy - a.cy) * k };
    }
  }
  return track[track.length - 1];
}

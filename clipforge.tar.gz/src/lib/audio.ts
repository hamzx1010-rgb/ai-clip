/**
 * Per-clip audio analysis: where are the real pauses, and is anyone talking?
 *
 * We decode the whole track once into a small RMS envelope (20 ms buckets) and
 * then answer questions about any time range from that envelope — no repeated
 * decoding, which is what makes per-clip analysis cheap on a phone.
 */

export interface AudioProfile {
  sampleRate: number;
  duration: number;
  channels: number;
  /** RMS per bucket, normalised 0..1. */
  rms: Float32Array;
  /** Seconds per bucket. */
  bucket: number;
  /** Adaptive silence threshold used for pause finding. */
  silenceThreshold: number;
  ok: boolean;
}

const BUCKET = 0.02; // 20 ms

export async function buildAudioProfile(blob: Blob): Promise<AudioProfile> {
  const empty: AudioProfile = {
    sampleRate: 0,
    duration: 0,
    channels: 0,
    rms: new Float32Array(0),
    bucket: BUCKET,
    silenceThreshold: 0,
    ok: false,
  };

  let ctx: OfflineAudioContext | AudioContext | null = null;
  try {
    const raw = await blob.arrayBuffer();
    const Ctor: typeof AudioContext =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return empty;
    ctx = new Ctor();
    const buf = await ctx.decodeAudioData(raw.slice(0));
    if (!buf || buf.duration <= 0) return empty;

    const n = Math.max(1, Math.ceil(buf.duration / BUCKET));
    const rms = new Float32Array(n);
    const perBucket = Math.max(1, Math.floor(BUCKET * buf.sampleRate));
    const data = buf.getChannelData(0);
    const data2 = buf.numberOfChannels > 1 ? buf.getChannelData(1) : null;

    for (let i = 0; i < n; i++) {
      const s = i * perBucket;
      const e = Math.min(data.length, s + perBucket);
      let sum = 0;
      let count = 0;
      for (let j = s; j < e; j++) {
        const a = data[j];
        const b = data2 ? data2[j] : 0;
        const v = (a + b) / (data2 ? 2 : 1);
        sum += v * v;
        count++;
      }
      rms[i] = count > 0 ? Math.sqrt(sum / count) : 0;
    }

    // Adaptive threshold: halfway between the quiet floor and typical speech.
    const sorted = Float32Array.from(rms).sort() as unknown as number[];
    sorted.sort((a, b) => a - b);
    const p10 = sorted[Math.floor(sorted.length * 0.1)] ?? 0;
    const p70 = sorted[Math.floor(sorted.length * 0.7)] ?? 0;
    const peak = sorted[sorted.length - 1] ?? 0;
    let threshold = Math.max(p10 * 2.2, peak * 0.045);
    if (threshold > p70) threshold = Math.max(p10 * 1.6, peak * 0.02);

    return {
      sampleRate: buf.sampleRate,
      duration: buf.duration,
      channels: buf.numberOfChannels,
      rms,
      bucket: BUCKET,
      silenceThreshold: threshold,
      ok: true,
    };
  } catch {
    return empty;
  } finally {
    if (ctx && 'close' in ctx) {
      try {
        void (ctx as AudioContext).close();
      } catch {
        /* ignore */
      }
    }
  }
}

function levelAt(p: AudioProfile, t: number): number {
  if (!p.ok) return 0;
  const i = Math.max(0, Math.min(p.rms.length - 1, Math.floor(t / p.bucket)));
  return p.rms[i];
}

export function isSilentAt(p: AudioProfile, t: number): boolean {
  if (!p.ok) return true; // no audio track -> everywhere is a "pause"
  return levelAt(p, t) < p.silenceThreshold;
}

export function loudnessIn(p: AudioProfile, from: number, to: number): number {
  if (!p.ok || to <= from) return 0;
  const i0 = Math.max(0, Math.floor(from / p.bucket));
  const i1 = Math.min(p.rms.length, Math.ceil(to / p.bucket));
  let sum = 0;
  let n = 0;
  for (let i = i0; i < i1; i++) {
    sum += p.rms[i];
    n++;
  }
  return n ? sum / n : 0;
}

/** Fraction of buckets in [from,to] that carry speech-level energy. */
export function speechRatioIn(p: AudioProfile, from: number, to: number): number {
  if (!p.ok || to <= from) return 0;
  const i0 = Math.max(0, Math.floor(from / p.bucket));
  const i1 = Math.min(p.rms.length, Math.ceil(to / p.bucket));
  let voiced = 0;
  let n = 0;
  for (let i = i0; i < i1; i++) {
    if (p.rms[i] >= p.silenceThreshold) voiced++;
    n++;
  }
  return n ? voiced / n : 0;
}

/**
 * Find the closest real pause to `t`.
 * A pause must be at least `minPause` seconds long, searched inside ±window.
 */
export function nearestPause(
  p: AudioProfile,
  t: number,
  opts: { minPause?: number; window?: number; from?: number; to?: number } = {},
): { time: number; found: boolean; pauseLength: number } {
  const minPause = opts.minPause ?? 0.28;
  const win = opts.window ?? 2.5;
  const lo = Math.max(opts.from ?? 0, t - win);
  const hi = Math.min(opts.to ?? p.duration, t + win);
  if (!p.ok) return { time: clamp(t, opts.from ?? 0, opts.to ?? Infinity), found: true, pauseLength: 99 };

  const step = p.bucket;
  const need = Math.max(1, Math.round(minPause / step));
  let best = -1;
  let bestScore = Infinity;
  let bestLen = 0;

  for (let x = lo; x <= hi; x += step) {
    // measure the quiet run centred near x
    let run = 0;
    let maxRun = 0;
    for (let k = 0; k < need * 3; k++) {
      const tt = x - (need * 1.5 * step) + k * step;
      if (isSilentAt(p, tt)) {
        run++;
        if (run > maxRun) maxRun = run;
      } else run = 0;
    }
    if (maxRun >= need) {
      const score = Math.abs(x - t);
      if (score < bestScore) {
        bestScore = score;
        best = x;
        bestLen = maxRun * step;
      }
    }
  }

  if (best < 0) return { time: clamp(t, lo, hi), found: false, pauseLength: 0 };
  return { time: clamp(best, lo, hi), found: true, pauseLength: bestLen };
}

export function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v));
}

/**
 * Verify that a finished file really has sound, using the same decoder path.
 * Returns seconds of audio and the fraction that is non-silent.
 */
export async function measureAudioInBlob(blob: Blob): Promise<{
  duration: number;
  audible: boolean;
  voicedRatio: number;
  peak: number;
}> {
  const none = { duration: 0, audible: false, voicedRatio: 0, peak: 0 };
  try {
    const p = await buildAudioProfile(blob);
    if (!p.ok || p.duration <= 0) return none;
    let voiced = 0;
    let peak = 0;
    for (let i = 0; i < p.rms.length; i++) {
      if (p.rms[i] > peak) peak = p.rms[i];
      if (p.rms[i] >= Math.max(p.silenceThreshold, peak * 0.05)) voiced++;
    }
    const voicedRatio = p.rms.length ? voiced / p.rms.length : 0;
    return { duration: p.duration, audible: peak > 0.0015, voicedRatio, peak };
  } catch {
    return none;
  }
}

// Remote video ingest: paste a direct link → download it (through our server so CORS never blocks) → process in the browser.

export type DlProgress = { loaded: number; total: number; speed: number };

const PLATFORM_RE = /(youtube\.com|youtu\.be|tiktok\.com|instagram\.com|facebook\.com|fb\.watch|twitch\.tv|kick\.com|vimeo\.com|x\.com|twitter\.com|reddit\.com)\//i;

/** Clean up what people paste: markdown links, <angle brackets>, share links. */
export function normalizeLink(raw: string): string {
  let s = raw.trim();
  const md = s.match(/\]\((https?:\/\/[^)\s]+)\)/); if (md) s = md[1];
  s = s.replace(/^<|>$/g, '').trim();
  if (!/^https?:\/\//i.test(s) && /^[\w.-]+\.[a-z]{2,}\//i.test(s)) s = 'https://' + s;
  try {
    const u = new URL(s);
    // Dropbox share → direct download
    if (/(^|\.)dropbox\.com$/i.test(u.hostname)) { u.searchParams.delete('dl'); u.searchParams.set('dl', '1'); return u.href; }
    // Google Drive share → direct download
    const gd = u.href.match(/drive\.google\.com\/file\/d\/([\w-]+)/) || (u.hostname === 'drive.google.com' && u.searchParams.get('id') ? [null, u.searchParams.get('id')] : null);
    if (gd && gd[1]) return `https://drive.google.com/uc?export=download&confirm=t&id=${gd[1]}`;
    return u.href;
  } catch { return s; }
}

export function isPlatformPage(url: string): boolean {
  return PLATFORM_RE.test(url) && !/\.(mp4|webm|mov|m4v|mkv)(\?|$)/i.test(url);
}

/** "Exploring.My.Abandoned.Minecraft.Server.720P_HD.mp4" → "Exploring My Abandoned Minecraft Server 720P HD" */
export function prettyName(file: string): string {
  let n = file;
  try { n = decodeURIComponent(n); } catch { /* keep */ }
  n = n.split('?')[0].split('/').pop() || 'video';
  n = n.replace(/\.(mp4|webm|mov|m4v|mkv|avi|mp3|wav|m4a)$/i, '');
  return n.replace(/[._]+/g, ' ').replace(/\s+/g, ' ').trim() || 'video';
}

export const proxyUrl = (url: string) => `${import.meta.env.BASE_URL}api/proxy?url=${encodeURIComponent(url)}`;
export const pageUrl = (url: string) => `${import.meta.env.BASE_URL}api/page?url=${encodeURIComponent(url)}`;
export const audioUrl = (url: string) => `${import.meta.env.BASE_URL}api/audio?url=${encodeURIComponent(url)}`;

async function readError(r: Response): Promise<string> {
  try { const j = await r.clone().json(); if (j?.error) return j.error; } catch { /* not json */ }
  return `Server returned ${r.status}`;
}

/** Download a remote video with progress. Tries our server proxy first, then a direct (CORS) fetch. */
export async function fetchRemoteVideo(rawUrl: string, onProgress: (p: DlProgress) => void, signal?: AbortSignal): Promise<{ blob: Blob; name: string; url: string }> {
  const url = normalizeLink(rawUrl);
  if (!/^https?:\/\//i.test(url)) throw new Error('That doesn’t look like a link. Paste a full https://… URL to a video file.');
  if (isPlatformPage(url)) throw new Error('That is a platform page (YouTube/TikTok/…), not a video file. Paste a direct video link — e.g. a GitHub release asset, Dropbox, S3 or any URL ending in .mp4.');

  let res: Response | null = null;
  let viaProxy = true;
  try {
    const r = await fetch(proxyUrl(url), { signal });
    const ct = r.headers.get('content-type') || '';
    if (r.ok && !ct.includes('text/html')) res = r;
    else if (ct.includes('application/json')) throw new Error(await readError(r));
    // html / 404 → no server running (static hosting) → try direct
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e;
    if ((e as Error).message && !(e instanceof TypeError)) throw e;
  }
  if (!res) {
    viaProxy = false;
    try { res = await fetch(url, { signal }); }
    catch (e) {
      if ((e as Error).name === 'AbortError') throw e;
      throw new Error('That host blocks browser downloads (CORS) and the ClipForge server isn’t reachable. Run the app with `npm start` (or on Render) so links go through the server.');
    }
    if (!res.ok) throw new Error(`Download failed (${res.status}).`);
  }
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('text/html')) throw new Error('That link returns a web page, not a video file. Use a direct download link (…/file.mp4).');

  const total = Number(res.headers.get('content-length')) || 0;
  const headerName = res.headers.get('x-filename');
  const name = prettyName(headerName ? decodeURIComponent(headerName) : new URL(url).pathname);
  const reader = res.body?.getReader();
  if (!reader) { const blob = await res.blob(); return { blob, name, url }; }

  const chunks: Uint8Array[] = [];
  let loaded = 0, lastT = performance.now(), lastLoaded = 0, speed = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value); loaded += value.length;
    const now = performance.now();
    if (now - lastT > 400) {
      const inst = ((loaded - lastLoaded) / (now - lastT)) * 1000;
      speed = speed ? speed * 0.6 + inst * 0.4 : inst;
      lastT = now; lastLoaded = loaded;
      onProgress({ loaded, total, speed });
    }
  }
  onProgress({ loaded, total: total || loaded, speed });
  let type = ct && !ct.includes('octet-stream') ? ct.split(';')[0] : '';
  if (!type) type = /\.webm(\?|$)/i.test(url) ? 'video/webm' : /\.mov(\?|$)/i.test(url) ? 'video/quicktime' : 'video/mp4';
  const blob = new Blob(chunks as BlobPart[], { type });
  chunks.length = 0;
  if (blob.size < 1000) throw new Error('The download was empty. Check that the link is public and points to a video file.');
  void viaProxy;
  return { blob, name, url };
}

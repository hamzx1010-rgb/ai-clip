/**
 * Tiny IndexedDB wrapper.
 *
 * Two stores on purpose:
 *  - "meta"  : small JSON records (runs + clips). Cheap to read on a phone.
 *  - "blobs" : the exported files. IndexedDB keeps them on disk, so a finished
 *              clip does NOT sit in RAM and does NOT get re-exported later.
 *
 * Everything is best-effort: if storage is unavailable (private mode, quota)
 * ClipForge still works for the current session.
 */

import type { Clip, RunMeta } from './types';

const DB_NAME = 'clipforge';
const DB_VERSION = 3;
const META = 'meta';
const BLOBS = 'blobs';

let dbPromise: Promise<IDBDatabase | null> | null = null;

function openDb(): Promise<IDBDatabase | null> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    try {
      if (typeof indexedDB === 'undefined') return resolve(null);
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(META)) {
          const s = db.createObjectStore(META);
          s.createIndex('byRun', 'runId');
        }
        if (!db.objectStoreNames.contains(BLOBS)) db.createObjectStore(BLOBS);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
  return dbPromise;
}

function tx<T>(
  store: string,
  mode: IDBTransactionMode,
  fn: (s: IDBObjectStore) => IDBRequest<T>,
): Promise<T | null> {
  return openDb().then(
    (db) =>
      new Promise<T | null>((resolve) => {
        if (!db) return resolve(null);
        try {
          const t = db.transaction(store, mode);
          const req = fn(t.objectStore(store));
          req.onsuccess = () => resolve(req.result as T);
          req.onerror = () => resolve(null);
        } catch {
          resolve(null);
        }
      }),
  );
}

/* ---------------- runs ---------------- */

export function saveRun(run: RunMeta): Promise<unknown> {
  return tx(META, 'readwrite', (s) => s.put(strip(run), `run:${run.id}`));
}

export function getRun(id: string): Promise<RunMeta | null> {
  return tx<RunMeta>(META, 'readonly', (s) => s.get(`run:${id}`));
}

export async function listRuns(): Promise<RunMeta[]> {
  const db = await openDb();
  if (!db) return [];
  return new Promise((resolve) => {
    try {
      const out: RunMeta[] = [];
      const t = db.transaction(META, 'readonly');
      t.objectStore(META).openCursor().onsuccess = (e) => {
        const c = (e.target as IDBRequest<IDBCursorWithValue | null>).result;
        if (c) {
          if (typeof c.key === 'string' && c.key.startsWith('run:')) {
            out.push(c.value as RunMeta);
          }
          c.continue();
        } else {
          out.sort((a, b) => b.createdAt - a.createdAt);
          resolve(out);
        }
      };
      t.onerror = () => resolve(out);
    } catch {
      resolve([]);
    }
  });
}

export async function deleteRun(id: string): Promise<void> {
  const clips = await listClips(id);
  await Promise.all(clips.map((c) => deleteClipData(c.id)));
  await tx(META, 'readwrite', (s) => s.delete(`run:${id}`));
}

/* ---------------- clips ---------------- */

export function saveClip(clip: Clip): Promise<unknown> {
  // Never persist object URLs — they die with the page.
  const rec = { ...clip, url: null, thumbUrl: null } as Clip;
  return tx(META, 'readwrite', (s) => s.put(strip(rec), `clip:${clip.id}`));
}

export async function listClips(runId: string): Promise<Clip[]> {
  const db = await openDb();
  if (!db) return [];
  return new Promise((resolve) => {
    try {
      const out: Clip[] = [];
      const t = db.transaction(META, 'readonly');
      const idx = t.objectStore(META).index('byRun');
      idx.openCursor(IDBKeyRange.only(runId)).onsuccess = (e) => {
        const c = (e.target as IDBRequest<IDBCursorWithValue | null>).result;
        if (c) {
          const v = c.value as Clip;
          if (v && v.id) out.push(v);
          c.continue();
        } else {
          out.sort((a, b) => a.index - b.index);
          resolve(out);
        }
      };
      t.onerror = () => resolve(out);
    } catch {
      resolve([]);
    }
  });
}

export async function allClips(): Promise<Clip[]> {
  const db = await openDb();
  if (!db) return [];
  return new Promise((resolve) => {
    try {
      const out: Clip[] = [];
      const t = db.transaction(META, 'readonly');
      t.objectStore(META).openCursor().onsuccess = (e) => {
        const c = (e.target as IDBRequest<IDBCursorWithValue | null>).result;
        if (c) {
          if (typeof c.key === 'string' && c.key.startsWith('clip:')) {
            out.push(c.value as Clip);
          }
          c.continue();
        } else {
          out.sort((a, b) => b.index - a.index);
          resolve(out);
        }
      };
      t.onerror = () => resolve(out);
    } catch {
      resolve([]);
    }
  });
}

/* ---------------- blobs ---------------- */

export function putBlob(clipId: string, blob: Blob): Promise<unknown> {
  return tx(BLOBS, 'readwrite', (s) => s.put(blob, `blob:${clipId}`));
}

export function getBlob(clipId: string): Promise<Blob | null> {
  return tx<Blob>(BLOBS, 'readonly', (s) => s.get(`blob:${clipId}`));
}

export function deleteClipData(clipId: string): Promise<unknown> {
  return tx(BLOBS, 'readwrite', (s) => s.delete(`blob:${clipId}`));
}

export async function storageEstimate(): Promise<{ usage: number; quota: number } | null> {
  try {
    if (navigator.storage?.estimate) {
      const e = await navigator.storage.estimate();
      return { usage: e.usage ?? 0, quota: e.quota ?? 0 };
    }
  } catch {
    /* ignore */
  }
  return null;
}

/* ---------------- helpers ---------------- */

function strip(o: unknown): unknown {
  return JSON.parse(JSON.stringify(o));
}

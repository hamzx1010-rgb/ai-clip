import { useEffect, useState } from 'react';

/** Phone-sized screen (Android/iPhone portrait, or a narrow window). */
export const PHONE_MQ = '(max-width: 760px)';
export const isPhone = () => typeof matchMedia !== 'undefined' && matchMedia(PHONE_MQ).matches;
/** Touch-first device (phones/tablets) — new browser tabs are clumsy there and get frozen in the background. */
export const isTouchDevice = () => typeof matchMedia !== 'undefined' && matchMedia('(pointer: coarse)').matches && !matchMedia('(pointer: fine)').matches;
/** Installed as an app (added to home screen). */
export const isStandalone = () => typeof matchMedia !== 'undefined' && (matchMedia('(display-mode: standalone)').matches || (navigator as { standalone?: boolean }).standalone === true);

export function useIsPhone(): boolean {
  const [m, setM] = useState(isPhone);
  useEffect(() => {
    const mq = matchMedia(PHONE_MQ);
    const on = () => setM(mq.matches);
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);
  return m;
}

// Keep the screen on while a long job runs — otherwise Android dims, locks and freezes the tab mid-render.
let lock: { release: () => Promise<void> } | null = null;
let want = false;
async function acquire() {
  try {
    const wl = (navigator as unknown as { wakeLock?: { request: (t: 'screen') => Promise<{ release: () => Promise<void>; addEventListener: (e: string, f: () => void) => void }> } }).wakeLock;
    if (!wl || lock || document.visibilityState !== 'visible') return;
    const l = await wl.request('screen');
    lock = l;
    l.addEventListener('release', () => { if (lock === l) lock = null; });
  } catch { /* not supported / denied — fine */ }
}
export function keepAwake(on: boolean) {
  want = on;
  if (on) void acquire();
  else if (lock) { const l = lock; lock = null; void l.release().catch(() => {}); }
}
if (typeof document !== 'undefined') document.addEventListener('visibilitychange', () => { if (want && document.visibilityState === 'visible') void acquire(); });

// "Install app" (Add to Home screen) — Chrome on Android fires beforeinstallprompt once the PWA is installable.
type BIP = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };
let deferred: BIP | null = null;
const instSubs = new Set<() => void>();
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e as BIP; instSubs.forEach((f) => f()); });
  window.addEventListener('appinstalled', () => { deferred = null; instSubs.forEach((f) => f()); });
}
export function useInstall(): { can: boolean; install: () => Promise<void> } {
  const [, force] = useState(0);
  useEffect(() => { const f = () => force((n) => n + 1); instSubs.add(f); return () => { instSubs.delete(f); }; }, []);
  return {
    can: !!deferred && !isStandalone(),
    install: async () => { if (!deferred) return; const d = deferred; deferred = null; await d.prompt(); await d.userChoice.catch(() => null); instSubs.forEach((f) => f()); },
  };
}
export function registerSW() {
  if (!('serviceWorker' in navigator) || !import.meta.env.PROD) return;
  window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(() => {}); });
}

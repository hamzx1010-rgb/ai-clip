/**
 * Engine A — WebCodecs + MP4Box ("fast" mode).
 *
 * This is the engine that makes "frozen after ~11 seconds" impossible:
 *
 *   stream MP4 access units -> VideoDecoder -> draw to canvas (crop/overlay)
 *   -> VideoEncoder -> MP4Box writer
 *
 * Nothing is paced by the wall clock, so a throttled or hidden tab cannot make
 * the recorder keep writing an old picture. Every frame carries an explicit
 * timestamp taken from the source, and we COUNT the frames that really came out
 * of the decoder and the frames that really went into the file. If the count is
 * short, the export throws instead of handing over a frozen clip.
 *
 * Audio is COPIED from the source (raw AAC access units, exactly what
 * `ffmpeg -c:a copy` does), so it works even in browsers with no AAC encoder
 * and it cannot drift out of sync.
 */

import {
  SourceReader,
  canDemux,
  isAnnexB,
  looksLikeMp4,
  readHeader,
  type ExtractedSample,
  type HeaderInfo,
  type SourceTracks,
  annexBToLengthPrefixed,
} from './mp4demux';
import { Mp4Mux } from './mp4mux';
import { cropRect } from './analyze';
import type { ExportJob, ExportResult } from './export-types';

export { canDemux, looksLikeMp4 };

export function webcodecsSupported(): boolean {
  return (
    typeof VideoDecoder !== 'undefined' &&
    typeof VideoEncoder !== 'undefined' &&
    typeof EncodedVideoChunk !== 'undefined'
  );
}

function levelHex(l: string): string {
  return Math.round(parseFloat(l) * 10).toString(16).padStart(2, '0');
}

/** Can this browser encode H.264 at 720x1280? */
export async function canEncodeH264(): Promise<boolean> {
  if (!webcodecsSupported()) return false;
  for (const profile of ['4200', '4d00', '6400']) {
    for (const level of ['3.1', '4.0', '4.2']) {
      try {
        const s = await VideoEncoder.isConfigSupported({
          codec: `avc1.${profile}${levelHex(level)}`,
          width: 720,
          height: 1280,
          bitrate: 2_500_000,
          framerate: 30,
        });
        if (s.supported) return true;
      } catch {
        /* try next */
      }
    }
  }
  return false;
}

/** True when the bytes are a full "avcC" box rather than its bare payload. */
function looksLikeAvcCBox(u: Uint8Array): boolean {
  return (
    u.length > 8 &&
    u[4] === 0x61 && u[5] === 0x76 && u[6] === 0x63 && u[6 + 1] === 0x43
  );
}

/* ------------------------------------------------------------------ */

export async function exportWebcodecs(job: ExportJob): Promise<ExportResult> {
  const t0 = performance.now();
  const notes: string[] = [];
  const { width, height, fps, start, end } = job;
  const duration = Math.max(0.04, end - start);

  if (!webcodecsSupported()) throw new Error('This browser has no WebCodecs support');

  const head = new Uint8Array(await job.srcBlob.slice(0, 32).arrayBuffer());
  if (!looksLikeMp4(head)) throw new Error('This engine needs an MP4/MOV source');

  /* ---------------- 1. read the header and the sample table -------------- */
  job.onProgress?.(0.01, 'Reading the video index');
  let header: HeaderInfo;
  try {
    header = await readHeader(job.srcBlob, { signal: job.signal });
  } catch (e) {
    // No index at the front (moov at the end). Fall back to a full scan.
    notes.push(`${(e as Error).message} — reading the whole file instead`);
    const full = new SourceReader({ blob: job.srcBlob, wantVideo: false, wantAudio: false, signal: job.signal });
    const p = full.start();
    const t = await full.ready();
    full.destroy();
    await p.catch(() => undefined);
    header = {
      tracks: t,
      videoTimescale: t.videoTimescale,
      audioTimescale: t.audioTimescale,
      videoSamples: [],
      audioSamples: [],
      moovFoundEarly: false,
      headerBytes: null,
      mdatDataStart: 0,
    };
  }
  const tracks: SourceTracks = header.tracks;
  if (!tracks.width || !tracks.height) throw new Error('The video track has no picture size');
  notes.push(`source ${tracks.videoCodec} ${tracks.width}x${tracks.height}`);

  /* ---------------- 2. how much of the file we will touch ---------------- */
  // mp4box cannot be handed a buffer that starts inside mdat (it waits for the
  // whole declared mdat), so we always parse from byte 0 — but we STOP as soon
  // as the clip's last frame has been delivered. On a 20-minute source that
  // turns a full-file read into a read of just the first minutes, and parsing
  // without extraction costs almost nothing.
  const fileSize = job.srcBlob.size;
  if (header.videoSamples.length) {
    const lastRow = header.videoSamples.find((r) => r.seconds > end);
    const byteEnd = lastRow ? lastRow.offset : fileSize;
    notes.push(
      `stops reading at about ${(byteEnd / 1048576).toFixed(1)} MB of a ${(fileSize / 1048576).toFixed(1)} MB file`,
    );
  }

  /* ---------------- 3. copy the audio for this range ---------------- */
  job.onProgress?.(0.03, 'Copying the sound');
  const copiedAudio = await copyAudioRange(job, tracks, start, end, notes);

  /* ---------------- 4. video pipeline ---------------- */
  const reader = new SourceReader({
    blob: job.srcBlob,
    wantVideo: true,
    wantAudio: false,
    stopAtSeconds: end + 0.5,
    chunkBytes: 1024 * 1024,
    highWater: 30,
    lowWater: 6,
    signal: job.signal,
    onProgress: (f) => job.onProgress?.(0.05 + f * 0.1, 'Reading the video file'),
  });

  const decConfig: VideoDecoderConfig = {
    codec: tracks.videoCodec,
    codedWidth: tracks.width,
    codedHeight: tracks.height,
    description: (tracks.avcCBytes ?? undefined) as BufferSource | undefined,
    optimizeForLatency: false,
  };
  const decSupport = await VideoDecoder.isConfigSupported(decConfig);
  if (!decSupport.supported) {
    reader.destroy();
    throw new Error(`This browser cannot decode ${tracks.videoCodec}`);
  }

  const encConfig = pickEncoderConfig(width, height, fps, job.videoBitrate);
  const encSupport = await VideoEncoder.isConfigSupported(encConfig);
  if (!encSupport.supported) {
    reader.destroy();
    throw new Error('This browser cannot encode H.264 — use Real-time mode');
  }

  let mux: Mp4Mux;
  try {
    mux = new Mp4Mux({
      width,
      height,
      // 600 is the conventional movie timescale; the media timescales below are
      // what the sample tables are actually counted in.
      videoTimescale: fps >= 45 ? 90000 : 600,
      avcC: tracks.avcCBytes ?? new Uint8Array(0),
      audioSampleRate: copiedAudio.rate,
      audioChannels: copiedAudio.channels,
      audioFrameDuration: copiedAudio.rate ? 1024 / copiedAudio.rate : 0,
    });
  } catch (e) {
    reader.destroy();
    throw new Error(
      `Could not start the MP4 writer (${String((e as Error)?.message ?? e)}). ` +
        `avcC bytes: ${tracks.avcCBytes?.length ?? 0}, ` +
        `audio ${copiedAudio.rate}Hz/${copiedAudio.channels}ch with ${copiedAudio.samples.length} frames`,
    );
  }

  /* ---- write the copied audio first: it is already in memory ---- */
  const audioTimescale = tracks.audioTimescale || copiedAudio.rate || 48000;
  mux.addRawAacFrames(copiedAudio.samples, audioTimescale);
  copiedAudio.samples.length = 0; // free immediately

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) {
    reader.destroy();
    throw new Error('Could not get a drawing surface');
  }
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, width, height);

  const crop = cropRect(tracks.width, tracks.height, width, height, job.layout, job.faceCenter);

  const timing = { readMs: 0, drawMs: 0, encWaitMs: 0, decWaitMs: 0, yieldMs: 0, draws: 0 };
  let framesDecoded = 0;
  let framesWritten = 0;
  let framesInRange = 0;
  let framesSkippedBefore = 0;
  let decoderError: string | null = null;
  let encoderError: string | null = null;
  let sawAnnexB: boolean | null = null;

  // Decoded frames and the source timestamp they belong to, in order.
  const outFrames: VideoFrame[] = [];
  const outTimes: number[] = [];
  const outDurs: number[] = [];
  const outKeys: boolean[] = [];
  const feedTimes: number[] = [];
  const feedDurs: number[] = [];
  const feedKeys: boolean[] = [];

  const decoder = new VideoDecoder({
    output: (frame) => {
      framesDecoded++;
      // IMPORTANT: take the times from the frame itself.
      // This source has B-frames, so the decoder hands pictures back in a
      // DIFFERENT order from the order they went in. Popping timestamps off a
      // FIFO of input times (what this used to do) mislabels frames: the clip
      // ends up with pairs of frames 5 ms apart and gaps of 100 ms between
      // them, which reads as an average frame rate of ~20 fps and looks juddery
      // even though every picture is correct.
      outFrames.push(frame);
      outTimes.push(frame.timestamp / 1e6);
      outDurs.push((frame.duration ?? Math.round(1e6 / fps)) / 1e6);
      // The source sync flag belongs to the sample we fed, not to this
      // picture, so it is not reused: the encoder picks its own key frames.
      feedTimes.shift();
      feedDurs.shift();
      feedKeys.shift();
    },
    error: (e) => {
      decoderError = e?.message ? String(e.message) : 'Video decoder failed';
    },
  });

  // The encoder hands back its own decoder configuration in the first output
  // callback. It MUST be the one written into avcC: the source's avcC
  // describes the source picture (1280x720 landscape), so reusing it makes the
  // finished clip's bitstream disagree with its sample entry and players
  // report the wrong size.
  let encAvcC: Uint8Array | null = null;

  const encoder = new VideoEncoder({
    output: (chunk, meta) => {
      if (!encAvcC) {
        const desc = meta?.decoderConfig?.description as BufferSource | undefined;
        if (desc) {
          const u8 = desc instanceof ArrayBuffer ? new Uint8Array(desc) : new Uint8Array(desc.buffer ?? desc);
          encAvcC = looksLikeAvcCBox(u8) ? u8.subarray(8) : u8;
        }
        if (!encAvcC || encAvcC.length < 8) encAvcC = tracks.avcCBytes ?? null;
        if (!encAvcC) {
          encoderError = 'The encoder did not report a decoder configuration, so the clip cannot be packaged';
        } else {
          mux.setAvcC(encAvcC);
        }
      }
      const data = new Uint8Array(chunk.byteLength);
      chunk.copyTo(data);
      if (sawAnnexB === null) sawAnnexB = isAnnexB(data);
      // Encoder chunks come back as length-prefixed AVCC (that is what
      // avc1 in an MP4 wants). If a browser hands back Annex-B instead,
      // convert so the file is playable everywhere.
      const avcc = sawAnnexB ? annexBToLengthPrefixed(data) : data;
      mux.addVideoFrame({
        data: avcc,
        time: chunk.timestamp / 1e6,
        duration: (chunk.duration ?? Math.round(1e6 / fps)) / 1e6,
        key: chunk.type === 'key',
      });
      framesWritten++;
    },
    error: (e) => {
      encoderError = e?.message ? `Video encoder failed: ${e.message}` : 'Video encoder failed';
    },
  });

  decoder.configure(decConfig);
  encoder.configure(encConfig);

  try {
    const readLoop = reader.start();
    await reader.ready();

    const vts = tracks.videoTimescale || 1;
    const nominalFrameSec = 1 / fps;
    // Frames are encoded one step behind so each duration is exact.
    let held: { frame: VideoFrame; t: number; key: boolean } | null = null;
    let lastEncodedT = -1;
    let stalledSince = 0;

    for (;;) {
      if (job.signal?.aborted) throw new Error('Stopped');
      if (decoderError) throw new Error(decoderError);
      if (encoderError) throw new Error(encoderError);

      const tRead = performance.now();
      const sample: ExtractedSample | null = await reader.nextVideo();
      timing.readMs += performance.now() - tRead;
      if (!sample) break;

      const tSec = sample.cts / vts;

      // Feed everything from the last key frame before `start` onwards.
      const pastEnd = tSec > end + nominalFrameSec;
      if (!pastEnd) {
        feedTimes.push(tSec);
        feedDurs.push(sample.duration / vts || nominalFrameSec);
        feedKeys.push(sample.is_sync);
        decoder.decode(
          new EncodedVideoChunk({
            type: sample.is_sync ? 'key' : 'delta',
            timestamp: Math.round(tSec * 1e6),
            duration: Math.round((sample.duration / vts || nominalFrameSec) * 1e6),
            data: sample.data,
          }),
        );
      }

      // Drain whatever the decoder has produced.
      while (outFrames.length) {
        const frame = outFrames.shift()!;
        const ft = outTimes.shift()!;
        const key = outKeys.shift()!;
        outDurs.shift();

        if (ft < start - 1e-4) {
          framesSkippedBefore++;
          frame.close();
          continue;
        }
        if (ft > end + 1e-4) {
          frame.close();
          continue;
        }
        framesInRange++;

        // Close out the previously held frame now that we know its duration.
        if (held) {
          const durSec = Math.max(1 / 240, ft - held.t);
          encodeHeld(ctx, canvas, encoder, held, durSec, job, width, height, crop, framesWritten, fps);
          lastEncodedT = held.t;
          held = null;
        }
        held = { frame, t: ft, key };
      }

      // Backpressure on the encoder.
      const tEnc = performance.now();
      while (encoder.encodeQueueSize > 8) {
        await new Promise((r) => setTimeout(r, 2));
        if (encoderError) throw new Error(encoderError);
        if (job.signal?.aborted) throw new Error('Stopped');
      }
      timing.encWaitMs += performance.now() - tEnc;
      // Keep the decoder from running too far ahead of the encoder.
      const tDec = performance.now();
      while (decoder.decodeQueueSize > 24) {
        await new Promise((r) => setTimeout(r, 2));
        if (decoderError) throw new Error(decoderError);
      }
      timing.decWaitMs += performance.now() - tDec;

      if (framesWritten % 24 === 0 && framesWritten > 0) {
        const done = Math.min(1, (lastEncodedT - start) / duration);
        job.onProgress?.(
          0.15 + done * 0.75,
          `Exporting ${Math.max(0, lastEncodedT - start).toFixed(1)}s of ${duration.toFixed(1)}s`,
        );
      }

      if (pastEnd) {
        // Flush the decoder so the tail frames arrive, then stop.
        try {
          await decoder.flush();
        } catch {
          /* ignore */
        }
        while (outFrames.length) {
          const frame = outFrames.shift()!;
          const ft = outTimes.shift()!;
          const key = outKeys.shift()!;
          outDurs.shift();
          if (ft < start - 1e-4 || ft > end + 1e-4) {
            frame.close();
            continue;
          }
          framesInRange++;
          if (held) {
            const durSec = Math.max(1 / 240, ft - held.t);
            encodeHeld(ctx, canvas, encoder, held, durSec, job, width, height, crop, framesWritten, fps);
            lastEncodedT = held.t;
          }
          held = { frame, t: ft, key };
        }
        break;
      }

      // A stall guard: if nothing has been written for a long time, say so
      // instead of spinning forever.
      if (framesWritten === 0) {
        if (!stalledSince) stalledSince = performance.now();
        else if (performance.now() - stalledSince > 120000) {
          throw new Error('No frames were produced in two minutes — giving up rather than hanging');
        }
      } else {
        stalledSince = 0;
      }

      // Yield to the UI occasionally, not on every single frame: a setTimeout
      // per frame costs more than the frame itself on a phone.
      if (framesDecoded % 16 === 0) {
        const tY = performance.now();
        await new Promise((r) => setTimeout(r, 0));
        timing.yieldMs += performance.now() - tY;
      }
    }

    // Flush and write the final held frame.
    try {
      await decoder.flush();
    } catch {
      /* ignore */
    }
    while (outFrames.length) {
      const frame = outFrames.shift()!;
      const ft = outTimes.shift()!;
      const key = outKeys.shift()!;
      outDurs.shift();
      if (ft < start - 1e-4 || ft > end + 1e-4) {
        frame.close();
        continue;
      }
      framesInRange++;
      if (held) {
        encodeHeld(ctx, canvas, encoder, held, Math.max(1 / 240, ft - held.t), job, width, height, crop, framesWritten, fps);
        lastEncodedT = held.t;
      }
      held = { frame, t: ft, key };
    }
    if (held) {
      encodeHeld(ctx, canvas, encoder, held, nominalFrameSec, job, width, height, crop, framesWritten, fps);
      lastEncodedT = held.t;
      held = null;
    }

    await encoder.flush();
    await readLoop.catch(() => undefined);
  } finally {
    try {
      encoder.close();
    } catch {
      /* ignore */
    }
    try {
      decoder.close();
    } catch {
      /* ignore */
    }
    reader.destroy();
    while (outFrames.length) outFrames.shift()!.close();
  }

  /* ---------------- 4. honesty checks before we hand it over ------------- */
  const expected = Math.max(1, Math.round(duration * fps));
  if (framesWritten === 0) {
    throw new Error(
      `Not a single frame was written. The decoder returned ${framesDecoded} frame(s) ` +
        `and ${framesInRange} were inside the clip range.`,
    );
  }
  if (framesWritten < Math.max(4, expected * 0.5)) {
    throw new Error(
      `Only ${framesWritten} frames were written for a ${duration.toFixed(1)}s clip ` +
        `(about ${expected} expected) — refusing to ship a frozen clip`,
    );
  }

  job.onProgress?.(0.95, 'Writing the file');
  const blob = mux.build();
  if (blob.size < 2048) throw new Error('The finished file was empty');

  const audioWritten = mux.audioFrames >= 2;
  if (copiedAudio.rate > 0 && !audioWritten) {
    notes.push('The source audio could not be copied into the file');
  }
  notes.push(
    `${framesWritten} frames written (${framesDecoded} decoded, ${framesSkippedBefore} before the cut, ${framesInRange} in range)`,
  );
  notes.push(
    `timing ms: read ${Math.round(timing.readMs)}, encoderWait ${Math.round(timing.encWaitMs)}, ` +
      `decoderWait ${Math.round(timing.decWaitMs)}, yield ${Math.round(timing.yieldMs)}, ` +
      `total ${Math.round(performance.now() - t0)}`,
  );
  if (sawAnnexB === null) notes.push('encoder produced no data');
  else if (sawAnnexB) notes.push('converted Annex-B to MP4 length-prefixed NAL units');

  job.onProgress?.(1, 'Export complete');

  return {
    blob,
    mime: 'video/mp4',
    engine: 'webcodecs-mp4',
    framesDecoded,
    framesWritten,
    framesExpected: expected,
    duration: mux.videoSeconds || duration,
    audioWritten,
    audioAttempted: copiedAudio.rate > 0,
    elapsedMs: Math.round(performance.now() - t0),
    stallsRecovered: 0,
    notes,
  };
}

/* ------------------------------------------------------------------ */

function encodeHeld(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  encoder: VideoEncoder,
  held: { frame: VideoFrame; t: number; key: boolean },
  durSec: number,
  job: ExportJob,
  width: number,
  height: number,
  crop: { sx: number; sy: number; sw: number; sh: number },
  frameIndex: number,
  fps: number,
) {
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(held.frame, crop.sx, crop.sy, crop.sw, crop.sh, 0, 0, width, height);
  held.frame.close();

  if (job.burnTitle) drawTitle(ctx, job.burnTitle, width, height, held.t - job.start, fps);

  const out = new VideoFrame(canvas, {
    timestamp: Math.round((held.t - job.start) * 1e6),
    duration: Math.round(Math.min(1, Math.max(1 / 240, durSec)) * 1e6),
  });
  encoder.encode(out, { keyFrame: frameIndex % (fps * 2) === 0 });
  out.close();
}

function drawTitle(
  ctx: CanvasRenderingContext2D,
  title: string,
  w: number,
  h: number,
  elapsed: number,
  fps: number,
) {
  void fps;
  if (elapsed > 3.2 || elapsed < 0) return;
  const pad = Math.round(w * 0.06);
  const size = Math.round(w * 0.072);
  ctx.font = `700 ${size}px system-ui, -apple-system, Segoe UI, Roboto, sans-serif`;
  ctx.textBaseline = 'top';
  const words = title.split(/\s+/);
  const lines: string[] = [];
  let cur = '';
  for (const word of words) {
    const test = cur ? `${cur} ${word}` : word;
    if (ctx.measureText(test).width > w - pad * 2 && cur) {
      lines.push(cur);
      cur = word;
    } else cur = test;
  }
  if (cur) lines.push(cur);
  const lineH = Math.round(size * 1.25);
  const shown = lines.slice(0, 3);
  const blockH = shown.length * lineH;
  const y0 = h - pad - blockH - Math.round(h * 0.06);
  ctx.fillStyle = '#000';
  ctx.fillRect(pad - 8, y0 - 8, w - (pad - 8) * 2, blockH + 16);
  ctx.fillStyle = '#fff';
  shown.forEach((ln, i) => ctx.fillText(ln, pad, y0 + i * lineH));
}

function pickEncoderConfig(
  width: number,
  height: number,
  fps: number,
  bitrateOverride?: number,
): VideoEncoderConfig {
  const pixels = width * height;
  const bitrate =
    bitrateOverride ?? Math.round(Math.min(6_500_000, Math.max(1_200_000, pixels * fps * 0.085)));
  const level =
    pixels <= 480 * 640 ? '3.0' : pixels <= 720 * 1280 ? '3.1' : pixels <= 1080 * 1920 ? '4.0' : '4.2';
  const profile = pixels <= 1280 * 720 ? '4200' : '4d00';
  const config: VideoEncoderConfig = {
    codec: `avc1.${profile}${levelHex(level)}`,
    width,
    height,
    framerate: fps,
    bitrate,
    latencyMode: 'quality',
  };
  return config;
}

/* ---------------- audio copy ---------------- */

export interface CopiedRange {
  rate: number;
  channels: number;
  samples: Array<{ data: Uint8Array; cts: number; duration: number }>;
}

/**
 * Read the source's AAC access units for [start,end] and re-base them to 0.
 * No decoding, no re-encoding: the sound cannot drift or be lost, and it works
 * in browsers that have no AAC encoder at all.
 */
export async function copyAudioRange(
  job: ExportJob,
  tracks: SourceTracks,
  start: number,
  end: number,
  notes: string[],
): Promise<CopiedRange> {
  const none: CopiedRange = { rate: 0, channels: 0, samples: [] };
  if (tracks.audioId < 0 || !tracks.audioSampleRate) {
    notes.push('The source has no audio track');
    return none;
  }
  if (!/^mp4a\.40/.test(tracks.audioCodec)) {
    notes.push(`Source audio is ${tracks.audioCodec || 'unknown'} — it cannot be copied into an MP4`);
    return none;
  }
  if (!tracks.esds) {
    notes.push('The source audio has no sample description, so it cannot be copied');
    return none;
  }

  const reader = new SourceReader({
    blob: job.srcBlob,
    wantVideo: false,
    wantAudio: true,
    stopAtSeconds: end + 0.5,
    chunkBytes: 1024 * 1024,
    signal: job.signal,
  });

  const out: CopiedRange['samples'] = [];
  try {
    const loop = reader.start();
    await reader.ready();
    const ats = tracks.audioTimescale || tracks.audioSampleRate;
    let base = -1;
    for (;;) {
      const s = await reader.nextAudio();
      if (!s) break;
      const t = s.cts / ats;
      if (t < start - 0.06) continue;
      if (t > end + 0.06) break;
      if (!s.data || s.data.byteLength === 0) continue;
      if (base < 0) base = s.cts;
      out.push({
        // Copy the bytes: mp4box already released its own reference.
        data: s.data.slice(),
        cts: s.cts - base,
        duration: s.duration || 1024,
      });
    }
    await loop.catch(() => undefined);
  } catch (e) {
    notes.push(`Audio copy failed: ${(e as Error).message}`);
  } finally {
    reader.destroy();
  }

  if (out.length < 2) {
    notes.push('No audio frames were found in that range');
    return none;
  }
  return { rate: tracks.audioSampleRate, channels: tracks.audioChannels || 2, samples: out };
}

/// <reference lib="webworker" />
// On-device narration with Kokoro-82M (Apache-2.0) via kokoro-js + transformers.js (wasm).
import { KokoroTTS } from 'kokoro-js';
import { env } from '@huggingface/transformers';

let tts: KokoroTTS | null = null;
let loading: Promise<KokoroTTS> | null = null;
const MODEL = 'onnx-community/Kokoro-82M-v1.0-ONNX';

function load() {
  return (loading ??= KokoroTTS.from_pretrained(MODEL, {
    dtype: 'q8',
    device: 'wasm',
    progress_callback: (p: { status: string; loaded?: number; total?: number; file?: string }) => {
      if (p.status === 'progress' && p.total) (self as unknown as Worker).postMessage({ type: 'download', loaded: p.loaded, total: p.total, file: p.file });
    },
  } as Parameters<typeof KokoroTTS.from_pretrained>[1]).then((t) => (tts = t)));
}

self.onmessage = async (e: MessageEvent) => {
  const m = e.data as { type: 'load'; threads?: number } | { type: 'speak'; id: number; text: string; voice: string; speed: number };
  try {
    if (m.type === 'load') {
      // several voice workers run side by side → split the CPU threads between them
      if (m.threads && env.backends.onnx?.wasm && !tts && !loading) (env.backends.onnx.wasm as { numThreads?: number }).numThreads = m.threads; await load(); (self as unknown as Worker).postMessage({ type: 'ready' }); return; }
    if (m.type === 'speak') {
      await load();
      const out = await tts!.generate(m.text, { voice: m.voice as never, speed: m.speed });
      const pcm = out.audio as Float32Array;
      (self as unknown as Worker).postMessage({ type: 'audio', id: m.id, pcm, sr: out.sampling_rate }, [pcm.buffer]);
    }
  } catch (err) {
    (self as unknown as Worker).postMessage({ type: 'error', id: (m as { id?: number }).id, error: String((err as Error)?.message || err) });
  }
};

// The AI Director: idea (+ optional reference / your interviews) → researched, narrated, fully edited 9:16 documentary
// project in the editor. Every stage degrades gracefully instead of failing.
import { ALL_FORMATS, AudioBufferSink, BlobSource, Input } from 'mediabunny';
import { findTopics, writeScriptAI, writeScriptFromSources, words, contentWords, type Script, type StyleNotes, type Beat } from './script';
import { topicQuery, wikiFind, wikiArticle, wikiSearch, webArticle, wikiQuotes, type Source, type Quote } from './research';
import { searchCommons, searchOpenverse, searchNasa, searchPexelsVideo, aiImageHit, downloadImage, extractBroll, videoHostsThrottled, type Hit } from './media';
import { releaseVoice, speak, warmUpVoice, TTS_MB, type Spoken } from './tts';
import { aiMode, freeAIDown } from './ai';
import { transcribeLocal } from '../localAsr';
import { analyzeVisual } from '../visual';
import { isPlatformPage, fetchRemoteVideo, pageUrl } from '../ingest';
import { musicWavBlob } from '../synth';
import { fmtTime, loadVideoMeta } from '../util';
import type { Word } from '../types';
import { newItem, textProps, shapeProps, type Asset, type Item, type Project, type Track } from '../../pages/editor/model';
import { makeAsset, saveProject } from '../../pages/editor/store';
import { set as idbSet } from 'idb-keyval';
import { uid } from '../util';

export type DirectorInput = {
  description: string;
  references: string[];
  referenceFile?: File | null;
  minutes: number; // 0 = auto
  voice: string;
  voiceEngine: 'kokoro' | 'openai';
  /** fast: quicker research/script/footage, narration & footage in parallel · deep: more sources, more chapters, more video */
  mode?: 'fast' | 'deep';
  captions: boolean;
  music: boolean;
  gentleMoves: boolean;
  aiImages: boolean;
  quotes: boolean;
  interviews: { file: File; name: string }[];
};
export type DStepId = 'idea' | 'research' | 'reference' | 'script' | 'footage' | 'interviews' | 'voice' | 'edit';
export type DStep = { id: DStepId; label: string; status: 'wait' | 'run' | 'done' | 'skip' | 'error'; detail?: string; progress?: number };
export type DirectorResult = { projectId: string; title: string; duration: number; description: string; credits: string; script: Script };

const W = 1080, H = 1920;
const DEFAULT_STYLE: StyleNotes = { wpm: 155, shotLen: 4.5 };

export async function runDirector(inp: DirectorInput, onSteps: (s: DStep[]) => void, onScript: (s: Partial<Script>) => void, signal: AbortSignal): Promise<DirectorResult> {
  const steps: DStep[] = [
    { id: 'idea', label: 'Understanding your idea', status: 'wait' },
    { id: 'research', label: 'Researching real sources (Wikipedia, articles, quotes)', status: 'wait' },
    { id: 'reference', label: 'Studying your reference video', status: 'wait' },
    { id: 'script', label: 'Writing the script', status: 'wait' },
    { id: 'footage', label: 'Finding archival footage & photos', status: 'wait' },
    { id: 'interviews', label: 'Picking interview soundbites', status: 'wait' },
    { id: 'voice', label: 'Recording narration (on-device voice)', status: 'wait' },
    { id: 'edit', label: 'Editing: cuts, captions, titles, music', status: 'wait' },
  ];
  const tStart = performance.now();
  const set = (id: DStepId, p: Partial<DStep>) => { Object.assign(steps.find((s) => s.id === id)!, p); onSteps(steps.map((s) => ({ ...s }))); if (p.status || p.detail) console.debug(`[director ${((performance.now() - tStart) / 1000).toFixed(1)}s] ${id}: ${p.status ?? ''} ${p.detail ?? ''}`); };
  const check = () => { if (signal.aborted) throw new DOMException('Cancelled', 'AbortError'); };
  onSteps(steps.map((s) => ({ ...s })));
  const fast = inp.mode !== 'deep';

  // 1 ── idea
  set('idea', { status: 'run' });
  // fast mode + free AI: skip this call — the free AI serves one request at a time and the script needs it more
  const skipIdea = fast && aiMode() === 'free';
  const topics = skipIdea ? null : await findTopics(inp.description, signal);
  check();
  const fallbackQuery = topicQuery(inp.description);
  set('idea', { status: 'done', detail: topics ? `Topic: ${topics.title || topics.wiki[0] || fallbackQuery}` : `Topic: “${fallbackQuery}” ${skipIdea ? '(fast mode — keyword search)' : '(AI unavailable — using keyword search)'}` });

  // 2 ── research
  set('research', { status: 'run' });
  const sources: Source[] = [];
  let styleName = '';
  const titles = topics?.wiki.length ? topics.wiki : (await wikiFind(inp.description, 1, signal).catch(() => [])).slice(0, 1);
  const wanted = titles.slice(0, fast ? 2 : 4);
  set('research', { detail: `Reading ${wanted.join(', ').slice(0, 100)}…` });
  const arts = await Promise.all(wanted.map(async (t) => { // all articles at once
    try {
      let a = await wikiArticle(t, signal);
      if (!a) { const s = (await wikiSearch(t, 1, signal))[0]; if (s) a = await wikiArticle(s, signal); }
      return a;
    } catch (e) { if (signal.aborted) throw e; return null; }
  }));
  for (const a of arts) if (a && a.words > 150 && !sources.some((x) => x.title === a.title)) sources.push(a);
  const videoRefs: string[] = [];
  for (const raw of inp.references) {
    const url = raw.trim(); if (!url) continue;
    if (/youtube\.com|youtu\.be|tiktok\.com|instagram\.com/i.test(url)) {
      try { const j = await (await fetch(pageUrl(`https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`), { signal })).json(); styleName = `${j.title} (${j.author_name})`; } catch { /* ignore */ }
      continue;
    }
    if (/\.(mp4|webm|mov|m4v|mkv)(\?|$)/i.test(url) && !isPlatformPage(url)) { videoRefs.push(url); continue; }
    try { const a = await webArticle(url, signal); if (a) sources.unshift(a); } catch (e) { if (signal.aborted) throw e; }
  }
  const quotes: Quote[] = inp.quotes ? await wikiQuotes(topics?.wiki[0] || sources[0]?.title || fallbackQuery, 10, signal) : [];
  const srcWords = sources.reduce((a, s) => a + s.words, 0);
  set('research', { status: sources.length ? 'done' : 'error', detail: sources.length ? `${sources.length} source${sources.length > 1 ? 's' : ''} · ${srcWords.toLocaleString()} words · ${quotes.length} real quotes — ${sources.map((s) => s.title).join(', ').slice(0, 120)}` : 'No encyclopedia article found — the script will rely on the AI' });

  // 3 ── reference video → pacing
  const style: StyleNotes = { ...DEFAULT_STYLE, name: styleName || undefined };
  if (inp.referenceFile || videoRefs.length) {
    set('reference', { status: 'run', detail: 'Loading reference…' });
    try {
      let blob: Blob = inp.referenceFile as Blob;
      if (!blob) blob = (await fetchRemoteVideo(videoRefs[0], (p) => set('reference', { detail: `Downloading reference ${p.total ? Math.round((p.loaded / p.total) * 100) + '%' : Math.round(p.loaded / 1e6) + ' MB'}` }), signal)).blob;
      const st = await analyzeReference(blob, (d) => set('reference', { detail: d }), signal, fast);
      Object.assign(style, st);
      set('reference', { status: 'done', detail: `Copying its pacing: a cut every ${style.shotLen.toFixed(1)}s${fast ? '' : ` · narration ≈ ${Math.round(style.wpm)} words/min`}` });
    } catch (e) {
      if (signal.aborted) throw e;
      set('reference', { status: 'error', detail: 'Couldn’t analyse it: ' + (e as Error).message.slice(0, 100) + ' — using default documentary pacing' });
    }
  } else set('reference', { status: 'skip', detail: styleName ? `Style hint: ${styleName} (platform videos can’t be downloaded — paste a direct .mp4 link or upload to copy pacing)` : 'No reference — default documentary pacing (cut every ~4.5 s)' });

  // 4 ── script
  set('script', { status: 'run', detail: aiMode() === 'key' ? 'Writing with your AI key…' : freeAIDown() ? 'Free AI is down right now — writing from the sources' : 'Writing with the free AI…' });
  const minutes = inp.minutes || Math.max(2, Math.min(20, Math.round(srcWords / 700) || 5));
  let script: Script;
  try {
    script = await writeScriptAI({
      fast,
      description: inp.description + (styleName ? `\nStyle reference: ${styleName}` : ''), minutes, sources, quotes, style, signal,
      onChapter: (c, i, n, title) => { set('script', { detail: `Chapter ${i + 1}/${n}: ${c.title}`, progress: (i + 1) / n }); onScript({ title }); },
    });
  } catch (e) {
    if (signal.aborted) throw e;
    if (!sources.length) throw new Error('The free AI is unavailable right now and no encyclopedia article matched your idea. Try again in a minute, add a free AI key in Settings (Google Gemini or Groq), or paste an article link as a reference.');
    script = writeScriptFromSources({ description: inp.description, minutes, sources, quotes, style, topic: sources[0].title });
    set('script', { detail: 'AI unavailable — wrote it from the sources instead' });
  }
  const nWords = words(script.hook) + words(script.outro) + script.chapters.reduce((a, c) => a + c.beats.reduce((b, x) => b + words(x.narration), 0), 0);
  onScript(script);
  set('script', { status: 'done', progress: 1, detail: `“${script.title}” · ${script.chapters.length} chapters · ${nWords.toLocaleString()} words (≈ ${fmtTime((nWords / style.wpm) * 60)}) · written ${script.writtenBy === 'ai' ? 'by AI from the research' : 'from the sources'}` });
  check();

  const allBeats: { beat: Beat; ci: number }[] = [{ beat: { narration: script.hook, visuals: script.keywords.slice(0, 3) }, ci: -1 }];
  script.chapters.forEach((c, ci) => c.beats.forEach((b) => allBeats.push({ beat: b, ci })));
  allBeats.push({ beat: { narration: script.outro, visuals: script.keywords.slice(3, 6).length ? script.keywords.slice(3, 6) : script.keywords.slice(0, 2) }, ci: script.chapters.length });

  // 7 ── narration — starts now and records in the background while footage is found (it's the slowest step)
  const vAbort = new AbortController();
  const vCheck = () => { if (signal.aborted || vAbort.signal.aborted) throw new DOMException('Cancelled', 'AbortError'); };
  const voiceTask = (async () => {
    set('voice', { status: 'run', detail: inp.voiceEngine === 'kokoro' ? `Loading voice (${TTS_MB} MB, first time only)…` : 'Using OpenAI voice…' });
    let workers = 1;
    let lastPct = -1;
    if (inp.voiceEngine === 'kokoro') workers = await warmUpVoice((p) => {
      if (p.phase !== 'download' || !p.total) return;
      const pct = Math.floor(((p.loaded || 0) / p.total) * 100);
      if (pct === lastPct) return; // one update per percent, not hundreds
      lastPct = pct;
      set('voice', { detail: `Loading voice ${pct}% (${TTS_MB} MB — downloaded the first time, then from cache)`, progress: pct / 100 });
    });
    vCheck();
    const quoteVoice = inp.voice.startsWith('af') || inp.voice.startsWith('bf') ? 'bm_george' : 'af_bella';
    const out: (Spoken | null)[] = new Array(allBeats.length).fill(null);
    const t0 = performance.now();
    let doneWords = 0, doneParts = 0;
    const speed = style.wpm > 170 ? 1.1 : style.wpm < 135 ? 0.92 : 1;
    await mapLimit(allBeats, inp.voiceEngine === 'kokoro' ? Math.max(1, workers) : 3, async ({ beat }, bi) => {
      vCheck();
      const text = beat.quote ? `${beat.quote.text}` : beat.narration;
      if (!text.trim()) { doneParts++; return; }
      out[bi] = await speak(text, beat.quote && inp.voiceEngine === 'kokoro' ? quoteVoice : inp.voice, { engine: inp.voiceEngine, speed });
      doneWords += words(text); doneParts++;
      const elapsed = (performance.now() - t0) / 1000;
      const eta = doneWords < nWords ? ((nWords - doneWords) * elapsed) / doneWords : 0;
      set('voice', { detail: `Recorded ${doneParts} of ${allBeats.length} parts${workers > 1 ? ` (${workers} voices in parallel)` : ''}${eta > 1 ? ` · about ${fmtTime(eta)} left` : ''}`, progress: doneParts / allBeats.length });
    });
    if (inp.voiceEngine === 'kokoro') releaseVoice(); // free the voice model's memory before editing/export
    set('voice', { status: 'done', progress: 1, detail: `${allBeats.length} parts recorded in ${fmtTime((performance.now() - t0) / 1000)}${workers > 1 ? ` with ${workers} voices in parallel` : ''}` });
    return out;
  })();
  voiceTask.catch(() => { releaseVoice(); }); // awaited below; this just avoids an "unhandled rejection" if footage fails first

  try {
  // 5 ── footage (several beats searched at once)
  set('footage', { status: 'run' });
  type Media = { asset: Asset; hit: Hit; dur?: number };
  const used = new Set<string>();
  const credits = new Map<string, Hit>();
  const cache = new Map<string, Promise<Hit[]>>();
  const spacey = /nasa|space|apollo|moon|mars|rocket|planet|galaxy|astronaut|orbit|satellite|shuttle/i.test(inp.description + script.keywords.join(' '));
  const topicWord = sources[0]?.title || topics?.title || '';
  let nImg = 0, nVid = 0, nAi = 0, videoBudget = fast ? Math.min(15, Math.ceil(minutes * 1.5)) : Math.min(40, Math.ceil(minutes * 3));
  const search = (q: string): Promise<Hit[]> => {
    if (!cache.has(q)) cache.set(q, (async () => {
      const [ci, cv, px, ns] = await Promise.all([
        searchCommons(q, 'image', 8, signal).catch(() => []),
        videoBudget > 0 ? searchCommons(q, 'video', 3, signal).catch(() => []) : Promise.resolve([]),
        searchPexelsVideo(q, 2, signal),
        spacey ? searchNasa(q, 'image', 3, signal) : Promise.resolve([]),
      ]);
      let hits = [...cv, ...px, ...ci, ...ns];
      if (hits.filter((h) => h.kind === 'image').length < 3) hits = hits.concat(await searchOpenverse(q, 6, signal));
      return hits;
    })().catch(() => [] as Hit[]));
    return cache.get(q)!;
  };
  // video cutting is heavy (download + re-encode) and video hosts rate-limit bursts → one at a time
  let videoLock: Promise<unknown> = Promise.resolve();
  const oneVideoAtATime = <T,>(fn: () => Promise<T>): Promise<T> => { const r = videoLock.then(fn); videoLock = r.catch(() => {}); return r; };
  const beatMedia: Media[][] = new Array(allBeats.length).fill(null).map(() => []);
  let beatsDone = 0;
  await mapLimit(allBeats, fast ? 5 : 4, async ({ beat }, bi) => {
    check();
    const est = beat.quote ? words(beat.quote.text) / 2.4 : (words(beat.narration) / style.wpm) * 60;
    const need = Math.max(1, Math.min(6, Math.ceil(est / style.shotLen)));
    const picks: Media[] = [];
    const qs = [...new Set((beat.visuals.length ? beat.visuals : [topicWord]).map((v) => (topicWord && !v.toLowerCase().includes(topicWord.toLowerCase().split(' ')[0]) && v.split(' ').length < 2 ? `${topicWord} ${v}` : v)))];
    for (const q of qs) {
      if (picks.length >= need) break;
      const hits = await search(q);
      for (const h of hits) {
        if (picks.length >= need) break;
        if (used.has(h.id)) continue;
        if (h.kind === 'video') {
          if (videoBudget <= 0 || videoHostsThrottled() || picks.some((p) => p.hit.kind === 'video')) continue;
          used.add(h.id); videoBudget--; // reserve before awaiting so parallel beats don't grab the same clip
          const clip = await oneVideoAtATime(async () => {
            if (videoHostsThrottled()) return null;
            set('footage', { detail: `Cutting b-roll from “${h.title.slice(0, 50)}”…` });
            return extractBroll(h, style.shotLen + 1.5, signal);
          });
          check();
          if (!clip) { videoBudget++; continue; }
          const asset = await makeAsset(clip.blob, `${h.title.slice(0, 40)}.${clip.blob.type.includes('mp4') ? 'mp4' : 'webm'}`);
          picks.push({ asset, hit: h, dur: clip.duration }); credits.set(h.id, h); nVid++;
        } else {
          used.add(h.id);
          const blob = await downloadImage(h, signal);
          if (!blob) continue;
          const asset = await makeAsset(blob, `${h.title.slice(0, 40)}.jpg`);
          if (!asset.width) continue;
          picks.push({ asset, hit: h }); credits.set(h.id, h); nImg++;
        }
      }
    }
    if (!picks.length && inp.aiImages) {
      const h = aiImageHit(`${beat.visuals[0] || topicWord}${topicWord && !String(beat.visuals[0]).includes(topicWord) ? ', ' + topicWord : ''}`);
      set('footage', { detail: `No real footage for “${beat.visuals[0]}” — generating an AI illustration…` });
      const blob = await downloadImage(h, signal);
      if (blob) { const asset = await makeAsset(blob, 'ai-illustration.jpg'); picks.push({ asset, hit: h }); credits.set(h.id, h); nAi++; }
    }
    beatMedia[bi] = picks;
    beatsDone++;
    set('footage', { detail: `${nImg} photos · ${nVid} video clips${nAi ? ` · ${nAi} AI illustrations` : ''} so far`, progress: beatsDone / allBeats.length });
  });
  // beats with nothing reuse the previous beat's last shots
  for (let bi = 1; bi < beatMedia.length; bi++) if (!beatMedia[bi].length) beatMedia[bi] = beatMedia[bi - 1].slice(-2);
  for (let bi = beatMedia.length - 2; bi >= 0; bi--) if (!beatMedia[bi].length) beatMedia[bi] = beatMedia[bi + 1].slice(0, 2);
  if (!beatMedia.some((m) => m.length)) throw new Error('Couldn’t find any footage or images for this topic. Try a more specific description (names, places, events).');
  const providers = [...new Set([...credits.values()].map((h) => h.provider))];
  set('footage', { status: 'done', progress: 1, detail: `${nImg} photos · ${nVid} video clips${nAi ? ` · ${nAi} AI illustrations (labelled)` : ''} from ${providers.join(', ')}` });

  // 6 ── interviews (your own footage)
  type Bite = { asset: Asset; name: string; s: number; e: number; words: Word[]; text: string };
  const bitesByChapter = new Map<number, Bite>();
  if (inp.interviews.length) {
    set('interviews', { status: 'run' });
    try {
      const cands: Bite[] = [];
      for (let k = 0; k < inp.interviews.length; k++) {
        const iv = inp.interviews[k];
        set('interviews', { detail: `Transcribing ${iv.name || iv.file.name} (${k + 1}/${inp.interviews.length})…` });
        const pcm = await audio16k(iv.file, 0, 1800);
        const ws = await transcribeLocal(pcm, 'base', 'en', (p) => set('interviews', { detail: p.phase === 'download' ? `Downloading speech model ${p.total ? Math.round(((p.loaded || 0) / p.total) * 100) : 0}%…` : `Transcribing ${iv.name || iv.file.name}…` }));
        const asset = await makeAsset(iv.file, iv.file.name);
        // sentence groups of 6–22 s
        let cur: Word[] = [];
        const flush = () => { if (cur.length) { const s = cur[0].s, e = cur[cur.length - 1].e; if (e - s >= 5) cands.push({ asset, name: iv.name || iv.file.name.replace(/\.[^.]+$/, ''), s: Math.max(0, s - 0.15), e: e + 0.25, words: cur, text: cur.map((w) => w.w).join(' ') }); } cur = []; };
        for (const w of ws) { cur.push(w); const d = w.e - cur[0].s; if ((/[.!?]$/.test(w.w) && d >= 7) || d >= 22) flush(); }
        flush();
      }
      const taken = new Set<Bite>();
      script.chapters.forEach((c, ci) => {
        const q = new Set(contentWords(c.title + ' ' + c.beats.map((b) => b.narration).join(' ')));
        let best: Bite | null = null, bestS = -1;
        for (const b of cands) { if (taken.has(b)) continue; const sc = contentWords(b.text).reduce((a, w) => a + (q.has(w) ? 1 : 0), 0) / Math.sqrt(b.words.length + 5); if (sc > bestS) { bestS = sc; best = b; } }
        if (best) { bitesByChapter.set(ci, best); taken.add(best); }
      });
      set('interviews', { status: 'done', detail: `${bitesByChapter.size} soundbites placed (${cands.length} candidates found)` });
    } catch (e) {
      if (signal.aborted) throw e;
      set('interviews', { status: 'error', detail: 'Couldn’t transcribe the interviews: ' + (e as Error).message.slice(0, 100) });
    }
  } else set('interviews', { status: 'skip', detail: 'No interviews uploaded — real quotes are read on screen instead' });

  if (steps.find((x) => x.id === 'voice')!.status !== 'done') set('edit', { status: 'run', detail: 'Waiting for the narration to finish…' });
  const spoken = await voiceTask;
  check();

  // 8 ── edit
  set('edit', { status: 'run', detail: 'Placing shots…' });
  const P = buildProject(script, allBeats, beatMedia, spoken, bitesByChapter, inp, style);
  for (const s of spoken) if (s) { const a = await makeAsset(s.blob, 'narration.wav'); P.voiceAssets.push(a); }
  const project = P.finish();
  console.debug('[director] project built', project.items.length, 'items');
  if (inp.music) {
    set('edit', { detail: 'Scoring music…' });
    const blob = await musicWavBlob(script.music, 6);
    const a = await makeAsset(blob, `music-${script.music}.wav`);
    project.assets.push(a);
    const mt = project.tracks.find((t) => t.name === 'Music')!.id;
    const end = Math.max(...project.items.map((i) => i.start + i.dur));
    for (let t = 0; t < end; t += a.duration) {
      const d = Math.min(a.duration, end - t);
      project.items.push(newItem({ type: 'audio', track: mt, name: 'Music', assetId: a.id, start: t, dur: d, volume: 0.12, fadeIn: t === 0 ? 2 : 0, fadeOut: t + d >= end - 0.01 ? 3 : 0 }));
    }
  }
  const credList = [...credits.values()];
  const creditsText = [
    `SOURCES & CREDITS — ${script.title}`, '',
    'Research:', ...sources.map((s) => `• ${s.title} — ${s.url}${s.kind === 'wikipedia' ? ' (CC BY-SA 4.0)' : ''}`),
    ...(quotes.length ? ['', 'Quotes: Wikiquote (CC BY-SA 4.0)'] : []), '',
    'Footage & images:', ...credList.map((h) => `• ${h.title} — ${h.credit} — ${h.license} — ${h.page}`),
    '', 'Narration: AI voice (Kokoro-82M, Apache-2.0). Music: generated by ClipForge (royalty-free).',
  ].join('\n');
  const duration = Math.max(...project.items.map((i) => i.start + i.dur));
  const desc = [
    script.title, '', script.hook, '', 'Chapters:', ...P.chapterMarks.map((c) => `${fmtTime(c.t)} ${c.title}`), '',
    creditsText,
  ].join('\n');
  project.markers = P.chapterMarks.map((c) => c.t);
  console.debug('[director] saving project');
  await saveProject(project);
  console.debug('[director] saved');
  await idbSet('cf:docmeta:' + project.id, { description: desc, credits: creditsText, script, at: Date.now() });
  set('edit', { status: 'done', detail: `${project.items.length} timeline items · ${fmtTime(duration)} long` });
  return { projectId: project.id, title: script.title, duration, description: desc, credits: creditsText, script };
  } catch (e) { vAbort.abort(); throw e; } // stop recording if anything else failed
}

/** Run `fn` over items with at most `limit` running at once (results stay in order via the index). */
async function mapLimit<T>(items: T[], limit: number, fn: (x: T, i: number) => Promise<void>): Promise<void> {
  let next = 0;
  await Promise.all(Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
    while (next < items.length) { const i = next++; await fn(items[i], i); }
  }));
}

/** Pacing & narration speed of a reference video (first ~2 minutes). */
async function analyzeReference(blob: Blob, onDetail: (d: string) => void, signal: AbortSignal, fast = false): Promise<Partial<StyleNotes>> {
  const url = URL.createObjectURL(blob);
  try {
    const meta = await loadVideoMeta(url);
    const span = Math.min(meta.duration, fast ? 60 : 150);
    onDetail('Measuring its editing pace…');
    const vis = await analyzeVisual(url, span, { faces: false, maxSamples: Math.round(span * 2) }, () => {});
    const cuts = vis.sceneCuts.filter((c: number | { t: number }) => (typeof c === 'number' ? c : c.t) < span).length;
    const shotLen = Math.max(2.2, Math.min(8, span / (cuts + 1)));
    if (fast) return { shotLen }; // fast mode: pacing only (no speech-model download)
    onDetail('Listening to its narration speed…');
    const pcm = await audio16k(blob, Math.min(10, meta.duration * 0.1), 90);
    let wpm = DEFAULT_STYLE.wpm, sample: string | undefined;
    if (!signal.aborted) {
      const ws = await transcribeLocal(pcm, 'tiny', 'en', () => {});
      if (ws.length > 30) {
        const speech = ws.reduce((a, w) => a + Math.min(1.2, w.e - w.s), 0) + ws.length * 0.08;
        wpm = Math.max(125, Math.min(185, (ws.length / Math.max(20, speech)) * 60));
        sample = ws.map((w) => w.w).join(' ');
      }
    }
    return { shotLen, wpm, sample };
  } finally { URL.revokeObjectURL(url); }
}

/** 16 kHz mono PCM of [start, start+len] seconds — reads only what's needed (works for big files). */
async function audio16k(file: Blob, start: number, len: number): Promise<Float32Array> {
  const input = new Input({ source: new BlobSource(file), formats: ALL_FORMATS });
  try {
    const at = await input.getPrimaryAudioTrack();
    if (!at || !(await at.canDecode())) throw new Error('no decodable audio track');
    const sink = new AudioBufferSink(at);
    const chunks: { buffer: AudioBuffer; timestamp: number }[] = [];
    for await (const b of sink.buffers(start, start + len)) chunks.push(b);
    if (!chunks.length) throw new Error('no audio in that range');
    const sr = chunks[0].buffer.sampleRate;
    const total = Math.ceil((chunks[chunks.length - 1].timestamp + chunks[chunks.length - 1].buffer.duration - chunks[0].timestamp) * sr);
    const mono = new Float32Array(total);
    for (const c of chunks) {
      const off = Math.round((c.timestamp - chunks[0].timestamp) * sr);
      const n = c.buffer.numberOfChannels;
      for (let ch = 0; ch < n; ch++) { const d = c.buffer.getChannelData(ch); for (let i = 0; i < d.length && off + i < total; i++) mono[off + i] += d[i] / n; }
    }
    const oac = new OfflineAudioContext(1, Math.ceil((total / sr) * 16000), 16000);
    const buf = new AudioBuffer({ length: total, sampleRate: sr, numberOfChannels: 1 });
    buf.getChannelData(0).set(mono);
    const s = oac.createBufferSource(); s.buffer = buf; s.connect(oac.destination); s.start();
    return (await oac.startRendering()).getChannelData(0);
  } finally { input.dispose?.(); }
}

/** Assemble the editor project. */
function buildProject(
  script: Script, beats: { beat: Beat; ci: number }[], beatMedia: { asset: Asset; hit: Hit; dur?: number }[][], spoken: (Spoken | null)[],
  bites: Map<number, { asset: Asset; name: string; s: number; e: number; words: Word[] }>, inp: DirectorInput, style: StyleNotes,
) {
  const mk = (name: string, kind: Track['kind']): Track => ({ id: uid('tr_'), kind, name, muted: false, locked: false, hidden: false });
  const tracks = [mk('Titles', 'visual'), mk('Captions', 'visual'), mk('Overlay', 'visual'), mk('Main', 'visual'), mk('Voice', 'audio'), mk('Music', 'audio')];
  const T = (n: string) => tracks.find((t) => t.name === n)!.id;
  const items: Item[] = [];
  const assets = new Map<string, Asset>();
  const voiceAssets: Asset[] = [];
  const chapterMarks: { t: number; title: string }[] = [];
  let t = 0.4;
  let shotNo = 0;

  const shot = (m: { asset: Asset; hit: Hit; dur?: number }, start: number, dur: number, extra: Partial<Item> = {}) => {
    assets.set(m.asset.id, m.asset);
    const a = m.asset;
    const base: Partial<Item> = { track: T('Main'), name: m.hit.title.slice(0, 24), assetId: a.id, start, dur, fit: 'cover', volume: 0, ...extra };
    if (a.kind === 'video') { items.push(newItem({ type: 'video', ...base, in: 0, dur: Math.min(dur, (m.dur ?? a.duration) - 0.05) } as Item)); return Math.min(dur, (m.dur ?? a.duration) - 0.05); }
    const it = newItem({ type: 'image', ...base } as Item);
    if (inp.gentleMoves && a.width && a.height) {
      const iw = a.width, ih = a.height;
      const dir = shotNo % 2 ? 1 : -1;
      if (iw / ih > W / H + 0.05) { // wider than the frame → slow pan across it
        const bw = iw * (H / ih);
        const lim = bw / (2 * W) - 0.5;
        const amp = Math.min(0.5, lim) * 0.55;
        it.kf.x = [{ t: 0, v: 0.5 - amp * dir, ease: 'linear' }, { t: dur, v: 0.5 + amp * dir, ease: 'linear' }];
      } else { // taller → slow vertical drift
        const bh = ih * (W / iw);
        const lim = bh / (2 * H) - 0.5;
        const amp = Math.min(0.3, lim) * 0.5;
        if (amp > 0.01) it.kf.y = [{ t: 0, v: 0.5 + amp * dir, ease: 'linear' }, { t: dur, v: 0.5 - amp * dir, ease: 'linear' }];
      }
    }
    items.push(it);
    shotNo++;
    return dur;
  };
  const cover = (media: { asset: Asset; hit: Hit; dur?: number }[], a: number, b: number, extra: Partial<Item> = {}) => {
    if (!media.length) return;
    let x = a, k = 0;
    while (x < b - 0.05) {
      const m = media[k % media.length]; k++;
      let d = Math.min(style.shotLen, b - x);
      if (b - (x + d) < 1.5) d = b - x;
      const got = shot(m, x, d, extra);
      x += Math.max(0.5, got);
    }
  };
  const captions = (sentences: { text: string; s: number; e: number }[], offset: number) => {
    if (!inp.captions) return;
    for (const s of sentences) {
      const ws = s.text.split(/\s+/).filter(Boolean);
      const chunks: string[][] = [];
      let cur: string[] = [];
      for (const w of ws) { cur.push(w); if (cur.length >= 4 || /[,.;:!?]$/.test(w)) { chunks.push(cur); cur = []; } }
      if (cur.length) chunks.push(cur);
      const tot = ws.reduce((a, w) => a + w.length + 1, 0);
      let acc = s.s;
      for (const c of chunks) {
        const d = ((c.reduce((a, w) => a + w.length + 1, 0)) / tot) * (s.e - s.s);
        items.push(newItem({ type: 'text', track: T('Captions'), name: c.join(' ').slice(0, 18), start: offset + acc, dur: Math.max(0.15, d), y: 0.73, text: textProps({ content: c.join(' '), font: 'Montserrat', size: 0.058, weight: 900, upper: true, stroke: '#000000', strokeW: 0.16, shadow: true, width: 0.86 }) }));
        acc += d;
      }
    }
  };
  const lowerDark = (start: number, dur: number, opacity = 0.55) => items.push(newItem({ type: 'shape', track: T('Overlay'), name: 'Dim', start, dur, opacity, shape: shapeProps({ kind: 'rect', fill: '#000000', w: 1.02, h: 1.02, radius: 0 }) }));

  // hook
  const hookSp = spoken[0];
  if (hookSp) {
    items.push(newItem({ type: 'audio', track: T('Voice'), name: 'Hook', assetId: '__voice0', start: t, dur: hookSp.duration }));
    cover(beatMedia[0], 0, t + hookSp.duration + 0.3);
    captions(hookSp.sentences, t);
    t += hookSp.duration + 0.3;
  }
  // title card
  const tcard = 3.2;
  cover(beatMedia[1]?.length ? beatMedia[1].slice(0, 1) : beatMedia[0].slice(0, 1), t, t + tcard, { adj: { brightness: 55, contrast: 100, saturate: 80, hue: 0, blur: 0, grayscale: 0, sepia: 0, invert: 0, temp: 0 } } as Partial<Item>);
  items.push(newItem({ type: 'text', track: T('Titles'), name: 'Title', start: t, dur: tcard, y: 0.45, animIn: 'fade', animOut: 'fade', animDur: 0.5, text: textProps({ content: script.title.toUpperCase(), font: 'Bebas Neue', weight: 400, size: 0.1, color: '#ffffff', shadow: true, width: 0.88 }) }));
  items.push(newItem({ type: 'shape', track: T('Overlay'), name: 'Rule', start: t + 0.3, dur: tcard - 0.3, y: 0.53, animIn: 'wipe-right', animDur: 0.6, shape: shapeProps({ kind: 'rect', fill: '#e8c872', w: 0.3, h: 0.004, radius: 0 }) }));
  t += tcard;

  let bi = 1;
  script.chapters.forEach((ch, ci) => {
    // chapter card
    const card = 2.4;
    chapterMarks.push({ t, title: ch.title });
    const firstMedia = beatMedia[bi] || [];
    cover(firstMedia.slice(0, 1), t, t + card, { adj: { brightness: 45, contrast: 105, saturate: 70, hue: 0, blur: 0, grayscale: 0, sepia: 0, invert: 0, temp: 0 }, animIn: 'fade', animDur: 0.5 } as Partial<Item>);
    items.push(newItem({ type: 'text', track: T('Titles'), name: `Chapter ${ci + 1}`, start: t + 0.2, dur: card - 0.2, y: 0.3, animIn: 'fade', animOut: 'fade', text: textProps({ content: `CHAPTER ${ci + 1}`, font: 'Inter', weight: 700, size: 0.03, color: '#e8c872', shadow: false }) }));
    items.push(newItem({ type: 'text', track: T('Titles'), name: ch.title.slice(0, 18), start: t + 0.35, dur: card - 0.35, y: 0.45, animIn: 'slide-up', animOut: 'fade', text: textProps({ content: ch.title, font: 'Playfair Display', weight: 800, size: ch.title.length > 26 ? 0.056 : 0.066, color: '#ffffff', width: 0.84 }) }));
    t += card;
    ch.beats.forEach((b, k) => {
      const sp = spoken[bi];
      const media = beatMedia[bi] || [];
      if (sp) {
        items.push(newItem({ type: 'audio', track: T('Voice'), name: b.quote ? 'Quote' : `Ch${ci + 1} · ${k + 1}`, assetId: '__voice' + bi, start: t, dur: sp.duration }));
        const end = t + sp.duration + (b.quote ? 0.8 : 0.28);
        cover(media, t, end);
        if (b.quote) {
          lowerDark(t, end - t, 0.62);
          items.push(newItem({ type: 'text', track: T('Titles'), name: 'Quote', start: t, dur: end - t, y: 0.44, animIn: 'fade', animOut: 'fade', text: textProps({ content: `“${b.quote.text}”`, font: 'Playfair Display', weight: 700, italic: true, size: 0.05, color: '#ffffff', width: 0.82 }) }));
          items.push(newItem({ type: 'text', track: T('Titles'), name: 'Quote by', start: t + 0.5, dur: end - t - 0.5, y: 0.66, animIn: 'fade', text: textProps({ content: `— ${b.quote.by}`, font: 'Inter', weight: 600, size: 0.032, color: '#e8c872', shadow: false }) }));
        } else captions(sp.sentences, t);
        t = end;
      }
      bi++;
      // interview soundbite after the 2nd beat of the chapter
      const bite = bites.get(ci);
      if (bite && k === Math.min(1, ch.beats.length - 1)) {
        assets.set(bite.asset.id, bite.asset);
        const d = bite.e - bite.s;
        const wide = bite.asset.width >= bite.asset.height;
        if (wide) items.push(newItem({ type: 'video', track: T('Main'), name: 'Interview bg', assetId: bite.asset.id, start: t, dur: d, in: bite.s, volume: 0, fit: 'cover', adj: { brightness: 50, contrast: 100, saturate: 80, hue: 0, blur: 14, grayscale: 0, sepia: 0, invert: 0, temp: 0 } } as Partial<Item> as Item));
        items.push(newItem({ type: 'video', track: T(wide ? 'Overlay' : 'Main'), name: bite.name.slice(0, 20), assetId: bite.asset.id, start: t, dur: d, in: bite.s, volume: 1, fit: wide ? 'contain' : 'cover' }));
        items.push(newItem({ type: 'shape', track: T('Titles'), name: 'Lower third', start: t + 0.3, dur: Math.min(4.5, d - 0.3), x: 0.5, y: 0.2, animIn: 'wipe-right', animOut: 'fade', shape: shapeProps({ kind: 'rect', fill: '#111111', w: 0.74, h: 0.07, radius: 0.2, label: bite.name }) }));
        captions([{ text: bite.words.map((w) => w.w).join(' '), s: bite.words[0].s - bite.s, e: bite.words[bite.words.length - 1].e - bite.s }], t);
        t += d + 0.3;
      }
    });
    t += 0.5;
  });
  // outro
  const outSp = spoken[bi];
  if (outSp) {
    items.push(newItem({ type: 'audio', track: T('Voice'), name: 'Outro', assetId: '__voice' + bi, start: t, dur: outSp.duration }));
    cover(beatMedia[bi] || beatMedia[0], t, t + outSp.duration + 0.4);
    captions(outSp.sentences, t);
    t += outSp.duration + 0.4;
  }
  // end card
  const endCard = 4.5;
  cover(beatMedia[0].slice(0, 1), t, t + endCard, { adj: { brightness: 35, contrast: 100, saturate: 60, hue: 0, blur: 6, grayscale: 0, sepia: 0, invert: 0, temp: 0 } } as Partial<Item>);
  items.push(newItem({ type: 'text', track: T('Titles'), name: 'End title', start: t, dur: endCard, y: 0.4, animIn: 'fade', text: textProps({ content: script.title.toUpperCase(), font: 'Bebas Neue', weight: 400, size: 0.075, width: 0.86 }) }));
  items.push(newItem({ type: 'text', track: T('Titles'), name: 'Sources', start: t + 0.6, dur: endCard - 0.6, y: 0.56, animIn: 'fade', text: textProps({ content: 'Sources & footage credits in the description', font: 'Inter', weight: 600, size: 0.026, color: '#cccccc', shadow: false, width: 0.8 }) }));

  return {
    voiceAssets, chapterMarks,
    finish(): Project {
      // map placeholder voice ids → real assets (in beat order, skipping empty beats)
      const order: number[] = []; spoken.forEach((s, i) => { if (s) order.push(i); });
      const idFor = new Map(order.map((beatIdx, k) => ['__voice' + beatIdx, voiceAssets[k]?.id]));
      for (const it of items) if (it.assetId?.startsWith('__voice')) it.assetId = idFor.get(it.assetId) || it.assetId;
      return {
        id: uid('proj_'), name: script.title, w: W, h: H, fps: 30, bgColor: '#000000', tracks, items,
        assets: [...assets.values(), ...voiceAssets], markers: [], markIn: null, markOut: null, createdAt: Date.now(), updatedAt: Date.now(),
      };
    },
  };
}

// Text AI for the director. Uses the user's own OpenAI-compatible key if set (OpenAI, Google Gemini, Groq, OpenRouter…),
// otherwise the free keyless Pollinations endpoint. Callers must handle failure (the director then writes from sources).
import { useApp } from '../../store';

export function aiMode(): 'key' | 'free' {
  return useApp.getState().settings.openaiKey.trim() ? 'key' : 'free';
}
export function aiLabel(): string {
  const s = useApp.getState().settings;
  if (!s.openaiKey.trim()) return 'free keyless AI (Pollinations)';
  const host = (() => { try { return new URL(s.openaiBase || 'https://api.openai.com/v1').host; } catch { return 'custom'; } })();
  return `your key · ${s.llmModel || 'gpt-4o-mini'} @ ${host}`;
}

export function parseJSON<T>(raw: string): T {
  let s = raw.trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a >= 0 && b > a) s = s.slice(a, b + 1);
  return JSON.parse(s) as T;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function viaKey(system: string, user: string, json: boolean, signal?: AbortSignal): Promise<string> {
  const s = useApp.getState().settings;
  const base = (s.openaiBase || 'https://api.openai.com/v1').replace(/\/$/, '');
  const body: Record<string, unknown> = { model: s.llmModel || 'gpt-4o-mini', temperature: 0.7, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] };
  if (json) body.response_format = { type: 'json_object' };
  const r = await fetch(base + '/chat/completions', { method: 'POST', signal, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + s.openaiKey.trim() }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`AI ${r.status}: ${(await r.text()).slice(0, 160)}`);
  const j = await r.json();
  return String(j.choices?.[0]?.message?.content ?? '');
}

let freeDownUntil = 0;
/** True if the free AI failed recently — callers skip it instead of waiting minutes for retries. */
export const freeAIDown = () => aiMode() === 'free' && Date.now() < freeDownUntil;
async function viaFree(system: string, user: string, json: boolean, signal?: AbortSignal, timeoutMs?: number): Promise<string> {
  if (Date.now() < freeDownUntil) throw new Error('free AI is unavailable right now');
  try { return await viaFreeInner(system, user, json, signal, timeoutMs); }
  catch (e) { if (!signal?.aborted) freeDownUntil = Date.now() + 4 * 60_000; throw e; }
}
async function viaFreeInner(system: string, user: string, json: boolean, signal?: AbortSignal, timeoutMs?: number): Promise<string> {
  let last = '';
  // 1) our own server relays to the free model (browsers get bot-checked when calling it directly)
  try {
    const r = await fetch('/api/ai', { method: 'POST', signal, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ system, user, json, timeoutMs }) });
    if (r.ok) { const j = await r.json(); if (String(j.text || '').trim()) return String(j.text); }
    last = `${r.status} ${(await r.text().catch(() => '')).slice(0, 120)}`;
    if (r.status !== 404 && r.status !== 405) throw new Error('free AI is busy right now (' + last + ')');
  } catch (e) { if (signal?.aborted || /busy/.test((e as Error).message)) throw e; last = String((e as Error).message); }
  // 2) static hosting without our server: try calling it directly
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await fetch('https://text.pollinations.ai/openai', {
        method: 'POST', signal, headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'openai', messages: [{ role: 'system', content: system }, { role: 'user', content: user }], ...(json ? { response_format: { type: 'json_object' } } : {}), private: true, referrer: 'clipforge' }),
      });
      if (r.ok) { const j = await r.json(); const c = String(j.choices?.[0]?.message?.content ?? ''); if (c.trim()) return c; }
      last = `${r.status} ${(await r.text().catch(() => '')).slice(0, 120)}`;
    } catch (e) { if (signal?.aborted) throw e; last = String((e as Error).message); }
    // GET fallback (different code path on their side)
    try {
      const prompt = `${system}\n\n${user}`.slice(0, 6000);
      const r = await fetch(`https://text.pollinations.ai/${encodeURIComponent(prompt)}?model=openai${json ? '&json=true' : ''}&private=true`, { signal });
      if (r.ok) { const t = await r.text(); if (t.trim() && !t.startsWith('{"error"')) return t; }
      last = `${r.status}`;
    } catch (e) { if (signal?.aborted) throw e; last = String((e as Error).message); }
    await sleep(2500 * (attempt + 1));
  }
  throw new Error('free AI is busy right now (' + last + ')');
}

export async function aiText(system: string, user: string, opts: { json?: boolean; signal?: AbortSignal; timeoutMs?: number } = {}): Promise<string> {
  return aiMode() === 'key' ? viaKey(system, user, !!opts.json, opts.signal) : viaFree(system, user, !!opts.json, opts.signal, opts.timeoutMs);
}
export async function aiJSON<T>(system: string, user: string, signal?: AbortSignal, timeoutMs?: number): Promise<T> {
  const raw = await aiText(system + '\nReply with valid JSON only — no markdown, no comments.', user, { json: true, signal, timeoutMs });
  try { return parseJSON<T>(raw); } catch {
    // one repair attempt
    const fixed = await aiText('Fix this into valid JSON. Output JSON only.', raw.slice(0, 12000), { json: true, signal, timeoutMs });
    return parseJSON<T>(fixed);
  }
}

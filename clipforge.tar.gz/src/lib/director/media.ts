// Footage & images for the director — real archival sources first (Wikimedia Commons, Openverse, NASA, Pexels if you
// have a key), AI-generated illustrations only as a clearly-labelled fallback.
import { ALL_FORMATS, BlobSource, BufferTarget, Conversion, Input, Mp4OutputFormat, Output, UrlSource, WebMOutputFormat, canEncodeVideo } from 'mediabunny';
import { proxyUrl } from '../ingest';
import { useApp } from '../../store';

export type Hit = {
  id: string; kind: 'image' | 'video'; provider: 'Wikimedia Commons' | 'Openverse' | 'NASA' | 'Pexels' | 'AI illustration';
  url: string; w: number; h: number; duration?: number; title: string; credit: string; license: string; page: string;
};

const stripHtml = (s: string) => s.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
const BAD = /\b(logo|icon|flag|coat of arms|signature|map of|locator|diagram|chart|graph|seal|emblem|symbol|svg|screenshot of text|pdf|djvu|stamp)\b/i;

export async function searchCommons(q: string, kind: 'image' | 'video', n = 8, signal?: AbortSignal): Promise<Hit[]> {
  const ft = kind === 'image' ? 'filetype:bitmap' : 'filetype:video';
  const url = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(q + ' ' + ft)}&gsrnamespace=6&gsrlimit=${n}` +
    `&prop=imageinfo${kind === 'video' ? '|videoinfo&viprop=derivatives|url|size|mime|extmetadata' : ''}&iiprop=url|size|mime|extmetadata&iiurlwidth=1280&format=json&origin=*`;
  const r = await fetch(url, { signal });
  if (!r.ok) return [];
  const j = await r.json();
  const pages = Object.values((j.query?.pages || {}) as Record<string, { title: string; index: number; imageinfo?: Record<string, unknown>[]; videoinfo?: Record<string, unknown>[] }>).sort((a, b) => a.index - b.index);
  const out: Hit[] = [];
  const seen = new Set<string>();
  for (const p of pages) {
    const ii = (p.videoinfo?.[0] || p.imageinfo?.[0]) as { url: string; thumburl?: string; width: number; height: number; mime: string; duration?: number; descriptionurl: string; extmetadata?: Record<string, { value: string }>; derivatives?: { src: string; type: string; width: number; height: number }[] } | undefined;
    if (!ii || BAD.test(p.title)) continue;
    const em = ii.extmetadata || {};
    const license = stripHtml(em.LicenseShortName?.value || 'see source');
    const credit = stripHtml(em.Artist?.value || em.Credit?.value || 'Wikimedia Commons contributor').slice(0, 80);
    const title = p.title.replace(/^File:/, '').replace(/\.[a-z0-9]+$/i, '');
    const key = title.toLowerCase().replace(/[_ ][a-z0-9_-]{11}$/i, '').replace(/[^a-z0-9]+/g, '');
    if (seen.has(key)) continue;
    seen.add(key);
    if (kind === 'image') {
      if (ii.width < 640 || ii.height < 400) continue;
      out.push({ id: 'wc:' + p.title, kind, provider: 'Wikimedia Commons', url: ii.thumburl || ii.url, w: ii.width, h: ii.height, title, credit, license, page: ii.descriptionurl });
    } else {
      const ders = (ii.derivatives || []).filter((d) => /webm/.test(d.type) && /vp9|vp8/.test(d.type) && d.height > 0);
      const pick = ders.filter((d) => d.height <= 480).sort((a, b) => b.height - a.height)[0] || ders.sort((a, b) => a.height - b.height)[0];
      if (!pick || !ii.duration || ii.duration < 4 || ii.duration > 1800) continue;
      out.push({ id: 'wc:' + p.title, kind, provider: 'Wikimedia Commons', url: pick.src, w: pick.width, h: pick.height, duration: ii.duration, title, credit, license, page: ii.descriptionurl });
    }
  }
  return out;
}

export async function searchOpenverse(q: string, n = 6, signal?: AbortSignal): Promise<Hit[]> {
  try {
    const r = await fetch(`https://api.openverse.org/v1/images/?q=${encodeURIComponent(q)}&page_size=${n}&mature=false&size=large`, { signal });
    if (!r.ok) return [];
    const j = await r.json();
    return (j.results || [])
      .filter((x: { width?: number; title?: string }) => (x.width || 0) >= 640 && !BAD.test(x.title || ''))
      .map((x: { id: string; url: string; width: number; height: number; title: string; creator?: string; license: string; license_version?: string; foreign_landing_url: string; source?: string }) => ({
        id: 'ov:' + x.id, kind: 'image' as const, provider: 'Openverse' as const, url: x.url, w: x.width, h: x.height, title: x.title || q,
        credit: x.creator || x.source || 'unknown', license: `CC ${x.license.toUpperCase()} ${x.license_version || ''}`.trim(), page: x.foreign_landing_url,
      }));
  } catch { return []; }
}

export async function searchNasa(q: string, kind: 'image' | 'video', n = 4, signal?: AbortSignal): Promise<Hit[]> {
  try {
    const r = await fetch(`https://images-api.nasa.gov/search?q=${encodeURIComponent(q)}&media_type=${kind}&page_size=${n}`, { signal });
    if (!r.ok) return [];
    const j = await r.json();
    const out: Hit[] = [];
    for (const it of (j.collection?.items || []).slice(0, n)) {
      const d = it.data?.[0]; if (!d) continue;
      try {
        const files: string[] = await (await fetch(it.href, { signal })).json();
        const pick = kind === 'image' ? files.find((f) => /~large\.jpg$/i.test(f)) || files.find((f) => /~orig\.jpg$/i.test(f)) : files.find((f) => /~mobile\.mp4$/i.test(f)) || files.find((f) => /~medium\.mp4$/i.test(f)) || files.find((f) => /~small\.mp4$/i.test(f));
        if (!pick) continue;
        out.push({ id: 'nasa:' + d.nasa_id, kind, provider: 'NASA', url: pick.replace(/^http:/, 'https:'), w: kind === 'image' ? 1600 : 1280, h: kind === 'image' ? 1200 : 720, duration: kind === 'video' ? 30 : undefined, title: d.title, credit: d.center ? `NASA ${d.center}` : 'NASA', license: 'Public domain (NASA)', page: `https://images.nasa.gov/details/${d.nasa_id}` });
      } catch { /* skip */ }
    }
    return out;
  } catch { return []; }
}

export async function searchPexelsVideo(q: string, n = 4, signal?: AbortSignal): Promise<Hit[]> {
  const key = useApp.getState().settings.pexelsKey?.trim();
  if (!key) return [];
  try {
    const r = await fetch(`https://api.pexels.com/videos/search?query=${encodeURIComponent(q)}&per_page=${n}&orientation=portrait`, { headers: { Authorization: key }, signal });
    if (!r.ok) return [];
    const j = await r.json();
    return (j.videos || []).map((v: { id: number; width: number; height: number; duration: number; url: string; user: { name: string }; video_files: { link: string; width: number; height: number; file_type: string }[] }) => {
      const f = v.video_files.filter((x) => x.file_type === 'video/mp4' && x.height <= 1920).sort((a, b) => b.height - a.height)[0] || v.video_files[0];
      return { id: 'px:' + v.id, kind: 'video' as const, provider: 'Pexels' as const, url: f.link, w: f.width, h: f.height, duration: v.duration, title: q, credit: v.user.name, license: 'Pexels license', page: v.url };
    });
  } catch { return []; }
}

let aiSeed = 1;
export function aiImageHit(prompt: string): Hit {
  const seed = aiSeed++ * 7919;
  const p = `${prompt}, documentary still, cinematic lighting, realistic, 35mm film, no text`;
  return { id: 'ai:' + seed + ':' + prompt.slice(0, 40), kind: 'image', provider: 'AI illustration', url: `https://image.pollinations.ai/prompt/${encodeURIComponent(p)}?width=1080&height=1920&nologo=true&seed=${seed}&model=flux`, w: 1080, h: 1920, title: prompt, credit: 'AI-generated (Pollinations / Flux)', license: 'AI illustration — not real footage', page: 'https://pollinations.ai' };
}

async function fetchBlob(url: string, signal?: AbortSignal, timeoutMs = 45000): Promise<Blob> {
  const t = AbortSignal.timeout(timeoutMs);
  const sig = signal ? AbortSignal.any([signal, t]) : t;
  try {
    if (/images-assets\.nasa\.gov/.test(url)) throw new Error('no CORS'); // known no-CORS host → straight to the proxy
    const r = await fetch(url, { signal: sig });
    if (r.ok) return await r.blob();
    throw new Error(String(r.status));
  } catch (e) {
    if (signal?.aborted) throw e;
    const r = await fetch(proxyUrl(url), { signal: sig });
    if (!r.ok) throw new Error(`download failed (${r.status})`);
    return await r.blob();
  }
}

/** Download an image; returns null when it's broken/too small. */
export async function downloadImage(h: Hit, signal?: AbortSignal): Promise<Blob | null> {
  try {
    const b = await fetchBlob(h.url, signal, h.provider === 'AI illustration' ? 90000 : 45000);
    if (b.size < 8000 || !/^image\//.test(b.type || 'image/')) return null;
    return b;
  } catch (e) { if (signal?.aborted) throw e; return null; }
}

let avcOk: Promise<boolean> | null = null;

// Wikimedia rate-limits media downloads per IP. One 429 → stop asking for video for a while (photos still work).
let throttledUntil = 0;
export const videoHostsThrottled = () => Date.now() < throttledUntil;
class Throttled extends Error {}

/** Open a remote video with as few requests as possible: small files in one download, big ones with gentle range reads. */
async function openRemote(url: string, estMB: number, signal?: AbortSignal): Promise<Input> {
  if (estMB <= 45) {
    const r = await fetch(url, { signal });
    if (r.status === 429 || r.status === 503) { throttledUntil = Date.now() + 10 * 60_000; throw new Throttled('rate-limited'); }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const len = Number(r.headers.get('content-length') || 0);
    if (len && len > 90e6) { r.body?.cancel().catch(() => {}); }
    else return new Input({ source: new BlobSource(await r.blob()), formats: ALL_FORMATS });
  }
  return new Input({
    formats: ALL_FORMATS,
    source: new UrlSource(url, {
      parallelism: 1, maxCacheSize: 24 * 2 ** 20,
      getRetryDelay: (n, err) => { if (/429/.test(String(err))) { throttledUntil = Date.now() + 10 * 60_000; return null; } return n < 1 ? 2 : null; },
    }),
  });
}
/**
 * Cut a short b-roll clip out of a (possibly huge) remote video without downloading all of it — Mediabunny reads
 * only the byte ranges it needs. Re-encoded to ≤720p, no audio.
 */
export async function extractBroll(h: Hit, seconds: number, signal?: AbortSignal): Promise<{ blob: Blob; duration: number } | null> {
  // 480p VP9 ≈ 1 Mbit/s
  const estMB = ((h.duration || 600) * (h.h >= 480 ? 0.14 : 0.07));
  const tryOnce = async (url: string) => {
    if (videoHostsThrottled()) throw new Throttled('rate-limited');
    const input = await openRemote(url, estMB, signal);
    const onAbort = () => input.dispose?.();
    signal?.addEventListener('abort', onAbort);
    try {
      const vt = await input.getPrimaryVideoTrack();
      if (!vt || !(await vt.canDecode())) return null;
      const dur = await input.computeDuration();
      if (!dur || dur < 3) return null;
      const len = Math.min(seconds, dur - 0.5);
      // skip intros/outros: start somewhere in 20–60% of the file (deterministic per file)
      let hsh = 0; for (const c of h.id) hsh = (hsh * 31 + c.charCodeAt(0)) >>> 0;
      const start = dur <= len + 1 ? 0 : Math.min(dur - len - 0.2, dur * (0.2 + ((hsh % 400) / 1000)));
      const useAvc = await (avcOk ??= canEncodeVideo('avc', { width: 720, height: 1280 }).catch(() => false));
      const output = new Output({ format: useAvc ? new Mp4OutputFormat({ fastStart: 'in-memory' }) : new WebMOutputFormat(), target: new BufferTarget() });
      const srcH = vt.displayHeight, srcW = vt.displayWidth;
      const scale = Math.min(1, 720 / Math.min(srcW, srcH));
      const conv = await Conversion.init({
        input, output, trim: { start, end: start + len },
        video: { codec: useAvc ? 'avc' : 'vp9', width: Math.round((srcW * scale) / 2) * 2, height: Math.round((srcH * scale) / 2) * 2, fit: 'fill', bitrate: 3_000_000, frameRate: 30 },
        audio: { discard: true },
      });
      if (!conv.isValid) return null;
      await conv.execute();
      return { blob: new Blob([(output.target as BufferTarget).buffer!], { type: useAvc ? 'video/mp4' : 'video/webm' }), duration: len };
    } finally {
      signal?.removeEventListener('abort', onAbort);
      input.dispose?.();
    }
  };
  try { return await tryOnce(h.url); } catch (e) {
    if (signal?.aborted) throw e;
    if (e instanceof Throttled || videoHostsThrottled()) return null;
    if (!/fetch|network|HTTP|CORS|range/i.test(String((e as Error)?.message || e))) { console.warn('b-roll failed', h.url, e); return null; }
    try { return await tryOnce(new URL(proxyUrl(h.url), location.href).href); } catch (e2) { if (signal?.aborted) throw e2; console.warn('b-roll failed', h.url, e2); return null; }
  }
}

// Debug hook for troubleshooting footage in the browser console: open the app with ?cfdebug
if (typeof window !== 'undefined' && location.search.includes('cfdebug')) Object.assign(window, { __cfMedia: { searchCommons, extractBroll, downloadImage } });

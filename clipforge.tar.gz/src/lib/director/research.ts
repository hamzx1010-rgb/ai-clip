// Research: real, citable sources. Wikipedia (CC BY-SA), Wikiquote, and any article links the user gives.
import { pageUrl } from '../ingest';

export type Section = { title: string; text: string };
export type Source = { kind: 'wikipedia' | 'web'; title: string; url: string; sections: Section[]; words: number };
export type Quote = { text: string; by: string; url: string };

const WP = 'https://en.wikipedia.org/w/api.php';
const SKIP = /^(see also|references|external links|notes|further reading|bibliography|sources|citations|footnotes|gallery|works cited|explanatory notes|filmography|discography)$/i;

async function getJSON<T>(url: string, signal?: AbortSignal): Promise<T> {
  const r = await fetch(url, { signal });
  if (!r.ok) throw new Error(`${r.status} for ${new URL(url).host}`);
  return (await r.json()) as T;
}

export async function wikiSearch(q: string, n = 3, signal?: AbortSignal): Promise<string[]> {
  const j = await getJSON<{ query?: { search: { title: string }[] } }>(`${WP}?action=query&list=search&srsearch=${encodeURIComponent(q)}&srlimit=${n}&format=json&origin=*`, signal);
  return (j.query?.search || []).map((s) => s.title);
}

/** Turn a free-form video idea into an encyclopedia search query ("A short, dark documentary about the Titanic — emotional" → "Titanic"). */
export function topicQuery(desc: string): string {
  let s = desc.split(/\s[—–-]\s|[;:.!?\n]|,\s*(?:with|focus|focusing|in a|using|told|dark|funny|epic|emotional|suspense)/i)[0] || desc;
  s = s.replace(/^\s*(please\s+)?(make|create|produce|do|give)\s+(me\s+)?/i, '')
    .replace(/\b(an?|the)\s+((very|really|super)\s+)?((short|long|quick|brief|full|mini|deep|detailed|dark|epic|funny|emotional|cinematic|suspenseful|\d+[- ]?min(ute)?s?)[, ]+)*(documentary|doc|video|film|story|explainer|breakdown|essay|short)\s+(about|on|of|covering|explaining)\s+/i, '')
    .replace(/^\s*(the\s+)?(true\s+)?(story|history|rise and fall|origins?)\s+of\s+/i, '')
    .replace(/\b(suspenseful|dramatic|dark|mysterious|epic|funny|emotional|cinematic|chill|calm|tone|style|vibe|explained( simply)?|simply)\b/gi, ' ')
    .replace(/[,"“”]/g, ' ').replace(/\s+/g, ' ').trim();
  return s.slice(0, 100) || desc.slice(0, 100);
}

/** Search Wikipedia for an idea, relaxing the query until something matches. */
export async function wikiFind(desc: string, n = 2, signal?: AbortSignal): Promise<string[]> {
  const q = topicQuery(desc);
  const words = q.split(' ');
  const tries = [q, words.slice(0, 5).join(' '), words.slice(0, 3).join(' '), words.filter((w) => /^[A-Z0-9]/.test(w)).join(' ')].filter((x, i, a) => x && a.indexOf(x) === i);
  for (const t of tries) {
    const r = await wikiSearch(t, n, signal).catch(() => [] as string[]);
    if (r.length) return r;
  }
  return [];
}

export function cleanText(s: string): string {
  return s
    .replace(/\[\d+\]|\[citation needed\]|\[note \d+\]/gi, '')
    .replace(/\s*\((?:[^()]*?(?:pronounced|listen|IPA|born|née|\/)[^()]*)\)/g, '') // pronunciations / birth brackets
    .replace(/\s+/g, ' ')
    .trim();
}

export async function wikiArticle(title: string, signal?: AbortSignal): Promise<Source | null> {
  const j = await getJSON<{ query?: { pages: Record<string, { title: string; extract?: string; missing?: string }> } }>(
    `${WP}?action=query&prop=extracts&explaintext=1&exsectionformat=wiki&redirects=1&titles=${encodeURIComponent(title)}&format=json&origin=*`, signal);
  const page = Object.values(j.query?.pages || {})[0];
  if (!page || page.missing !== undefined || !page.extract) return null;
  const sections: Section[] = [];
  let cur: Section = { title: 'Introduction', text: '' };
  for (const line of page.extract.split('\n')) {
    const h = line.match(/^(={2,6})\s*(.+?)\s*\1\s*$/);
    if (h) {
      if (cur.text.trim()) sections.push(cur);
      cur = { title: h[2], text: '' };
      if (h[1].length > 2 && sections.length && !SKIP.test(sections[sections.length - 1].title)) cur.title = h[2]; // subsections kept as their own sections
    } else if (line.trim()) cur.text += cleanText(line) + '\n';
  }
  if (cur.text.trim()) sections.push(cur);
  const kept = sections.filter((s) => !SKIP.test(s.title) && s.text.split(/\s+/).length > 25);
  return { kind: 'wikipedia', title: page.title, url: `https://en.wikipedia.org/wiki/${encodeURIComponent(page.title.replace(/ /g, '_'))}`, sections: kept, words: kept.reduce((a, s) => a + s.text.split(/\s+/).length, 0) };
}

/** Readable text from any article link (fetched through our server so CORS doesn't matter). */
export async function webArticle(url: string, signal?: AbortSignal): Promise<Source | null> {
  const r = await fetch(pageUrl(url), { signal });
  if (!r.ok) throw new Error(`couldn't open ${new URL(url).host} (${r.status})`);
  const ct = r.headers.get('content-type') || '';
  if (!/html|text/.test(ct)) return null;
  const html = await r.text();
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('script,style,nav,header,footer,aside,form,noscript,figure,iframe').forEach((n) => n.remove());
  const title = (doc.querySelector('meta[property="og:title"]')?.getAttribute('content') || doc.title || url).trim();
  const root = doc.querySelector('article') || doc.querySelector('main') || doc.body;
  const sections: Section[] = [];
  let cur: Section = { title: 'Introduction', text: '' };
  root?.querySelectorAll('h2,h3,p,li').forEach((el) => {
    const t = cleanText(el.textContent || '');
    if (!t) return;
    if (/^H[23]$/.test(el.tagName)) { if (cur.text.trim()) sections.push(cur); cur = { title: t.slice(0, 80), text: '' }; }
    else if (t.split(' ').length >= 12) cur.text += t + '\n';
  });
  if (cur.text.trim()) sections.push(cur);
  const kept = sections.filter((s) => !SKIP.test(s.title));
  if (!kept.length) return null;
  return { kind: 'web', title, url, sections: kept, words: kept.reduce((a, s) => a + s.text.split(/\s+/).length, 0) };
}

/** Real, attributed quotes from Wikiquote for a person/topic. */
export async function wikiQuotes(topic: string, max = 12, signal?: AbortSignal): Promise<Quote[]> {
  const WQ = 'https://en.wikiquote.org/w/api.php';
  try {
    const s = await getJSON<{ query?: { search: { title: string }[] } }>(`${WQ}?action=query&list=search&srsearch=${encodeURIComponent(topic)}&srlimit=1&format=json&origin=*`, signal);
    const title = s.query?.search?.[0]?.title;
    if (!title) return [];
    const p = await getJSON<{ parse?: { wikitext: { '*': string } } }>(`${WQ}?action=parse&page=${encodeURIComponent(title)}&prop=wikitext&format=json&origin=*&redirects=1`, signal);
    const wt = p.parse?.wikitext['*'] || '';
    const out: Quote[] = [];
    let section = '';
    for (const line of wt.split('\n')) {
      const h = line.match(/^==\s*(.+?)\s*==\s*$/);
      if (h) { section = h[1]; continue; }
      if (/disputed|misattributed|about\b|quotes about/i.test(section)) continue;
      const m = line.match(/^\*\s(?!\*)(.+)$/);
      if (!m) continue;
      const text = m[1]
        .replace(/'''?|''/g, '').replace(/\[\[(?:[^|\]]*\|)?([^\]]+)\]\]/g, '$1').replace(/\[https?:\/\/\S+\s([^\]]+)\]/g, '$1')
        .replace(/<[^>]+>/g, '').replace(/\{\{[^}]*\}\}/g, '').replace(/[❝❞]/g, '').replace(/\s+/g, ' ').trim();
      const n = text.split(' ').length;
      if (n >= 7 && n <= 45 && !/^(ch|p|pp|vol)\.|isbn|^source/i.test(text)) out.push({ text, by: title, url: `https://en.wikiquote.org/wiki/${encodeURIComponent(title.replace(/ /g, '_'))}` });
      if (out.length >= max) break;
    }
    return out;
  } catch { return []; }
}

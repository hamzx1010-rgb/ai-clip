// Narration: free on-device Kokoro voice (English), or OpenAI TTS when the user has a key and picks it.
import { encodeWav } from '../audio';
import { ttsOpenAI } from '../llm';

export const VOICES = [
  { id: 'am_michael', label: 'Michael — calm US male', sex: 'm' },
  { id: 'bm_george', label: 'George — British male, classic documentary', sex: 'm' },
  { id: 'am_fenrir', label: 'Fenrir — deep US male', sex: 'm' },
  { id: 'bm_fable', label: 'Fable — British male, storyteller', sex: 'm' },
  { id: 'af_heart', label: 'Heart — warm US female (most natural)', sex: 'f' },
  { id: 'af_bella', label: 'Bella — expressive US female', sex: 'f' },
  { id: 'bf_emma', label: 'Emma — British female', sex: 'f' },
  { id: 'af_nicole', label: 'Nicole — soft, whispery female', sex: 'f' },
] as const;
export const TTS_MB = 92;

export type Spoken = { blob: Blob; duration: number; sentences: { text: string; s: number; e: number }[] };
type Progress = (p: { phase: 'download' | 'speak'; loaded?: number; total?: number; done?: number; of?: number }) => void;

// A small pool of voice workers. Kokoro is a small model that doesn't use many threads well, so on phones/PCs with
// plenty of cores and memory, 2–3 workers speaking different sentences at once is much faster than one.
type W = { w: Worker; busy: number; ready: Promise<void> | null };
let pool: W[] = [];
let seq = 0;
const pending = new Map<number, { res: (v: { pcm: Float32Array; sr: number }) => void; rej: (e: Error) => void; wk: W }>();
let onDownload: Progress | null = null;

/** How many voice workers this device can afford. */
export function voicePoolSize(): number {
  const cores = navigator.hardwareConcurrency || 2;
  const mem = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 4;
  if (cores >= 12 && mem >= 8) return 3;
  if (cores >= 6 && mem >= 4) return 2;
  return 1;
}
let poolTarget = 1;

function spawn(): W {
  const w = new Worker(new URL('./tts.worker.ts', import.meta.url), { type: 'module' });
  const wk: W = { w, busy: 0, ready: null };
  w.onmessage = (e) => {
    const m = e.data;
    if (m.type === 'download') { if (wk === pool[0]) onDownload?.({ phase: 'download', loaded: m.loaded, total: m.total }); }
    else if (m.type === 'audio') { const p = pending.get(m.id); if (p) { p.wk.busy--; p.res({ pcm: m.pcm, sr: m.sr }); pending.delete(m.id); } }
    else if (m.type === 'error') {
      if (m.id !== undefined && pending.has(m.id)) { const p = pending.get(m.id)!; p.wk.busy--; p.rej(new Error(m.error)); pending.delete(m.id); }
      else for (const [k, p] of pending) if (p.wk === wk) { p.rej(new Error(m.error)); pending.delete(k); }
    }
  };
  w.onerror = (e) => {
    for (const [k, p] of pending) if (p.wk === wk) { p.rej(new Error(e.message || 'voice engine crashed')); pending.delete(k); }
    pool = pool.filter((x) => x !== wk); // drop a crashed extra worker; the others keep going
  };
  return wk;
}
function load(wk: W, threads: number) {
  return (wk.ready ??= new Promise<void>((res, rej) => {
    const h = (e: MessageEvent) => {
      if (e.data.type === 'ready') { wk.w.removeEventListener('message', h); res(); }
      else if (e.data.type === 'error' && e.data.id === undefined) { wk.w.removeEventListener('message', h); rej(new Error(e.data.error)); }
    };
    wk.w.addEventListener('message', h);
    wk.w.postMessage({ type: 'load', threads });
  }));
}
const threadsPer = () => Math.max(1, Math.min(4, Math.floor((navigator.hardwareConcurrency || 2) / Math.max(1, poolTarget))));

async function pick(): Promise<W> {
  if (!pool.length) pool.push(spawn());
  await load(pool[0], threadsPer()); // the first worker downloads the model; the rest load it from the cache
  const ready = pool.filter((w) => w.ready);
  return ready.sort((a, b) => a.busy - b.busy)[0];
}

function speakRaw(text: string, voice: string, speed: number): Promise<{ pcm: Float32Array; sr: number }> {
  return pick().then((wk) => {
    const id = ++seq;
    wk.busy++;
    return new Promise((res, rej) => { pending.set(id, { res, rej, wk }); wk.w.postMessage({ type: 'speak', id, text, voice, speed }); });
  });
}

/** Split narration into sentences (keeps abbreviations like "Dr." / "U.S." together reasonably). */
export function sentences(text: string): string[] {
  const t = text.replace(/\s+/g, ' ').trim();
  const out: string[] = [];
  const re = /[^.!?…]+(?:[.!?…]+["”’)]*|$)/g;
  let m: RegExpExecArray | null;
  let buf = '';
  while ((m = re.exec(t))) {
    const s = m[0].trim(); if (!s) continue;
    buf = buf ? buf + ' ' + s : s;
    if (/\b(?:Mr|Mrs|Ms|Dr|St|Jr|Sr|vs|etc|U\.S|No)\.$/i.test(buf) || buf.length < 12) continue;
    out.push(buf); buf = '';
  }
  if (buf) out.push(buf);
  // very long sentences → split on commas/semicolons so the voice engine stays stable
  return out.flatMap((s) => (s.length <= 260 ? [s] : s.split(/(?<=[,;:])\s+/).reduce<string[]>((a, part) => { if (a.length && (a[a.length - 1] + ' ' + part).length < 240) a[a.length - 1] += ' ' + part; else a.push(part); return a; }, [])));
}

/** Speak a paragraph; returns a WAV blob plus exact per-sentence timings (for captions). */
export async function speak(text: string, voice: string, opts: { speed?: number; engine?: 'kokoro' | 'openai'; onProgress?: Progress } = {}): Promise<Spoken> {
  const speed = opts.speed ?? 1;
  const parts = sentences(text);
  if (opts.engine === 'openai') {
    const blob = await ttsOpenAI(text, voice || 'onyx');
    const ab = await new AudioContext().decodeAudioData(await blob.arrayBuffer());
    const total = parts.reduce((a, s) => a + s.length, 0) || 1;
    let acc = 0;
    return { blob, duration: ab.duration, sentences: parts.map((s) => { const a = acc; acc += (s.length / total) * ab.duration; return { text: s, s: a, e: acc }; }) };
  }
  onDownload = opts.onProgress ?? null;
  let done = 0;
  // all sentences are queued at once; the worker pool speaks them in parallel
  const pcs = await Promise.all(parts.map((p) => speakRaw(p, voice, speed).then((r) => { opts.onProgress?.({ phase: 'speak', done: ++done, of: parts.length }); return r; })));
  const sr = pcs[0]?.sr || 24000;
  const gap = Math.round(sr * 0.14);
  const trim = (p: Float32Array) => { // trim leading/trailing near-silence so pacing is tight
    let a = 0, b = p.length;
    while (a < b && Math.abs(p[a]) < 0.004) a++;
    while (b > a && Math.abs(p[b - 1]) < 0.004) b--;
    return p.subarray(Math.max(0, a - Math.round(sr * 0.02)), Math.min(p.length, b + Math.round(sr * 0.05)));
  };
  const trimmed = pcs.map((p) => trim(p.pcm));
  const len = trimmed.reduce((a, p) => a + p.length + gap, 0);
  const ab = new AudioBuffer({ length: Math.max(1, len), sampleRate: sr, numberOfChannels: 1 });
  const ch = ab.getChannelData(0);
  const timings: Spoken['sentences'] = [];
  let off = 0;
  trimmed.forEach((p, i) => { ch.set(p, off); timings.push({ text: parts[i], s: off / sr, e: (off + p.length) / sr }); off += p.length + gap; });
  return { blob: encodeWav(ab), duration: ab.duration, sentences: timings };
}

/** Download/load the voice; with `parallel`, also start extra workers (they load from the browser cache). */
export async function warmUpVoice(onProgress?: Progress, parallel = voicePoolSize()) {
  onDownload = onProgress ?? null;
  poolTarget = Math.max(1, parallel);
  if (!pool.length) pool.push(spawn());
  await load(pool[0], threadsPer());
  while (pool.length < poolTarget) pool.push(spawn());
  await Promise.all(pool.slice(1).map((wk) => load(wk, threadsPer()).catch(() => { wk.w.terminate(); pool = pool.filter((x) => x !== wk); })));
  return pool.length;
}

/** Shut the voice workers down and free their memory (~400 MB each) — called when narration is finished,
 *  so editing & exporting afterwards has the memory to itself. The model stays in the browser cache. */
export function releaseVoice() {
  for (const wk of pool) wk.w.terminate();
  pool = [];
  for (const [k, p] of pending) { p.rej(new Error('voice engine stopped')); pending.delete(k); }
}

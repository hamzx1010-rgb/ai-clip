// Narration: free on-device Kokoro voice (English), or OpenAI TTS when the user has a key and picks it.
import { encodeWav } from '../audio';
import { ttsOpenAI } from '../llm';

export const VOICES = [
  { id: 'am_michael', label: 'Michael — calm US male', sex: 'm' },
  { id: 'bm_george', label: 'George — British male, classic documentary', sex: 'm' },
  { id: 'am_fenrir', label: 'Fenrir — deep US male', sex: 'm' },
  { id: 'bm_fable', label: 'Fable — British male, storyteller', sex: 'm' },
  { id: 'af_heart', label: 'Heart — warm US female (most natural)', sex: 'f' },
  { id: 'af_bella', label: 'Bella — expressive US female', sex: 'f' },
  { id: 'bf_emma', label: 'Emma — British female', sex: 'f' },
  { id: 'af_nicole', label: 'Nicole — soft, whispery female', sex: 'f' },
] as const;
export const TTS_MB = 92;

export type Spoken = { blob: Blob; duration: number; sentences: { text: string; s: number; e: number }[] };
type Progress = (p: { phase: 'download' | 'speak'; loaded?: number; total?: number; done?: number; of?: number }) => void;

let worker: Worker | null = null;
let seq = 0;
const pending = new Map<number, { res: (v: { pcm: Float32Array; sr: number }) => void; rej: (e: Error) => void }>();
let onDownload: Progress | null = null;

function getWorker() {
  if (worker) return worker;
  worker = new Worker(new URL('./tts.worker.ts', import.meta.url), { type: 'module' });
  worker.onmessage = (e) => {
    const m = e.data;
    if (m.type === 'download') onDownload?.({ phase: 'download', loaded: m.loaded, total: m.total });
    else if (m.type === 'audio') { pending.get(m.id)?.res({ pcm: m.pcm, sr: m.sr }); pending.delete(m.id); }
    else if (m.type === 'error') {
      if (m.id !== undefined && pending.has(m.id)) { pending.get(m.id)!.rej(new Error(m.error)); pending.delete(m.id); }
      else for (const [k, p] of pending) { p.rej(new Error(m.error)); pending.delete(k); }
    }
  };
  worker.onerror = (e) => { for (const [k, p] of pending) { p.rej(new Error(e.message || 'voice engine crashed')); pending.delete(k); } };
  return worker;
}

function speakRaw(text: string, voice: string, speed: number): Promise<{ pcm: Float32Array; sr: number }> {
  const id = ++seq;
  return new Promise((res, rej) => { pending.set(id, { res, rej }); getWorker().postMessage({ type: 'speak', id, text, voice, speed }); });
}

/** Split narration into sentences (keeps abbreviations like "Dr." / "U.S." together reasonably). */
export function sentences(text: string): string[] {
  const t = text.replace(/\s+/g, ' ').trim();
  const out: string[] = [];
  const re = /[^.!?…]+(?:[.!?…]+["”’)]*|$)/g;
  let m: RegExpExecArray | null;
  let buf = '';
  while ((m = re.exec(t))) {
    const s = m[0].trim(); if (!s) continue;
    buf = buf ? buf + ' ' + s : s;
    if (/\b(?:Mr|Mrs|Ms|Dr|St|Jr|Sr|vs|etc|U\.S|No)\.$/i.test(buf) || buf.length < 12) continue;
    out.push(buf); buf = '';
  }
  if (buf) out.push(buf);
  // very long sentences → split on commas/semicolons so the voice engine stays stable
  return out.flatMap((s) => (s.length <= 260 ? [s] : s.split(/(?<=[,;:])\s+/).reduce<string[]>((a, part) => { if (a.length && (a[a.length - 1] + ' ' + part).length < 240) a[a.length - 1] += ' ' + part; else a.push(part); return a; }, [])));
}

/** Speak a paragraph; returns a WAV blob plus exact per-sentence timings (for captions). */
export async function speak(text: string, voice: string, opts: { speed?: number; engine?: 'kokoro' | 'openai'; onProgress?: Progress } = {}): Promise<Spoken> {
  const speed = opts.speed ?? 1;
  const parts = sentences(text);
  if (opts.engine === 'openai') {
    const blob = await ttsOpenAI(text, voice || 'onyx');
    const ab = await new AudioContext().decodeAudioData(await blob.arrayBuffer());
    const total = parts.reduce((a, s) => a + s.length, 0) || 1;
    let acc = 0;
    return { blob, duration: ab.duration, sentences: parts.map((s) => { const a = acc; acc += (s.length / total) * ab.duration; return { text: s, s: a, e: acc }; }) };
  }
  onDownload = opts.onProgress ?? null;
  const pcs: { pcm: Float32Array; sr: number }[] = [];
  for (let i = 0; i < parts.length; i++) {
    opts.onProgress?.({ phase: 'speak', done: i, of: parts.length });
    pcs.push(await speakRaw(parts[i], voice, speed));
  }
  const sr = pcs[0]?.sr || 24000;
  const gap = Math.round(sr * 0.14);
  const trim = (p: Float32Array) => { // trim leading/trailing near-silence so pacing is tight
    let a = 0, b = p.length;
    while (a < b && Math.abs(p[a]) < 0.004) a++;
    while (b > a && Math.abs(p[b - 1]) < 0.004) b--;
    return p.subarray(Math.max(0, a - Math.round(sr * 0.02)), Math.min(p.length, b + Math.round(sr * 0.05)));
  };
  const trimmed = pcs.map((p) => trim(p.pcm));
  const len = trimmed.reduce((a, p) => a + p.length + gap, 0);
  const ab = new AudioBuffer({ length: Math.max(1, len), sampleRate: sr, numberOfChannels: 1 });
  const ch = ab.getChannelData(0);
  const timings: Spoken['sentences'] = [];
  let off = 0;
  trimmed.forEach((p, i) => { ch.set(p, off); timings.push({ text: parts[i], s: off / sr, e: (off + p.length) / sr }); off += p.length + gap; });
  return { blob: encodeWav(ab), duration: ab.duration, sentences: timings };
}

export async function warmUpVoice(onProgress?: Progress) {
  onDownload = onProgress ?? null;
  const w = getWorker();
  await new Promise<void>((res, rej) => {
    const h = (e: MessageEvent) => { if (e.data.type === 'ready') { w.removeEventListener('message', h); res(); } else if (e.data.type === 'error' && e.data.id === undefined) { w.removeEventListener('message', h); rej(new Error(e.data.error)); } };
    w.addEventListener('message', h);
    w.postMessage({ type: 'load' });
  });
}

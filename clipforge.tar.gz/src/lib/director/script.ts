// Script writing. With an AI: outline → chapter-by-chapter narration grounded in the research.
// Without (or if the free AI is down): narration is written straight from the sources (extractive), so it still works.
import { aiJSON } from './ai';
import type { Quote, Source } from './research';
import { MUSIC } from '../synth';

export type Beat = { narration: string; visuals: string[]; quote?: Quote };
export type Chapter = { title: string; beats: Beat[] };
export type Script = { title: string; hook: string; chapters: Chapter[]; outro: string; music: string; keywords: string[]; writtenBy: 'ai' | 'sources' };
export type StyleNotes = { wpm: number; shotLen: number; sample?: string; name?: string };

const DOC_MOODS = ['suspense', 'emotional', 'epic', 'horror', 'lofi', 'synthwave'];
export const words = (s: string) => s.split(/\s+/).filter(Boolean).length;

function researchDigest(sources: Source[], maxWords: number): string {
  const out: string[] = [];
  let n = 0;
  for (const s of sources) {
    out.push(`### SOURCE: ${s.title} (${s.url})`);
    for (const sec of s.sections) {
      const t = sec.text.split(/\s+/).slice(0, Math.max(60, Math.floor(maxWords / Math.max(4, s.sections.length)))).join(' ');
      out.push(`## ${sec.title}\n${t}`);
      n += words(t);
      if (n > maxWords) return out.join('\n');
    }
  }
  return out.join('\n');
}

export async function findTopics(description: string, signal?: AbortSignal): Promise<{ wiki: string[]; keywords: string[]; title: string } | null> {
  try {
    const j = await aiJSON<{ wikipedia_titles: string[]; keywords: string[]; working_title: string }>(
      'You help a documentary researcher. Given a video idea, list the English Wikipedia article titles most useful as factual sources (exact titles if you know them), and visual search keywords.',
      `Video idea: """${description}"""\nJSON: {"wikipedia_titles": [up to 4 strings], "keywords": [6-10 short visual search terms], "working_title": string}`, signal, 70_000);
    return { wiki: (j.wikipedia_titles || []).slice(0, 4), keywords: (j.keywords || []).slice(0, 10), title: j.working_title || '' };
  } catch { return null; }
}

type Outline = { title: string; hook: string; music: string; outro: string; chapters: { title: string; summary: string; facts: string[]; visuals: string[] }[] };

export async function writeScriptAI(p: {
  description: string; minutes: number; sources: Source[]; quotes: Quote[]; style: StyleNotes; onChapter?: (c: Chapter, i: number, n: number, title: string) => void; signal?: AbortSignal;
}): Promise<Script> {
  const totalWords = Math.round(p.minutes * p.style.wpm);
  const nCh = Math.max(2, Math.min(14, Math.round(p.minutes / 2.2)));
  const digest = researchDigest(p.sources, 2600);
  const styleLine = p.style.sample ? `Match the voice and pacing of this reference narration sample: """${p.style.sample.slice(0, 700)}"""` : '';
  const outline = await aiJSON<Outline>(
    'You are an award-winning documentary writer for vertical (9:16) YouTube Shorts/TikTok-style documentaries. Facts must come from the provided research; never invent quotes, numbers or events. If research is thin, stay general rather than making things up.',
    `IDEA: """${p.description}"""\nTARGET LENGTH: ${p.minutes} minutes (~${totalWords} narrated words), ${nCh} chapters.\n${styleLine}\nRESEARCH:\n${digest}\n\n` +
    `Return JSON: {"title": catchy title (max 8 words), "hook": 2-3 sentence cold open that makes people keep watching, "music": one of ${JSON.stringify(DOC_MOODS)}, "outro": 2-3 closing sentences, ` +
    `"chapters": [{"title": short chapter title, "summary": what this chapter covers, "facts": [3-8 specific facts from the research], "visuals": [3-5 concrete search terms for archival photos/footage of this chapter, e.g. names of people, places, objects, events]}]}`,
    p.signal);
  const chapters: Chapter[] = [];
  const perCh = Math.max(80, Math.round((totalWords - words(outline.hook) - words(outline.outro)) / Math.max(1, outline.chapters.length)));
  const quotes = [...p.quotes];
  for (let i = 0; i < outline.chapters.length; i++) {
    const oc = outline.chapters[i];
    const rel = relevantResearch(p.sources, `${oc.title} ${oc.summary} ${oc.facts.join(' ')}`, 900);
    let beats: Beat[] = [];
    try {
      const j = await aiJSON<{ beats: { narration: string; visuals: string[] }[] }>(
        'You write narration for one chapter of a documentary. Spoken, vivid, simple sentences; no headings, no stage directions, no "[music]". Only facts from the research.',
        `DOCUMENTARY: ${outline.title}\nCHAPTER ${i + 1}/${outline.chapters.length}: ${oc.title} — ${oc.summary}\nFACTS: ${oc.facts.join(' | ')}\nPREVIOUS CHAPTER ENDED WITH: ${chapters[i - 1]?.beats.slice(-1)[0]?.narration.slice(-200) ?? '(start)'}\n${styleLine}\nRESEARCH:\n${rel}\n\n` +
        `Write about ${perCh} words split into beats of 2-4 sentences. For each beat give 2-3 concrete visual search terms (real names, places, objects) for archival photos or footage.\nJSON: {"beats": [{"narration": string, "visuals": [strings]}]}`,
        p.signal);
      beats = (j.beats || []).filter((b) => b.narration && words(b.narration) > 4).map((b) => ({ narration: b.narration.trim(), visuals: (b.visuals || []).slice(0, 3).concat(oc.visuals.slice(0, 1)) }));
    } catch (e) {
      if (p.signal?.aborted) throw e;
      beats = extractiveBeats(rel, perCh, [oc.title, ...oc.visuals]);
    }
    if (quotes.length && beats.length > 1 && i % 2 === 1) beats.splice(Math.min(2, beats.length), 0, { narration: '', visuals: oc.visuals.slice(0, 2), quote: quotes.shift() });
    const ch = { title: oc.title, beats };
    chapters.push(ch);
    p.onChapter?.(ch, i, outline.chapters.length, outline.title);
  }
  return { title: outline.title, hook: outline.hook, chapters, outro: outline.outro, music: DOC_MOODS.includes(outline.music) ? outline.music : 'suspense', keywords: outline.chapters.flatMap((c) => c.visuals).slice(0, 12), writtenBy: 'ai' };
}

const STOP = new Set('the a an and or of to in on for with at by from as is was were are be been this that these those it its into about over after before during their his her they them he she we you your our not but also than then which who whom whose what when where why how can could would should may might will just very more most such some any each other there here all one two new'.split(' '));
export const contentWords = (s: string) => s.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length > 2 && !STOP.has(w));

function relevantResearch(sources: Source[], query: string, maxWords: number): string {
  const q = new Set(contentWords(query));
  const secs = sources.flatMap((s) => s.sections.map((x) => ({ ...x, src: s.title })));
  const scored = secs.map((s) => ({ s, score: contentWords(s.title + ' ' + s.text).reduce((a, w) => a + (q.has(w) ? 1 : 0), 0) / Math.sqrt(words(s.text) + 20) })).sort((a, b) => b.score - a.score);
  const out: string[] = []; let n = 0;
  for (const { s } of scored) { const t = s.text.split(/\s+/).slice(0, 400).join(' '); out.push(`## ${s.title}\n${t}`); n += words(t); if (n > maxWords) break; }
  return out.join('\n');
}

const sentencesOf = (t: string) => (t.replace(/\s*\([^()]{0,120}\)/g, '').replace(/\s*\[[^\]]{0,80}\]/g, '').replace(/\s+/g, ' ').match(/[^.!?]+[.!?]+(\s|$)/g) || []).map((s) => s.trim()).filter((s) => words(s) >= 5 && words(s) <= 45);

function visualTerms(text: string, extra: string[]): string[] {
  const caps = (text.match(/\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,2})\b/g) || []).filter((c) => !STOP.has(c.toLowerCase()) && c.length > 3);
  const freq = new Map<string, number>(); caps.forEach((c) => freq.set(c, (freq.get(c) || 0) + 1));
  return [...[...freq.entries()].sort((a, b) => b[1] - a[1]).map(([c]) => c).slice(0, 2), ...extra].filter(Boolean).slice(0, 3);
}

function extractiveBeats(text: string, budget: number, extra: string[]): Beat[] {
  const ss = sentencesOf(text.replace(/^##.*$/gm, ''));
  const beats: Beat[] = [];
  let cur: string[] = [], used = 0;
  for (const s of ss) {
    if (used >= budget) break;
    cur.push(s); used += words(s);
    if (cur.length >= 3) { const t = cur.join(' '); beats.push({ narration: t, visuals: visualTerms(t, extra) }); cur = []; }
  }
  if (cur.length) { const t = cur.join(' '); beats.push({ narration: t, visuals: visualTerms(t, extra) }); }
  return beats;
}

/** No AI available → build the documentary straight from the sources. */
export function writeScriptFromSources(p: { description: string; minutes: number; sources: Source[]; quotes: Quote[]; style: StyleNotes; topic: string }): Script {
  const total = Math.round(p.minutes * p.style.wpm);
  const main = p.sources[0];
  const intro = main.sections.find((s) => s.title === 'Introduction') || main.sections[0];
  const introSS = sentencesOf(intro.text);
  const hook = introSS.slice(0, 2).join(' ') || `This is the story of ${main.title}.`;
  const secs = p.sources.flatMap((s) => s.sections.filter((x) => x !== intro).map((x) => ({ ...x, src: s })));
  const nCh = Math.max(2, Math.min(secs.length, Math.round(p.minutes / 2.2) + 1));
  // prefer big sections, keep article order
  const chosen = [...secs].sort((a, b) => words(b.text) - words(a.text)).slice(0, nCh).sort((a, b) => secs.indexOf(a) - secs.indexOf(b));
  const per = Math.max(60, Math.round((total - words(hook) - 30) / Math.max(1, chosen.length)));
  const quotes = [...p.quotes];
  const chapters: Chapter[] = chosen.map((s, i) => {
    const beats = extractiveBeats(s.text, per, [`${p.topic} ${s.title}`, p.topic]);
    if (quotes.length && beats.length > 1 && i % 2 === 1) beats.splice(1, 0, { narration: '', visuals: [p.topic], quote: quotes.shift() });
    return { title: s.title, beats };
  }).filter((c) => c.beats.length);
  const moodGuess = /war|crime|murder|dark|mystery|disaster|death|anarchy|horror|haunted/i.test(p.description + hook) ? 'suspense' : /space|empire|history|ancient|rise|battle/i.test(p.description + hook) ? 'epic' : 'emotional';
  return { title: main.title, hook, chapters, outro: `And that is the story of ${main.title}.`, music: moodGuess, keywords: [p.topic, ...chosen.map((c) => c.title)], writtenBy: 'sources' };
}

export const MUSIC_IDS = MUSIC.map((m) => m.id);

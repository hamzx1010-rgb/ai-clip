/**
 * Getting the source video into the page.
 *
 * Two things matter here:
 *  1. A remote URL is fetched into a Blob. That way the bytes are same-origin,
 *     so the canvas is never tainted and MediaRecorder/WebCodecs can read them.
 *  2. The Blob is dropped (URL revoked, reference cleared) as soon as the run
 *     finishes — a 20-minute 720p file must not stay in memory.
 */

export interface VideoSource {
  kind: 'file' | 'url';
  name: string;
  blob: Blob;
  url: string;
  sizeBytes: number;
  /** Set when we had to go through a CORS proxy. */
  viaProxy?: string;
}

/** Public CORS proxies, tried in order. Only used when the host refuses us. */
const PROXIES = [
  (u: string) => `https://corsproxy.io/?url=${encodeURIComponent(u)}`,
  (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
];

export function looksLikeUrl(s: string): boolean {
  return /^https?:\/\//i.test(s.trim()) || /^blob:/i.test(s.trim());
}

/** Normalise the usual "sharing" links people paste into a real media URL. */
export function normaliseMediaUrl(raw: string): string {
  const u = raw.trim();
  // GitHub blob page -> raw file
  const gh = u.match(/^https?:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/(.+)$/i);
  if (gh) return `https://raw.githubusercontent.com/${gh[1]}/${gh[2]}/${gh[3]}`;
  return u;
}

async function fetchWithTimeout(url: string, ms: number, onProgress?: (frac: number) => void) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { signal: ctrl.signal, mode: 'cors', redirect: 'follow', cache: 'no-store' });
    if (!res.ok) throw new Error(`Server said ${res.status}`);
    const type = res.headers.get('content-type') || 'video/mp4';
    const total = Number(res.headers.get('content-length') || 0);

    // Always read the body as a stream of bytes and build the Blob ourselves.
    // Two reasons:
    //   1. res.blob() is unreliable for large cross-origin video bodies on some
    //      Chrome builds (it rejects with "Failed to fetch" after the headers
    //      already arrived, while arrayBuffer()/getReader() succeed);
    //   2. streaming lets a 300 MB file show real progress and never
    //      double-buffers the whole thing.
    if (res.body && typeof res.body.getReader === 'function') {
      const reader = res.body.getReader();
      const parts: Uint8Array[] = [];
      let got = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          parts.push(value);
          got += value.byteLength;
          if (total) onProgress?.(Math.min(1, got / total));
        }
      }
      onProgress?.(1);
      if (!got) throw new Error('Empty response');
      return new Blob(parts as BlobPart[], { type });
    }

    // No readable stream: fall back to arrayBuffer (never res.blob()).
    const buf = await res.arrayBuffer();
    onProgress?.(1);
    if (!buf.byteLength) throw new Error('Empty response');
    return new Blob([buf], { type });
  } finally {
    clearTimeout(t);
  }
}

export async function loadSource(
  input: string | File,
  onProgress?: (frac: number, label: string) => void,
): Promise<VideoSource> {
  if (typeof input !== 'string') {
    const url = URL.createObjectURL(input);
    return {
      kind: 'file',
      name: input.name,
      blob: input,
      url,
      sizeBytes: input.size,
    };
  }

  const target = normaliseMediaUrl(input);
  onProgress?.(0, 'Contacting server');

  const attempts: Array<{ url: string; label: string; timeout: number }> = [
    { url: target, label: 'Downloading', timeout: 1000 * 60 * 20 },
    ...PROXIES.map((p, i) => ({
      url: p(target),
      label: `Downloading (relay ${i + 1})`,
      timeout: 1000 * 60 * 20,
    })),
  ];

  let lastErr: unknown = null;
  for (const a of attempts) {
    try {
      onProgress?.(0, a.label);
      const blob = await fetchWithTimeout(a.url, a.timeout, (f) => onProgress?.(f, a.label));
      if (!blob.size) throw new Error('Empty response');
      const url = URL.createObjectURL(blob);
      return {
        kind: 'url',
        name: fileNameFromUrl(target),
        blob,
        url,
        sizeBytes: blob.size,
        viaProxy: a.url === target ? undefined : a.url,
      };
    } catch (e) {
      lastErr = e;
    }
  }
  throw new Error(
    `Could not download that link. ${plainError(lastErr)}. ` +
      `The site may block cross-origin requests — save the video and pick the file instead.`,
  );
}

export function fileNameFromUrl(u: string): string {
  try {
    const p = new URL(u).pathname.split('/').filter(Boolean).pop();
    return p ? decodeURIComponent(p) : 'video.mp4';
  } catch {
    return 'video.mp4';
  }
}

export function plainError(e: unknown): string {
  if (!e) return 'Unknown problem';
  if (e instanceof Error) {
    if (e.name === 'AbortError') return 'It took too long';
    if (e.name === 'TypeError' && /fetch/i.test(e.message)) return 'The network refused';
    return e.message;
  }
  return String(e);
}

/** Free the bytes as soon as we are done with them. */
export function releaseSource(src: VideoSource | null) {
  if (!src) return;
  try {
    URL.revokeObjectURL(src.url);
  } catch {
    /* ignore */
  }
}

export interface SourceInfo {
  duration: number;
  width: number;
  height: number;
  hasAudio: boolean;
  codecGuess: string;
}

/** Probe a video element for duration/size. Retries because some files report 0 first. */
export async function probeVideo(url: string, timeoutMs = 20000): Promise<SourceInfo> {
  const v = document.createElement('video');
  v.preload = 'metadata';
  v.muted = true;
  v.playsInline = true;
  v.src = url;

  try {
    await new Promise<void>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('The video did not load in time')), timeoutMs);
      v.addEventListener('loadedmetadata', () => {
        clearTimeout(t);
        resolve();
      });
      v.addEventListener('error', () => {
        clearTimeout(t);
        reject(new Error(describeMediaError(v.error)));
      });
    });

    let duration = Number.isFinite(v.duration) ? v.duration : 0;
    // Some MP4s report Infinity/0 until we nudge them.
    if (!Number.isFinite(duration) || duration <= 0 || duration === Infinity) {
      duration = await nudgeDuration(v);
    }

    return {
      duration,
      width: v.videoWidth || 0,
      height: v.videoHeight || 0,
      hasAudio: !v.muted,
      codecGuess: guessCodec(),
    };
  } finally {
    v.removeAttribute('src');
    v.load();
  }

  function guessCodec() {
    const c = v.canPlayType('video/mp4; codecs="avc1.42E01E, mp4a.40.2"');
    return c ? `H.264 (${c})` : 'unknown';
  }
}

function describeMediaError(err: MediaError | null): string {
  switch (err?.code) {
    case MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED:
      return 'This browser cannot play that video format';
    case MediaError.MEDIA_ERR_NETWORK:
      return 'The network dropped while loading';
    case MediaError.MEDIA_ERR_DECODE:
      return 'The video could not be decoded';
    default:
      return 'The video could not be loaded';
  }
}

async function nudgeDuration(v: HTMLVideoElement): Promise<number> {
  return new Promise((resolve) => {
    const done = (d: number) => {
      clearTimeout(t);
      v.removeEventListener('timeupdate', onTime);
      resolve(Number.isFinite(d) && d > 0 ? d : 0);
    };
    const onTime = () => {
      if (Number.isFinite(v.duration) && v.duration > 0) done(v.duration);
    };
    const t = setTimeout(() => done(v.duration), 4000);
    v.addEventListener('timeupdate', onTime);
    try {
      v.currentTime = 1e7; // classic trick: forces the demuxer to read the index
    } catch {
      /* ignore */
    }
  });
}

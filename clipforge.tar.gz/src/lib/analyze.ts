/**
 * Per-clip analysis. Every clip is judged on its own:
 *  - layout: face crop only if THIS clip really has a person on camera
 *  - cut points: snapped into real pauses
 *  - title + hook: its own
 *  - score: from this clip's own motion, speech and cut quality
 */

import {
  buildAudioProfile,
  clamp,
  loudnessIn,
  nearestPause,
  speechRatioIn,
  type AudioProfile,
} from './audio';
import { detectFacesIn } from './faces';
import { grabGray, grayDiff, readyVideo, sampleRange } from './frames';
import { makeTitleAndHook } from './title';
import type { ClipAnalysis, ExportSettings, LayoutMode } from './types';

export interface Segment {
  index: number;
  start: number;
  end: number;
}

export interface AnalyzeProgress {
  stage: 'audio' | 'survey' | 'faces' | 'scoring' | 'done';
  clipIndex: number;
  total: number;
  frac: number;
  message: string;
}

export interface AnalyzeResult {
  segments: Segment[];
  analyses: Map<number, ClipAnalysis>;
  audio: AudioProfile;
  sourceMotion: number;
  timeline: Float32Array; // motion per second of source
  faceTimeline: Uint8Array; // 1 where a face was seen
}

const SURVEY_STEP = 0.5; // seconds

/** Find candidate segments, then measure and score each one separately. */
export async function analyzeSource(
  srcUrl: string,
  duration: number,
  settings: ExportSettings,
  sourceName: string,
  keywords: string[],
  blob: Blob,
  onProgress: (p: AnalyzeProgress) => void,
  signal: AbortSignal,
): Promise<AnalyzeResult> {
  /* ---------- 1. audio envelope (pauses + speech) ---------- */
  onProgress({ stage: 'audio', clipIndex: -1, total: 0, frac: 0.02, message: 'Listening for pauses' });
  const audio = await buildAudioProfile(blob);

  /* ---------- 2. cheap survey of the whole video ---------- */
  onProgress({ stage: 'survey', clipIndex: -1, total: 0, frac: 0.05, message: 'Scanning the video' });
  const v = await readyVideo(srcUrl);
  const { timeline, faceTimeline, sourceMotion } = await survey(v, duration, signal, (frac, msg) =>
    onProgress({ stage: 'survey', clipIndex: -1, total: 0, frac: 0.05 + frac * 0.45, message: msg }),
  );

  /* ---------- 3. pick candidate cuts ---------- */
  const raw = pickCandidates(timeline, audio, duration, settings);
  const segments: Segment[] = [];
  for (let i = 0; i < raw.length; i++) {
    const r = raw[i];
    // Snap both ends into the nearest real pause.
    const s = nearestPause(audio, r.start, { from: 0, to: duration, minPause: 0.26, window: 2.2 });
    const e = nearestPause(audio, r.end, { from: 0, to: duration, minPause: 0.26, window: 2.2 });
    const start = clamp(s.time, 0, Math.max(0, duration - settings.minSeconds));
    const end = clamp(e.time, start + settings.minSeconds, duration);
    if (end - start < settings.minSeconds) continue;
    if (segments.some((x) => overlap(x.start, x.end, start, end) > 0.5)) continue;
    segments.push({ index: segments.length, start, end });
    void i;
  }

  /* ---------- 4. analyse each clip on its own ---------- */
  const analyses = new Map<number, ClipAnalysis>();
  const faceCanvas = document.createElement('canvas');

  for (let i = 0; i < segments.length; i++) {
    if (signal.aborted) break;
    const seg = segments[i];
    onProgress({
      stage: 'faces',
      clipIndex: i,
      total: segments.length,
      frac: 0.5 + (i / segments.length) * 0.5,
      message: `Checking clip ${i + 1} of ${segments.length}`,
    });

    // Motion inside this exact range.
    const sampled = await sampleRange(v, seg.start, seg.end, { samples: 12, size: 48, signal });

    // Faces inside this exact range.
    let withFace = 0;
    let checked = 0;
    const faceHits: ClipAnalysis['faces'] = [];
    const faceSamples = 6;
    for (let k = 0; k < faceSamples; k++) {
      if (signal.aborted) break;
      const t = seg.start + ((seg.end - seg.start) * (k + 0.5)) / faceSamples;
      try {
        await seekAndSettle(v, t);
      } catch {
        continue;
      }
      checked++;
      const f = await detectFacesIn(v, faceCanvas);
      if (f.length) {
        withFace++;
        faceHits.push(...f.slice(0, 2));
      }
      await yieldNow();
    }

    const faceRatio = checked ? withFace / checked : 0;
    const hasFace = checked >= 3 && faceRatio >= 0.5 && faceHits.length >= 2;
    let faceCenter: { x: number; y: number } | null = null;
    if (hasFace) {
      let sx = 0;
      let sy = 0;
      for (const h of faceHits) {
        sx += h.x + h.w / 2;
        sy += h.y + h.h * 0.42;
      }
      faceCenter = { x: sx / faceHits.length, y: sy / faceHits.length };
    }

    const speech = speechRatioIn(audio, seg.start, seg.end);
    const loud = loudnessIn(audio, seg.start, seg.end);
    const sPause = nearestPause(audio, seg.start, { from: seg.start - 1.5, to: seg.start + 1.5, minPause: 0.22 });
    const ePause = nearestPause(audio, seg.end, { from: seg.end - 1.5, to: seg.end + 1.5, minPause: 0.22 });

    const dur = seg.end - seg.start;

    const { score, notes } = scoreClip({
      duration: dur,
      motion: sampled.motion,
      speechRatio: speech,
      loudness: loud,
      startsInPause: sPause.found && Math.abs(sPause.time - seg.start) < 1.2,
      endsInPause: ePause.found && Math.abs(ePause.time - seg.end) < 1.2,
      hasFace,
      faceRatio,
      framesSampled: sampled.frames,
      settings,
    });

    const th = makeTitleAndHook({
      index: seg.index,
      start: seg.start,
      end: seg.end,
      hasFace,
      motion: sampled.motion,
      speechRatio: speech,
      keywords,
      sourceName,
    });

    analyses.set(seg.index, {
      faces: faceHits.slice(0, 12),
      faceRatio,
      hasFace,
      faceCenter,
      motion: sampled.motion,
      speechRatio: speech,
      startsInPause: sPause.found,
      endsInPause: ePause.found,
      score,
      title: th.title,
      hook: th.hook,
      keywords: th.keywords,
      scoreNotes: notes,
    });

    await yieldNow();
  }

  onProgress({ stage: 'done', clipIndex: segments.length, total: segments.length, frac: 1, message: 'Analysis done' });
  v.pause();
  v.removeAttribute('src');
  v.load();
  v.remove();

  return { segments, analyses, audio, sourceMotion, timeline, faceTimeline };
}

/* ------------------------------------------------------------------ */

async function survey(
  v: HTMLVideoElement,
  duration: number,
  signal: AbortSignal,
  onProgress: (frac: number, msg: string) => void,
): Promise<{ timeline: Float32Array; faceTimeline: Uint8Array; sourceMotion: number }> {
  const steps = Math.max(8, Math.min(240, Math.floor(duration / SURVEY_STEP)));
  const timeline = new Float32Array(steps);
  const faceTimeline = new Uint8Array(steps);
  const canvas = document.createElement('canvas');
  const faceCanvas = document.createElement('canvas');
  let prev: Uint8ClampedArray | null = null;
  let sum = 0;

  for (let i = 0; i < steps; i++) {
    if (signal.aborted) break;
    const t = (duration * (i + 0.5)) / steps;
    const g = await grabGray(v, t, 40, canvas);
    if (g) {
      const d = prev ? grayDiff(prev, g.gray) : 0;
      timeline[i] = d;
      sum += d;
      prev = g.gray;
    }
    // Face check on every 4th sample: enough to know where people are,
    // cheap enough for a 20-minute video on a phone.
    if (i % 4 === 0) {
      const f = await detectFacesIn(v, faceCanvas);
      if (f.length) {
        faceTimeline[i] = 1;
        if (i > 0) faceTimeline[i - 1] = 1;
        if (i + 1 < steps) faceTimeline[i + 1] = 1;
      }
    }
    if (i % 6 === 5) {
      onProgress(i / steps, `Scanning ${Math.round((i / steps) * 100)}%`);
      await yieldNow();
    }
  }
  onProgress(1, 'Scan complete');
  return { timeline, faceTimeline, sourceMotion: steps ? sum / steps : 0 };
}

/**
 * Turn a motion timeline into non-overlapping candidate segments that
 * start and end on quiet ground.
 */
function pickCandidates(
  timeline: Float32Array,
  audio: AudioProfile,
  duration: number,
  settings: ExportSettings,
): Array<{ start: number; end: number }> {
  const steps = timeline.length;
  if (!steps || duration <= settings.minSeconds) return [];
  const secPerStep = duration / steps;

  // Sliding-window mean motion, window ~= target clip length.
  const win = Math.max(3, Math.round(settings.targetSeconds / secPerStep));
  const score = new Float32Array(steps);
  let run = 0;
  for (let i = 0; i < steps; i++) {
    run += timeline[i];
    if (i >= win) run -= timeline[i - win];
    const n = Math.min(win, i + 1);
    score[i] = run / n;
  }

  // Normalise
  let maxS = 0;
  for (let i = 0; i < steps; i++) maxS = Math.max(maxS, score[i]);
  if (maxS > 0) for (let i = 0; i < steps; i++) score[i] /= maxS;

  const out: Array<{ start: number; end: number }> = [];
  const minGap = settings.minSeconds;
  let guard = 0;

  while (guard++ < 200) {
    let bestI = -1;
    let bestV = -1;
    for (let i = 0; i < steps; i++) {
      const t = i * secPerStep;
      if (out.some((o) => t > o.start - minGap && t < o.end + minGap)) continue;
      if (score[i] > bestV) {
        bestV = score[i];
        bestI = i;
      }
    }
    if (bestI < 0 || bestV <= 0.08) break;

    const centre = bestI * secPerStep + secPerStep / 2;
    let start = clamp(centre - settings.targetSeconds / 2, 0, duration - settings.minSeconds);
    let end = clamp(start + settings.targetSeconds, start + settings.minSeconds, duration);

    // Grow/shrink to land on quiet audio so cuts feel natural.
    const s = nearestPause(audio, start, { from: start - 3, to: start + 3, minPause: 0.26 });
    const e = nearestPause(audio, end, { from: end - 3, to: end + 3, minPause: 0.26 });
    if (s.found) start = clamp(s.time, 0, duration - settings.minSeconds);
    if (e.found) end = clamp(e.time, start + settings.minSeconds, duration);
    end = clamp(end, start + settings.minSeconds, Math.min(duration, start + settings.maxSeconds));

    if (end - start < settings.minSeconds) break;
    if (out.some((o) => overlap(o.start, o.end, start, end) > 0.25)) {
      score[bestI] = 0; // don't pick the same place again
      continue;
    }
    out.push({ start, end });
    for (let i = 0; i < steps; i++) {
      const t = i * secPerStep;
      if (t > start - minGap * 0.8 && t < end + minGap * 0.8) score[i] = 0;
    }
    if (out.length >= 40) break;
  }

  return out.sort((a, b) => a.start - b.start);
}

function overlap(a0: number, a1: number, b0: number, b1: number): number {
  const lo = Math.max(a0, b0);
  const hi = Math.min(a1, b1);
  if (hi <= lo) return 0;
  return (hi - lo) / Math.min(a1 - a0, b1 - b0);
}

function scoreClip(x: {
  duration: number;
  motion: number;
  speechRatio: number;
  loudness: number;
  startsInPause: boolean;
  endsInPause: boolean;
  hasFace: boolean;
  faceRatio: number;
  framesSampled: number;
  settings: ExportSettings;
}): { score: number; notes: string[] } {
  const notes: string[] = [];
  let s = 0;

  // Length: sweet spot near the target.
  const lenScore =
    1 - Math.min(1, Math.abs(x.duration - x.settings.targetSeconds) / (x.settings.maxSeconds || 45));
  s += lenScore * 22;
  notes.push(`Length ${x.duration.toFixed(0)}s`);

  // Motion: a clip with no movement looks broken.
  const m = Math.min(1, x.motion / 6);
  s += m * 26;
  if (x.motion < 0.8) notes.push('Very little movement');
  else if (x.motion > 5) notes.push('Lots of movement');

  // Speech: Shorts with talking do better than dead air.
  s += Math.min(1, x.speechRatio / 0.6) * 22;
  if (x.speechRatio < 0.15) notes.push('Almost no speech');
  if (x.loudness < 0.004) notes.push('Very quiet audio');

  // Clean cuts.
  if (x.startsInPause) s += 9;
  else notes.push('Start may cut into a word');
  if (x.endsInPause) s += 9;
  else notes.push('End may cut into a word');

  // A person on camera.
  if (x.hasFace) {
    s += 12 * Math.min(1, x.faceRatio * x.settings.faceBoost);
    notes.push(`Person on camera ${Math.round(x.faceRatio * 100)}% of the time`);
  } else {
    notes.push('No person on camera — full frame');
  }

  // Never pretend we saw enough frames.
  if (x.framesSampled < 6) {
    s -= 18;
    notes.push('Only a few frames could be read');
  }

  return { score: Math.max(0, Math.min(100, Math.round(s))), notes };
}

async function seekAndSettle(v: HTMLVideoElement, t: number): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => {
      v.removeEventListener('seeked', onSeeked);
      reject(new Error('seek timeout'));
    }, 6000);
    function onSeeked() {
      clearTimeout(timer);
      v.removeEventListener('seeked', onSeeked);
      resolve();
    }
    v.addEventListener('seeked', onSeeked, { once: true });
    try {
      v.currentTime = Math.max(0, t);
    } catch (e) {
      clearTimeout(timer);
      reject(e instanceof Error ? e : new Error('seek failed'));
    }
  });
}

export function yieldNow(): Promise<void> {
  return new Promise((r) => setTimeout(r, 0));
}

/** Crop rectangle for a layout mode, in source pixel space. */
export function cropRect(
  srcW: number,
  srcH: number,
  outW: number,
  outH: number,
  layout: LayoutMode,
  faceCenter: { x: number; y: number } | null,
): { sx: number; sy: number; sw: number; sh: number } {
  const targetAR = outW / outH;
  const srcAR = srcW / srcH;
  let sw: number;
  let sh: number;
  if (layout === 'face' && srcAR > targetAR) {
    // source is wider than 9:16 -> crop width, keep height, follow the face
    sh = srcH;
    sw = srcH * targetAR;
  } else if (layout === 'face' && srcAR <= targetAR) {
    sw = srcW;
    sh = srcW / targetAR;
  } else {
    // full frame: letterbox-free cover crop of the whole picture
    if (srcAR > targetAR) {
      sh = srcH;
      sw = srcH * targetAR;
    } else {
      sw = srcW;
      sh = srcW / targetAR;
    }
  }
  let sx = (srcW - sw) / 2;
  let sy = (srcH - sh) / 2;
  if (layout === 'face' && faceCenter) {
    sx = clamp(faceCenter.x * srcW - sw / 2, 0, Math.max(0, srcW - sw));
    sy = clamp(faceCenter.y * srcH - sh / 2, 0, Math.max(0, srcH - sh));
  }
  return { sx, sy, sw, sh };
}

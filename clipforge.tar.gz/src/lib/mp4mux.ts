/**
 * A small, correct progressive-MP4 writer for H.264 video + AAC audio.
 *
 * Why hand-written instead of mp4box's writer:
 * mp4box.js 0.5.3's ISOFile.addSample() ALWAYS creates a single-sample
 * moof+mdat pair and never fills stts/stsc/stco/stsz. The result is a file
 * that ffmpeg rejects ("could not find corresponding trex", empty sample
 * tables) and a phone will not play. Its reader is excellent, so ClipForge
 * still uses mp4box to DEMUX — it just does not use it to mux.
 *
 * What this writes:
 *   ftyp
 *   mdat                      (all samples, interleaved roughly every 0.5 s so
 *                              the file plays while it downloads)
 *   moov
 *     mvhd
 *     trak (video) tkhd mdia(mdhd hdlr minf(vmhd dinf stbl(stsd(avc1+avcC)
 *                                       stts stsc stsz stco stss)))
 *     trak (audio) tkhd mdia(mdhd hdlr minf(smhd dinf stbl(stsd(mp4a+esds)
 *                                       stts stsc stsz stco)))
 */

export interface MuxSample {
  data: Uint8Array;
  /** Presentation time, seconds from the start of the clip. */
  time: number;
  /** Duration in seconds. */
  duration: number;
  /** Video only: is this a key frame? */
  key?: boolean;
}

export interface MuxerConfig {
  width: number;
  height: number;
  videoTimescale: number;
  /** Raw AVCDecoderConfigurationRecord bytes (no box header). */
  avcC: Uint8Array;
  audioSampleRate: number;
  audioChannels: number;
  /** Seconds per AAC frame, normally 1024/sampleRate. */
  audioFrameDuration: number;
}

interface Track {
  timescale: number;
  samples: MuxSample[];
  duration: number;
}

const BOX = {
  be32: (n: number) => [(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff],
  be16: (n: number) => [(n >>> 8) & 0xff, n & 0xff],
};

function leaf(type: string, payload: number[]): number[] {
  const size = 8 + payload.length;
  return [...BOX.be32(size), ...ascii(type), ...payload];
}

function container(type: string, children: number[][]): number[] {
  const payload = children.flat();
  return leaf(type, payload);
}

function ascii(s: string): number[] {
  const out: number[] = [];
  for (let i = 0; i < s.length; i++) out.push(s.charCodeAt(i) & 0xff);
  return out;
}

function u32(n: number): number[] {
  return BOX.be32(n >>> 0);
}
function u16(n: number): number[] {
  return BOX.be16(n & 0xffff);
}
/** Sample entry for video: avc1 + avcC. */
function avc1Entry(cfg: MuxerConfig): number[] {
  const payload = [
    0, 0, 0, 0, 0, 0, // reserved (6)
    ...u16(1), // data_reference_index
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // pre_defined + reserved (16)
    ...u16(cfg.width),
    ...u16(cfg.height),
    ...u32(0x00480000), // horizresolution 72 dpi
    ...u32(0x00480000), // vertresolution
    ...u32(0), // reserved
    ...u16(1), // frame_count
    // compressorname: 32 bytes, first byte is the length
    0, ...new Array(31).fill(0),
    ...u16(0x0018), // depth
    ...u16(0xffff), // pre_defined = -1
    ...leaf('avcC', [...cfg.avcC]),
  ];
  return leaf('avc1', payload);
}

/**
 * Build an ES_Descriptor for AAC-LC from the sample rate and channel count.
 * This is the audio equivalent of avcC: without it the track has no decoder
 * configuration and nothing will play it.
 */
export function buildAudioSpecificConfig(sampleRate: number, channels: number): Uint8Array {
  const RATES = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];
  let idx = RATES.indexOf(sampleRate);
  let explicitRate = false;
  if (idx < 0) {
    idx = 15; // escape: the real rate follows in 24 bits
    explicitRate = true;
  }
  const ch = Math.max(1, Math.min(7, channels));
  // 5 bits AOT(2) | 4 bits freq index | 4 bits channels | 3 bits padding
  const b0 = (2 << 3) | (idx >> 1);
  const b1 = ((idx & 1) << 7) | (ch << 3);
  const out = [b0, b1];
  if (explicitRate) {
    out.push((sampleRate >> 16) & 0xff, (sampleRate >> 8) & 0xff, sampleRate & 0xff);
  }
  return new Uint8Array(out);
}

function descriptor(tag: number, body: number[]): number[] {
  // MPEG-4 descriptor length encoding: up to 3 continuation bytes.
  const len = body.length;
  const lenBytes: number[] = [];
  if (len < 0x80) {
    lenBytes.push(len);
  } else {
    const parts = [len & 0x7f, (len >> 7) & 0x7f, (len >> 14) & 0x7f];
    let n = parts.length - 1;
    while (n > 0 && parts[n] === 0) n--;
    for (let i = n; i >= 1; i--) lenBytes.push(parts[i] | 0x80);
    lenBytes.push(parts[0]);
  }
  return [tag, ...lenBytes, ...body];
}

export function buildEsds(sampleRate: number, channels: number, bitrate = 128000): number[] {
  const asc = [...buildAudioSpecificConfig(sampleRate, channels)];
  const decSpecific = descriptor(0x05, asc);
  const decConfig = descriptor(
    0x04,
    [
      0x40, // objectTypeIndication: Audio ISO/IEC 14496-3
      0x15, // streamType 5 (audio) << 2 | upStream 0 | reserved 1
      0x00, 0x00, 0x00, // bufferSizeDB (24 bits)
      ...u32(bitrate), // maxBitrate
      ...u32(bitrate), // avgBitrate
      ...decSpecific,
    ],
  );
  const esDesc = descriptor(
    0x03,
    [...u16(1), 0x00 /* streamDependence/URL/OCR flags */, ...decConfig, ...descriptor(0x06, [0x02])],
  );
  // ES_Descriptor box: full box (version + flags) then the descriptor
  return leaf('esds', [0, 0, 0, 0, ...esDesc]);
}

/** Sample entry for audio: mp4a + esds. */
function mp4aEntry(cfg: MuxerConfig): number[] {
  const payload = [
    0, 0, 0, 0, 0, 0, // reserved (6)
    ...u16(1), // data_reference_index
    0, 0, 0, 0, 0, 0, 0, 0, // reserved (8) - NOT 4: getting this wrong shifts
    // channelcount and samplerate by 8 bytes and ffmpeg reports "aac 0ch"
    ...u16(Math.max(1, Math.min(8, cfg.audioChannels || 2))), // channelcount
    ...u16(16), // samplesize
    ...u16(0), // pre_defined
    ...u16(0), // reserved
    ...u32(cfg.audioSampleRate << 16), // samplerate as 16.16 fixed point
    ...buildEsds(cfg.audioSampleRate, cfg.audioChannels),
  ];
  return leaf('mp4a', payload);
}

/** stts: run-length encoded (count, delta) pairs. */
function sttsBox(deltas: number[]): number[] {
  const runs: Array<{ delta: number; count: number }> = [];
  for (const d of deltas) {
    const last = runs[runs.length - 1];
    if (last && last.delta === d) last.count++;
    else runs.push({ delta: d, count: 1 });
  }
  const body: number[] = [...u32(runs.length)];
  for (const r of runs) body.push(...u32(r.count), ...u32(r.delta));
  return leaf('stts', [0, 0, 0, 0, ...body]);
}

/** stsz: per-sample sizes. */
function stszBox(sizes: number[]): number[] {
  const body: number[] = [...u32(0), ...u32(sizes.length)];
  for (const s of sizes) body.push(...u32(s));
  return leaf('stsz', [0, 0, 0, 0, ...body]);
}

/** stco: chunk byte offsets. */
function stcoBox(offsets: number[]): number[] {
  const body: number[] = [...u32(offsets.length)];
  for (const o of offsets) body.push(...u32(o));
  return leaf('stco', [0, 0, 0, 0, ...body]);
}

/** stss: sync (key) sample numbers, 1-based. */
function stssBox(keys: number[]): number[] {
  const body: number[] = [...u32(keys.length)];
  for (const k of keys) body.push(...u32(k));
  return leaf('stss', [0, 0, 0, 0, ...body]);
}

export class Mp4Mux {
  private cfg: MuxerConfig;
  private video: Track;
  private audio: Track | null;

  constructor(cfg: MuxerConfig) {
    this.cfg = cfg;
    this.video = { timescale: cfg.videoTimescale, samples: [], duration: 0 };
    this.audio = cfg.audioSampleRate > 0
      ? { timescale: cfg.audioSampleRate, samples: [], duration: 0 }
      : null;
  }

  /**
   * Replace the decoder configuration written into the video sample entry.
   * Called as soon as the encoder reports its own avcC, which is the only one
   * that matches the bitstream it produces.
   */
  setAvcC(avcC: Uint8Array) {
    this.cfg = { ...this.cfg, avcC };
  }

  get videoFrames(): number {
    return this.video.samples.length;
  }

  get audioFrames(): number {
    return this.audio?.samples.length ?? 0;
  }

  get videoSeconds(): number {
    return this.video.duration;
  }

  get audioSeconds(): number {
    return this.audio?.duration ?? 0;
  }

  addVideoFrame(s: MuxSample) {
    this.video.samples.push(s);
    this.video.duration = Math.max(this.video.duration, s.time + s.duration);
  }

  addAudioFrame(s: MuxSample) {
    if (!this.audio) return;
    this.audio.samples.push(s);
    this.audio.duration = Math.max(this.audio.duration, s.time + s.duration);
  }

  /**
   * Raw AAC frames straight from the source, with timestamps in the source
   * audio timescale. Re-based so the clip starts at zero.
   */
  addRawAacFrames(frames: Array<{ data: Uint8Array; cts: number; duration: number }>, timescale: number) {
    if (!this.audio || !frames.length) return;
    const base = frames[0].cts;
    for (const f of frames) {
      const time = (f.cts - base) / timescale;
      const duration = (f.duration || 1024) / timescale;
      this.audio.samples.push({ data: f.data, time, duration });
      this.audio.duration = Math.max(this.audio.duration, time + duration);
    }
  }

  build(): Blob {
    const v = this.video;
    if (!v.samples.length) throw new Error('Nothing to write: no video frames');

    // Sort each track by presentation time; the encoder can hand frames back
    // slightly out of order and an unsorted table is an unplayable file.
    v.samples.sort((a, b) => a.time - b.time);
    const a = this.audio;
    if (a) a.samples.sort((x, y) => x.time - y.time);

    const movieDuration = Math.max(v.duration, a?.duration ?? 0);
    const movieTimescale = 600;

    /* ---------- interleave: lay out chunks alternating every ~0.5s ---------- */
    interface Chunk {
      track: 'v' | 'a';
      indices: number[];
    }
    const chunks: Chunk[] = [];
    const INTERLEAVE = 0.5;
    let vi = 0;
    let ai = 0;
    let clock = 0;
    const totalV = v.samples.length;
    const totalA = a?.samples.length ?? 0;
    while (vi < totalV || ai < totalA) {
      const wantV = vi < totalV && (a === null || v.samples[vi].time <= clock + INTERLEAVE || ai >= totalA);
      if (wantV) {
        const idxs: number[] = [];
        while (vi < totalV && (a === null || v.samples[vi].time <= clock + INTERLEAVE || ai >= totalA)) {
          idxs.push(vi++);
        }
        if (idxs.length) chunks.push({ track: 'v', indices: idxs });
      } else if (ai < totalA && a) {
        const idxs: number[] = [];
        while (ai < totalA && a.samples[ai].time <= clock + INTERLEAVE) idxs.push(ai++);
        if (idxs.length) chunks.push({ track: 'a', indices: idxs });
      }
      clock += INTERLEAVE;
      if (chunks.length > 200000) break; // safety
    }

    /* ---------- ftyp + mdat header ---------- */
    const ftyp = leaf('ftyp', [
      ...ascii('isom'),
      ...u32(0x200),
      ...ascii('isom'), ...ascii('iso2'), ...ascii('avc1'), ...ascii('mp41'),
    ]);
    const mdatHeaderSize = 8;

    // First pass: compute byte offsets for every chunk.
    let payloadSize = 0;
    const chunkOffsets: number[] = [];
    for (const c of chunks) {
      chunkOffsets.push(ftyp.length + mdatHeaderSize + payloadSize);
      for (const i of c.indices) {
        payloadSize += (c.track === 'v' ? v.samples[i] : a!.samples[i]).data.length;
      }
    }

    /* ---------- per-track sample tables ---------- */
    const buildTrackTables = (track: Track, isVideo: boolean, trackIdHint: number) => {
      void trackIdHint;
      const sizes = track.samples.map((s) => s.data.length);
      const deltas = track.samples.map((s) => Math.max(1, Math.round(s.duration * track.timescale)));
      // one chunk entry per chunk that belongs to this track
      const entries: Array<{ firstChunk: number; samplesPerChunk: number; desc: number }> = [];
      let chunkNo = 0;
      for (let ci = 0; ci < chunks.length; ci++) {
        const c = chunks[ci];
        if ((c.track === 'v') !== isVideo) continue;
        chunkNo++;
        const last = entries[entries.length - 1];
        if (last && last.samplesPerChunk === c.indices.length) continue;
        entries.push({ firstChunk: chunkNo, samplesPerChunk: c.indices.length, desc: 1 });
      }
      const stscBody: number[] = [...u32(entries.length)];
      for (const e of entries) stscBody.push(...u32(e.firstChunk), ...u32(e.samplesPerChunk), ...u32(e.desc));

      const myChunkOffsets: number[] = [];
      let cn = 0;
      for (let ci = 0; ci < chunks.length; ci++) {
        const c = chunks[ci];
        if ((c.track === 'v') !== isVideo) continue;
        cn++;
        myChunkOffsets.push(chunkOffsets[ci]);
      }

      const tables = [
        sttsBox(deltas),
        leaf('stsc', [0, 0, 0, 0, ...stscBody]),
        stszBox(sizes),
        stcoBox(myChunkOffsets),
      ];
      if (isVideo) {
        const keys: number[] = [];
        track.samples.forEach((s, i) => {
          if (s.key) keys.push(i + 1);
        });
        if (keys.length && keys.length < track.samples.length) tables.push(stssBox(keys));
      }
      return tables;
    };

    const videoTables = buildTrackTables(v, true, 1);
    const audioTables = a ? buildTrackTables(a, false, 2) : [];

    /* ---------- moov ---------- */
    const mvhd = leaf('mvhd', [
      0, 0, 0, 0, // version + flags
      ...u32(0), // creation_time
      ...u32(0), // modification_time
      ...u32(movieTimescale),
      ...u32(Math.round(movieDuration * movieTimescale)),
      ...u32(0x00010000), // rate 1.0
      ...u16(0x0100), // volume 1.0
      ...u16(0), // reserved
      ...u32(0), ...u32(0), // reserved
      // matrix (identity)
      ...u32(0x00010000), ...u32(0), ...u32(0),
      ...u32(0), ...u32(0x00010000), ...u32(0),
      ...u32(0), ...u32(0), ...u32(0x40000000),
      ...u32(0), ...u32(0), ...u32(0), ...u32(0), ...u32(0), ...u32(0), // pre_defined
      ...u32(3), // next_track_ID
    ]);

    const videoTrak = container('trak', [
      leaf('tkhd', [
        0, 0, 0, 0x07, // version + flags (enabled|in_movie|in_preview)
        ...u32(0), ...u32(0), // creation, modification
        ...u32(1), // track_ID
        ...u32(0), // reserved
        ...u32(Math.round(movieDuration * movieTimescale)),
        ...u32(0), ...u32(0), // reserved
        ...u16(0), // layer
        ...u16(0), // alternate_group
        ...u16(0), // volume (0 for video)
        ...u16(0), // reserved
        ...u32(0x00010000), ...u32(0), ...u32(0),
        ...u32(0), ...u32(0x00010000), ...u32(0),
        ...u32(0), ...u32(0), ...u32(0x40000000),
        ...u32(this.cfg.width << 16),
        ...u32(this.cfg.height << 16),
      ]),
      container('mdia', [
        leaf('mdhd', [
          0, 0, 0, 0,
          ...u32(0), ...u32(0),
          ...u32(v.timescale),
          ...u32(Math.round(v.duration * v.timescale)),
          ...u16(0x55c4), // language "und"
          ...u16(0),
        ]),
        leaf('hdlr', [
          0, 0, 0, 0,
          ...u32(0), // pre_defined
          ...ascii('vide'),
          ...u32(0), ...u32(0), ...u32(0),
          ...ascii('ClipForge video'), 0,
        ]),
        container('minf', [
          leaf('vmhd', [0, 0, 0, 0x01, ...u16(0), ...u16(0), ...u16(0), ...u16(0)]),
          container('dinf', [leaf('dref', [0, 0, 0, 0, ...u32(1), ...leaf('url ', [0, 0, 0, 0x01])])]),
          container('stbl', [
            leaf('stsd', [0, 0, 0, 0, ...u32(1), ...avc1Entry(this.cfg)]),
            ...videoTables,
          ]),
        ]),
      ]),
    ]);

    const traks = [videoTrak];
    if (a && this.audio) {
      const audioTrak = container('trak', [
        leaf('tkhd', [
          0, 0, 0, 0x07,
          ...u32(0), ...u32(0),
          ...u32(2),
          ...u32(0),
          ...u32(Math.round(movieDuration * movieTimescale)),
          ...u32(0), ...u32(0),
          ...u16(0), ...u16(0),
          ...u16(0x0100), // volume 1.0 for audio
          ...u16(0),
          ...u32(0x00010000), ...u32(0), ...u32(0),
          ...u32(0), ...u32(0x00010000), ...u32(0),
          ...u32(0), ...u32(0), ...u32(0x40000000),
          ...u32(0), ...u32(0),
        ]),
        container('mdia', [
          leaf('mdhd', [
            0, 0, 0, 0,
            ...u32(0), ...u32(0),
            ...u32(a.timescale),
            ...u32(Math.round(a.duration * a.timescale)),
            ...u16(0x55c4),
            ...u16(0),
          ]),
          leaf('hdlr', [
            0, 0, 0, 0,
            ...u32(0),
            ...ascii('soun'),
            ...u32(0), ...u32(0), ...u32(0),
            ...ascii('ClipForge audio'), 0,
          ]),
          container('minf', [
            leaf('smhd', [0, 0, 0, 0, ...u16(0), ...u16(0)]),
            container('dinf', [leaf('dref', [0, 0, 0, 0, ...u32(1), ...leaf('url ', [0, 0, 0, 0x01])])]),
            container('stbl', [
              leaf('stsd', [0, 0, 0, 0, ...u32(1), ...mp4aEntry(this.cfg)]),
              ...audioTables,
            ]),
          ]),
        ]),
      ]);
      traks.push(audioTrak);
    }

    const moov = container('moov', [mvhd, ...traks]);

    /* ---------- assemble ---------- */
    const parts: BlobPart[] = [];
    const header = new Uint8Array([...ftyp, ...u32(payloadSize + mdatHeaderSize), ...ascii('mdat')]);
    parts.push(header);
    for (const c of chunks) {
      for (const i of c.indices) {
        parts.push((c.track === 'v' ? v.samples[i] : a!.samples[i]).data);
      }
    }
    parts.push(new Uint8Array(moov));

    return new Blob(parts as BlobPart[], { type: 'video/mp4' });
  }
}

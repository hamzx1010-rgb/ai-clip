/**
 * The export orchestrator.
 *
 * Contract: ClipForge NEVER hands over a broken file silently.
 *   1. export with the best engine for this browser;
 *   2. read the finished file back and verify it (length, motion all the way to
 *      the end, audio present, video length == audio length, frame count);
 *   3. if it fails, rebuild the clip automatically with the other engine and
 *      verify again;
 *   4. only if every attempt fails does the clip get an error — in plain words,
 *      next to that clip, without stopping the others.
 */

import { exportWebcodecs, canDemux, canEncodeH264, webcodecsSupported } from './export-webcodecs';
import { exportRealtime, pickRecorderMime, recorderSupported } from './export-realtime';
import { verifyExport, verificationSummary } from './verify';
import type { ExportAttempt, ExportJob, ExportResult } from './export-types';
import type { Verification } from './types';

export interface PipelineOptions {
  job: ExportJob;
  /** True when the source has an audio track. */
  sourceHasAudio: boolean;
  /** Rebuild automatically when verification fails. */
  autoRebuild: boolean;
  /** Force real-time capture even when WebCodecs is available. */
  forceRealtime?: boolean;
  maxAttempts?: number;
  onAttempt?: (n: number, engine: string, message: string) => void;
}

export interface PipelineResult {
  result: ExportResult;
  verification: Verification;
  attempts: ExportAttempt[];
  /** Which engine produced the file we are handing over. */
  engine: ExportResult['engine'];
}

export function engineSupport(): {
  webcodecs: boolean;
  h264Encode: boolean | null;
  recorder: boolean;
  recorderMime: string;
} {
  return {
    webcodecs: webcodecsSupported(),
    h264Encode: null, // filled asynchronously by callers that need it
    recorder: recorderSupported(),
    recorderMime: recorderSupported() ? pickRecorderMime() : '',
  };
}

/** Decide the order of engines for this browser + job. */
export async function planEngines(
  job: ExportJob,
  forceRealtime: boolean,
): Promise<Array<'fast' | 'realtime'>> {
  const order: Array<'fast' | 'realtime'> = [];
  const canFast =
    !forceRealtime &&
    job.mode !== 'realtime' &&
    webcodecsSupported() &&
    (await canDemux(job.srcBlob)) &&
    (await canEncodeH264());
  const canRealtime = recorderSupported() && !!pickRecorderMime();

  if (canFast) order.push('fast');
  if (canRealtime) order.push('realtime');
  if (job.mode === 'realtime' && canRealtime) {
    // Forced real-time: put it first, keep fast as the repair path.
    return ['realtime', ...(canFast ? ['fast' as const] : [])];
  }
  if (!order.length) {
    throw new Error(
      'This browser can neither encode video with WebCodecs nor record a canvas. ' +
        'Try Chrome or Brave on Android.',
    );
  }
  return order;
}

export async function exportClipWithVerification(opts: PipelineOptions): Promise<PipelineResult> {
  const { job, sourceHasAudio, autoRebuild, forceRealtime, onAttempt } = opts;
  const maxAttempts = opts.maxAttempts ?? (autoRebuild ? 3 : 1);
  const engines = await planEngines(job, !!forceRealtime);
  const attempts: ExportAttempt[] = [];

  let lastError = '';

  for (let a = 0; a < Math.min(maxAttempts, Math.max(engines.length, 1)); a++) {
    if (job.signal?.aborted) throw new Error('Stopped');
    const engine = engines[a % engines.length];
    const attemptJob: ExportJob = { ...job, mode: engine };
    onAttempt?.(a + 1, engine, engine === 'fast' ? 'Encoding frame by frame' : 'Recording in real time');

    let result: ExportResult;
    try {
      result = engine === 'fast' ? await exportWebcodecs(attemptJob) : await exportRealtime(attemptJob);
    } catch (e) {
      lastError = (e as Error)?.message || String(e);
      attempts.push({
        blob: new Blob(),
        mime: '',
        engine: engine === 'fast' ? 'webcodecs-mp4' : 'mediarecorder-webm',
        framesDecoded: 0,
        framesWritten: 0,
        framesExpected: 0,
        duration: 0,
        audioWritten: false,
        audioAttempted: false,
        elapsedMs: 0,
        stallsRecovered: 0,
        notes: [`Failed: ${lastError}`],
        verification: blankVerification(engine, lastError, a + 1),
      });
      continue;
    }

    onAttempt?.(a + 1, engine, 'Reading the finished file back');
    let verification: Verification;
    try {
      verification = await verifyExport(result.blob, result, {
        expectedDuration: job.end - job.start,
        fps: job.fps,
        // Only demand sound when the engine that produced this file was able to
        // write it. A browser with no AAC encoder still gets a valid, verified,
        // full-length clip out of the fast engine — just without sound — and the
        // real-time engine is then what supplies audio.
        sourceHasAudio: sourceHasAudio && result.audioWritten !== false,
        signal: job.signal,
      });
    } catch (e) {
      verification = blankVerification(
        result.engine,
        `Could not check the file: ${(e as Error).message}`,
        a + 1,
      );
    }
    verification.attempts = a + 1;
    attempts.push({ ...result, verification });

    if (verification.ok) {
      return { result, verification, attempts, engine: result.engine };
    }

    lastError = verificationSummary(verification);
    onAttempt?.(a + 1, engine, `Check failed — ${lastError}`);
    if (!autoRebuild) break;
  }

  // Every attempt failed. Report it in plain words; the caller decides what to
  // show, but we never pretend it worked.
  const best = attempts
    .filter((x) => x.blob.size > 0)
    .sort((x, y) => Number(y.verification.ok) - Number(x.verification.ok))[0];
  const err = new Error(
    best
      ? `The clip failed its check ${attempts.length} time(s): ${lastError}`
      : `Could not make this clip: ${lastError}`,
  );
  (err as Error & { attempts?: ExportAttempt[]; verification?: Verification }).attempts = attempts;
  if (best) (err as Error & { verification?: Verification }).verification = best.verification;
  throw err;
}

function blankVerification(engine: string, message: string, attempts: number): Verification {
  return {
    ok: false,
    duration: 0,
    expectedDuration: 0,
    audioDuration: 0,
    audioPresent: false,
    framesDecoded: 0,
    framesExpected: 0,
    motionThrough: 0,
    motionSamples: [],
    longestFreeze: 0,
    attempts,
    engine: engine as Verification['engine'],
    messages: [message],
    checkedAt: Date.now(),
  };
}

export { verificationSummary };

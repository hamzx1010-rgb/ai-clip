/** Shared shapes for the export pipeline. */

import type { LayoutMode, Verification } from './types';

export interface ExportJob {
  /** Blob URL of the source video (same-origin, never tainted). */
  srcUrl: string;
  /** The source bytes — needed for the WebCodecs demux path. */
  srcBlob: Blob;
  start: number;
  end: number;
  width: number;
  height: number;
  fps: number;
  layout: LayoutMode;
  faceCenter: { x: number; y: number } | null;
  /** Optional title burned into the picture. */
  burnTitle?: string | null;
  /** 'fast' = WebCodecs offline, 'realtime' = captureStream + MediaRecorder. */
  mode: 'fast' | 'realtime';
  /** Video bitrate in bits/second. */
  videoBitrate?: number;
  audioBitrate?: number;
  signal?: AbortSignal;
  onProgress?: (frac: number, message: string) => void;
}

export interface ExportResult {
  blob: Blob;
  mime: string;
  engine: 'webcodecs-mp4' | 'mediarecorder-webm';
  /** Frames the decoder actually handed us from the source. */
  framesDecoded: number;
  /** Frames we actually wrote into the output. */
  framesWritten: number;
  framesExpected: number;
  duration: number;
  /** True when audio frames were really written into the file. */
  audioWritten: boolean;
  /** True when the source had audio and we tried to carry it over. */
  audioAttempted: boolean;
  /** How long the export took, ms. */
  elapsedMs: number;
  /** Stall events survived during a real-time export. */
  stallsRecovered: number;
  notes: string[];
}

export interface ExportAttempt extends ExportResult {
  verification: Verification;
}

export function framesExpectedFor(duration: number, fps: number): number {
  return Math.max(1, Math.round(duration * fps));
}

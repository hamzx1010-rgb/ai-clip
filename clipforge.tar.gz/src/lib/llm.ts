import type { Segment, Transcript, Word } from './types';
import { useApp } from '../store';
import { encodeWav, decodeToMono } from './audio';

const key = () => useApp.getState().settings.openaiKey.trim();
const baseUrl = () => (useApp.getState().settings.openaiBase || 'https://api.openai.com/v1').replace(/\/$/, '');
export const hasAI = () => !!key();

export async function chatJSON<T = unknown>(system: string, user: string, model?: string): Promise<T> {
  const r = await fetch(baseUrl() + '/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key() },
    body: JSON.stringify({
      model: model || useApp.getState().settings.llmModel || 'gpt-4o-mini',
      response_format: { type: 'json_object' },
      temperature: 0.6,
      messages: [{ role: 'system', content: system }, { role: 'user', content: user }],
    }),
  });
  if (!r.ok) throw new Error('AI request failed: ' + r.status + ' ' + (await r.text()).slice(0, 200));
  const j = await r.json();
  return JSON.parse(j.choices[0].message.content) as T;
}

/** Whisper transcription with word timestamps. Audio is downsampled to 16 kHz mono WAV and chunked (<25 MB). */
export async function transcribeWhisper(file: Blob, language: string, onProgress?: (p: number, label: string) => void, pre?: AudioBuffer): Promise<Transcript> {
  const ab = pre ?? (await decodeToMono(file));
  const CH = 600; // 10-min chunks ≈ 19 MB WAV
  const segments: Segment[] = [];
  const chunks = Math.ceil(ab.duration / CH);
  for (let c = 0; c < chunks; c++) {
    onProgress?.(c / chunks, `Transcribing chunk ${c + 1}/${chunks} with Whisper`);
    const off = c * CH;
    const wav = encodeWav(ab, off, Math.min(ab.duration, off + CH));
    const fd = new FormData();
    fd.append('file', wav, 'audio.wav');
    fd.append('model', 'whisper-1');
    fd.append('response_format', 'verbose_json');
    fd.append('timestamp_granularities[]', 'word');
    fd.append('timestamp_granularities[]', 'segment');
    if (language && language !== 'auto') fd.append('language', language);
    const r = await fetch(baseUrl() + '/audio/transcriptions', { method: 'POST', headers: { Authorization: 'Bearer ' + key() }, body: fd });
    if (!r.ok) throw new Error('Whisper failed: ' + r.status + ' ' + (await r.text()).slice(0, 200));
    const j = await r.json();
    const words: Word[] = (j.words || []).map((w: { word: string; start: number; end: number }) => ({ w: w.word.trim(), s: w.start + off, e: w.end + off }));
    // attach punctuation from segment text to word list
    for (const s of j.segments || []) {
      const segWords = words.filter((w) => w.s >= s.start + off - 0.05 && w.e <= s.end + off + 0.05);
      const tokens = String(s.text).trim().split(/\s+/);
      if (tokens.length === segWords.length) segWords.forEach((w, i) => (w.w = tokens[i]));
      segments.push({ start: s.start + off, end: s.end + off, text: String(s.text).trim(), words: segWords.length ? segWords : spread(String(s.text).trim(), s.start + off, s.end + off) });
    }
  }
  onProgress?.(1, 'Transcript ready');
  return { segments, source: 'whisper', language };
}

export function spread(text: string, start: number, end: number): Word[] {
  const ws = text.split(/\s+/).filter(Boolean);
  const tot = ws.reduce((a, w) => a + w.length + 2, 0);
  let t = start;
  return ws.map((w) => { const d = ((w.length + 2) / tot) * (end - start); const o = { w, s: t, e: t + d }; t += d; return o; });
}

export function parseSubtitles(src: string): Transcript {
  const blocks = src.replace(/\r/g, '').split(/\n\n+/);
  const segs: Segment[] = [];
  const toS = (x: string) => { const m = x.trim().replace(',', '.').split(':').map(Number); return m.length === 3 ? m[0] * 3600 + m[1] * 60 + m[2] : m[0] * 60 + m[1]; };
  for (const b of blocks) {
    const lines = b.split('\n').filter((l) => l.trim() && l.trim() !== 'WEBVTT');
    const ti = lines.findIndex((l) => l.includes('-->'));
    if (ti < 0) continue;
    const [a, z] = lines[ti].split('-->');
    const text = lines.slice(ti + 1).join(' ').replace(/<[^>]+>/g, '').trim();
    if (!text) continue;
    let speaker: string | undefined;
    const m = text.match(/^([A-Z][\w ]{0,20}):\s/);
    const body = m ? text.slice(m[0].length) : text;
    if (m) speaker = m[1];
    const s = toS(a), e = toS(z.split(' ')[1] ?? z);
    segs.push({ start: s, end: e, text: body, speaker, words: spread(body, s, e) });
  }
  return { segments: segs, source: 'srt' };
}

export async function loadSampleTranscript(): Promise<Transcript> {
  const j = await (await fetch(import.meta.env.BASE_URL + 'sample/sample.json')).json();
  return {
    source: 'sample',
    language: 'en',
    segments: j.segments.map((s: { speaker: string; start: number; end: number; text: string; words: { w: string; s: number; e: number }[] }) => ({ speaker: s.speaker, start: s.start, end: s.end, text: s.text, words: s.words })),
  };
}

export async function ttsOpenAI(text: string, voice = 'alloy'): Promise<Blob> {
  const r = await fetch(baseUrl() + '/audio/speech', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key() },
    body: JSON.stringify({ model: 'tts-1', voice, input: text, response_format: 'mp3' }),
  });
  if (!r.ok) throw new Error('TTS failed: ' + r.status);
  return await r.blob();
}

export async function generateImageAI(prompt: string, size = '1024x1792'): Promise<Blob> {
  const r = await fetch(baseUrl() + '/images/generations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key() },
    body: JSON.stringify({ model: 'dall-e-3', prompt, size, n: 1, response_format: 'b64_json' }),
  });
  if (!r.ok) throw new Error('Image generation failed: ' + r.status);
  const j = await r.json();
  const b = atob(j.data[0].b64_json);
  const arr = new Uint8Array(b.length);
  for (let i = 0; i < b.length; i++) arr[i] = b.charCodeAt(i);
  return new Blob([arr], { type: 'image/png' });
}

export type ScriptScene = { heading: string; voiceover: string; onScreen: string; visual: string; seconds: number };
export async function writeScript(topic: string, platform: string, tone: string, seconds: number): Promise<{ title: string; hook: string; scenes: ScriptScene[]; cta: string; hashtags: string[] }> {
  if (hasAI()) {
    return chatJSON(
      'You are a viral short-form video scriptwriter. Reply with JSON: {title, hook, scenes:[{heading, voiceover, onScreen, visual, seconds}], cta, hashtags:[]}. The hook must land in under 2 seconds. On-screen text max 6 words.',
      `Topic: ${topic}\nPlatform: ${platform}\nTone: ${tone}\nTarget length: ${seconds}s`,
    );
  }
  // offline template writer
  const T = topic.trim() || 'your topic';
  const n = Math.max(3, Math.min(6, Math.round(seconds / 8)));
  const beats = [
    ['The problem', `Most people get ${T} completely wrong.`, 'You\'re doing it wrong', 'Close-up, direct eye contact'],
    ['The myth', `They think it takes years. It doesn't.`, 'The biggest myth', 'B-roll: calendar pages flying'],
    ['Step 1', `First, start with the one thing that matters most about ${T}.`, 'Step 1 👇', 'Screen recording / demo'],
    ['Step 2', 'Second, do it every single day for thirty days.', 'Step 2: consistency', 'Time-lapse B-roll'],
    ['Proof', 'I tried this and the results were insane.', 'The results 🤯', 'Before / after split screen'],
    ['Payoff', `That's the real secret to ${T}.`, 'The secret', 'Slow push-in on face'],
  ];
  const scenes = beats.slice(0, n).map(([h, vo, os, vis]) => ({ heading: h, voiceover: vo, onScreen: os, visual: vis, seconds: Math.round(seconds / n) }));
  return {
    title: `The truth about ${T} nobody tells you`,
    hook: `Stop scrolling — you're doing ${T} wrong.`,
    scenes,
    cta: 'Follow for part 2 and comment "MORE" if you want the full guide.',
    hashtags: ['#' + T.replace(/\s+/g, '').toLowerCase(), '#fyp', '#learnontiktok', '#tips'],
  };
}

export async function refineClipsWithLLM(clips: { id: string; text: string }[]): Promise<Record<string, { score: number; title: string; hook: string; reason: string }>> {
  const { aiJSON } = await import('./director/ai');
  const payload = clips.slice(0, 16).map((c) => ({ id: c.id, text: c.text.slice(0, 700) }));
  const r = await aiJSON<{ clips: { id: string; score: number; title: string; hook: string; reason: string }[] }>(
    `You are a YouTube Shorts retention editor. Shorts are ranked by: % of viewers who choose to watch instead of swiping away in the first 1-2 seconds, average % viewed, and replays.
For each clip transcript return:
- score 0-100: how likely it holds viewers to the end (strong first line, specific payoff, no dead setup, self-contained without earlier context).
- hook: on-screen text shown during the first 3 seconds, max 8 words, a curiosity gap that teases THIS clip's payoff without revealing it. It must be true to the transcript: no fake claims, no "you won't believe", at most one emoji.
- title: under 60 chars, specific, and it makes people want to watch.
- reason: one short sentence.
Reply JSON {"clips":[{"id","score","hook","title","reason"}]}`,
    JSON.stringify(payload), undefined, 40000,
  );
  const out: Record<string, { score: number; title: string; hook: string; reason: string }> = {};
  for (const c of r.clips || []) if (c && c.id && typeof c.hook === 'string' && c.hook.length <= 70) out[c.id] = { ...c, score: Math.max(0, Math.min(100, Number(c.score) || 0)) };
  return out;
}

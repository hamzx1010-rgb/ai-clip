/**
 * Minimal typings for mp4box.js (the package ships without any).
 * Only the parts ClipForge uses are declared.
 */
declare module 'mp4box' {
  export interface MP4MediaData {
    timescale: number;
    duration: number;
    nb_samples: number;
    segment_info?: unknown;
  }

  export interface MP4VideoTrack extends MP4MediaData {
    id: number;
    video: { width: number; height: number };
    avcDecoderConfigRecord?: unknown;
    codec?: string;
    hvcC?: unknown;
    avcC?: unknown;
  }

  export interface MP4AudioTrack extends MP4MediaData {
    id: number;
    audio: { sample_rate: number; channel_count: number; sample_size: number };
    esds?: unknown;
    codec?: string;
  }

  export interface MP4Track {
    id: number;
    timescale: number;
    duration: number;
    nb_samples: number;
    video?: { width: number; height: number };
    audio?: { sample_rate: number; channel_count: number; sample_size: number };
    codec?: string;
    avcC?: unknown;
    hvcC?: unknown;
    avcDecoderConfigRecord?: unknown;
    esds?: unknown;
    type?: string;
  }

  export interface MP4Info {
    duration: number;
    timescale: number;
    isFragmented: boolean;
    isProgressive: boolean;
    hasIOD: boolean;
    brands: string[];
    created: Date;
    modified: Date;
    tracks: MP4Track[];
    videoTracks?: MP4VideoTrack[];
    audioTracks?: MP4AudioTrack[];
  }

  export interface MP4Sample {
    number: number;
    track_id: number;
    timescale: number;
    description_index: number;
    is_sync: boolean;
    is_leading?: number;
    depends_on?: number;
    duration: number;
    cts: number;
    dts: number;
    data: Uint8Array;
    size: number;
    offset?: number;
    has_redundancy?: number;
    is_depended_on?: number;
    degradation_priority?: number;
  }

  export interface Trak {
    mdia?: { mdhd?: { timescale?: number } };
    samples?: MP4Sample[];
    nb_samples?: number;
  }

  export interface ISOFile {
    fileStart?: number;
    moov?: { traks?: Trak[] };
    getTrackById(id: number): MP4Track | null;
    getTrackSamplesInfo(track_id: number): MP4Sample[];
    getSample(track_id: number, number: number): MP4Sample | null;
    releaseUsedSamples(track_id: number, sampleNum: number): void;
    setExtractionOptions(track_id: number, user?: unknown, options?: { nbSamples?: number }): void;
    start(): void;
    stop(): void;
    flush(): void;
    appendBuffer(data: ArrayBuffer & { fileStart?: number }): number;
    onReady?: (info: MP4Info) => void;
    onSamples?: (id: number, user: unknown, samples: MP4Sample[]) => void;
    onError?: (e: unknown) => void;
    onMissingMoov?: () => void;

    /* ---- writing ---- */
    addTrack(options: {
      timescale: number;
      media_duration?: number;
      samplerate?: number;
      channel_count?: number;
      samples_description?: unknown;
      hvcC?: unknown;
      avcDecoderConfigRecord?: unknown;
      width?: number;
      height?: number;
      avc_inband?: boolean;
      type?: string;
      description?: string;
      description_boxes?: unknown;
      default_sample_description_index_id?: number;
    }): number;
    addSample(
      track_id: number,
      data: Uint8Array | ArrayBuffer,
      sample: { dts?: number; cts?: number; duration?: number; is_sync?: boolean; description_index?: number },
    ): void;
    getBuffer(): ArrayBuffer;
    save(name: string): void;
    onMoovStart?: () => void;
    onProgress?: (frac: number) => void;
  }

  export function createFile(): ISOFile;
  export function Log(): unknown;
  const MP4Box: {
    createFile(): ISOFile;
    Log: { debug?: boolean; info?: boolean; error?: boolean; warn?: boolean };
  };
  export default MP4Box;
}

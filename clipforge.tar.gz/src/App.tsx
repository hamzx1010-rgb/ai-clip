import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { StoreContext, DEFAULT_UI, type Route, type UiSettings } from './store';
import TopBar from './components/TopBar';
import ClipsPage from './pages/ClipsPage';
import HistoryPage from './pages/HistoryPage';
import SettingsPage from './pages/SettingsPage';
import DirectorPage from './pages/DirectorPage';
import StreamsPage from './pages/StreamsPage';
import EditorPage from './pages/EditorPage';
import type { Clip, RunMeta } from './lib/types';
import type { VideoSource } from './lib/source';
import * as db from './lib/db';

const LS_KEY = 'clipforge.ui.v2';

function loadUi(): UiSettings {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return DEFAULT_UI;
    const parsed = JSON.parse(raw) as Partial<UiSettings>;
    return {
      ...DEFAULT_UI,
      ...parsed,
      exportSettings: { ...DEFAULT_UI.exportSettings, ...(parsed.exportSettings ?? {}) },
      ai: { ...DEFAULT_UI.ai, ...(parsed.ai ?? {}) },
    };
  } catch {
    return DEFAULT_UI;
  }
}

export default function App() {
  const [route, setRoute] = useState<Route>('clips');
  const [run, setRun] = useState<RunMeta | null>(null);
  const [clips, setClipsState] = useState<Clip[]>([]);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [source, setSource] = useState<VideoSource | null>(null);
  const [sourceHasAudio, setSourceHasAudio] = useState(true);
  const [ui, setUiState] = useState<UiSettings>(loadUi);
  const abortRef = useRef<AbortController | null>(null);

  /* ---------- persist settings (never the API key in plain sight for long) -- */
  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(ui));
    } catch {
      /* ignore */
    }
  }, [ui]);

  const setUi = useCallback((patch: Partial<UiSettings>) => {
    setUiState((prev) => ({ ...prev, ...patch }));
  }, []);

  const pushLog = useCallback((line: string) => {
    setLogs((prev) => {
      const next = prev.length > 400 ? prev.slice(prev.length - 400) : prev.slice();
      next.push(line);
      return next;
    });
  }, []);

  const clearLogs = useCallback(() => setLogs([]), []);

  const setClips = useCallback((c: Clip[]) => setClipsState(c), []);

  const updateClip = useCallback((c: Clip) => {
    setClipsState((prev) => {
      const i = prev.findIndex((x) => x.id === c.id);
      if (i < 0) return [...prev, c];
      const next = prev.slice();
      // keep live object URLs from the previous record
      next[i] = { ...next[i], ...c, url: c.url ?? next[i].url ?? null, thumbUrl: c.thumbUrl ?? next[i].thumbUrl ?? null };
      return next;
    });
  }, []);

  /* ---------- deep link: #/history etc. ---------- */
  useEffect(() => {
    const apply = () => {
      const h = window.location.hash.replace(/^#\/?/, '');
      const known: Route[] = ['clips', 'results', 'history', 'settings', 'director', 'streams', 'editor'];
      if (known.includes(h as Route)) setRoute(h as Route);
    };
    apply();
    window.addEventListener('hashchange', apply);
    return () => window.removeEventListener('hashchange', apply);
  }, []);

  const go = useCallback((r: Route) => {
    setRoute(r);
    try {
      window.location.hash = `/${r}`;
      window.scrollTo({ top: 0 });
    } catch {
      /* ignore */
    }
  }, []);

  /* ---------- restore the last unfinished run on boot ---------- */
  useEffect(() => {
    (async () => {
      try {
        const runs = await db.listRuns();
        if (!runs.length) return;
        const latest = runs[0];
        const stored = await db.listClips(latest.id);
        if (stored.length) {
          setRun(latest);
          setClipsState(stored.map((c) => ({ ...c, url: null, thumbUrl: null })));
        }
      } catch {
        /* ignore */
      }
    })();
  }, []);

  const store = useMemo(
    () => ({
      route,
      go,
      run,
      clips,
      setClips,
      updateClip,
      busy,
      setBusy,
      status,
      setStatus,
      progress,
      setProgress,
      logs,
      pushLog,
      clearLogs,
      error,
      setError,
      source,
      setSource,
      sourceHasAudio,
      setSourceHasAudio,
      ui,
      setUi,
      abortRef,
      setRun,
    }),
    [
      route, go, run, clips, setClips, updateClip, busy, status, progress, logs,
      pushLog, clearLogs, error, source, sourceHasAudio, ui, setUi,
    ],
  ) as never;

  return (
    <StoreContext.Provider value={store}>
      <TopBar />
      <main id="main">
        {route === 'clips' && <ClipsPage />}
        {route === 'results' && <EditorPage mode="results" />}
        {route === 'history' && <HistoryPage />}
        {route === 'settings' && <SettingsPage />}
        {route === 'director' && <DirectorPage />}
        {route === 'streams' && <StreamsPage />}
        {route === 'editor' && <EditorPage mode="editor" />}
      </main>
    </StoreContext.Provider>
  );
}

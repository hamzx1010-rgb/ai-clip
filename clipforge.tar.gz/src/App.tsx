import { isTouchDevice, useIsPhone } from './lib/mobile';
import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Clapperboard, Film, Home, Radio, Search, Settings as Cog, Wand2, Command } from 'lucide-react';
import { useApp, hashToRoute, routeToHash, TAB_ROUTES, type Route } from './store';
import { useBusy } from './lib/busy';
import { autoClean } from './lib/sessionStore';
import { ExternalLink } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import ClipVideo from './pages/ClipVideo';
import ClipStream from './pages/ClipStream';
import Results from './pages/Results';
import Editor from './pages/editor/Editor';
import Director from './pages/Director';
import SettingsPage from './pages/Settings';
import { ensureFonts } from './lib/captions';

export function Logo({ onClick }: { onClick?: () => void }) {
  return (
    <div className="logo" onClick={onClick}>
      <div className="logo-mark"><Clapperboard size={17} color="#fff" /></div>
      <span>Clip<span className="grad-text">Forge</span></span>
    </div>
  );
}

const NAV: { r: Route['name']; label: string; icon: ReactNode }[] = [
  { r: 'dashboard', label: 'Dashboard', icon: <Home size={18} /> },
  { r: 'clip-video', label: 'Clip a Video', icon: <Film size={18} /> },
  { r: 'clip-stream', label: 'Clip a Stream', icon: <Radio size={18} /> },
  { r: 'director', label: 'AI Director', icon: <Clapperboard size={18} /> },
  { r: 'editor', label: 'Editor', icon: <Wand2 size={18} /> },
  { r: 'settings', label: 'Settings', icon: <Cog size={18} /> },
];


const BOTNAV: { r: Route['name']; short: string; icon: ReactNode }[] = [
  { r: 'dashboard', short: 'Home', icon: <Home size={21} /> },
  { r: 'clip-video', short: 'Clip', icon: <Film size={21} /> },
  { r: 'clip-stream', short: 'Stream', icon: <Radio size={21} /> },
  { r: 'director', short: 'Director', icon: <Clapperboard size={21} /> },
  { r: 'settings', short: 'Settings', icon: <Cog size={21} /> },
];

export default function App() {
  const phoneMode = useIsPhone() || isTouchDevice();
  const { route, go, open, toasts, dismiss, settings, paletteOpen, setPalette } = useApp();
  const busy = useBusy();
  const [visited, setVisited] = useState<Set<Route['name']>>(() => new Set([route.name]));
  useEffect(() => { setVisited((v) => (v.has(route.name) ? v : new Set(v).add(route.name))); }, [route.name]);
  useEffect(() => {
    // back/forward buttons and links move between pages inside the app
    const h = () => useApp.setState({ route: hashToRoute(location.hash) });
    window.addEventListener('popstate', h); window.addEventListener('hashchange', h);
    if (!location.hash) history.replaceState(null, '', location.pathname + location.search + routeToHash(useApp.getState().route));
    // settings changed in another tab
    const st = (e: StorageEvent) => { if (e.key === 'clipforge-app') useApp.persist.rehydrate(); };
    window.addEventListener('storage', st);
    autoClean(useApp.getState().settings.autoDeleteDays).catch(() => {});
    return () => { window.removeEventListener('popstate', h); window.removeEventListener('hashchange', h); window.removeEventListener('storage', st); };
  }, []);
  useEffect(() => {
    ensureFonts();
    // deep link: https://your-app.onrender.com/?url=<direct video link>
    const q = new URLSearchParams(location.search);
    const link = q.get('url') || q.get('video');
    if (link) {
      useApp.getState().setPendingUrl(link);
      history.replaceState(null, '', location.pathname + '#/clip-video');
      go({ name: 'clip-video' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle('light', settings.theme === 'light');
  }, [settings.theme]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPalette(!useApp.getState().paletteOpen); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setPalette]);

  // results & editor are per-item pages; the tool pages are kept alive (hidden) once visited
  let page: ReactNode = null;
  if (route.name === 'results') page = <Results key={route.sessionId} sessionId={route.sessionId} />;
  const keep = (name: Route['name'], el: ReactNode) => (visited.has(name) || route.name === name) && (
    <div key={name} style={route.name === name || (name === 'clip-video' && (route.name === 'landing' || route.name === 'publish')) ? undefined : { display: 'none' }}>{el}</div>
  );
  const bare = route.name === 'editor';
  const activeTool = route.name === 'results' ? (useApp.getState().sessions.find((x) => x.id === route.sessionId)?.mode === 'stream' ? 'clip-stream' : 'clip-video') : route.name;
  const busyOf = (r: Route['name']) => busy.some((k) => k.startsWith(r));
  const inOwnTab = (r: Route['name']) => window.name === 'cf-' + r;
  return (
    <>
      {bare && <Editor key={route.projectId || 'new'} projectId={route.projectId} />}
      <div className="shell" style={bare ? { display: 'none' } : undefined}>
        <aside className="sidebar">
          <Logo onClick={() => go({ name: 'dashboard' })} />
          {NAV.map((n) => {
            const newTab = !phoneMode && settings.newTabs !== false && TAB_ROUTES.includes(n.r) && !inOwnTab(n.r);
            return (
              <div key={n.r} className={'nav-item' + (activeTool === n.r ? ' on' : '')} title={newTab ? 'Opens in its own tab' : undefined}
                onClick={() => (n.r === 'editor' ? open({ name: 'editor' }) : open({ name: n.r } as Route))}>
                {n.icon}<span className="grow">{n.label}</span>
                {busyOf(n.r) ? <span className="spin" style={{ width: 12, height: 12 }} title="Working…" /> : newTab ? <ExternalLink size={12} className="dim" /> : null}
              </div>
            );
          })}
          <div className="grow" />
          <div className="nav-item" onClick={() => setPalette(true)}><Search size={18} /><span>Search <span className="kbd">Ctrl K</span></span></div>
        </aside>
        <main className="main">
          {keep('dashboard', <Dashboard />)}
          {keep('clip-video', <ClipVideo />)}
          {keep('clip-stream', <ClipStream />)}
          {keep('director', <Director />)}
          {keep('settings', <SettingsPage />)}
          {page}
        </main>
        <nav className="botnav">
          {BOTNAV.map((n) => (
            <button key={n.r} className={'botnav-item' + (activeTool === n.r ? ' on' : '')} onClick={() => open({ name: n.r } as Route)}>
              <span className="botnav-ic">{n.icon}{busyOf(n.r) && <span className="botnav-dot" />}</span>
              <span>{n.short}</span>
            </button>
          ))}
        </nav>
      </div>
      {paletteOpen && <Palette onClose={() => setPalette(false)} />}
      <div className="toasts">
        {toasts.map((t) => <div key={t.id} className={'toast ' + t.kind} onClick={() => dismiss(t.id)}>{t.text}</div>)}
      </div>
    </>
  );
}

function Palette({ onClose }: { onClose: () => void }) {
  const { go, open, sessions, setSettings, settings } = useApp();
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(0);
  const items = useMemo(() => {
    const base: { label: string; hint: string; run: () => void }[] = [
      { label: 'Go to Dashboard', hint: 'Navigate', run: () => go({ name: 'dashboard' }) },
      { label: 'Clip a Video — upload & auto-clip', hint: 'Mode 1', run: () => open({ name: 'clip-video' }) },
      { label: 'Clip a Stream — VOD, chat, live monitor', hint: 'Mode 2', run: () => open({ name: 'clip-stream' }) },
      { label: 'AI Director — describe a video, AI makes it', hint: 'Mode 3', run: () => open({ name: 'director' }) },
      { label: 'Open the editor', hint: 'Editor', run: () => open({ name: 'editor' }) },
      { label: 'AI settings — OpenAI key for Whisper / GPT / TTS', hint: 'Settings', run: () => go({ name: 'settings' }) },
      { label: `Switch to ${settings.theme === 'dark' ? 'light' : 'dark'} mode`, hint: 'Theme', run: () => setSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' }) },
    ];
    for (const s of sessions) base.push({ label: `Open clips: ${s.name}`, hint: `${s.clips.length} clips`, run: () => go({ name: 'results', sessionId: s.id }) });
    const f = q.toLowerCase();
    return base.filter((b) => b.label.toLowerCase().includes(f) || b.hint.toLowerCase().includes(f));
  }, [q, sessions, go, open, setSettings, settings.theme]);
  return (
    <div className="modal-back" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="palette">
        <div className="row" style={{ paddingLeft: 18 }}>
          <Command size={18} className="dim" />
          <input autoFocus placeholder="Search any feature, page or project…" value={q}
            onChange={(e) => { setQ(e.target.value); setSel(0); }}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') { e.preventDefault(); setSel((s) => Math.min(items.length - 1, s + 1)); }
              if (e.key === 'ArrowUp') { e.preventDefault(); setSel((s) => Math.max(0, s - 1)); }
              if (e.key === 'Enter' && items[sel]) { items[sel].run(); onClose(); }
              if (e.key === 'Escape') onClose();
            }} />
        </div>
        <div style={{ maxHeight: 380, overflow: 'auto', padding: '6px 0' }}>
          {items.map((it, i) => (
            <div key={it.label} className={'item' + (i === sel ? ' sel' : '')} onMouseEnter={() => setSel(i)} onClick={() => { it.run(); onClose(); }}>
              <span className="grow">{it.label}</span><span className="badge">{it.hint}</span>
            </div>
          ))}
          {!items.length && <div className="item muted">No results</div>}
        </div>
      </div>
    </div>
  );
}

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { CalendarDays, Clapperboard, Film, Home, Radio, Search, Settings as Cog, Wand2, Sparkles, Command } from 'lucide-react';
import { useApp, type Route } from './store';
import Landing from './pages/Landing';
import Dashboard from './pages/Dashboard';
import ClipVideo from './pages/ClipVideo';
import ClipStream from './pages/ClipStream';
import Results from './pages/Results';
import Editor from './pages/editor/Editor';
import Publish from './pages/Publish';
import SettingsPage from './pages/Settings';
import { ensureFonts } from './lib/captions';

export function Logo({ onClick }: { onClick?: () => void }) {
  return (
    <div className="logo" onClick={onClick}>
      <div className="logo-mark"><Clapperboard size={17} color="#fff" /></div>
      <span>Clip<span className="grad-text">Forge</span></span>
    </div>
  );
}

const NAV: { r: Route['name']; label: string; icon: ReactNode }[] = [
  { r: 'dashboard', label: 'Dashboard', icon: <Home size={18} /> },
  { r: 'clip-video', label: 'Clip a Video', icon: <Film size={18} /> },
  { r: 'clip-stream', label: 'Clip a Stream', icon: <Radio size={18} /> },
  { r: 'editor', label: 'Create from Scratch', icon: <Wand2 size={18} /> },
  { r: 'publish', label: 'Publish & Analytics', icon: <CalendarDays size={18} /> },
  { r: 'settings', label: 'Brand Kit & Settings', icon: <Cog size={18} /> },
];

export default function App() {
  const { route, go, toasts, dismiss, settings, paletteOpen, setPalette, credits } = useApp();
  useEffect(() => {
    ensureFonts();
    // deep link: https://your-app.onrender.com/?url=<direct video link>
    const q = new URLSearchParams(location.search);
    const link = q.get('url') || q.get('video');
    if (link) {
      useApp.getState().setPendingUrl(link);
      go({ name: 'clip-video' });
      history.replaceState(null, '', location.pathname);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle('light', settings.theme === 'light');
  }, [settings.theme]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPalette(!useApp.getState().paletteOpen); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [setPalette]);

  let page: ReactNode;
  switch (route.name) {
    case 'landing': page = <Landing />; break;
    case 'dashboard': page = <Dashboard />; break;
    case 'clip-video': page = <ClipVideo />; break;
    case 'clip-stream': page = <ClipStream />; break;
    case 'results': page = <Results key={route.sessionId} sessionId={route.sessionId} />; break;
    case 'editor': page = <Editor key={route.projectId || 'new'} projectId={route.projectId} />; break;
    case 'publish': page = <Publish />; break;
    case 'settings': page = <SettingsPage />; break;
  }
  const bare = route.name === 'landing' || route.name === 'editor';
  return (
    <>
      {bare ? page : (
        <div className="shell">
          <aside className="sidebar">
            <Logo onClick={() => go({ name: 'landing' })} />
            {NAV.map((n) => (
              <div key={n.r} className={'nav-item' + (route.name === n.r || (route.name === 'results' && n.r === (useApp.getState().sessions.find((x) => x.id === route.sessionId)?.mode === 'stream' ? 'clip-stream' : 'clip-video')) ? ' on' : '')} onClick={() => go({ name: n.r } as Route)}>
                {n.icon}<span>{n.label}</span>
              </div>
            ))}
            <div className="grow" />
            <div className="nav-item" onClick={() => setPalette(true)}><Search size={18} /><span>Search <span className="kbd">Ctrl K</span></span></div>
            <div className="card tight hide-sm" style={{ marginTop: 8 }}>
              <div className="row between small"><span className="muted">AI credits</span><b>{credits}</b></div>
              <div className="bar mt8" style={{ height: 6 }}><div style={{ width: `${Math.min(100, credits / 5)}%` }} /></div>
              <div className="row between small mt8"><span className="badge brand"><Sparkles size={11} /> Pro trial</span><span className="dim tiny">{settings.openaiKey ? 'AI key ✓' : 'offline AI'}</span></div>
            </div>
          </aside>
          <main className="main">{page}</main>
        </div>
      )}
      {paletteOpen && <Palette onClose={() => setPalette(false)} />}
      <div className="toasts">
        {toasts.map((t) => <div key={t.id} className={'toast ' + t.kind} onClick={() => dismiss(t.id)}>{t.text}</div>)}
      </div>
    </>
  );
}

function Palette({ onClose }: { onClose: () => void }) {
  const { go, sessions, setSettings, settings } = useApp();
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(0);
  const items = useMemo(() => {
    const base: { label: string; hint: string; run: () => void }[] = [
      { label: 'Go to Dashboard', hint: 'Navigate', run: () => go({ name: 'dashboard' }) },
      { label: 'Clip a Video — upload & auto-clip', hint: 'Mode 1', run: () => go({ name: 'clip-video' }) },
      { label: 'Clip a Stream — VOD, chat, live monitor', hint: 'Mode 2', run: () => go({ name: 'clip-stream' }) },
      { label: 'Create from Scratch — open editor', hint: 'Mode 3', run: () => go({ name: 'editor' }) },
      { label: 'Scheduling calendar', hint: 'Publish', run: () => go({ name: 'publish' }) },
      { label: 'Analytics dashboard', hint: 'Publish', run: () => go({ name: 'publish' }) },
      { label: 'Brand kit — logo, handle, colors', hint: 'Settings', run: () => go({ name: 'settings' }) },
      { label: 'AI settings — OpenAI key for Whisper / GPT / TTS', hint: 'Settings', run: () => go({ name: 'settings' }) },
      { label: `Switch to ${settings.theme === 'dark' ? 'light' : 'dark'} mode`, hint: 'Theme', run: () => setSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' }) },
      { label: 'Pricing', hint: 'Landing', run: () => { go({ name: 'landing' }); setTimeout(() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' }), 100); } },
      { label: 'Landing page', hint: 'Navigate', run: () => go({ name: 'landing' }) },
    ];
    for (const s of sessions) base.push({ label: `Open clips: ${s.name}`, hint: `${s.clips.length} clips`, run: () => go({ name: 'results', sessionId: s.id }) });
    const f = q.toLowerCase();
    return base.filter((b) => b.label.toLowerCase().includes(f) || b.hint.toLowerCase().includes(f));
  }, [q, sessions, go, setSettings, settings.theme]);
  return (
    <div className="modal-back" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="palette">
        <div className="row" style={{ paddingLeft: 18 }}>
          <Command size={18} className="dim" />
          <input autoFocus placeholder="Search any feature, page or project…" value={q}
            onChange={(e) => { setQ(e.target.value); setSel(0); }}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') { e.preventDefault(); setSel((s) => Math.min(items.length - 1, s + 1)); }
              if (e.key === 'ArrowUp') { e.preventDefault(); setSel((s) => Math.max(0, s - 1)); }
              if (e.key === 'Enter' && items[sel]) { items[sel].run(); onClose(); }
              if (e.key === 'Escape') onClose();
            }} />
        </div>
        <div style={{ maxHeight: 380, overflow: 'auto', padding: '6px 0' }}>
          {items.map((it, i) => (
            <div key={it.label} className={'item' + (i === sel ? ' sel' : '')} onMouseEnter={() => setSel(i)} onClick={() => { it.run(); onClose(); }}>
              <span className="grow">{it.label}</span><span className="badge">{it.hint}</span>
            </div>
          ))}
          {!items.length && <div className="item muted">No results</div>}
        </div>
      </div>
    </div>
  );
}

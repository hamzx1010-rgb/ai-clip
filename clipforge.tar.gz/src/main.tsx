import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';
import App from './App';
import { registerSW } from './lib/mobile';

registerSW();

if (location.search.includes('cfdebug')) import('./pages/editor/bench').then((m) => Object.assign(window, { __cfBench: m }));

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
